# <DBM Mod> Raids (DF)

## [10.1.27](https://github.com/DeadlyBossMods/DBM-Retail/tree/10.1.27) (2023-09-14)
[Full Changelog](https://github.com/DeadlyBossMods/DBM-Retail/compare/10.1.26...10.1.27) [Previous Releases](https://github.com/DeadlyBossMods/DBM-Retail/releases)

- prep new tag for retail  
- Fix some missed spellids  
- Make all 4 ofthis weeks test mods public now that it's test day  
- Update DBM-Raids-Dragonflight.toc (#932)  
- Update DBM-Raids-Dragonflight.toc (#931)  
    Add zhTW  
- Update koKR (Retail) (#930)  
- Update koKR (#268)  
- Populate a few IDs  
- stub in world boss module for 10.2  
- map data update  
- minor fixes  
- missed one  
- Fixed a bug where old mod checks were not checking the reworked modules  
- update banned mods  
- Created new unified DBM raids module that contains both the 10.2 raid, and the 10.0 raid moved into it. 10.1 raid will be left alone until 10.2 ships to avoid messing with user settings mid tier.  
    This work preps DBM for PTR mod drycodes and PTR testing  
- Add 10.2 raid instance info  
- Support S3 M+ Dungeon pool in affixes module  
- bump alpha  
