# BugSack

## [v10.1.7](https://github.com/funkydude/BugSack/tree/v10.1.7) (2023-09-11)
[Full Changelog](https://github.com/funkydude/BugSack/compare/v10.1.6...v10.1.7) [Previous Releases](https://github.com/funkydude/BugSack/releases)

- Update ruRU (#95)  
