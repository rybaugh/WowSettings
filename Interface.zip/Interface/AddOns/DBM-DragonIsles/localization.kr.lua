if GetLocale() ~= "koKR" then return end
local L

-----------------------
-- Strunraan, The Sky's Misery --
-----------------------
--L= DBM:GetModLocalization(2515)

--L:SetMiscLocalization({
--	Pull	= ""
--})

-----------------------
-- Liskanoth --
-----------------------
--L= DBM:GetModLocalization(2518)

--L:SetMiscLocalization({
--	Pull	= ""
--})

-----------------------
-- Bazual, The Dreaded Flame --
-----------------------
--L= DBM:GetModLocalization(2517)

--L:SetMiscLocalization({
--	Pull	= ""
--})

-----------------------
-- Basrikron, The Shale Wing --
-----------------------
--L= DBM:GetModLocalization(2506)

--L:SetMiscLocalization({
--	Pull	= ""
--})

-----------------------
-- Aurostor, The Hibernator --
-----------------------
--L= DBM:GetModLocalization(2562)

--L:SetMiscLocalization({
--	Pull	= ""
--})
