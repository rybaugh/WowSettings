if GetLocale() ~= "ruRU" then return end
local L

-----------------------
-- Струнраан Бедствие Небес --
-----------------------
--L= DBM:GetModLocalization(2515)

--L:SetMiscLocalization({
--	Pull	= ""
--})

-----------------------
-- Лисканот Крах Мироздания --
-----------------------
--L= DBM:GetModLocalization(2518)

--L:SetMiscLocalization({
--	Pull	= ""
--})

-----------------------
-- Базуал Чудовищное Пламя --
-----------------------
--L= DBM:GetModLocalization(2517)

--L:SetMiscLocalization({
--	Pull	= ""
--})

-----------------------
-- Базрикрон Каменное Крыло --
-----------------------
--L= DBM:GetModLocalization(2506)

--L:SetMiscLocalization({
--	Pull	= ""
--})

-----------------------
-- Первые Старейшины --
-----------------------
--L= DBM:GetModLocalization(2531)

--L:SetMiscLocalization({
--	Pull	= ""
--})
