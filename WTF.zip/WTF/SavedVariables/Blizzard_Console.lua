
Blizzard_Console_SavedVars = {
	["version"] = 3,
	["messageHistory"] = {
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [1]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [2]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [3]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [4]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [5]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [6]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [7]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [8]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [9]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [10]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [11]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [12]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [13]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [14]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [15]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [16]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [17]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [18]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [19]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [20]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [21]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [22]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [23]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [24]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [25]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [26]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [27]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [28]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [29]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [30]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [31]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [32]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [33]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [34]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [35]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [36]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [37]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [38]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [39]
		{
			"Only one lightning storm at a time is supported (including storms from weather).", -- [1]
			0, -- [2]
		}, -- [40]
		{
			"Changing lightning storm from previous lightning ID:0 to new lightning ID: 119.", -- [1]
			0, -- [2]
		}, -- [41]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [42]
		{
			"End lightning storm.", -- [1]
			0, -- [2]
		}, -- [43]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [44]
		{
			"Only one lightning storm at a time is supported (including storms from weather).", -- [1]
			0, -- [2]
		}, -- [45]
		{
			"Changing lightning storm from previous lightning ID:0 to new lightning ID: 119.", -- [1]
			0, -- [2]
		}, -- [46]
		{
			"Weather changed to 1, intensity 0.197713\n", -- [1]
			0, -- [2]
		}, -- [47]
		{
			"End lightning storm.", -- [1]
			0, -- [2]
		}, -- [48]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [49]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [50]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [51]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [52]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [53]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [54]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [55]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [56]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [57]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [58]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [59]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [60]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [61]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [62]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [63]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [64]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [65]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [66]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [67]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [68]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [69]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [70]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [71]
		{
			"Multithreaded particulate volumes pass disabled.", -- [1]
			0, -- [2]
		}, -- [72]
		{
			"Multithreaded alpha water volumes pass enabled.", -- [1]
			0, -- [2]
		}, -- [73]
		{
			"Multithreaded daynight update enabled.", -- [1]
			0, -- [2]
		}, -- [74]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [75]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [76]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [77]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [78]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [79]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [80]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [81]
		{
			"Particulate volumes enabled.", -- [1]
			0, -- [2]
		}, -- [82]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [83]
		{
			"Spell Clutter set to dynamic", -- [1]
			0, -- [2]
		}, -- [84]
		{
			"Shadow mode changed to 4 - 4 band dynamic shadows on units and terrain, 2048", -- [1]
			0, -- [2]
		}, -- [85]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [86]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [87]
		{
			"Shadow cascade blending changed to 0", -- [1]
			0, -- [2]
		}, -- [88]
		{
			"Shadow RT mode changed to 3 (High) - Full-resolution directional & local light shadows", -- [1]
			0, -- [2]
		}, -- [89]
		{
			"maxLightCount must be in range 0 to 32.", -- [1]
			0, -- [2]
		}, -- [90]
		{
			"CVar 'maxLightCount' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [91]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [92]
		{
			"SSAO type set to 1", -- [1]
			0, -- [2]
		}, -- [93]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [94]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [95]
		{
			"Texture filtering mode updated.", -- [1]
			0, -- [2]
		}, -- [96]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [97]
		{
			"Outline mode changed to 1", -- [1]
			0, -- [2]
		}, -- [98]
		{
			"Physics interaction level changed to 2", -- [1]
			0, -- [2]
		}, -- [99]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [100]
		{
			"Resample quality changed to 3", -- [1]
			0, -- [2]
		}, -- [101]
		{
			"MSAA set to 2 color samples, 2 coverage samples", -- [1]
			0, -- [2]
		}, -- [102]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [103]
		{
			"lodObjectSizeScale cannot be changed.", -- [1]
			0, -- [2]
		}, -- [104]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [105]
		{
			"dynamicLod enabled", -- [1]
			0, -- [2]
		}, -- [106]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [107]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [108]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [109]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [110]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [111]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [112]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [113]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [114]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [115]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [116]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [117]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [118]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [119]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [120]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [121]
		{
			"[GlueLogin] [F] Starting login launcherPortal=\"us.actual.battle.net\" loginPortal=\"us.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [122]
		{
			"[GlueLogin] [F] Resetting", -- [1]
			0, -- [2]
		}, -- [123]
		{
			"[IBN_Login] [F] Initializing", -- [1]
			0, -- [2]
		}, -- [124]
		{
			"[IBN_Login] [F] Attempting logon host=\"us.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [125]
		{
			"[GlueLogin] [F] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [126]
		{
			"[GlueLogin] [F] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [127]
		{
			"[GlueLogin] [F] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [128]
		{
			"[GlueLogin] [F] Logon complete.", -- [1]
			0, -- [2]
		}, -- [129]
		{
			"[GlueLogin] [F] Reconnect token saved;  creationTime=\"1695910958\" expirationTime=\"1695925358\"", -- [1]
			0, -- [2]
		}, -- [130]
		{
			"[GlueLogin] [F] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [131]
		{
			"[IBN_Login] [F] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [132]
		{
			"[IBN_Login] [F] Received realm list ticket code=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [133]
		{
			"[GlueLogin] [F] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [134]
		{
			"[IBN_Login] [F] Received sub region list code=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [135]
		{
			"[IBN_Login] [F] Requesting last played chars numSubRegions=\"5\"", -- [1]
			0, -- [2]
		}, -- [136]
		{
			"[GlueLogin] [F] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [137]
		{
			"[IBN_Login] [F] Joining realm subRegion=\"1-1-89\" realmAddress=\"1-5-4\"", -- [1]
			0, -- [2]
		}, -- [138]
		{
			"[IBN_Login] [F] OnRealmJoin code=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [139]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [140]
		{
			"[GlueLogin] [F] Received AuthedToWoW result=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [141]
		{
			"[IBN_Login] [F] Front disconnecting connectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [142]
		{
			"[GlueLogin] [F] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [143]
		{
			"[IBN_BackInterface] [F] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [144]
		{
			"[WowEntitlements] [BNetAccount-0-00000014F2E9] [WowAccount-0-0000006575E4] Initialized with 84 entitlements.", -- [1]
			0, -- [2]
		}, -- [145]
		{
			"[IBN_Login] [F] Front disconnected connectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [146]
		{
			"[GlueLogin] [F] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [147]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [148]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [149]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [150]
		{
			"Proficiency in item class 2 set to 0x0000008001", -- [1]
			0, -- [2]
		}, -- [151]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [152]
		{
			"Proficiency in item class 2 set to 0x000000c001", -- [1]
			0, -- [2]
		}, -- [153]
		{
			"Proficiency in item class 2 set to 0x000004c001", -- [1]
			0, -- [2]
		}, -- [154]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [155]
		{
			"Proficiency in item class 2 set to 0x000004c005", -- [1]
			0, -- [2]
		}, -- [156]
		{
			"Proficiency in item class 2 set to 0x000004c00d", -- [1]
			0, -- [2]
		}, -- [157]
		{
			"Proficiency in item class 2 set to 0x000004e00d", -- [1]
			0, -- [2]
		}, -- [158]
		{
			"Proficiency in item class 2 set to 0x000004e01d", -- [1]
			0, -- [2]
		}, -- [159]
		{
			"Proficiency in item class 2 set to 0x000004e09d", -- [1]
			0, -- [2]
		}, -- [160]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [161]
		{
			"Proficiency in item class 2 set to 0x000004e09d", -- [1]
			0, -- [2]
		}, -- [162]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [163]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [164]
		{
			"Time set to 9/28/2023 (Thu) 7:21", -- [1]
			0, -- [2]
		}, -- [165]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [166]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [167]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [168]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [169]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [170]
		{
			"Total: 1d 18h 37m 35s", -- [1]
			0, -- [2]
		}, -- [171]
		{
			"Level: 0d 3h 19m 57s", -- [1]
			0, -- [2]
		}, -- [172]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [173]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [174]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [175]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [176]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [177]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [178]
		{
			"Skill 118 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [179]
		{
			"Skill 183 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [180]
		{
			"Skill 756 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [181]
		{
			"Skill 921 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [182]
		{
			"Skill 2731 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [183]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [184]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [185]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [186]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [187]
		{
			"Skill 118 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [188]
		{
			"Skill 183 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [189]
		{
			"Skill 756 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [190]
		{
			"Skill 921 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [191]
		{
			"Skill 2731 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [192]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [193]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [194]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [195]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [196]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [197]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [198]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [199]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [200]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [201]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [202]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [203]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [204]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [205]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [206]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [207]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [208]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [209]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [210]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [211]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [212]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [213]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [214]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [215]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [216]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [217]
		{
			"Proficiency in item class 2 set to 0x0000008001", -- [1]
			0, -- [2]
		}, -- [218]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [219]
		{
			"Proficiency in item class 2 set to 0x000000c001", -- [1]
			0, -- [2]
		}, -- [220]
		{
			"Proficiency in item class 2 set to 0x000000c003", -- [1]
			0, -- [2]
		}, -- [221]
		{
			"Proficiency in item class 2 set to 0x000000c403", -- [1]
			0, -- [2]
		}, -- [222]
		{
			"Proficiency in item class 4 set to 0x0000000061", -- [1]
			0, -- [2]
		}, -- [223]
		{
			"Proficiency in item class 4 set to 0x0000000069", -- [1]
			0, -- [2]
		}, -- [224]
		{
			"Proficiency in item class 4 set to 0x000000006d", -- [1]
			0, -- [2]
		}, -- [225]
		{
			"Proficiency in item class 2 set to 0x000000c423", -- [1]
			0, -- [2]
		}, -- [226]
		{
			"Proficiency in item class 2 set to 0x000000e423", -- [1]
			0, -- [2]
		}, -- [227]
		{
			"Proficiency in item class 2 set to 0x000010e423", -- [1]
			0, -- [2]
		}, -- [228]
		{
			"Proficiency in item class 2 set to 0x000010e433", -- [1]
			0, -- [2]
		}, -- [229]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [230]
		{
			"Proficiency in item class 2 set to 0x000010e433", -- [1]
			0, -- [2]
		}, -- [231]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [232]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [233]
		{
			"Time set to 9/28/2023 (Thu) 8:18", -- [1]
			0, -- [2]
		}, -- [234]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [235]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [236]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [237]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [238]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [239]
		{
			"Total: 117d 18h 23m 9s", -- [1]
			0, -- [2]
		}, -- [240]
		{
			"Level: 22d 10h 36m 50s", -- [1]
			0, -- [2]
		}, -- [241]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [242]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [243]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [244]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [245]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [246]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [247]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [248]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [249]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [250]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [251]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [252]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [253]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [254]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [255]
		{
			"Proficiency in item class 2 set to 0x0000008001", -- [1]
			0, -- [2]
		}, -- [256]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [257]
		{
			"Proficiency in item class 2 set to 0x000000c001", -- [1]
			0, -- [2]
		}, -- [258]
		{
			"Proficiency in item class 2 set to 0x000004c001", -- [1]
			0, -- [2]
		}, -- [259]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [260]
		{
			"Proficiency in item class 2 set to 0x000004c005", -- [1]
			0, -- [2]
		}, -- [261]
		{
			"Proficiency in item class 2 set to 0x000004c00d", -- [1]
			0, -- [2]
		}, -- [262]
		{
			"Proficiency in item class 2 set to 0x000004e00d", -- [1]
			0, -- [2]
		}, -- [263]
		{
			"Proficiency in item class 2 set to 0x000004e01d", -- [1]
			0, -- [2]
		}, -- [264]
		{
			"Proficiency in item class 2 set to 0x000004e09d", -- [1]
			0, -- [2]
		}, -- [265]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [266]
		{
			"Proficiency in item class 2 set to 0x000004e09d", -- [1]
			0, -- [2]
		}, -- [267]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [268]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [269]
		{
			"Time set to 9/28/2023 (Thu) 8:44", -- [1]
			0, -- [2]
		}, -- [270]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [271]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [272]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [273]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [274]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [275]
		{
			"Total: 1d 19h 33m 26s", -- [1]
			0, -- [2]
		}, -- [276]
		{
			"Level: 0d 4h 15m 48s", -- [1]
			0, -- [2]
		}, -- [277]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [278]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [279]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [280]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [281]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [282]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [283]
		{
			"Skill 118 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [284]
		{
			"Skill 183 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [285]
		{
			"Skill 756 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [286]
		{
			"Skill 921 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [287]
		{
			"Skill 2731 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [288]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [289]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [290]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [291]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [292]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [293]
		{
			"Skill 118 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [294]
		{
			"Skill 183 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [295]
		{
			"Skill 756 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [296]
		{
			"Skill 921 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [297]
		{
			"Skill 2731 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [298]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [299]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [300]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [301]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [302]
		{
			"Skill 118 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [303]
		{
			"Skill 183 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [304]
		{
			"Skill 756 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [305]
		{
			"Skill 921 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [306]
		{
			"Skill 2731 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [307]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [308]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [309]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [310]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [311]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [312]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [313]
		{
			"Skill 118 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [314]
		{
			"Skill 183 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [315]
		{
			"Skill 756 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [316]
		{
			"Skill 921 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [317]
		{
			"Skill 2731 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [318]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [319]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [320]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [321]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [322]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [323]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [324]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [325]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [326]
		{
			"Skill 118 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [327]
		{
			"Skill 183 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [328]
		{
			"Skill 756 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [329]
		{
			"Skill 921 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [330]
		{
			"Skill 2731 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [331]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [332]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [333]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [334]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [335]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [336]
		{
			"Skill 118 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [337]
		{
			"Skill 183 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [338]
		{
			"Skill 756 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [339]
		{
			"Skill 921 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [340]
		{
			"Skill 2731 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [341]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [342]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [343]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [344]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [345]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [346]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [347]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [348]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [349]
		{
			"Skill 118 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [350]
		{
			"Skill 183 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [351]
		{
			"Skill 756 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [352]
		{
			"Skill 921 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [353]
		{
			"Skill 2731 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [354]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [355]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [356]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [357]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [358]
		{
			"Skill 118 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [359]
		{
			"Skill 183 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [360]
		{
			"Skill 756 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [361]
		{
			"Skill 921 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [362]
		{
			"Skill 2731 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [363]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [364]
		{
			"Weather changed to 4, intensity 0.500000\n", -- [1]
			0, -- [2]
		}, -- [365]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [366]
		{
			"Weather changed to 4, intensity 0.500000\n", -- [1]
			0, -- [2]
		}, -- [367]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [368]
		{
			"Weather changed to 4, intensity 0.500000\n", -- [1]
			0, -- [2]
		}, -- [369]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [370]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [371]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [372]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [373]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [374]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [375]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [376]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [377]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [378]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [379]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [380]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [381]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [382]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [383]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [384]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [385]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [386]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [387]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [388]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [389]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [390]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [391]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [392]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [393]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [394]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [395]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [396]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [397]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [398]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [399]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [400]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [401]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [402]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [403]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [404]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [405]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [406]
		{
			"Total: 1d 21h 38m 36s", -- [1]
			0, -- [2]
		}, -- [407]
		{
			"Level: 0d 6h 20m 58s", -- [1]
			0, -- [2]
		}, -- [408]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [409]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [410]
		{
			"Total: 1d 21h 39m 3s", -- [1]
			0, -- [2]
		}, -- [411]
		{
			"Level: 0d 6h 21m 25s", -- [1]
			0, -- [2]
		}, -- [412]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [413]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [414]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [415]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [416]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [417]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [418]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [419]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [420]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [421]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [422]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [423]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [424]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [425]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [426]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [427]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [428]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [429]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [430]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [431]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [432]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [433]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [434]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [435]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [436]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [437]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [438]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [439]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [440]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [441]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [442]
		{
			"Weather changed to 1, intensity 0.165705\n", -- [1]
			0, -- [2]
		}, -- [443]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [444]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [445]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [446]
		{
			"Only one lightning storm at a time is supported (including storms from weather).", -- [1]
			0, -- [2]
		}, -- [447]
		{
			"Changing lightning storm from previous lightning ID:0 to new lightning ID: 119.", -- [1]
			0, -- [2]
		}, -- [448]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [449]
		{
			"End lightning storm.", -- [1]
			0, -- [2]
		}, -- [450]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [451]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [452]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [453]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [454]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [455]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [456]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [457]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [458]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [459]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [460]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [461]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [462]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [463]
		{
			"Multithreaded particulate volumes pass disabled.", -- [1]
			0, -- [2]
		}, -- [464]
		{
			"Multithreaded alpha water volumes pass enabled.", -- [1]
			0, -- [2]
		}, -- [465]
		{
			"Multithreaded daynight update enabled.", -- [1]
			0, -- [2]
		}, -- [466]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [467]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [468]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [469]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [470]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [471]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [472]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [473]
		{
			"Particulate volumes enabled.", -- [1]
			0, -- [2]
		}, -- [474]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [475]
		{
			"Spell Clutter set to dynamic", -- [1]
			0, -- [2]
		}, -- [476]
		{
			"Shadow mode changed to 4 - 4 band dynamic shadows on units and terrain, 2048", -- [1]
			0, -- [2]
		}, -- [477]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [478]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [479]
		{
			"Shadow cascade blending changed to 0", -- [1]
			0, -- [2]
		}, -- [480]
		{
			"Shadow RT mode changed to 3 (High) - Full-resolution directional & local light shadows", -- [1]
			0, -- [2]
		}, -- [481]
		{
			"maxLightCount must be in range 0 to 32.", -- [1]
			0, -- [2]
		}, -- [482]
		{
			"CVar 'maxLightCount' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [483]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [484]
		{
			"SSAO type set to 1", -- [1]
			0, -- [2]
		}, -- [485]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [486]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [487]
		{
			"Texture filtering mode updated.", -- [1]
			0, -- [2]
		}, -- [488]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [489]
		{
			"Outline mode changed to 1", -- [1]
			0, -- [2]
		}, -- [490]
		{
			"Physics interaction level changed to 2", -- [1]
			0, -- [2]
		}, -- [491]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [492]
		{
			"Resample quality changed to 3", -- [1]
			0, -- [2]
		}, -- [493]
		{
			"MSAA set to 2 color samples, 2 coverage samples", -- [1]
			0, -- [2]
		}, -- [494]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [495]
		{
			"lodObjectSizeScale cannot be changed.", -- [1]
			0, -- [2]
		}, -- [496]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [497]
		{
			"dynamicLod enabled", -- [1]
			0, -- [2]
		}, -- [498]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [499]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [500]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [501]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [502]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [503]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [504]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [505]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [506]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [507]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [508]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [509]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [510]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [511]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [512]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [513]
		{
			"[GlueLogin] [F] Starting login launcherPortal=\"us.actual.battle.net\" loginPortal=\"us.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [514]
		{
			"[GlueLogin] [F] Resetting", -- [1]
			0, -- [2]
		}, -- [515]
		{
			"[IBN_Login] [F] Initializing", -- [1]
			0, -- [2]
		}, -- [516]
		{
			"[IBN_Login] [F] Attempting logon host=\"us.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [517]
		{
			"[GlueLogin] [F] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [518]
		{
			"[GlueLogin] [F] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [519]
		{
			"[GlueLogin] [F] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [520]
		{
			"[GlueLogin] [F] Logon complete.", -- [1]
			0, -- [2]
		}, -- [521]
		{
			"[GlueLogin] [F] Reconnect token saved;  creationTime=\"1695930403\" expirationTime=\"1695944803\"", -- [1]
			0, -- [2]
		}, -- [522]
		{
			"[GlueLogin] [F] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [523]
		{
			"[IBN_Login] [F] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [524]
		{
			"[IBN_Login] [F] Received realm list ticket code=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [525]
		{
			"[GlueLogin] [F] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [526]
		{
			"[IBN_Login] [F] Received sub region list code=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [527]
		{
			"[IBN_Login] [F] Requesting last played chars numSubRegions=\"5\"", -- [1]
			0, -- [2]
		}, -- [528]
		{
			"[GlueLogin] [F] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [529]
		{
			"[IBN_Login] [F] Joining realm subRegion=\"1-1-89\" realmAddress=\"1-5-4\"", -- [1]
			0, -- [2]
		}, -- [530]
		{
			"[IBN_Login] [F] OnRealmJoin code=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [531]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [532]
		{
			"[GlueLogin] [F] Received AuthedToWoW result=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [533]
		{
			"[IBN_Login] [F] Front disconnecting connectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [534]
		{
			"[GlueLogin] [F] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [535]
		{
			"[IBN_BackInterface] [F] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [536]
		{
			"[WowEntitlements] [BNetAccount-0-00000014F2E9] [WowAccount-0-0000006575E4] Initialized with 84 entitlements.", -- [1]
			0, -- [2]
		}, -- [537]
		{
			"[IBN_Login] [F] Front disconnected connectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [538]
		{
			"[GlueLogin] [F] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [539]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [540]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [541]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [542]
		{
			"Proficiency in item class 2 set to 0x0000008001", -- [1]
			0, -- [2]
		}, -- [543]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [544]
		{
			"Proficiency in item class 2 set to 0x000000c001", -- [1]
			0, -- [2]
		}, -- [545]
		{
			"Proficiency in item class 2 set to 0x000004c001", -- [1]
			0, -- [2]
		}, -- [546]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [547]
		{
			"Proficiency in item class 2 set to 0x000004c005", -- [1]
			0, -- [2]
		}, -- [548]
		{
			"Proficiency in item class 2 set to 0x000004c00d", -- [1]
			0, -- [2]
		}, -- [549]
		{
			"Proficiency in item class 2 set to 0x000004e00d", -- [1]
			0, -- [2]
		}, -- [550]
		{
			"Proficiency in item class 2 set to 0x000004e01d", -- [1]
			0, -- [2]
		}, -- [551]
		{
			"Proficiency in item class 2 set to 0x000004e09d", -- [1]
			0, -- [2]
		}, -- [552]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [553]
		{
			"Proficiency in item class 2 set to 0x000004e09d", -- [1]
			0, -- [2]
		}, -- [554]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [555]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [556]
		{
			"Time set to 9/28/2023 (Thu) 12:46", -- [1]
			0, -- [2]
		}, -- [557]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [558]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [559]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [560]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [561]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [562]
		{
			"Total: 1d 23h 32m 7s", -- [1]
			0, -- [2]
		}, -- [563]
		{
			"Level: 0d 8h 14m 29s", -- [1]
			0, -- [2]
		}, -- [564]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [565]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [566]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [567]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [568]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [569]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [570]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [571]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [572]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [573]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [574]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [575]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [576]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [577]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [578]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [579]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [580]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [581]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [582]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [583]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [584]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [585]
		{
			"Changed difficulty successfully", -- [1]
			0, -- [2]
		}, -- [586]
		{
			"Completed challenge mode mapID 2527, level 5, time 1015570", -- [1]
			0, -- [2]
		}, -- [587]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [588]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [589]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [590]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [591]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [592]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [593]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [594]
		{
			"Total: 2d 0h 16m 25s", -- [1]
			0, -- [2]
		}, -- [595]
		{
			"Level: 0d 8h 58m 47s", -- [1]
			0, -- [2]
		}, -- [596]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [597]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [598]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [599]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [600]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [601]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [602]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [603]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [604]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [605]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [606]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [607]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [608]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [609]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [610]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [611]
		{
			"Changed difficulty successfully", -- [1]
			0, -- [2]
		}, -- [612]
		{
			"Completed challenge mode mapID 2520, level 4, time 1308876", -- [1]
			0, -- [2]
		}, -- [613]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [614]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [615]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [616]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [617]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [618]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [619]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [620]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [621]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [622]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [623]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [624]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [625]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [626]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [627]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [628]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [629]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [630]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [631]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [632]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [633]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [634]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [635]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [636]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [637]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [638]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [639]
		{
			"Changed difficulty successfully", -- [1]
			0, -- [2]
		}, -- [640]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [641]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [642]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [643]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [644]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [645]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [646]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [647]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [648]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [649]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [650]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [651]
		{
			"Multithreaded particulate volumes pass disabled.", -- [1]
			0, -- [2]
		}, -- [652]
		{
			"Multithreaded alpha water volumes pass enabled.", -- [1]
			0, -- [2]
		}, -- [653]
		{
			"Multithreaded daynight update enabled.", -- [1]
			0, -- [2]
		}, -- [654]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [655]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [656]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [657]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [658]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [659]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [660]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [661]
		{
			"Particulate volumes enabled.", -- [1]
			0, -- [2]
		}, -- [662]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [663]
		{
			"Spell Clutter set to dynamic", -- [1]
			0, -- [2]
		}, -- [664]
		{
			"Shadow mode changed to 4 - 4 band dynamic shadows on units and terrain, 2048", -- [1]
			0, -- [2]
		}, -- [665]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [666]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [667]
		{
			"Shadow cascade blending changed to 0", -- [1]
			0, -- [2]
		}, -- [668]
		{
			"Shadow RT mode changed to 3 (High) - Full-resolution directional & local light shadows", -- [1]
			0, -- [2]
		}, -- [669]
		{
			"maxLightCount must be in range 0 to 32.", -- [1]
			0, -- [2]
		}, -- [670]
		{
			"CVar 'maxLightCount' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [671]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [672]
		{
			"SSAO type set to 1", -- [1]
			0, -- [2]
		}, -- [673]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [674]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [675]
		{
			"Texture filtering mode updated.", -- [1]
			0, -- [2]
		}, -- [676]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [677]
		{
			"Outline mode changed to 1", -- [1]
			0, -- [2]
		}, -- [678]
		{
			"Physics interaction level changed to 2", -- [1]
			0, -- [2]
		}, -- [679]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [680]
		{
			"Resample quality changed to 3", -- [1]
			0, -- [2]
		}, -- [681]
		{
			"MSAA set to 2 color samples, 2 coverage samples", -- [1]
			0, -- [2]
		}, -- [682]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [683]
		{
			"lodObjectSizeScale cannot be changed.", -- [1]
			0, -- [2]
		}, -- [684]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [685]
		{
			"dynamicLod enabled", -- [1]
			0, -- [2]
		}, -- [686]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [687]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [688]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [689]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [690]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [691]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [692]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [693]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [694]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [695]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [696]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [697]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [698]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [699]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [700]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [701]
		{
			"[GlueLogin] [F] Starting login launcherPortal=\"us.actual.battle.net\" loginPortal=\"us.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [702]
		{
			"[GlueLogin] [F] Resetting", -- [1]
			0, -- [2]
		}, -- [703]
		{
			"[IBN_Login] [F] Initializing", -- [1]
			0, -- [2]
		}, -- [704]
		{
			"[IBN_Login] [F] Attempting logon host=\"us.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [705]
		{
			"[GlueLogin] [F] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [706]
		{
			"[GlueLogin] [F] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [707]
		{
			"[GlueLogin] [F] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [708]
		{
			"[GlueLogin] [F] Logon complete.", -- [1]
			0, -- [2]
		}, -- [709]
		{
			"[GlueLogin] [F] Reconnect token saved;  creationTime=\"1696014516\" expirationTime=\"1696028916\"", -- [1]
			0, -- [2]
		}, -- [710]
		{
			"[GlueLogin] [F] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [711]
		{
			"[IBN_Login] [F] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [712]
		{
			"[IBN_Login] [F] Received realm list ticket code=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [713]
		{
			"[GlueLogin] [F] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [714]
		{
			"[IBN_Login] [F] Received sub region list code=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [715]
		{
			"[IBN_Login] [F] Requesting last played chars numSubRegions=\"5\"", -- [1]
			0, -- [2]
		}, -- [716]
		{
			"[GlueLogin] [F] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [717]
		{
			"[IBN_Login] [F] Joining realm subRegion=\"1-1-89\" realmAddress=\"1-5-4\"", -- [1]
			0, -- [2]
		}, -- [718]
		{
			"[IBN_Login] [F] OnRealmJoin code=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [719]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [720]
		{
			"[GlueLogin] [F] Received AuthedToWoW result=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [721]
		{
			"[IBN_Login] [F] Front disconnecting connectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [722]
		{
			"[GlueLogin] [F] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [723]
		{
			"[IBN_BackInterface] [F] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [724]
		{
			"[IBN_Login] [F] Front disconnected connectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [725]
		{
			"[GlueLogin] [F] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [726]
		{
			"[WowEntitlements] [BNetAccount-0-00000014F2E9] [WowAccount-0-0000006575E4] Initialized with 84 entitlements.", -- [1]
			0, -- [2]
		}, -- [727]
		{
			"set pending gxRestart", -- [1]
			0, -- [2]
		}, -- [728]
		{
			"set pending gxRestart", -- [1]
			0, -- [2]
		}, -- [729]
		{
			"set pending gxRestart", -- [1]
			0, -- [2]
		}, -- [730]
		{
			"set pending gxRestart", -- [1]
			0, -- [2]
		}, -- [731]
		{
			"set pending gxRestart", -- [1]
			0, -- [2]
		}, -- [732]
		{
			"set pending gxRestart", -- [1]
			0, -- [2]
		}, -- [733]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [734]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [735]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [736]
		{
			"Proficiency in item class 2 set to 0x0000008001", -- [1]
			0, -- [2]
		}, -- [737]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [738]
		{
			"Proficiency in item class 2 set to 0x000000c001", -- [1]
			0, -- [2]
		}, -- [739]
		{
			"Proficiency in item class 2 set to 0x000000c003", -- [1]
			0, -- [2]
		}, -- [740]
		{
			"Proficiency in item class 2 set to 0x000000c403", -- [1]
			0, -- [2]
		}, -- [741]
		{
			"Proficiency in item class 4 set to 0x0000000061", -- [1]
			0, -- [2]
		}, -- [742]
		{
			"Proficiency in item class 4 set to 0x0000000069", -- [1]
			0, -- [2]
		}, -- [743]
		{
			"Proficiency in item class 4 set to 0x000000006d", -- [1]
			0, -- [2]
		}, -- [744]
		{
			"Proficiency in item class 2 set to 0x000000c423", -- [1]
			0, -- [2]
		}, -- [745]
		{
			"Proficiency in item class 2 set to 0x000000e423", -- [1]
			0, -- [2]
		}, -- [746]
		{
			"Proficiency in item class 2 set to 0x000010e423", -- [1]
			0, -- [2]
		}, -- [747]
		{
			"Proficiency in item class 2 set to 0x000010e433", -- [1]
			0, -- [2]
		}, -- [748]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [749]
		{
			"Proficiency in item class 2 set to 0x000010e433", -- [1]
			0, -- [2]
		}, -- [750]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [751]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [752]
		{
			"Time set to 9/29/2023 (Fri) 12:08", -- [1]
			0, -- [2]
		}, -- [753]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [754]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [755]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [756]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [757]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [758]
		{
			"Total: 117d 18h 49m 2s", -- [1]
			0, -- [2]
		}, -- [759]
		{
			"Level: 22d 11h 2m 43s", -- [1]
			0, -- [2]
		}, -- [760]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [761]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [762]
		{
			"Weather changed to 4, intensity 0.500000\n", -- [1]
			0, -- [2]
		}, -- [763]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [764]
		{
			"Weather changed to 4, intensity 0.500000\n", -- [1]
			0, -- [2]
		}, -- [765]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [766]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [767]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [768]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [769]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [770]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [771]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [772]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [773]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [774]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [775]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [776]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [777]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [778]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [779]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [780]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [781]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [782]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [783]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [784]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [785]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [786]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [787]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [788]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [789]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [790]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [791]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [792]
		{
			"Changed difficulty successfully", -- [1]
			0, -- [2]
		}, -- [793]
		{
			"Completed challenge mode mapID 2520, level 17, time 1337855", -- [1]
			0, -- [2]
		}, -- [794]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [795]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [796]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [797]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [798]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [799]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [800]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [801]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [802]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [803]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [804]
		{
			"Proficiency in item class 2 set to 0x0000000100", -- [1]
			0, -- [2]
		}, -- [805]
		{
			"Proficiency in item class 2 set to 0x0000000101", -- [1]
			0, -- [2]
		}, -- [806]
		{
			"Proficiency in item class 2 set to 0x0000000141", -- [1]
			0, -- [2]
		}, -- [807]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [808]
		{
			"Proficiency in item class 2 set to 0x0000004141", -- [1]
			0, -- [2]
		}, -- [809]
		{
			"Proficiency in item class 2 set to 0x0000004143", -- [1]
			0, -- [2]
		}, -- [810]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [811]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [812]
		{
			"Proficiency in item class 2 set to 0x0000004163", -- [1]
			0, -- [2]
		}, -- [813]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [814]
		{
			"Proficiency in item class 2 set to 0x0000104163", -- [1]
			0, -- [2]
		}, -- [815]
		{
			"Proficiency in item class 2 set to 0x0000104173", -- [1]
			0, -- [2]
		}, -- [816]
		{
			"Proficiency in item class 2 set to 0x00001041f3", -- [1]
			0, -- [2]
		}, -- [817]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [818]
		{
			"Proficiency in item class 2 set to 0x00001041f3", -- [1]
			0, -- [2]
		}, -- [819]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [820]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [821]
		{
			"Time set to 9/29/2023 (Fri) 12:46", -- [1]
			0, -- [2]
		}, -- [822]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [823]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [824]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [825]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [826]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [827]
		{
			"Total: 49d 1h 0m 50s", -- [1]
			0, -- [2]
		}, -- [828]
		{
			"Level: 0d 22h 51m 43s", -- [1]
			0, -- [2]
		}, -- [829]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [830]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [831]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [832]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [833]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [834]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [835]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [836]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [837]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [838]
		{
			"Proficiency in item class 2 set to 0x0000008001", -- [1]
			0, -- [2]
		}, -- [839]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [840]
		{
			"Proficiency in item class 2 set to 0x000000c001", -- [1]
			0, -- [2]
		}, -- [841]
		{
			"Proficiency in item class 2 set to 0x000000c003", -- [1]
			0, -- [2]
		}, -- [842]
		{
			"Proficiency in item class 2 set to 0x000000c403", -- [1]
			0, -- [2]
		}, -- [843]
		{
			"Proficiency in item class 4 set to 0x0000000061", -- [1]
			0, -- [2]
		}, -- [844]
		{
			"Proficiency in item class 4 set to 0x0000000069", -- [1]
			0, -- [2]
		}, -- [845]
		{
			"Proficiency in item class 4 set to 0x000000006d", -- [1]
			0, -- [2]
		}, -- [846]
		{
			"Proficiency in item class 2 set to 0x000000c423", -- [1]
			0, -- [2]
		}, -- [847]
		{
			"Proficiency in item class 2 set to 0x000000e423", -- [1]
			0, -- [2]
		}, -- [848]
		{
			"Proficiency in item class 2 set to 0x000010e423", -- [1]
			0, -- [2]
		}, -- [849]
		{
			"Proficiency in item class 2 set to 0x000010e433", -- [1]
			0, -- [2]
		}, -- [850]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [851]
		{
			"Proficiency in item class 2 set to 0x000010e433", -- [1]
			0, -- [2]
		}, -- [852]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [853]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [854]
		{
			"Time set to 9/29/2023 (Fri) 12:53", -- [1]
			0, -- [2]
		}, -- [855]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [856]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [857]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [858]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [859]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [860]
		{
			"Total: 117d 19h 26m 46s", -- [1]
			0, -- [2]
		}, -- [861]
		{
			"Level: 22d 11h 40m 27s", -- [1]
			0, -- [2]
		}, -- [862]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [863]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [864]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [865]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [866]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [867]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [868]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [869]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [870]
		{
			"Proficiency in item class 2 set to 0x0000000100", -- [1]
			0, -- [2]
		}, -- [871]
		{
			"Proficiency in item class 2 set to 0x0000000101", -- [1]
			0, -- [2]
		}, -- [872]
		{
			"Proficiency in item class 2 set to 0x0000000141", -- [1]
			0, -- [2]
		}, -- [873]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [874]
		{
			"Proficiency in item class 2 set to 0x0000004141", -- [1]
			0, -- [2]
		}, -- [875]
		{
			"Proficiency in item class 2 set to 0x0000004143", -- [1]
			0, -- [2]
		}, -- [876]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [877]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [878]
		{
			"Proficiency in item class 2 set to 0x0000004163", -- [1]
			0, -- [2]
		}, -- [879]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [880]
		{
			"Proficiency in item class 2 set to 0x0000104163", -- [1]
			0, -- [2]
		}, -- [881]
		{
			"Proficiency in item class 2 set to 0x0000104173", -- [1]
			0, -- [2]
		}, -- [882]
		{
			"Proficiency in item class 2 set to 0x00001041f3", -- [1]
			0, -- [2]
		}, -- [883]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [884]
		{
			"Proficiency in item class 2 set to 0x00001041f3", -- [1]
			0, -- [2]
		}, -- [885]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [886]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [887]
		{
			"Time set to 9/29/2023 (Fri) 12:56", -- [1]
			0, -- [2]
		}, -- [888]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [889]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [890]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [891]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [892]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [893]
		{
			"Total: 49d 1h 7m 23s", -- [1]
			0, -- [2]
		}, -- [894]
		{
			"Level: 0d 22h 58m 16s", -- [1]
			0, -- [2]
		}, -- [895]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [896]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [897]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [898]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [899]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [900]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [901]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [902]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [903]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [904]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [905]
		{
			"Skill 118 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [906]
		{
			"Skill 183 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [907]
		{
			"Skill 756 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [908]
		{
			"Skill 796 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [909]
		{
			"Skill 2732 increased from 350 to 175", -- [1]
			0, -- [2]
		}, -- [910]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [911]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [912]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [913]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [914]
		{
			"Skill 118 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [915]
		{
			"Skill 183 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [916]
		{
			"Skill 756 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [917]
		{
			"Skill 796 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [918]
		{
			"Skill 2732 increased from 175 to 350", -- [1]
			0, -- [2]
		}, -- [919]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [920]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [921]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [922]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [923]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [924]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [925]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [926]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [927]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [928]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [929]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [930]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [931]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [932]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [933]
		{
			"Proficiency in item class 2 set to 0x0000000100", -- [1]
			0, -- [2]
		}, -- [934]
		{
			"Proficiency in item class 2 set to 0x0000000101", -- [1]
			0, -- [2]
		}, -- [935]
		{
			"Proficiency in item class 2 set to 0x0000000141", -- [1]
			0, -- [2]
		}, -- [936]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [937]
		{
			"Proficiency in item class 2 set to 0x0000004141", -- [1]
			0, -- [2]
		}, -- [938]
		{
			"Proficiency in item class 2 set to 0x0000004143", -- [1]
			0, -- [2]
		}, -- [939]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [940]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [941]
		{
			"Proficiency in item class 2 set to 0x0000004163", -- [1]
			0, -- [2]
		}, -- [942]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [943]
		{
			"Proficiency in item class 2 set to 0x0000104163", -- [1]
			0, -- [2]
		}, -- [944]
		{
			"Proficiency in item class 2 set to 0x0000104173", -- [1]
			0, -- [2]
		}, -- [945]
		{
			"Proficiency in item class 2 set to 0x00001041f3", -- [1]
			0, -- [2]
		}, -- [946]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [947]
		{
			"Proficiency in item class 2 set to 0x00001041f3", -- [1]
			0, -- [2]
		}, -- [948]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [949]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [950]
		{
			"Time set to 9/29/2023 (Fri) 14:06", -- [1]
			0, -- [2]
		}, -- [951]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [952]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [953]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [954]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [955]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [956]
		{
			"Total: 49d 2h 13m 33s", -- [1]
			0, -- [2]
		}, -- [957]
		{
			"Level: 1d 0h 4m 26s", -- [1]
			0, -- [2]
		}, -- [958]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [959]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [960]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [961]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [962]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [963]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [964]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [965]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [966]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [967]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [968]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [969]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [970]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [971]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [972]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [973]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [974]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [975]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [976]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [977]
		{
			"Changed difficulty successfully", -- [1]
			0, -- [2]
		}, -- [978]
		{
			"Completed challenge mode mapID 2527, level 8, time 1100569", -- [1]
			0, -- [2]
		}, -- [979]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [980]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [981]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [982]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [983]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [984]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [985]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [986]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [987]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [988]
		{
			"Weather changed to 1, intensity 0.144083\n", -- [1]
			0, -- [2]
		}, -- [989]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [990]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [991]
		{
			"Weather changed to 2, intensity 0.239552\n", -- [1]
			0, -- [2]
		}, -- [992]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [993]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [994]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [995]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [996]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [997]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [998]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [999]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [1000]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [1001]
	},
	["height"] = 300,
	["fontHeight"] = 14,
	["isShown"] = false,
	["commandHistory"] = {
	},
}
