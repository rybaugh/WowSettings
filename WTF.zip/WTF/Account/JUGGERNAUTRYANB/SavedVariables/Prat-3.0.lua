
Prat3DB = {
	["namespaces"] = {
		["Prat_ChannelColorMemory"] = {
		},
		["Prat_Fading"] = {
		},
		["Prat_Scroll"] = {
		},
		["Prat_Mentions"] = {
		},
		["Prat_CopyChat"] = {
		},
		["Prat_PopupMessage"] = {
		},
		["Prat_ServerNames"] = {
		},
		["Prat_TellTarget"] = {
		},
		["Prat_AltNames"] = {
		},
		["Prat_PlayerNames"] = {
		},
		["Prat_Memory"] = {
		},
		["Prat_Frames"] = {
			["profiles"] = {
				["Default"] = {
					["minchatwidthdefault"] = 250.0000152587891,
					["maxchatheightdefault"] = 800,
					["initialized"] = true,
				},
			},
		},
		["Prat_Editbox"] = {
		},
		["Prat_History"] = {
		},
		["Prat_KeyBindings"] = {
		},
		["Prat_Font"] = {
		},
		["Prat_Bubbles"] = {
		},
		["Prat_UrlCopy"] = {
		},
		["Prat_DebugModules"] = {
		},
		["Prat_Timestamps"] = {
		},
		["Prat_Achievements"] = {
		},
		["Prat_NewcomersChat"] = {
		},
		["Prat_Alias"] = {
		},
		["Prat_OriginalButtons"] = {
		},
		["Prat_Highlight"] = {
		},
		["Prat_Paragraph"] = {
		},
		["Prat_ChannelSticky"] = {
		},
		["Prat_Invites"] = {
		},
		["Prat_LinkInfoIcons"] = {
		},
		["Prat_ChannelNames"] = {
		},
		["Prat_ChatLog"] = {
		},
		["Prat_Search"] = {
		},
		["Prat_Buttons"] = {
		},
		["Prat_Sounds"] = {
		},
		["Prat_HoverTips"] = {
		},
	},
	["profileKeys"] = {
		["Janwa - Mal'Ganis"] = "Default",
		["Gelosia - Mal'Ganis"] = "Default",
		["Ryanmage - Mal'Ganis"] = "Default",
		["Allaeda - Mal'Ganis"] = "Default",
		["Stormart - Mal'Ganis"] = "Default",
		["Skelay - Mal'Ganis"] = "Default",
		["Elyyine - Mal'Ganis"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["modules"] = {
				["Alias"] = 2,
				["Mentions"] = 2,
				["PopupMessage"] = 2,
				["AltNames"] = 2,
				["Sounds"] = 2,
				["Paragraph"] = 2,
				["KeyBindings"] = 2,
				["LinkInfoIcons"] = 2,
				["DebugModules"] = 2,
				["OriginalButtons"] = 2,
				["ChatLog"] = 2,
			},
		},
	},
}
