
Scrap_Sets = {
	["tutorial"] = 5,
	["list"] = {
	},
}
