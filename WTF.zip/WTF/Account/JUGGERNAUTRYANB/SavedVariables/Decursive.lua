
DecursiveDB = {
	["global"] = {
		["LastVersionAnnounce"] = 1696024638,
	},
	["class"] = {
		["HUNTER"] = {
			["CureOrder-3"] = {
				1, -- [1]
				5, -- [2]
				nil, -- [3]
				2, -- [4]
				[64] = 7,
				[16] = 4,
				[32] = 6,
				[8] = 3,
			},
		},
		["DEMONHUNTER"] = {
			["CureOrder-2"] = {
				1, -- [1]
				5, -- [2]
				nil, -- [3]
				2, -- [4]
				[64] = 7,
				[16] = 4,
				[32] = 6,
				[8] = 3,
			},
		},
		["ROGUE"] = {
			["CureOrder-3"] = {
				1, -- [1]
				5, -- [2]
				nil, -- [3]
				2, -- [4]
				[64] = 7,
				[16] = 4,
				[32] = 6,
				[8] = 3,
			},
		},
		["MAGE"] = {
			["CureOrder-2"] = {
				1, -- [1]
				5, -- [2]
				nil, -- [3]
				2, -- [4]
				[64] = 7,
				[16] = 4,
				[32] = 6,
				[8] = 3,
			},
		},
		["DRUID"] = {
			["CureOrder-4"] = {
				1, -- [1]
				5, -- [2]
				nil, -- [3]
				2, -- [4]
				[64] = 7,
				[16] = 4,
				[32] = 6,
				[8] = 3,
			},
		},
		["SHAMAN"] = {
			["CureOrder-2"] = {
				1, -- [1]
				5, -- [2]
				nil, -- [3]
				2, -- [4]
				[64] = 7,
				[16] = 4,
				[32] = 6,
				[8] = 3,
			},
		},
		["DEATHKNIGHT"] = {
			["CureOrder-2"] = {
				1, -- [1]
				5, -- [2]
				nil, -- [3]
				2, -- [4]
				[64] = 7,
				[16] = 4,
				[32] = 6,
				[8] = 3,
			},
		},
	},
	["profileKeys"] = {
		["Janwa - Mal'Ganis"] = "Default",
		["Gelosia - Mal'Ganis"] = "Default",
		["Ryanmage - Mal'Ganis"] = "Default",
		["Allaeda - Mal'Ganis"] = "Default",
		["Stormart - Mal'Ganis"] = "Default",
		["Skelay - Mal'Ganis"] = "Default",
		["Elyyine - Mal'Ganis"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["DebuffsFrameContainer_y"] = 494.933337020874,
			["MainBarX"] = 682.6666717529297,
			["MainBarY"] = -96.00000071525574,
			["DebuffsFrameContainer_x"] = 1024.000007629395,
		},
	},
}
