
RaiderIO_Config = {
	["profilePoint"] = {
		["y"] = 0,
		["x"] = -16,
		["point"] = "TOPLEFT",
	},
}
RaiderIO_LastCharacter = "us-Skelay-malganis"
RaiderIO_MissingCharacters = {
	["us-Bingchillin-malganis"] = true,
	["us-Ihavecake-sargeras"] = true,
	["us-Bloodynature-malganis"] = true,
	["us-Whitemagicia-area-52"] = true,
	["us-Kokokrispie-tichondrius"] = true,
	["us-Nano-malganis"] = true,
	["us-Rzyy-malganis"] = true,
	["us-Blesser-illidan"] = true,
	["us-Holypits-malganis"] = true,
	["us-Dreadnaughte-tichondrius"] = true,
	["us-Baliryo-malganis"] = true,
	["us-Ohallandwar-malganis"] = true,
	["us-Alynndra-azralon"] = true,
	["us-Yatiro-illidan"] = true,
	["us-Masacre-malganis"] = true,
	["us-Cazadormalo-zuljin"] = true,
	["us-Bîcêps-azralon"] = true,
	["us-Blacklorde-azralon"] = true,
	["us-Areyousingle-blackrock"] = true,
	["us-Mehga-malganis"] = true,
	["us-Larsonia-malganis"] = true,
	["us-Rodnall-malganis"] = true,
	["us-Golokolo-malganis"] = true,
	["us-Crimsonglow-malganis"] = true,
	["us-Pihay-area-52"] = true,
	["us-Kotshiku-malganis"] = true,
	["us-Destrothar-malganis"] = true,
	["us-Catalogs-malganis"] = true,
	["us-Givzaken-illidan"] = true,
	["us-Drayden-malganis"] = true,
	["us-Minegishi-malganis"] = true,
	["us-Narthwa-malganis"] = true,
	["us-Holruk-malganis"] = true,
	["us-Luzdesol-zuljin"] = true,
	["us-Yanshee-malganis"] = true,
	["us-Hírakø-ragnaros"] = true,
	["us-Ragingspirit-ragnaros"] = true,
	["us-Nuelzinhu-azralon"] = true,
	["us-Usedbandaid-malganis"] = true,
	["us-Oldrellik-malganis"] = true,
	["us-Xenothÿne-wyrmrest-accord"] = true,
	["us-Bronzyy-illidan"] = true,
	["us-Quiels-azralon"] = true,
	["us-Sneakystab-llane"] = true,
	["us-Detreehache-area-52"] = true,
	["us-Bennynotank-malganis"] = true,
}
RaiderIO_MissingServers = {
}
RaiderIO_CachedRuns = nil
RaiderIO_RWF = {
}
RaiderIO_CompletedReplays = {
}
