
_detalhes_global = {
	["boss_icon_cache"] = {
		["assault of the zaqali"] = 5151368,
		["kazzara, the hellforged"] = 5151370,
		["echo of neltharion"] = 5151369,
		["the forgotten experiments"] = 5151375,
		["rashok, the elder"] = 5151372,
		["the vigilant steward, zskarn"] = 5151376,
		["magmorax"] = 5151371,
		["scalecommander sarkareth"] = 5151373,
		["the amalgamation chamber"] = 5151374,
	},
	["encounter_spell_pool"] = {
		{
			1790, -- [1]
			"Rokmora", -- [2]
		}, -- [1]
		{
			1052, -- [1]
			"Oathsworn Pathfinder", -- [2]
		}, -- [2]
		[407917] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[411242] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[377995] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[372113] = {
			2568, -- [1]
			"Infected Lasher <Wilted Oak>", -- [2]
		},
		[401525] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[82415] = {
			1056, -- [1]
			"Corborus", -- [2]
		},
		[375439] = {
			2610, -- [1]
			"Magmatusk", -- [2]
		},
		[84589] = {
			1055, -- [1]
			"Siamat", -- [2]
		},
		[405618] = {
			2682, -- [1]
			"Warlord Kagni", -- [2]
		},
		[82671] = {
			1052, -- [1]
			"Oathsworn Myrmidon", -- [2]
		},
		[381834] = {
			2570, -- [1]
			"Rira Hackclaw", -- [2]
		},
		[78835] = {
			1058, -- [1]
			"Ozruk", -- [2]
		},
		[73976] = {
			1052, -- [1]
			"Neferset Plaguebringer", -- [2]
		},
		[395647] = {
			2555, -- [1]
			"[*] Fiery Surge", -- [2]
		},
		[200637] = {
			1793, -- [1]
			"Dargrul", -- [2]
		},
		[396672] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[369563] = {
			2555, -- [1]
			"Baelog", -- [2]
		},
		[373912] = {
			2569, -- [1]
			"Decatriarch Wratheye", -- [2]
		},
		[381329] = {
			2612, -- [1]
			"Qalashi Lavabearer", -- [2]
		},
		[401022] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[405626] = {
			2683, -- [1]
			"Magmorax", -- [2]
		},
		[375449] = {
			2610, -- [1]
			"Magmatusk", -- [2]
		},
		[403326] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[373915] = {
			2569, -- [1]
			"Decatriarch Wratheye", -- [2]
		},
		[183633] = {
			1791, -- [1]
			"Rockbound Pelter", -- [2]
		},
		[80180] = {
			1058, -- [1]
			"Stonecore Bruiser", -- [2]
		},
		[411767] = {
			2682, -- [1]
			"Warlord Kagni", -- [2]
		},
		[188493] = {
			1792, -- [1]
			"Naraxas", -- [2]
		},
		[373917] = {
			2569, -- [1]
			"Decatriarch Wratheye", -- [2]
		},
		[405886] = {
			2689, -- [1]
			"Dragonfire Golem", -- [2]
		},
		[84784] = {
			1054, -- [1]
			"Augh", -- [2]
		},
		[405375] = {
			2693, -- [1]
			"Thadrion", -- [2]
		},
		[396424] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[402051] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[188494] = {
			1792, -- [1]
			"[*] Rancid Maw", -- [2]
		},
		[387474] = {
			2618, -- [1]
			"Primal Tsunami", -- [2]
		},
		[217011] = {
			1792, -- [1]
			"Angry Crowd", -- [2]
		},
		[101984] = {
			1271, -- [1]
			"Murozond", -- [2]
		},
		[408959] = {
			2682, -- [1]
			"Warlord Kagni", -- [2]
		},
		[384663] = {
			2612, -- [1]
			"Forgewrought Monstrosity", -- [2]
		},
		[78903] = {
			1058, -- [1]
			"Ozruk", -- [2]
		},
		[388245] = {
			2616, -- [1]
			"Gulping Goliath", -- [2]
		},
		[400777] = {
			2680, -- [1]
			"Rashok", -- [2]
		},
		[401801] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[382620] = {
			2567, -- [1]
			"Gutshot", -- [2]
		},
		[386201] = {
			2562, -- [1]
			"[*] Corrupted Mana", -- [2]
		},
		[88814] = {
			1053, -- [1]
			"High Prophet Barim", -- [2]
		},
		[102241] = {
			1884, -- [1]
			"Echo of Tyrande", -- [2]
		},
		[188114] = {
			1790, -- [1]
			"Rokmora", -- [2]
		},
		[410243] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[256016] = {
			2093, -- [1]
			"[*] Vile Coating", -- [2]
		},
		[405640] = {
			2687, -- [1]
			"Shadowflame Amalgamation", -- [2]
		},
		[406152] = {
			2680, -- [1]
			"Rashok", -- [2]
		},
		[405641] = {
			2687, -- [1]
			"Shadowflame Amalgamation", -- [2]
		},
		[408966] = {
			2683, -- [1]
			"Magmorax", -- [2]
		},
		[406153] = {
			2680, -- [1]
			"Rashok", -- [2]
		},
		[196811] = {
			2693, -- [1]
			"Divine Image <Grica-Trollbane>", -- [2]
		},
		[216376] = {
			1793, -- [1]
			"Lava Geyser", -- [2]
		},
		[405643] = {
			2687, -- [1]
			"Shadowflame Amalgamation", -- [2]
		},
		[384416] = {
			2567, -- [1]
			"Gutshot", -- [2]
		},
		[101411] = {
			1882, -- [1]
			"Echo of Sylvanas", -- [2]
		},
		[196812] = {
			2693, -- [1]
			"Divine Image <Grica-Trollbane>", -- [2]
		},
		[402831] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[80184] = {
			1058, -- [1]
			"Stonecore Bruiser", -- [2]
		},
		[408714] = {
			2687, -- [1]
			"Eternal Blaze", -- [2]
		},
		[83445] = {
			1052, -- [1]
			"General Husam", -- [2]
		},
		[196813] = {
			2687, -- [1]
			"Divine Image <Grica-Trollbane>", -- [2]
		},
		[401810] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[413319] = {
			1041, -- [1]
			"Altairus", -- [2]
		},
		[75645] = {
			1040, -- [1]
			"Corla, Herald of Twilight", -- [2]
		},
		[385187] = {
			2616, -- [1]
			"Gulping Goliath", -- [2]
		},
		[107550] = {
			1271, -- [1]
			"Murozond", -- [2]
		},
		[405392] = {
			2693, -- [1]
			"Rionthus", -- [2]
		},
		[408717] = {
			2687, -- [1]
			"Essence of Shadow", -- [2]
		},
		[411019] = {
			1042, -- [1]
			"Skyfall Star", -- [2]
		},
		[373424] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[408462] = {
			2693, -- [1]
			"Thadrion", -- [2]
		},
		[373936] = {
			2568, -- [1]
			"Wilted Oak", -- [2]
		},
		[83446] = {
			1055, -- [1]
			"Minion of Siamat", -- [2]
		},
		[406161] = {
			2680, -- [1]
			"[*] Lava Explosion", -- [2]
		},
		[405394] = {
			2687, -- [1]
			"Shadowflame Amalgamation", -- [2]
		},
		[378029] = {
			2570, -- [1]
			"Gashtooth", -- [2]
		},
		[256405] = {
			2095, -- [1]
			"Trothak", -- [2]
		},
		[385958] = {
			2562, -- [1]
			"Vexamus <Magic Book>", -- [2]
		},
		[377008] = {
			2564, -- [1]
			"Crawth", -- [2]
		},
		[377009] = {
			2564, -- [1]
			"Crawth", -- [2]
		},
		[389541] = {
			2680, -- [1]
			"White Tiger Statue <Staggerbot-Korgath>", -- [2]
		},
		[406165] = {
			2680, -- [1]
			"Rashok", -- [2]
		},
		[76478] = {
			1040, -- [1]
			"Twilight Torturer", -- [2]
		},
		[372151] = {
			2567, -- [1]
			"Gutchewer Bear", -- [2]
		},
		[377522] = {
			2611, -- [1]
			"Raging Ember", -- [2]
		},
		[373942] = {
			2569, -- [1]
			"Decatriarch Wratheye", -- [2]
		},
		[401819] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[385963] = {
			2617, -- [1]
			"Khajin the Unyielding", -- [2]
		},
		[373943] = {
			2568, -- [1]
			"Wilted Oak", -- [2]
		},
		[410516] = {
			2682, -- [1]
			"Warlord Kagni", -- [2]
		},
		[409749] = {
			2682, -- [1]
			"Flamebound Huntsman", -- [2]
		},
		[82425] = {
			1053, -- [1]
			"Harbinger of Darkness", -- [2]
		},
		[209862] = {
			1790, -- [1]
			"[*] Volcanic Plume", -- [2]
		},
		[272412] = {
			2094, -- [1]
			"Cutwater Harpooner", -- [2]
		},
		[405914] = {
			2687, -- [1]
			"Shadowflame Amalgamation", -- [2]
		},
		[413331] = {
			1041, -- [1]
			"Altairus", -- [2]
		},
		[272413] = {
			2094, -- [1]
			"Cutwater Harpooner", -- [2]
		},
		[374969] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[88308] = {
			1041, -- [1]
			"Altairus", -- [2]
		},
		[406172] = {
			2680, -- [1]
			"Rashok", -- [2]
		},
		[406428] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[82362] = {
			1038, -- [1]
			"Twilight Zealot", -- [2]
		},
		[401825] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[409242] = {
			2682, -- [1]
			"Magma Mystic", -- [2]
		},
		[377018] = {
			2611, -- [1]
			"Warlord Sargha", -- [2]
		},
		[387504] = {
			2618, -- [1]
			"Primal Tsunami", -- [2]
		},
		[369602] = {
			2555, -- [1]
			"Olaf", -- [2]
		},
		[404896] = {
			2687, -- [1]
			"Eternal Blaze", -- [2]
		},
		[407198] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[401316] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[407199] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[407200] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[369605] = {
			2556, -- [1]
			"Bromach", -- [2]
		},
		[257308] = {
			2096, -- [1]
			"Harlan Sweete", -- [2]
		},
		[401319] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[200404] = {
			1793, -- [1]
			"Dargrul", -- [2]
		},
		[343520] = {
			2556, -- [1]
			"[*] Storming", -- [2]
		},
		[388788] = {
			2618, -- [1]
			"[*] Rogue Waves", -- [2]
		},
		[386743] = {
			2617, -- [1]
			"Khajin the Unyielding", -- [2]
		},
		[405413] = {
			2693, -- [1]
			"Rionthus", -- [2]
		},
		[402600] = {
			2685, -- [1]
			"Arcane Image", -- [2]
		},
		[102057] = {
			1881, -- [1]
			"Undying Flame", -- [2]
		},
		[257310] = {
			2096, -- [1]
			"Irontide Cannon", -- [2]
		},
		[369610] = {
			2556, -- [1]
			"Quaking Totem <Bromach>", -- [2]
		},
		[403625] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[102569] = {
			1271, -- [1]
			"Murozond", -- [2]
		},
		[407207] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[401325] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[373960] = {
			2569, -- [1]
			"Decatriarch Wratheye", -- [2]
		},
		[385981] = {
			2562, -- [1]
			"[*] Arcane Orb", -- [2]
		},
		[377542] = {
			2611, -- [1]
			"[*] Burning Ground", -- [2]
		},
		[401327] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[378054] = {
			2568, -- [1]
			"[*] Withering Away!", -- [2]
		},
		[381379] = {
			2570, -- [1]
			"Gashtooth", -- [2]
		},
		[410535] = {
			2682, -- [1]
			"Warlord Kagni", -- [2]
		},
		[378055] = {
			2568, -- [1]
			"Decaying Slime <Treemouth>", -- [2]
		},
		[368081] = {
			2568, -- [1]
			"[*] Withering", -- [2]
		},
		[404910] = {
			2687, -- [1]
			"Eternal Blaze", -- [2]
		},
		[82622] = {
			1053, -- [1]
			"High Prophet Barim", -- [2]
		},
		[257314] = {
			2096, -- [1]
			"Irontide Grenadier", -- [2]
		},
		[82750] = {
			1053, -- [1]
			"Neferset Torturer", -- [2]
		},
		[376780] = {
			2611, -- [1]
			"Warlord Sargha", -- [2]
		},
		[258338] = {
			2094, -- [1]
			"Captain Raoul", -- [2]
		},
		[86331] = {
			1043, -- [1]
			"Grand Vizier Ertan", -- [2]
		},
		[83454] = {
			1052, -- [1]
			"[*] Shockwave", -- [2]
		},
		[404403] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[257316] = {
			2096, -- [1]
			"Harlan Sweete", -- [2]
		},
		[75590] = {
			1040, -- [1]
			"Twilight Sadist", -- [2]
		},
		[389059] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[374482] = {
			2613, -- [1]
			"Grounding Spear <Chargath, Bane of Scales>", -- [2]
		},
		[377807] = {
			2570, -- [1]
			"Rira Hackclaw", -- [2]
		},
		[88314] = {
			1041, -- [1]
			"Twister", -- [2]
		},
		[375251] = {
			2610, -- [1]
			"Magmatusk", -- [2]
		},
		[402617] = {
			2687, -- [1]
			"Eternal Blaze", -- [2]
		},
		[407221] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[401339] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[407733] = {
			2693, -- [1]
			"Neldris", -- [2]
		},
		[198496] = {
			1791, -- [1]
			"Ularogg Cragshaper", -- [2]
		},
		[84031] = {
			1052, -- [1]
			"Oathsworn Skinner", -- [2]
		},
		[199775] = {
			1792, -- [1]
			"Naraxas", -- [2]
		},
		[101614] = {
			1881, -- [1]
			"Echo of Baine", -- [2]
		},
		[80195] = {
			1058, -- [1]
			"Stonecore Bruiser", -- [2]
		},
		[256552] = {
			2095, -- [1]
			"Hammer Shark", -- [2]
		},
		[406712] = {
			2683, -- [1]
			"[*] Lava", -- [2]
		},
		[75272] = {
			1040, -- [1]
			"Rom'ogg Bonecrusher", -- [2]
		},
		[327942] = {
			1038, -- [1]
			"Windfury Totem <Nezaren-Hyjal>", -- [2]
		},
		[401854] = {
			2687, -- [1]
			"Essence of Shadow", -- [2]
		},
		[409271] = {
			2682, -- [1]
			"Magma Mystic", -- [2]
		},
		[256553] = {
			2095, -- [1]
			"Hammer Shark", -- [2]
		},
		[413364] = {
			2683, -- [1]
			"Magmorax", -- [2]
		},
		[405437] = {
			2687, -- [1]
			"Shadowflame Amalgamation", -- [2]
		},
		[84544] = {
			1055, -- [1]
			"Servant of Siamat <[*] Static Shock>", -- [2]
		},
		[409275] = {
			2682, -- [1]
			"Magma Mystic", -- [2]
		},
		[405439] = {
			2689, -- [1]
			"[*] Tactical Destruction", -- [2]
		},
		[200418] = {
			1793, -- [1]
			"Dargrul", -- [2]
		},
		[402115] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[401348] = {
			2683, -- [1]
			"Magmorax", -- [2]
		},
		[384725] = {
			2567, -- [1]
			"Rotfang Hyena <Gutshot>", -- [2]
		},
		[376797] = {
			2568, -- [1]
			"Treemouth", -- [2]
		},
		[406976] = {
			2682, -- [1]
			"Siege Arbalest", -- [2]
		},
		[397514] = {
			2682, -- [1]
			"Warlord Kagni", -- [2]
		},
		[403908] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[83778] = {
			1054, -- [1]
			"Pygmy Firebreather", -- [2]
		},
		[77768] = {
			1039, -- [1]
			"Conflagration", -- [2]
		},
		[402120] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[403655] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[388822] = {
			2565, -- [1]
			"Echo of Doragosa", -- [2]
		},
		[373733] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[374245] = {
			2568, -- [1]
			"[*] Rotting Creek", -- [2]
		},
		[76618] = {
			1039, -- [1]
			"Conflagration", -- [2]
		},
		[181113] = {
			2689, -- [1]
			"Dragonfire Golem", -- [2]
		},
		[91196] = {
			1053, -- [1]
			"Blaze of the Heavens", -- [2]
		},
		[373735] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[405704] = {
			2687, -- [1]
			"Shadowflame Amalgamation", -- [2]
		},
		[372201] = {
			2612, -- [1]
			"Qalashi Irontorch", -- [2]
		},
		[200551] = {
			1793, -- [1]
			"Dargrul", -- [2]
		},
		[84547] = {
			1055, -- [1]
			"[*] Static Shock", -- [2]
		},
		[102066] = {
			1882, -- [1]
			"Time-Twisted Geist", -- [2]
		},
		[372203] = {
			2612, -- [1]
			"Qalashi Irontorch", -- [2]
		},
		[377830] = {
			2570, -- [1]
			"Rira Hackclaw", -- [2]
		},
		[406730] = {
			2687, -- [1]
			"Eternal Blaze", -- [2]
		},
		[258352] = {
			2094, -- [1]
			"Captain Eudora", -- [2]
		},
		[392666] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[383204] = {
			2618, -- [1]
			"[*] Crashing Tsunami", -- [2]
		},
		[406989] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[257458] = {
			2096, -- [1]
			"Harlan Sweete", -- [2]
		},
		[376811] = {
			2568, -- [1]
			"Treemouth", -- [2]
		},
		[372208] = {
			2612, -- [1]
			"[*] Djaradin Lava", -- [2]
		},
		[108589] = {
			1271, -- [1]
			"Murozond", -- [2]
		},
		[390111] = {
			2617, -- [1]
			"Khajin the Unyielding", -- [2]
		},
		[381416] = {
			2570, -- [1]
			"Rira Hackclaw", -- [2]
		},
		[383974] = {
			2567, -- [1]
			"Gutshot", -- [2]
		},
		[401621] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[198509] = {
			1791, -- [1]
			"Ularogg Cragshaper", -- [2]
		},
		[375535] = {
			2610, -- [1]
			"Magmatusk", -- [2]
		},
		[405458] = {
			2687, -- [1]
			"Shadowflame Amalgamation", -- [2]
		},
		[413131] = {
			2096, -- [1]
			"Harlan Sweete", -- [2]
		},
		[257460] = {
			2096, -- [1]
			"[*] Fiery Debris", -- [2]
		},
		[381419] = {
			2570, -- [1]
			"Rira Hackclaw", -- [2]
		},
		[406227] = {
			2693, -- [1]
			"Rionthus", -- [2]
		},
		[91263] = {
			1052, -- [1]
			"General Husam", -- [2]
		},
		[372213] = {
			2612, -- [1]
			"Qalashi Lavabearer", -- [2]
		},
		[403671] = {
			2683, -- [1]
			"Magmorax", -- [2]
		},
		[387559] = {
			2618, -- [1]
			"Primal Tsunami", -- [2]
		},
		[84550] = {
			1055, -- [1]
			"Minion of Siamat", -- [2]
		},
		[383979] = {
			2567, -- [1]
			"Gutshot", -- [2]
		},
		[83655] = {
			1052, -- [1]
			"General Husam", -- [2]
		},
		[390118] = {
			2617, -- [1]
			"Khajin the Unyielding", -- [2]
		},
		[401883] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[375286] = {
			2555, -- [1]
			"Longboat Raid", -- [2]
		},
		[282449] = {
			2682, -- [1]
			4, -- [2]
		},
		[369660] = {
			2556, -- [1]
			"Quaking Totem <Bromach>", -- [2]
		},
		[406233] = {
			2693, -- [1]
			"Rionthus", -- [2]
		},
		[30153] = {
			2682, -- [1]
			"Felguard <Potgoblin-Durotan>", -- [2]
		},
		[401119] = {
			2682, -- [1]
			"Blazing Spear", -- [2]
		},
		[369662] = {
			2556, -- [1]
			"Quaking Totem <Bromach>", -- [2]
		},
		[412117] = {
			2693, -- [1]
			"Neldris", -- [2]
		},
		[369663] = {
			2556, -- [1]
			"Quaking Totem <Bromach>", -- [2]
		},
		[373756] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[375291] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[82506] = {
			1053, -- [1]
			"High Prophet Barim", -- [2]
		},
		[102135] = {
			1881, -- [1]
			"Time-Twisted Drake", -- [2]
		},
		[263274] = {
			2093, -- [1]
			"Skycap'n Kragg", -- [2]
		},
		[193273] = {
			1791, -- [1]
			"Ularogg Cragshaper", -- [2]
		},
		[372224] = {
			2612, -- [1]
			"Qalashi Bonesplitter", -- [2]
		},
		[256060] = {
			2093, -- [1]
			"Skycap'n Kragg", -- [2]
		},
		[372225] = {
			2612, -- [1]
			"Qalashi Bonesplitter", -- [2]
		},
		[407775] = {
			2693, -- [1]
			"Thadrion", -- [2]
		},
		[387571] = {
			2618, -- [1]
			"Primal Tsunami", -- [2]
		},
		[76561] = {
			1038, -- [1]
			"Twilight Zealot", -- [2]
		},
		[82763] = {
			1052, -- [1]
			"Oathsworn Axemaster", -- [2]
		},
		[373762] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[258875] = {
			2094, -- [1]
			"Blackout Barrel <Captain Raoul>", -- [2]
		},
		[101625] = {
			1881, -- [1]
			"Echo of Baine", -- [2]
		},
		[409313] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[83339] = {
			1052, -- [1]
			"[*] Hard Impact", -- [2]
		},
		[409058] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[75347] = {
			1040, -- [1]
			"Quake", -- [2]
		},
		[401642] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[75539] = {
			1040, -- [1]
			"Rom'ogg Bonecrusher", -- [2]
		},
		[381694] = {
			2570, -- [1]
			"Gashtooth", -- [2]
		},
		[369674] = {
			2556, -- [1]
			"Stonevault Geomancer", -- [2]
		},
		[385531] = {
			2616, -- [1]
			"Gulping Goliath", -- [2]
		},
		[374534] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[377859] = {
			2568, -- [1]
			"Treemouth", -- [2]
		},
		[375046] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[374535] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[369677] = {
			2555, -- [1]
			"Olaf", -- [2]
		},
		[82637] = {
			1053, -- [1]
			"[*] Plague of Ages", -- [2]
		},
		[75732] = {
			1038, -- [1]
			"Corla, Herald of Twilight", -- [2]
		},
		[375306] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[79249] = {
			1057, -- [1]
			"[*] Gravity Well", -- [2]
		},
		[256706] = {
			2095, -- [1]
			"Trothak", -- [2]
		},
		[76500] = {
			1040, -- [1]
			"Twilight Sadist", -- [2]
		},
		[387585] = {
			2618, -- [1]
			"Primal Tsunami", -- [2]
		},
		[407790] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[82255] = {
			1053, -- [1]
			"Harbinger of Darkness", -- [2]
		},
		[402420] = {
			2688, -- [1]
			"[*] Molten Scar", -- [2]
		},
		[375055] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[375056] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[379404] = {
			2612, -- [1]
			"Qalashi Lavabearer", -- [2]
		},
		[375057] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[200700] = {
			1793, -- [1]
			"Dargrul", -- [2]
		},
		[405492] = {
			2693, -- [1]
			"Thadrion", -- [2]
		},
		[83151] = {
			1055, -- [1]
			"Siamat", -- [2]
		},
		[379406] = {
			2612, -- [1]
			"Qalashi Lavabearer", -- [2]
		},
		[410608] = {
			2693, -- [1]
			"Rionthus", -- [2]
		},
		[188169] = {
			1790, -- [1]
			"Rokmora", -- [2]
		},
		[410353] = {
			2682, -- [1]
			"Warlord Kagni", -- [2]
		},
		[407796] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[75543] = {
			1040, -- [1]
			"Rom'ogg Bonecrusher", -- [2]
		},
		[404472] = {
			2693, -- [1]
			"Neldris", -- [2]
		},
		[375061] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[384524] = {
			2615, -- [1]
			"Watcher Irideus", -- [2]
		},
		[384014] = {
			2615, -- [1]
			"Watcher Irideus", -- [2]
		},
		[80467] = {
			1058, -- [1]
			"Ozruk", -- [2]
		},
		[408567] = {
			2682, -- [1]
			"Warlord Kagni", -- [2]
		},
		[210166] = {
			1792, -- [1]
			"Naraxas", -- [2]
		},
		[82769] = {
			1052, -- [1]
			"[*] Infectious Plague", -- [2]
		},
		[401407] = {
			2682, -- [1]
			"Flamebound Huntsman", -- [2]
		},
		[404732] = {
			2687, -- [1]
			"Eternal Blaze", -- [2]
		},
		[385551] = {
			2616, -- [1]
			"Gulping Goliath", -- [2]
		},
		[384529] = {
			2567, -- [1]
			"Rotfang Hyena <Gutshot>", -- [2]
		},
		[407547] = {
			2680, -- [1]
			"Rashok", -- [2]
		},
		[406780] = {
			2687, -- [1]
			"Shadowflame Amalgamation", -- [2]
		},
		[407036] = {
			2684, -- [1]
			"Voice From Beyond", -- [2]
		},
		[384019] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[375068] = {
			2610, -- [1]
			"Lava Tentacles <Magmatusk>", -- [2]
		},
		[384531] = {
			2567, -- [1]
			"Rotfang Hyena", -- [2]
		},
		[406526] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[403202] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[406783] = {
			2687, -- [1]
			"Shadowflame Amalgamation", -- [2]
		},
		[407039] = {
			2684, -- [1]
			"Voice From Beyond", -- [2]
		},
		[403203] = {
			2687, -- [1]
			"Eternal Blaze", -- [2]
		},
		[76185] = {
			1036, -- [1]
			"Ascendant Lord Obsidius", -- [2]
		},
		[375071] = {
			2610, -- [1]
			"Lava Tentacles <Magmatusk>", -- [2]
		},
		[410365] = {
			2682, -- [1]
			"Warlord Kagni", -- [2]
		},
		[409598] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[75610] = {
			1040, -- [1]
			"Corla, Herald of Twilight", -- [2]
		},
		[256589] = {
			2094, -- [1]
			"Captain Raoul", -- [2]
		},
		[78807] = {
			1058, -- [1]
			"Ozruk", -- [2]
		},
		[369703] = {
			2556, -- [1]
			"Bromach", -- [2]
		},
		[76186] = {
			1036, -- [1]
			"Ascendant Lord Obsidius", -- [2]
		},
		[372262] = {
			2612, -- [1]
			"Qalashi Bonesplitter", -- [2]
		},
		[410369] = {
			2682, -- [1]
			"Warlord Kagni", -- [2]
		},
		[410625] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[381470] = {
			2570, -- [1]
			"Tricktotem", -- [2]
		},
		[404744] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[407046] = {
			2688, -- [1]
			"Dread Rift <Kazzara, the Hellforged>", -- [2]
		},
		[407302] = {
			2693, -- [1]
			"Neldris", -- [2]
		},
		[409093] = {
			2683, -- [1]
			"Magmorax", -- [2]
		},
		[199176] = {
			1792, -- [1]
			"Naraxas", -- [2]
		},
		[372266] = {
			2612, -- [1]
			"Qalashi Bonesplitter", -- [2]
		},
		[373939] = {
			2569, -- [1]
			"Rotburst Totem <Decatriarch Wratheye>", -- [2]
		},
		[373944] = {
			2569, -- [1]
			"Decatriarch Wratheye", -- [2]
		},
		[385029] = {
			2567, -- [1]
			"Fleshripper Vulture", -- [2]
		},
		[403057] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[192231] = {
			2683, -- [1]
			"Liquid Magma Totem <ßillymays-Area52>", -- [2]
		},
		[215929] = {
			1790, -- [1]
			"Blightshard Skitter <Rokmora>", -- [2]
		},
		[75851] = {
			1039, -- [1]
			"Karsh Steelbender", -- [2]
		},
		[410631] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[87618] = {
			1042, -- [1]
			"Asaad", -- [2]
		},
		[377559] = {
			2568, -- [1]
			"Treemouth", -- [2]
		},
		[404846] = {
			2683, -- [1]
			"Magmorax", -- [2]
		},
		[76188] = {
			1036, -- [1]
			"Ascendant Lord Obsidius", -- [2]
		},
		[387359] = {
			2618, -- [1]
			"[*] Waterlogged", -- [2]
		},
		[408576] = {
			2693, -- [1]
			"Rionthus", -- [2]
		},
		[389056] = {
			2615, -- [1]
			"Watcher Irideus", -- [2]
		},
		[405391] = {
			2693, -- [1]
			"Rionthus", -- [2]
		},
		[76508] = {
			1040, -- [1]
			"Crazed Mage", -- [2]
		},
		[76572] = {
			1040, -- [1]
			"Twilight Sadist", -- [2]
		},
		[375215] = {
			2616, -- [1]
			"Gulping Goliath", -- [2]
		},
		[404721] = {
			2683, -- [1]
			"Magmorax", -- [2]
		},
		[384764] = {
			2567, -- [1]
			"Rotfang Hyena <Gutshot>", -- [2]
		},
		[73564] = {
			1055, -- [1]
			"Siamat", -- [2]
		},
		[209921] = {
			1793, -- [1]
			"Dargrul", -- [2]
		},
		[83094] = {
			1055, -- [1]
			"Siamat", -- [2]
		},
		[378155] = {
			2570, -- [1]
			"Tricktotem", -- [2]
		},
		[387618] = {
			2618, -- [1]
			"Primalist Infuser", -- [2]
		},
		[82263] = {
			1053, -- [1]
			"Soul Fragment", -- [2]
		},
		[383015] = {
			1792, -- [1]
			"Poison Cleansing Totem <Stormart>", -- [2]
		},
		[404754] = {
			2685, -- [1]
			"Null Glimmer <Sarkareth>", -- [2]
		},
		[413546] = {
			2683, -- [1]
			"Magmorax", -- [2]
		},
		[386757] = {
			2617, -- [1]
			"Khajin the Unyielding", -- [2]
		},
		[103171] = {
			1882, -- [1]
			"[*] Blighted Arrows", -- [2]
		},
		[325984] = {
			1058, -- [1]
			"Ozruk", -- [2]
		},
		[31707] = {
			2684, -- [1]
			"Water Elemental", -- [2]
		},
		[409359] = {
			2682, -- [1]
			"Warlord Kagni", -- [2]
		},
		[210150] = {
			1792, -- [1]
			"Naraxas", -- [2]
		},
		[217851] = {
			1792, -- [1]
			"Naraxas", -- [2]
		},
		[89105] = {
			1043, -- [1]
			"Lurking Tempest", -- [2]
		},
		[78939] = {
			1058, -- [1]
			"Ozruk", -- [2]
		},
		[375241] = {
			2612, -- [1]
			"The Scorching Forge", -- [2]
		},
		[384161] = {
			2612, -- [1]
			"Qalashi Irontorch", -- [2]
		},
		[86292] = {
			1043, -- [1]
			"Ertan's Vortex", -- [2]
		},
		[419591] = {
			1791, -- [1]
			6, -- [2]
		},
		[411633] = {
			2683, -- [1]
			"[*] Burning Chains", -- [2]
		},
		[411236] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[104318] = {
			2687, -- [1]
			"Wild Imp <Flickers-Area52>", -- [2]
		},
		[376783] = {
			2611, -- [1]
			"Warlord Sargha", -- [2]
		},
		[102151] = {
			1884, -- [1]
			"Echo of Tyrande", -- [2]
		},
		[256005] = {
			2093, -- [1]
			"Sharkbait", -- [2]
		},
		[102149] = {
			1884, -- [1]
			"Moonlance <Echo of Tyrande>", -- [2]
		},
		[81677] = {
			1054, -- [1]
			"Frenzied Crocolisk", -- [2]
		},
		[377825] = {
			2555, -- [1]
			"[*] Burning Pitch", -- [2]
		},
		[258773] = {
			2093, -- [1]
			"Skycap'n Kragg", -- [2]
		},
		[405016] = {
			2687, -- [1]
			"Essence of Shadow", -- [2]
		},
		[374704] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[407544] = {
			2680, -- [1]
			"Rashok", -- [2]
		},
		[82137] = {
			1040, -- [1]
			"Rom'ogg Bonecrusher", -- [2]
		},
		[385442] = {
			2616, -- [1]
			"Gulping Goliath", -- [2]
		},
		[386559] = {
			2617, -- [1]
			"Khajin the Unyielding", -- [2]
		},
		[374839] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[76511] = {
			1040, -- [1]
			"Mad Prisoner", -- [2]
		},
		[384558] = {
			2567, -- [1]
			"Rotfang Hyena", -- [2]
		},
		[372538] = {
			2612, -- [1]
			"Lava Flare", -- [2]
		},
		[402461] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[403740] = {
			2683, -- [1]
			"Magmorax", -- [2]
		},
		[81690] = {
			1054, -- [1]
			"Lockmaw", -- [2]
		},
		[409367] = {
			2693, -- [1]
			"Neldris", -- [2]
		},
		[75571] = {
			1040, -- [1]
			"Rom'ogg Bonecrusher", -- [2]
		},
		[403741] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[404908] = {
			2687, -- [1]
			"Wild Imp <Flickers-Area52>", -- [2]
		},
		[374586] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[374842] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[408857] = {
			2680, -- [1]
			"Rashok", -- [2]
		},
		[401952] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[102381] = {
			1271, -- [1]
			"Murozond", -- [2]
		},
		[200721] = {
			1793, -- [1]
			"Dargrul", -- [2]
		},
		[205549] = {
			1792, -- [1]
			"Naraxas", -- [2]
		},
		[376997] = {
			2564, -- [1]
			"Crawth", -- [2]
		},
		[82522] = {
			1053, -- [1]
			"High Prophet Barim", -- [2]
		},
		[408431] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[82764] = {
			1052, -- [1]
			"Oathsworn Pathfinder", -- [2]
		},
		[407069] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[411417] = {
			2683, -- [1]
			"Magmorax", -- [2]
		},
		[403699] = {
			2687, -- [1]
			"Essence of Shadow", -- [2]
		},
		[407919] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[81947] = {
			1053, -- [1]
			"High Prophet Barim", -- [2]
		},
		[217090] = {
			1793, -- [1]
			"Dargrul", -- [2]
		},
		[196810] = {
			2687, -- [1]
			"Divine Image <Grica-Trollbane>", -- [2]
		},
		[82139] = {
			1053, -- [1]
			"High Prophet Barim", -- [2]
		},
		[388882] = {
			2618, -- [1]
			"Primalist Infuser", -- [2]
		},
		[407327] = {
			2693, -- [1]
			"Thadrion", -- [2]
		},
		[411230] = {
			2682, -- [1]
			"Warlord Kagni", -- [2]
		},
		[403747] = {
			2683, -- [1]
			"Magmorax", -- [2]
		},
		[407329] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[409238] = {
			2683, -- [1]
			"Magmorax", -- [2]
		},
		[102472] = {
			1884, -- [1]
			"Echo of Tyrande", -- [2]
		},
		[403748] = {
			2687, -- [1]
			"Eternal Blaze", -- [2]
		},
		[408160] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[256477] = {
			2095, -- [1]
			"Hammer Shark", -- [2]
		},
		[410654] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[257756] = {
			2094, -- [1]
			"Bilge Rat Buccaneer", -- [2]
		},
		[181089] = {
			1041, -- [1]
			"Altairus", -- [2]
		},
		[255966] = {
			2093, -- [1]
			"Skycap'n Kragg", -- [2]
		},
		[404425] = {
			2685, -- [1]
			"Desolate Blossom", -- [2]
		},
		[76002] = {
			1039, -- [1]
			"Karsh Steelbender", -- [2]
		},
		[81942] = {
			1053, -- [1]
			"Heaven's Fury", -- [2]
		},
		[64695] = {
			2689, -- [1]
			"Earthgrab Totem <Bartank-Scilla>", -- [2]
		},
		[404942] = {
			2689, -- [1]
			"Zskarn", -- [2]
		},
		[257757] = {
			2094, -- [1]
			"Bilge Rat Buccaneer", -- [2]
		},
		[101619] = {
			1881, -- [1]
			"[*] Magma", -- [2]
		},
		[401898] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[272554] = {
			2095, -- [1]
			"[*] Bloody Mess", -- [2]
		},
		[405433] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[101592] = {
			1271, -- [1]
			"Murozond", -- [2]
		},
		[384827] = {
			2567, -- [1]
			"Gutshot", -- [2]
		},
		[403497] = {
			2685, -- [1]
			"Astral Formation <Sarkareth>", -- [2]
		},
		[268717] = {
			2093, -- [1]
			"Sharkbait", -- [2]
		},
		[95248] = {
			1053, -- [1]
			"Blaze of the Heavens", -- [2]
		},
		[406311] = {
			2693, -- [1]
			"Neldris", -- [2]
		},
		[374854] = {
			2613, -- [1]
			"Grounding Spear <Chargath, Bane of Scales>", -- [2]
		},
		[374343] = {
			2565, -- [1]
			"Echo of Doragosa", -- [2]
		},
		[84251] = {
			1052, -- [1]
			"Earthquake", -- [2]
		},
		[418588] = {
			1791, -- [1]
			6, -- [2]
		},
		[400430] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[30213] = {
			2688, -- [1]
			"Felguard <Flickers-Area52>", -- [2]
		},
		[402989] = {
			2683, -- [1]
			"Magmorax", -- [2]
		},
		[406313] = {
			2693, -- [1]
			"Neldris", -- [2]
		},
		[75428] = {
			1040, -- [1]
			"Rom'ogg Bonecrusher", -- [2]
		},
		[192799] = {
			1790, -- [1]
			"Blightshard Skitter <Rokmora>", -- [2]
		},
		[384575] = {
			2567, -- [1]
			"Rotfang Hyena", -- [2]
		},
		[84799] = {
			1054, -- [1]
			"Augh", -- [2]
		},
		[400432] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[405599] = {
			2693, -- [1]
			"Thadrion", -- [2]
		},
		[95249] = {
			1053, -- [1]
			"Blaze of the Heavens", -- [2]
		},
		[404269] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[413136] = {
			2096, -- [1]
			"Harlan Sweete", -- [2]
		},
		[408873] = {
			2682, -- [1]
			"Warlord Kagni", -- [2]
		},
		[114942] = {
			2610, -- [1]
			"Healing Tide Totem <Imshorty-Illidan>", -- [2]
		},
		[188046] = {
			2680, -- [1]
			"Denizen of the Dream <Unbearable-Gorgonnash>", -- [2]
		},
		[389181] = {
			2615, -- [1]
			"Watcher Irideus", -- [2]
		},
		[85467] = {
			1043, -- [1]
			"Lurking Tempest", -- [2]
		},
		[76502] = {
			1040, -- [1]
			"Twilight Sadist", -- [2]
		},
		[377844] = {
			2570, -- [1]
			"Rira Hackclaw", -- [2]
		},
		[407596] = {
			2680, -- [1]
			"Rashok", -- [2]
		},
		[401383] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[373326] = {
			2565, -- [1]
			"Echo of Doragosa", -- [2]
		},
		[408620] = {
			2682, -- [1]
			"Obsidian Guard", -- [2]
		},
		[407597] = {
			2680, -- [1]
			"Rashok", -- [2]
		},
		[198428] = {
			1791, -- [1]
			"Ularogg Cragshaper", -- [2]
		},
		[80800] = {
			1059, -- [1]
			"Lava Fissure", -- [2]
		},
		[389007] = {
			2565, -- [1]
			"[*] Wild Energy", -- [2]
		},
		[405736] = {
			2689, -- [1]
			"Zskarn", -- [2]
		},
		[80801] = {
			1059, -- [1]
			"Lava Fissure", -- [2]
		},
		[369696] = {
			2556, -- [1]
			"Stonevault Ambusher", -- [2]
		},
		[372561] = {
			2613, -- [1]
			"Qalashi Hunter", -- [2]
		},
		[369791] = {
			2555, -- [1]
			"Eric \"The Swift\"", -- [2]
		},
		[408367] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[374352] = {
			2565, -- [1]
			"Echo of Doragosa", -- [2]
		},
		[406321] = {
			2680, -- [1]
			"[*] Lava Vortex", -- [2]
		},
		[385691] = {
			2616, -- [1]
			"Gulping Goliath", -- [2]
		},
		[407856] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[405812] = {
			2689, -- [1]
			"Zskarn", -- [2]
		},
		[381770] = {
			2568, -- [1]
			"Decaying Slime <Treemouth>", -- [2]
		},
		[408624] = {
			2682, -- [1]
			"Obsidian Guard", -- [2]
		},
		[389443] = {
			2615, -- [1]
			"Nullification Device", -- [2]
		},
		[374355] = {
			2612, -- [1]
			"The Scorching Forge", -- [2]
		},
		[200732] = {
			1793, -- [1]
			"Dargrul", -- [2]
		},
		[403510] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[404789] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[272055] = {
			2093, -- [1]
			"Sharkbait", -- [2]
		},
		[408370] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[375890] = {
			2610, -- [1]
			"Magmatusk", -- [2]
		},
		[256594] = {
			2094, -- [1]
			"Captain Raoul", -- [2]
		},
		[384623] = {
			2612, -- [1]
			"Qalashi Blacksmith", -- [2]
		},
		[372566] = {
			2613, -- [1]
			"Qalashi Hunter", -- [2]
		},
		[89753] = {
			2688, -- [1]
			"Felguard <Flickers-Area52>", -- [2]
		},
		[389446] = {
			2615, -- [1]
			"Nullification Device", -- [2]
		},
		[378229] = {
			2570, -- [1]
			"Gashtooth", -- [2]
		},
		[408372] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[369754] = {
			2556, -- [1]
			"Bromach", -- [2]
		},
		[388424] = {
			2618, -- [1]
			"Primal Tsunami", -- [2]
		},
		[408117] = {
			2682, -- [1]
			"Warlord Kagni", -- [2]
		},
		[408373] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[385451] = {
			2616, -- [1]
			"Gulping Goliath", -- [2]
		},
		[376149] = {
			2569, -- [1]
			"Choking Rotcloud <Decatriarch Wratheye>", -- [2]
		},
		[102158] = {
			1881, -- [1]
			"Time-Twisted Seer", -- [2]
		},
		[405082] = {
			2687, -- [1]
			"Essence of Shadow", -- [2]
		},
		[410676] = {
			2683, -- [1]
			"Magmorax", -- [2]
		},
		[183088] = {
			1791, -- [1]
			"Mightstone Breaker", -- [2]
		},
		[404027] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[372570] = {
			2613, -- [1]
			"Qalashi Hunter", -- [2]
		},
		[406585] = {
			2682, -- [1]
			"Warlord Kagni", -- [2]
		},
		[415025] = {
			2682, -- [1]
			"[*] Paracausal Fragment of Frostmourne", -- [2]
		},
		[374361] = {
			2565, -- [1]
			"Echo of Doragosa", -- [2]
		},
		[256489] = {
			2095, -- [1]
			"Trothak", -- [2]
		},
		[407196] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[385359] = {
			2567, -- [1]
			"Gutshot", -- [2]
		},
		[403771] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[373742] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[256106] = {
			2093, -- [1]
			"Skycap'n Kragg", -- [2]
		},
		[405645] = {
			2687, -- [1]
			"Shadowflame Amalgamation", -- [2]
		},
		[403515] = {
			2685, -- [1]
			"Astral Formation <Sarkareth>", -- [2]
		},
		[375209] = {
			2612, -- [1]
			"The Scorching Forge", -- [2]
		},
		[400450] = {
			2682, -- [1]
			"Warlord Kagni", -- [2]
		},
		[405821] = {
			2680, -- [1]
			"Rashok", -- [2]
		},
		[404031] = {
			2693, -- [1]
			"Neldris", -- [2]
		},
		[406333] = {
			2680, -- [1]
			"Rashok", -- [2]
		},
		[412472] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[405822] = {
			2680, -- [1]
			"Rashok", -- [2]
		},
		[374365] = {
			2610, -- [1]
			"Magmatusk", -- [2]
		},
		[382805] = {
			2568, -- [1]
			"Wilted Oak", -- [2]
		},
		[383061] = {
			2683, -- [1]
			"Liquid Magma Totem <ßillymays-Area52>", -- [2]
		},
		[75823] = {
			1038, -- [1]
			"Corla, Herald of Twilight", -- [2]
		},
		[201633] = {
			2682, -- [1]
			"Earthen Wall Totem <Daffné-Zul'jin>", -- [2]
		},
		[198028] = {
			1790, -- [1]
			"[*] Crystalline Ground", -- [2]
		},
		[83066] = {
			1055, -- [1]
			"Siamat", -- [2]
		},
		[76584] = {
			1038, -- [1]
			"Twilight Zealot", -- [2]
		},
		[413263] = {
			1042, -- [1]
			"Skyfall Nova <Asaad>", -- [2]
		},
		[405819] = {
			2680, -- [1]
			"Rashok", -- [2]
		},
		[377034] = {
			2564, -- [1]
			"Crawth", -- [2]
		},
		[101840] = {
			1881, -- [1]
			"Echo of Baine", -- [2]
		},
		[369697] = {
			2556, -- [1]
			"Stonevault Ambusher", -- [2]
		},
		[367521] = {
			2567, -- [1]
			"Rotbow Stalker", -- [2]
		},
		[397386] = {
			2682, -- [1]
			"Magma Mystic", -- [2]
		},
		[384343] = {
			2567, -- [1]
			"Gutshot", -- [2]
		},
		[377004] = {
			2564, -- [1]
			"Crawth", -- [2]
		},
		[406207] = {
			2689, -- [1]
			"[*] Tactical Destruction", -- [2]
		},
		[377950] = {
			2570, -- [1]
			"Tricktotem", -- [2]
		},
		[101627] = {
			1881, -- [1]
			"Echo of Baine", -- [2]
		},
		[406851] = {
			2680, -- [1]
			"Rashok", -- [2]
		},
		[405316] = {
			2680, -- [1]
			"Rashok", -- [2]
		},
		[401480] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[83171] = {
			1052, -- [1]
			"[*] Mystic Trap", -- [2]
		},
		[404713] = {
			2693, -- [1]
			"Neldris", -- [2]
		},
		[256494] = {
			2095, -- [1]
			"Trothak", -- [2]
		},
		[91872] = {
			1055, -- [1]
			"Servant of Siamat <[*] Static Shock>", -- [2]
		},
		[378208] = {
			2570, -- [1]
			"Gashtooth", -- [2]
		},
		[408131] = {
			2684, -- [1]
			"Voice From Beyond", -- [2]
		},
		[403272] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[406597] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[76522] = {
			1038, -- [1]
			"Twilight Zealot", -- [2]
		},
		[83776] = {
			1054, -- [1]
			"Pygmy Firebreather", -- [2]
		},
		[278467] = {
			2094, -- [1]
			"Rummy Mancomb", -- [2]
		},
		[257908] = {
			2096, -- [1]
			"Irontide Officer", -- [2]
		},
		[78859] = {
			1058, -- [1]
			"Ozruk", -- [2]
		},
		[375397] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[102193] = {
			1884, -- [1]
			"Echo of Tyrande", -- [2]
		},
		[374641] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[382303] = {
			2556, -- [1]
			"Bromach", -- [2]
		},
		[91853] = {
			1055, -- [1]
			"Siamat", -- [2]
		},
		[375204] = {
			2610, -- [1]
			"[*] Liquid Hot Magma", -- [2]
		},
		[376933] = {
			2568, -- [1]
			"Treemouth", -- [2]
		},
		[369781] = {
			2555, -- [1]
			"Eric \"The Swift\"", -- [2]
		},
		[376934] = {
			2568, -- [1]
			"Treemouth", -- [2]
		},
		[82533] = {
			1053, -- [1]
			"Harbinger of Darkness", -- [2]
		},
		[406601] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[384351] = {
			2615, -- [1]
			"Watcher Irideus", -- [2]
		},
		[378020] = {
			2570, -- [1]
			"Gashtooth", -- [2]
		},
		[82789] = {
			1052, -- [1]
			"Oathsworn Skinner", -- [2]
		},
		[80807] = {
			1059, -- [1]
			"Slabhide", -- [2]
		},
		[198475] = {
			1791, -- [1]
			"Ularogg Cragshaper", -- [2]
		},
		[378764] = {
			2568, -- [1]
			"Treemouth", -- [2]
		},
		[321538] = {
			1792, -- [1]
			"Cat", -- [2]
		},
		[385181] = {
			2616, -- [1]
			"Gulping Goliath", -- [2]
		},
		[404813] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[386181] = {
			2562, -- [1]
			"Vexamus <Magic Book>", -- [2]
		},
		[374635] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[410351] = {
			2682, -- [1]
			"Warlord Kagni", -- [2]
		},
		[376170] = {
			2569, -- [1]
			"Decatriarch Wratheye", -- [2]
		},
		[384662] = {
			2612, -- [1]
			"Forgewrought Monstrosity", -- [2]
		},
		[256979] = {
			2094, -- [1]
			"Captain Eudora", -- [2]
		},
		[410953] = {
			2684, -- [1]
			"[*] Volcanic Heart", -- [2]
		},
		[76524] = {
			1038, -- [1]
			"Twilight Zealot", -- [2]
		},
		[32409] = {
			2570, -- [1]
			"[*] Shadow Word: Death", -- [2]
		},
		[381444] = {
			2570, -- [1]
			"Rira Hackclaw", -- [2]
		},
		[83877] = {
			1052, -- [1]
			"Oathsworn Pathfinder", -- [2]
		},
		[258381] = {
			2094, -- [1]
			"Captain Eudora", -- [2]
		},
		[391773] = {
			2611, -- [1]
			"Dragon's Eruption", -- [2]
		},
		[96260] = {
			1042, -- [1]
			"Asaad", -- [2]
		},
		[401318] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[15284] = {
			1039, -- [1]
			"Karsh Steelbender", -- [2]
		},
		[384353] = {
			2567, -- [1]
			"Gutshot", -- [2]
		},
		[383840] = {
			2615, -- [1]
			"Watcher Irideus", -- [2]
		},
		[384015] = {
			2615, -- [1]
			"Watcher Irideus", -- [2]
		},
		[183100] = {
			1791, -- [1]
			"Mightstone Breaker", -- [2]
		},
		[86881] = {
			1056, -- [1]
			"Corborus", -- [2]
		},
		[403284] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[377965] = {
			2570, -- [1]
			"Tricktotem", -- [2]
		},
		[76617] = {
			1039, -- [1]
			"Conflagration", -- [2]
		},
		[76589] = {
			1038, -- [1]
			"Twilight Zealot", -- [2]
		},
		[396124] = {
			2567, -- [1]
			"Gutshot", -- [2]
		},
		[413151] = {
			1043, -- [1]
			"Grand Vizier Ertan", -- [2]
		},
		[404032] = {
			2693, -- [1]
			"Thadrion", -- [2]
		},
		[398938] = {
			2682, -- [1]
			"Warlord Kagni", -- [2]
		},
		[401401] = {
			2682, -- [1]
			"Flamebound Huntsman", -- [2]
		},
		[256363] = {
			2095, -- [1]
			"Trothak", -- [2]
		},
		[413145] = {
			2096, -- [1]
			"Harlan Sweete", -- [2]
		},
		[375416] = {
			2568, -- [1]
			"Infected Lasher <Wilted Oak>", -- [2]
		},
		[374471] = {
			2613, -- [1]
			"Grounding Spear <Chargath, Bane of Scales>", -- [2]
		},
		[403543] = {
			2680, -- [1]
			"[*] Lava Wave", -- [2]
		},
		[384577] = {
			2567, -- [1]
			"Rotfang Hyena", -- [2]
		},
		[384148] = {
			2567, -- [1]
			"Rotfang Hyena <Gutshot>", -- [2]
		},
		[76680] = {
			1036, -- [1]
			"Twilight Element Warden", -- [2]
		},
		[405462] = {
			2689, -- [1]
			"[*] Dragonfire Traps", -- [2]
		},
		[378057] = {
			2568, -- [1]
			"Decaying Slime <Treemouth>", -- [2]
		},
		[374389] = {
			2616, -- [1]
			"Curious Swoglet", -- [2]
		},
		[406358] = {
			2693, -- [1]
			"Neldris", -- [2]
		},
		[375924] = {
			2555, -- [1]
			"Eric \"The Swift\"", -- [2]
		},
		[397383] = {
			2682, -- [1]
			"Magma Mystic", -- [2]
		},
		[413264] = {
			1042, -- [1]
			"Skyfall Nova <Asaad>", -- [2]
		},
		[386202] = {
			2562, -- [1]
			"Vexamus <Magic Book>", -- [2]
		},
		[401500] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[377204] = {
			2611, -- [1]
			"Warlord Sargha", -- [2]
		},
		[86309] = {
			1043, -- [1]
			"Ertan's Vortex", -- [2]
		},
		[406678] = {
			2689, -- [1]
			"Zskarn", -- [2]
		},
		[81630] = {
			1054, -- [1]
			"Lockmaw", -- [2]
		},
		[79340] = {
			1057, -- [1]
			"High Priestess Azil", -- [2]
		},
		[387691] = {
			2562, -- [1]
			"Vexamus <Magic Book>", -- [2]
		},
		[52042] = {
			1793, -- [1]
			"Healing Stream Totem <Stormart>", -- [2]
		},
		[374533] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[81642] = {
			1054, -- [1]
			"Lockmaw", -- [2]
		},
		[81706] = {
			1054, -- [1]
			"Lockmaw", -- [2]
		},
		[406516] = {
			2688, -- [1]
			"Kazzara, the Hellforged", -- [2]
		},
		[407641] = {
			2680, -- [1]
			"Rashok", -- [2]
		},
		[378230] = {
			2570, -- [1]
			"Gashtooth", -- [2]
		},
		[405084] = {
			2687, -- [1]
			"Essence of Shadow", -- [2]
		},
		[82320] = {
			1053, -- [1]
			"High Prophet Barim", -- [2]
		},
		[83113] = {
			1052, -- [1]
			"General Husam", -- [2]
		},
		[405042] = {
			2693, -- [1]
			"Thadrion", -- [2]
		},
		[404062] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[386562] = {
			2617, -- [1]
			"Khajin the Unyielding", -- [2]
		},
		[369792] = {
			2555, -- [1]
			"Eric \"The Swift\"", -- [2]
		},
		[410968] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[369573] = {
			2555, -- [1]
			"Baelog", -- [2]
		},
		[406365] = {
			2693, -- [1]
			"Neldris", -- [2]
		},
		[75441] = {
			1040, -- [1]
			"Chains of Woe <Rom'ogg Bonecrusher>", -- [2]
		},
		[198963] = {
			1792, -- [1]
			"Naraxas", -- [2]
		},
		[257402] = {
			2096, -- [1]
			"Harlan Sweete", -- [2]
		},
		[256358] = {
			2095, -- [1]
			"Trothak", -- [2]
		},
		[82858] = {
			1057, -- [1]
			"High Priestess Azil", -- [2]
		},
		[8599] = {
			1040, -- [1]
			"Mad Prisoner", -- [2]
		},
		[196809] = {
			2687, -- [1]
			"Divine Image <Grica-Trollbane>", -- [2]
		},
		[76594] = {
			1038, -- [1]
			"Twilight Zealot", -- [2]
		},
		[404456] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[378235] = {
			2570, -- [1]
			"Gashtooth", -- [2]
		},
		[407936] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[372971] = {
			2612, -- [1]
			"Qalashi Blacksmith", -- [2]
		},
		[405601] = {
			2693, -- [1]
			"Thadrion", -- [2]
		},
		[413147] = {
			2096, -- [1]
			"Harlan Sweete", -- [2]
		},
		[84521] = {
			1055, -- [1]
			"Servant of Siamat <[*] Static Shock>", -- [2]
		},
		[255952] = {
			2093, -- [1]
			"Skycap'n Kragg", -- [2]
		},
		[401510] = {
			2680, -- [1]
			"Rashok", -- [2]
		},
		[81644] = {
			1054, -- [1]
			"[*] Dust Flail", -- [2]
		},
		[404068] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[402053] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[83455] = {
			1055, -- [1]
			"Minion of Siamat", -- [2]
		},
		[401400] = {
			2682, -- [1]
			"Flamebound Huntsman", -- [2]
		},
		[410207] = {
			2682, -- [1]
			"Warlord Kagni", -- [2]
		},
		[83051] = {
			1055, -- [1]
			"Cloud Burst", -- [2]
		},
		[404448] = {
			2680, -- [1]
			"Rashok", -- [2]
		},
		[406530] = {
			2688, -- [1]
			"[*] Riftburn", -- [2]
		},
		[374812] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[200154] = {
			1793, -- [1]
			"Molten Charskin <Dargrul>", -- [2]
		},
		[403559] = {
			2687, -- [1]
			"Essence of Shadow", -- [2]
		},
		[407048] = {
			2684, -- [1]
			"Neltharion", -- [2]
		},
		[84522] = {
			1055, -- [1]
			"Servant of Siamat <[*] Static Shock>", -- [2]
		},
		[401258] = {
			2682, -- [1]
			"Warlord Kagni", -- [2]
		},
		[198024] = {
			1790, -- [1]
			"Rokmora", -- [2]
		},
		[383935] = {
			2615, -- [1]
			"Watcher Irideus", -- [2]
		},
		[105238] = {
			1881, -- [1]
			"Undying Flame", -- [2]
		},
		[387264] = {
			2569, -- [1]
			"Decatriarch Wratheye", -- [2]
		},
		[76612] = {
			1038, -- [1]
			"Twilight Zealot", -- [2]
		},
		[377017] = {
			2611, -- [1]
			"Warlord Sargha", -- [2]
		},
		[272046] = {
			2093, -- [1]
			"Sharkbait", -- [2]
		},
		[407552] = {
			2693, -- [1]
			"Rionthus", -- [2]
		},
		[199817] = {
			1792, -- [1]
			"Naraxas", -- [2]
		},
		[405383] = {
			2693, -- [1]
			"Thadrion", -- [2]
		},
		[403978] = {
			2689, -- [1]
			"Zskarn", -- [2]
		},
		[408422] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[373896] = {
			2569, -- [1]
			"Decatriarch Wratheye", -- [2]
		},
		[401809] = {
			2687, -- [1]
			"Essence of Shadow", -- [2]
		},
		[377477] = {
			2611, -- [1]
			"Warlord Sargha", -- [2]
		},
		[402050] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[386173] = {
			2562, -- [1]
			"Vexamus <Magic Book>", -- [2]
		},
		[377222] = {
			2568, -- [1]
			"[*] Consume", -- [2]
		},
		[101412] = {
			1882, -- [1]
			"Echo of Sylvanas", -- [2]
		},
		[402207] = {
			2688, -- [1]
			"[*] Ray of Anguish", -- [2]
		},
		[89212] = {
			1052, -- [1]
			"Sharptalon Eagle <Oathsworn Pathfinder>", -- [2]
		},
		[192800] = {
			1790, -- [1]
			"[*] Choking Dust", -- [2]
		},
		[374410] = {
			2610, -- [1]
			"Magmatusk", -- [2]
		},
		[408425] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[256551] = {
			2095, -- [1]
			"Hammer Shark", -- [2]
		},
		[193376] = {
			1791, -- [1]
			"Ularogg Cragshaper", -- [2]
		},
		[389179] = {
			2615, -- [1]
			"Watcher Irideus", -- [2]
		},
		[390968] = {
			2568, -- [1]
			"Treemouth", -- [2]
		},
		[193375] = {
			1791, -- [1]
			"Ularogg Cragshaper", -- [2]
		},
		[79345] = {
			1057, -- [1]
			"High Priestess Azil", -- [2]
		},
		[411240] = {
			2685, -- [1]
			"Sarkareth", -- [2]
		},
		[383875] = {
			2568, -- [1]
			"Treemouth", -- [2]
		},
		[84987] = {
			1055, -- [1]
			"Siamat", -- [2]
		},
		[82670] = {
			1052, -- [1]
			"Oathsworn Captain", -- [2]
		},
		[375436] = {
			2610, -- [1]
			"Magmatusk", -- [2]
		},
		[403459] = {
			2687, -- [1]
			"Essence of Shadow", -- [2]
		},
		[406206] = {
			2689, -- [1]
			"[*] Tactical Destruction", -- [2]
		},
		[369675] = {
			2556, -- [1]
			"Stonevault Geomancer", -- [2]
		},
	},
	["immersion_pets_on_solo_play"] = false,
	["npcid_ignored"] = {
	},
	["dungeon_data"] = {
	},
	["report_pos"] = {
		1, -- [1]
		1, -- [2]
	},
	["latest_report_table"] = {
	},
	["exp90temp"] = {
		["delete_damage_TCOB"] = true,
	},
	["always_use_profile"] = false,
	["deathlog_healingdone_min_arena"] = 400,
	["spell_school_cache"] = {
		["Intensifying Flame"] = 4,
		["Dust Flail"] = 8,
		["Flame Breath"] = 4,
		["Shadow Word: Pain"] = 32,
		["Terror Claws"] = 36,
		["Rotting from Within"] = 8,
		["Flaming Cudgel"] = 4,
		["Gathered Storms"] = 8,
		["Barbed Shot"] = 1,
		["Liquid Hot Magma"] = 4,
		["Collapsed Earth"] = 8,
		["Shadowflame Contamination"] = 36,
		["Magma Breaker"] = 4,
		["Blazing Barrier"] = 4,
		["Holy Word: Chastise"] = 2,
		["Fiery Surge"] = 4,
		["Corrupted Mana"] = 64,
		["Fireball"] = 4,
		["Shocking Quake"] = 8,
		["Arcane Intellect"] = 64,
		["Magma Wave"] = 4,
		["Infectious Plague"] = 8,
		["Crystalline Ground"] = 8,
		["Frozen Orb"] = 16,
		["Explosive Shot"] = 4,
		["Tears of Elune"] = 64,
		["Blaze of the Heavens"] = 4,
		["Corrupting Shadow"] = 32,
		["Adaptive Swarm"] = 32,
		["Dreadnaught"] = 1,
		["Phoenix Flames"] = 4,
		["Magma Lob"] = 4,
		["Gulp Swog Toxin"] = 8,
		["Melee"] = 1,
		["Shiv"] = 1,
		["Scorching Heatwave"] = 36,
		["Seared"] = 4,
		["Overpowering Croak"] = 1,
		["Spell Reflection"] = 1,
		["Toxic Retch"] = 8,
		["Resonating Orb"] = 64,
		["Crusader Strike"] = 1,
		["Temporal Anomaly"] = 64,
		["Volcanic Heart"] = 12,
		["Cave In"] = 1,
		["Burning Metal"] = 4,
		["Serpent Sting"] = 8,
		["Bladed Shield Spike"] = 1,
		["Djaradin Lava"] = 4,
		["Germinate"] = 1,
		["Dazzled"] = 64,
		["Avalanche"] = 16,
		["Glacial Surge"] = 16,
		["Gash Frenzy"] = 1,
		["Power Field"] = 8,
		["Chill Streak"] = 16,
		["Frost Strike"] = 16,
		["Storm's Edge"] = 8,
		["Heat Wave"] = 4,
		["Ray of Anguish"] = 36,
		["Arctic Bola"] = 16,
		["Necrotic Breath"] = 8,
		["Energy Blast"] = 64,
		["Crystal Barrage"] = 1,
		["Marked for Butchery"] = 1,
		["Healing Tide"] = 8,
		["Flailing Shark"] = 1,
		["Lava Strike"] = 4,
		["Inferno Cloak"] = 4,
		["Chains of Ice"] = 16,
		["Magma Flow"] = 12,
		["Arbalest Fire"] = 1,
		["Hamstring"] = 1,
		["Shadow Strike"] = 32,
		["Shadowcore Oil Blast"] = 32,
		["Rotburst Totem"] = 8,
		["Remorseless Winter"] = 16,
		["Burning Ember"] = 1,
		["Dragging Harpoon"] = 1,
		["Penance"] = 2,
		["Goin' Bananas"] = 1,
		["Roiling Shadowflame"] = 36,
		["Harpoon"] = 1,
		["Blizzard"] = 16,
		["Lava Lash"] = 4,
		["Rancid Maw"] = 8,
		["Choking Dust"] = 8,
		["Lava Vortex"] = 4,
		["Biting Cold"] = 16,
		["Blistering Twilight"] = 36,
		["Overpower"] = 1,
		["Strike of the Mountain"] = 8,
		["Starfire"] = 64,
		["Warbreaker"] = 1,
		["Heartfire"] = 6,
		["Searing Breath"] = 4,
		["Ignara's Fury"] = 4,
		["Feral Frenzy"] = 1,
		["Deep Wounds"] = 1,
		["Chain Lightning"] = 8,
		["Deep Breath"] = 12,
		["Schism"] = 32,
		["Chimaeral Sting"] = 8,
		["Searing Heat"] = 4,
		["Mystic Trap"] = 4,
		["Bold Ambush"] = 1,
		["Rake"] = 1,
		["Rip"] = 1,
		["Sundered Reality"] = 32,
		["Shadow Covenant"] = 32,
		["Incinerating Maws"] = 4,
		["Burning Heat"] = 4,
		["Scorching Breath"] = 4,
		["Burning Rush"] = 4,
		["Motes of Oblivion"] = 32,
		["Magma Eruption"] = 4,
		["Scorching Roar"] = 4,
		["Withering Away!"] = 8,
		["Thunder Crash"] = 8,
		["Cave Rubble"] = 1,
		["Wings of Extinction"] = 36,
		["Living Bomb"] = 4,
		["Infernal Heart"] = 36,
		["Spearhead"] = 1,
		["Eruption"] = 4,
		["Ensnaring Trap"] = 1,
		["Liquefying Ooze"] = 8,
		["Crumbling Facade"] = 12,
		["Tiro-Autom�tico"] = 1,
		["Restorative Mists"] = 8,
		["Roar of Sacrifice"] = 8,
		["Ground Rupture"] = 1,
		["Violent Reaction"] = 4,
		["Astral Eruption"] = 32,
		["Coordinated Assault"] = 1,
		["Violent Eruption"] = 64,
		["Meteor Burn"] = 4,
		["Thunderous Roar"] = 1,
		["Rogue Waves"] = 16,
		["Frost Cyclone"] = 16,
		["Master Marksman"] = 1,
		["Rotting Creek"] = 8,
		["Latent Poison"] = 8,
		["Disintegrated"] = 64,
		["Ancient Fury"] = 36,
		["Mass Disintegrate"] = 64,
		["Flame Shock"] = 12,
		["Bite"] = 1,
		["Meteor"] = 4,
		["Bellowing Roar"] = 64,
		["Glimmer of Light"] = 2,
		["Lingering Umbra"] = 32,
		["Shrapnel Bomb"] = 4,
		["Dread Rift"] = 36,
		["Reverberating Slam"] = 1,
		["Pheromone Bomb"] = 4,
		["Howling Blast"] = 16,
		["Arcane Missiles"] = 64,
		["Echoing Fissure"] = 12,
		["Rearm"] = 1,
		["Crashing Star"] = 72,
		["Hellbeam"] = 36,
		["Swirling Shadowflame"] = 36,
		["Lava Splash"] = 4,
		["Slam"] = 1,
		["Crashing Tsunami"] = 16,
		["Blast Wave"] = 4,
		["Sunfire"] = 8,
		["Devastating Leap"] = 12,
		["Shooting Stars"] = 72,
		["Revenant's Blood"] = 36,
		["Flame Eruption"] = 4,
		["Burning Ground"] = 4,
		["Fiery Debris"] = 4,
		["Lightning Arc"] = 8,
		["Burning Claws"] = 4,
		["Blazing Spear"] = 4,
		["Immolate"] = 4,
		["Rend"] = 1,
		["Execute"] = 1,
		["Flanking Strike"] = 1,
		["Vile Coating"] = 8,
		["Bleeding Gash"] = 1,
		["Fungal Growth"] = 8,
		["Ravager"] = 1,
		["Shadow Prison"] = 32,
		["Purge the Wicked"] = 6,
		["Holy Nova"] = 2,
		["Volcanic Plume"] = 4,
		["Frostwhelp's Aid"] = 16,
		["Waterbolt"] = 16,
		["Ferocious Bite"] = 1,
		["Gloom Conflagration"] = 36,
		["Oblivion"] = 32,
		["Engulfing Heat"] = 36,
		["Ice Nova"] = 16,
		["Lightning Shield"] = 8,
		["Smite"] = 2,
		["Wailing Winds"] = 8,
		["Frost Nova"] = 16,
		["Storming"] = 8,
		["Kill Shot"] = 1,
		["Cyclone Shield"] = 8,
		["Tyr's Enforcer"] = 2,
		["Fist of Stone"] = 1,
		["Molten Blast"] = 4,
		["Launched Thorns"] = 8,
		["Conflagration"] = 4,
		["Glittering Surge"] = 64,
		["Shockwave"] = 1,
		["Blazing Breath"] = 4,
		["Scatter Shot"] = 1,
		["Barrel Smash"] = 1,
		["Erupted Ground"] = 4,
		["Rushing Darkness"] = 32,
		["Halo"] = 2,
		["Slow"] = 64,
		["Overwhelming Rage"] = 16,
		["Flame Gout"] = 4,
		["Mana Bomb"] = 64,
		["Fatal Mark"] = 1,
		["Burst"] = 8,
		["Storm Bolt"] = 1,
		["Starfall"] = 72,
		["Maim"] = 1,
		["Hard Impact"] = 1,
		["Internal Bleeding"] = 1,
		["Starsurge"] = 72,
		["Frost Strike Off-Hand"] = 16,
		["Forgewrought Fury"] = 4,
		["Desolate Blossom"] = 32,
		["Bloody Mess"] = 1,
		["Fury of Elune"] = 72,
		["Coalescing Void"] = 32,
		["Butchery"] = 1,
		["Unstable Flames"] = 4,
		["Fel Armor"] = 32,
		["Static Shock"] = 8,
		["Gravity Well"] = 32,
		["Forgestorm"] = 4,
		["Molten Spittle"] = 4,
		["Throw Totem"] = 1,
		["Blazing Heat"] = 4,
		["Thrash"] = 1,
		["Pyroblast"] = 4,
		["Impending Victory"] = 1,
		["Fiery Meteor"] = 4,
		["Depletion"] = 1,
		["Scorching Bomb"] = 4,
		["Infused Globule"] = 16,
		["Obliterate Off-Hand"] = 1,
		["Volatile Spew"] = 64,
		["Searing Slam"] = 4,
		["Gulp"] = 8,
		["Volcanic Blast"] = 12,
		["Haymaker"] = 1,
		["Splintered Shadow"] = 32,
		["Hallowed Ground"] = 2,
		["Cleave"] = 1,
		["Orbital Strike"] = 72,
		["Dampening Wave"] = 32,
		["Entropic Embrace"] = 48,
		["Auto Shot"] = 1,
		["Bladestorm"] = 1,
		["Corpo-a-Corpo"] = 1,
		["Burning Chains"] = 4,
		["Searing Claws"] = 4,
		["Downwind of Altairus"] = 16,
		["Intimidating Shout"] = 1,
		["Distortion Bomb"] = 64,
		["Dragonfire Traps"] = 4,
		["Rending Charge"] = 1,
		["Frostbolt"] = 16,
		["Spark Volley"] = 8,
		["Pistol Shot"] = 4,
		["Shadowflame Fissures"] = 36,
		["Withering"] = 8,
		["Wrath"] = 8,
		["Mortal Strike"] = 1,
		["Seeping Lava"] = 12,
		["Hellsteel Fragment"] = 36,
		["Falling Debris"] = 1,
		["Dark Reprimand"] = 32,
		["Whirlwind"] = 1,
		["Earthquake"] = 8,
		["Frostbite"] = 16,
		["Blinding Sleet"] = 16,
		["Lightning Bolt"] = 8,
		["Goldrinn's Fang"] = 72,
		["Moonfire"] = 64,
		["Shadow Word: Death"] = 32,
		["Blazing Aegis"] = 4,
		["Ray of Frost"] = 16,
		["Water Jet"] = 16,
		["Energy Bomb"] = 64,
		["Frenzied Assault"] = 1,
		["Paracausal Fragment of Frostmourne"] = 1,
		["Conflagration Flare Up"] = 4,
		["Astral Smolder"] = 72,
		["Renew"] = 2,
		["Slag Eruption"] = 4,
		["Death Strike Off-Hand"] = 1,
		["Shadowflame Wreathe"] = 36,
		["Stellar Flare"] = 72,
		["Echo of Light"] = 2,
		["Arcane Orb"] = 64,
		["Lava Ejection"] = 4,
		["Polymorph"] = 64,
		["Heaven's Fury"] = 2,
		["Full Moon"] = 72,
		["Doom Flames"] = 36,
		["Flurry"] = 16,
		["Ice Strike"] = 16,
		["Death Strike"] = 1,
		["Blazing Hammer"] = 4,
		["Five Lashings"] = 1,
		["Expiation"] = 32,
		["Swipe"] = 1,
		["Riftburn"] = 36,
		["Blazing Eruption"] = 4,
		["Void Bomb"] = 32,
		["Recent Catastrophe"] = 126,
		["Infused Strikes"] = 64,
		["Burning Pitch"] = 4,
		["Choking Rotcloud"] = 8,
		["Frost Fever"] = 16,
		["Claw"] = 1,
		["Wild Mushroom"] = 8,
		["Elementium Spike Shield"] = 64,
		["Static Surge"] = 64,
		["Abomination Limb"] = 32,
		["Umbral Detonation"] = 32,
		["Blazing Charge"] = 4,
		["Clinging Void"] = 32,
		["Decayed Senses"] = 8,
		["Wild Energy"] = 64,
		["Igniting Roar"] = 4,
		["Razorice"] = 16,
		["Shatter"] = 1,
		["Tempest Storm"] = 8,
		["Skyfall Nova"] = 64,
		["Moonlance"] = 64,
		["Eagle Claw"] = 1,
		["Ice Lance"] = 16,
		["Grounding Spear"] = 1,
		["Withering Rot"] = 8,
		["Lava"] = 4,
		["Scorching Detonation"] = 4,
		["Void Slash"] = 32,
		["Toxic Effluvia"] = 8,
		["Astral Formation"] = 32,
		["Crepuscular Veil"] = 32,
		["Fire Blast"] = 4,
		["Gloom Combustion"] = 36,
		["Lava Wave"] = 4,
		["Cannon Barrage"] = 4,
		["Deafening Screech"] = 8,
		["Landslide"] = 8,
		["Sunder Reality"] = 32,
		["Heroic Leap"] = 1,
		["Mongoose Bite"] = 1,
		["The Dragon's Eruption"] = 4,
		["Searing Cannonfire"] = 4,
		["Disease Breath"] = 8,
		["Phoenix Reborn"] = 4,
		["Dragon's Breath"] = 4,
		["Flame Patch"] = 4,
		["Judgment"] = 2,
		["Decaystrike"] = 1,
		["Magma"] = 4,
		["Wound Poison"] = 8,
		["Rupturing Skitter"] = 8,
		["Fiery Focus"] = 1,
		["Consume"] = 8,
		["Flaming Slash"] = 4,
		["Abyssal Breath"] = 32,
		["Molten Scar"] = 36,
		["Stomp"] = 1,
		["Splintered Flames"] = 4,
		["Kill Command"] = 1,
		["Waterlogged"] = 16,
		["Shred"] = 1,
		["Crippling Bite"] = 1,
		["Partially Digested"] = 8,
		["Molten Gold"] = 4,
		["Decay Spray"] = 8,
		["Bone Bolt"] = 1,
		["Belly Slam"] = 1,
		["Tactical Destruction"] = 4,
		["Infused Explosion"] = 64,
		["Void Claws"] = 32,
		["Scorch"] = 4,
		["Obliterate"] = 1,
		["The Skullcracker"] = 1,
		["Body Slam"] = 1,
		["Hammer Fist"] = 1,
		["Lava Burst"] = 4,
		["Ruptured Veil"] = 32,
		["Surrender to Corruption"] = 32,
		["Shattered Rock"] = 8,
		["Dragonbone Axe"] = 1,
		["Swirling Flame"] = 4,
		["Plague of Ages"] = 8,
		["Mind Blast"] = 32,
		["Icicle"] = 16,
		["Heated Swings"] = 1,
		["Flaming Shrapnel"] = 4,
		["Charge"] = 1,
		["Earthen Crush"] = 1,
		["Wrecking Throw"] = 1,
		["Primordial Wave"] = 32,
		["Unstable Essence"] = 64,
		["Pure Decay"] = 8,
		["Volatile Bomb"] = 1,
		["Death Chakram"] = 1,
		["Polar Winds"] = 16,
		["Twisting Winds"] = 8,
		["Flesh Rip"] = 1,
		["Frostwyrm's Fury"] = 16,
		["Lava Explosion"] = 4,
		["Fury of the Eagle"] = 1,
		["Blighted Arrows"] = 32,
		["Ignite"] = 4,
		["Flamestrike"] = 4,
		["Gut Shot"] = 1,
		["Disintegrate"] = 80,
		["Withered Eruption"] = 8,
	},
	["deathlog_healingdone_min"] = 1,
	["damage_scroll_auto_open"] = true,
	["show_warning_id1_amount"] = 2,
	["latest_shield_spellid_cache_access"] = 1695698514,
	["current_exp_raid_encounters"] = {
	},
	["keystone_frame"] = {
		["scale"] = 1,
		["position"] = {
		},
	},
	["show_aug_predicted_spell_damage"] = false,
	["trinket_data"] = {
		[381760] = {
			["lastCombatId"] = 449,
			["minTime"] = 40.01699995994568,
			["averageTime"] = 60,
			["activations"] = 46,
			["totalCooldownTime"] = 2779.12099981308,
			["lastPlayerName"] = "Dèd-Dalaran",
			["lastActivation"] = 1695928302.952,
			["maxTime"] = 129.0249998569489,
			["spellName"] = "Mutated Tentacle Slam",
		},
		[388739] = {
			["lastCombatId"] = 449,
			["minTime"] = 40.32900023460388,
			["averageTime"] = 72,
			["activations"] = 27,
			["totalCooldownTime"] = 1968.50700044632,
			["lastPlayerName"] = "Midnyght-Uther",
			["lastActivation"] = 1695928273.038,
			["maxTime"] = 158.4030001163483,
			["spellName"] = "Pure Decay",
		},
		[397376] = {
			["lastCombatId"] = 449,
			["minTime"] = 42.51399993896484,
			["averageTime"] = 82,
			["activations"] = 15,
			["totalCooldownTime"] = 1231.309000015259,
			["lastPlayerName"] = "Dâirystorm",
			["lastActivation"] = 1695928313.995,
			["maxTime"] = 165.3619999885559,
			["spellName"] = "Burning Embers",
		},
		[388755] = {
			["lastCombatId"] = 449,
			["minTime"] = 40.02600002288818,
			["averageTime"] = 65,
			["activations"] = 47,
			["totalCooldownTime"] = 3100.514999866486,
			["lastPlayerName"] = "Bigmoves-Trollbane",
			["lastActivation"] = 1695928302.729,
			["maxTime"] = 185.699000120163,
			["spellName"] = "Soulseeker Arrow",
		},
		[389839] = {
			["lastCombatId"] = 434,
			["minTime"] = 9999999,
			["averageTime"] = 0,
			["activations"] = 0,
			["totalCooldownTime"] = 0,
			["lastPlayerName"] = "Aleyla-WyrmrestAccord",
			["lastActivation"] = 1695925664.834,
			["maxTime"] = 0,
			["spellName"] = "Fire Shot",
		},
		[214052] = {
			["lastCombatId"] = 0,
			["minTime"] = 9999999,
			["averageTime"] = 0,
			["activations"] = 0,
			["totalCooldownTime"] = 0,
			["lastPlayerName"] = "",
			["lastActivation"] = 0,
			["maxTime"] = 0,
			["spellName"] = "Fel Meteor",
		},
		[384325] = {
			["lastCombatId"] = 275,
			["minTime"] = 42.69199991226196,
			["averageTime"] = 56,
			["activations"] = 2,
			["totalCooldownTime"] = 112.6539998054504,
			["lastPlayerName"] = "Levac-Azralon",
			["lastActivation"] = 1695852036.071,
			["maxTime"] = 69.96199989318848,
			["spellName"] = "Barf's Ambush",
		},
		[382426] = {
			["lastCombatId"] = 511,
			["minTime"] = 40.06699991226196,
			["averageTime"] = 48,
			["activations"] = 20,
			["totalCooldownTime"] = 976.4449999332428,
			["lastPlayerName"] = "Feeber-Stormrage",
			["lastActivation"] = 1696014859.721,
			["maxTime"] = 73.8309998512268,
			["spellName"] = "Spiteful Stormbolt",
		},
		[384290] = {
			["lastCombatId"] = 275,
			["minTime"] = 40.61999988555908,
			["averageTime"] = 70,
			["activations"] = 4,
			["totalCooldownTime"] = 282.1479997634888,
			["lastPlayerName"] = "Levac-Azralon",
			["lastActivation"] = 1695852120.317,
			["maxTime"] = 112.9049999713898,
			["spellName"] = "Smorf's Ambush",
		},
		[385903] = {
			["lastCombatId"] = 0,
			["minTime"] = 9999999,
			["averageTime"] = 0,
			["activations"] = 0,
			["totalCooldownTime"] = 0,
			["lastPlayerName"] = "",
			["lastActivation"] = 0,
			["maxTime"] = 0,
			["spellName"] = "Crystal Sickness",
		},
		[401428] = {
			["lastCombatId"] = 537,
			["minTime"] = 40.13000011444092,
			["averageTime"] = 59,
			["activations"] = 35,
			["totalCooldownTime"] = 2067.815999507904,
			["lastPlayerName"] = "Sultarion",
			["lastActivation"] = 1696019105.602,
			["maxTime"] = 182.2339999675751,
			["spellName"] = "Ravenous Shadowflame",
		},
		[394453] = {
			["lastCombatId"] = 355,
			["minTime"] = 40.27100014686585,
			["averageTime"] = 109,
			["activations"] = 5,
			["totalCooldownTime"] = 547.0530002117157,
			["lastPlayerName"] = "Hiren-Thrall",
			["lastActivation"] = 1695918904.028,
			["maxTime"] = 192.6240000724793,
			["spellName"] = "Broodkeeper's Blaze",
		},
		[407961] = {
			["lastCombatId"] = 473,
			["minTime"] = 58.46499991416931,
			["averageTime"] = 63,
			["activations"] = 47,
			["totalCooldownTime"] = 2983.095999717712,
			["lastPlayerName"] = "Îllest-EmeraldDream",
			["lastActivation"] = 1695932914.074,
			["maxTime"] = 75.97199988365173,
			["spellName"] = "Lava Wave",
		},
		[401324] = {
			["lastCombatId"] = 557,
			["minTime"] = 40.05100011825562,
			["averageTime"] = 68,
			["activations"] = 91,
			["totalCooldownTime"] = 6230.582999944688,
			["lastPlayerName"] = "Skelay",
			["lastActivation"] = 1696024559.772,
			["maxTime"] = 204.6849999427795,
			["spellName"] = "Echoed Flare",
		},
	},
	["global_plugin_database"] = {
		["DETAILS_PLUGIN_ENCOUNTER_DETAILS"] = {
			["encounter_timers_bw"] = {
			},
			["encounter_timers_dbm"] = {
			},
		},
	},
	["savedCustomSpells"] = {
		{
			7, -- [1]
			"Environment (Lava)", -- [2]
			"Interface\\ICONS\\Ability_Rhyolith_Volcano", -- [3]
		}, -- [1]
		{
			1, -- [1]
			"Melee", -- [2]
			"Interface\\ICONS\\INV_Sword_04", -- [3]
		}, -- [2]
		{
			2, -- [1]
			"Auto Shot", -- [2]
			"Interface\\ICONS\\INV_Weapon_Bow_07", -- [3]
		}, -- [3]
		{
			4, -- [1]
			"Environment (Drowning)", -- [2]
			"Interface\\ICONS\\Ability_Suffocate", -- [3]
		}, -- [4]
		{
			8, -- [1]
			"Environment (Slime)", -- [2]
			"Interface\\ICONS\\Ability_Creature_Poison_02", -- [3]
		}, -- [5]
		{
			395296, -- [1]
			"Ebon Might", -- [2]
			"Interface\\Addons\\Details\\images\\ebon_might", -- [3]
		}, -- [6]
		{
			5, -- [1]
			"Environment (Fatigue)", -- [2]
			"Interface\\ICONS\\Spell_Arcane_MindMastery", -- [3]
		}, -- [7]
		{
			196917, -- [1]
			"Light of the Martyr (Damage)", -- [2]
			1360762, -- [3]
		}, -- [8]
		{
			77535, -- [1]
			"Blood Shield", -- [2]
			"Interface\\Addons\\Details\\images\\icon_blood_shield", -- [3]
		}, -- [9]
		{
			3, -- [1]
			"Environment (Falling)", -- [2]
			"Interface\\ICONS\\Spell_Magic_FeatherFall", -- [3]
		}, -- [10]
		{
			6, -- [1]
			"Environment (Fire)", -- [2]
			"Interface\\ICONS\\INV_SummerFest_FireSpirit", -- [3]
		}, -- [11]
		{
			98021, -- [1]
			"Health Exchange", -- [2]
			237586, -- [3]
		}, -- [12]
		{
			108271, -- [1]
			"Astral Shift", -- [2]
			"Interface\\Addons\\Details\\images\\icon_astral_shift", -- [3]
		}, -- [13]
		{
			382426, -- [1]
			"|T4638591:14:14:0:0:14:14:1:12:1:12|t Spiteful Storm", -- [2]
			572029, -- [3]
		}, -- [14]
		{
			408682, -- [1]
			"|T4624639:14:14:0:0:14:14:1:12:1:12|t Dragonfire Bomb Dispenser", -- [2]
			4624639, -- [3]
		}, -- [15]
		{
			388948, -- [1]
			"|T609814:14:14:0:0:14:14:1:12:1:12|t Globe of Jagged Ice", -- [2]
			629077, -- [3]
		}, -- [16]
		{
			382097, -- [1]
			"|T4638708:14:14:0:0:14:14:1:12:1:12|t Rumbling Ruby", -- [2]
			1016245, -- [3]
		}, -- [17]
		{
			377451, -- [1]
			"|T4643989:14:14:0:0:14:14:1:12:1:12|t Conjured Chillglobe", -- [2]
			4643989, -- [3]
		}, -- [18]
		{
			388855, -- [1]
			"|T4638394:14:14:0:0:14:14:1:12:1:12|t Miniature Singing Stone", -- [2]
			4638394, -- [3]
		}, -- [19]
		{
			397376, -- [1]
			"|T4638716:14:14:0:0:14:14:1:12:1:12|t Kyrakka's Searing Embers", -- [2]
			460952, -- [3]
		}, -- [20]
		{
			407961, -- [1]
			"|T134337:14:14:0:0:14:14:1:12:1:12|t Igneous Flowstone", -- [2]
			1029721, -- [3]
		}, -- [21]
		{
			384290, -- [1]
			"|T443377:14:14:0:0:14:14:1:12:1:12|t Frenzying Signoll Flare", -- [2]
			132101, -- [3]
		}, -- [22]
		{
			377455, -- [1]
			"|T237430:14:14:0:0:14:14:1:12:1:12|t Iceblood Deathsnare", -- [2]
			237430, -- [3]
		}, -- [23]
		{
			401428, -- [1]
			"|T3853931:14:14:0:0:14:14:1:12:1:12|t Vessel of Searing Shadow", -- [2]
			4914678, -- [3]
		}, -- [24]
		{
			408815, -- [1]
			"|T4823024:14:14:0:0:14:14:1:12:1:12|t Djaruun, Pillar of the Elder Flame", -- [2]
			136243, -- [3]
		}, -- [25]
		{
			382056, -- [1]
			"|T1387353:14:14:0:0:14:14:1:12:1:12|t Decoration of Flame", -- [2]
			1387353, -- [3]
		}, -- [26]
		{
			382135, -- [1]
			"|T650636:14:14:0:0:14:14:1:12:1:12|t Manic Grieftorch", -- [2]
			650636, -- [3]
		}, -- [27]
		{
			384325, -- [1]
			"|T443377:14:14:0:0:14:14:1:12:1:12|t Frenzying Signoll Flare", -- [2]
			135860, -- [3]
		}, -- [28]
		{
			214985, -- [1]
			"|T519378:14:14:0:0:14:14:1:12:1:12|t Windscar Whetstone", -- [2]
			1029585, -- [3]
		}, -- [29]
		{
			394453, -- [1]
			"|T4638576:14:14:0:0:14:14:1:12:1:12|t Seal of Diurna's Chosen", -- [2]
			514016, -- [3]
		}, -- [30]
		{
			377459, -- [1]
			"|T4638565:14:14:0:0:14:14:1:12:1:12|t All-Totem of the Master", -- [2]
			135829, -- [3]
		}, -- [31]
		{
			382090, -- [1]
			"|T4554454:14:14:0:0:14:14:1:12:1:12|t Storm-Eater's Boon", -- [2]
			4554454, -- [3]
		}, -- [32]
		{
			387036, -- [1]
			"|T4638716:14:14:0:0:14:14:1:12:1:12|t Kyrakka's Searing Embers", -- [2]
			460952, -- [3]
		}, -- [33]
		{
			381760, -- [1]
			"|T538042:14:14:0:0:14:14:1:12:1:12|t Mutated Magmammoth Scale", -- [2]
			538042, -- [3]
		}, -- [34]
		{
			401306, -- [1]
			"|T2356069:14:14:0:0:14:14:1:12:1:12|t Elementium Pocket Anvil", -- [2]
			2356069, -- [3]
		}, -- [35]
		{
			383934, -- [1]
			"|T839910:14:14:0:0:14:14:1:12:1:12|t Water's Beating Heart", -- [2]
			839910, -- [3]
		}, -- [36]
		{
			385903, -- [1]
			"|T237007:14:14:0:0:14:14:1:12:1:12|t Umbrelskul's Fractured Heart", -- [2]
			237007, -- [3]
		}, -- [37]
		{
			389839, -- [1]
			"|T4509422:14:14:0:0:14:14:1:12:1:12|t Ruby Whelp Shell", -- [2]
			4572404, -- [3]
		}, -- [38]
		{
			402583, -- [1]
			"|T4914670:14:14:0:0:14:14:1:12:1:12|t Beacon to the Beyond", -- [2]
			4914670, -- [3]
		}, -- [39]
		{
			388739, -- [1]
			"|T4635246:14:14:0:0:14:14:1:12:1:12|t Idol of Pure Decay", -- [2]
			4635246, -- [3]
		}, -- [40]
		{
			388755, -- [1]
			"|T2103807:14:14:0:0:14:14:1:12:1:12|t Furious Ragefeather", -- [2]
			2103807, -- [3]
		}, -- [41]
		{
			381967, -- [1]
			"|T1020391:14:14:0:0:14:14:1:12:1:12|t Controlled Current Technique", -- [2]
			1020391, -- [3]
		}, -- [42]
		{
			401324, -- [1]
			"|T2356069:14:14:0:0:14:14:1:12:1:12|t Elementium Pocket Anvil", -- [2]
			4914678, -- [3]
		}, -- [43]
		{
			381475, -- [1]
			"|T4638721:14:14:0:0:14:14:1:12:1:12|t Erupting Spear Fragment", -- [2]
			4638721, -- [3]
		}, -- [44]
		{
			382058, -- [1]
			"|T1387353:14:14:0:0:14:14:1:12:1:12|t Decoration of Flame", -- [2]
			1387353, -- [3]
		}, -- [45]
		{
			214200, -- [1]
			"|T535593:14:14:0:0:14:14:1:12:1:12|t Mote of Sanctification", -- [2]
			237541, -- [3]
		}, -- [46]
		{
			384004, -- [1]
			"|T1029000:14:14:0:0:14:14:1:12:1:12|t Homeland Raid Horn", -- [2]
			252172, -- [3]
		}, -- [47]
		{
			214052, -- [1]
			"|T136030:14:14:0:0:14:14:1:12:1:12|t Eye of Skovald", -- [2]
			135799, -- [3]
		}, -- [48]
	},
	["keystone_cache"] = {
	},
	["breakdown_spell_tab"] = {
		["blockspell_padding"] = 5,
		["spellcontainer_height"] = 311,
		["blockspell_height"] = 67,
		["blockspell_backgroundcolor"] = {
			0.05, -- [1]
			0.05, -- [2]
			0.05, -- [3]
			0.2, -- [4]
		},
		["phasecontainer_islocked"] = true,
		["blockspell_spark_color"] = {
			1, -- [1]
			1, -- [2]
			1, -- [3]
			0.7, -- [4]
		},
		["blockcontainer_width"] = 456.0000305175781,
		["spellbar_background_alpha"] = 0.92,
		["spellcontainer_width"] = 429.0000610351563,
		["spellcontainer_header_fontcolor"] = {
			1, -- [1]
			1, -- [2]
			1, -- [3]
			1, -- [4]
		},
		["phasecontainer_height"] = 140.0000457763672,
		["phasecontainer_enabled"] = true,
		["genericcontainer_headers_right"] = {
		},
		["phasecontainer_width"] = 290.0000915527344,
		["phasecontainer_headers"] = {
		},
		["statusbar_texture"] = "Interface\\AddOns\\Details\\images\\bar_skyline",
		["spellcontainer_islocked"] = true,
		["nest_pet_spells_by_caster"] = true,
		["blockspell_bordercolor"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
			0.7, -- [4]
		},
		["targetcontainer_headers"] = {
		},
		["blockspell_spark_width"] = 4,
		["genericcontainer_width"] = 429,
		["spellcontainer_header_height"] = 20,
		["blockcontainer_islocked"] = true,
		["genericcontainer_right_width"] = 403,
		["blockspell_color"] = {
			0.6, -- [1]
			0.6, -- [2]
			0.6, -- [3]
			0.55, -- [4]
		},
		["blockspell_spark_show"] = true,
		["spellcontainer_header_fontsize"] = 10,
		["statusbar_background_color"] = {
			0.15, -- [1]
			0.15, -- [2]
			0.15, -- [3]
		},
		["targetcontainer_width"] = 429.0000610351563,
		["genericcontainer_islocked"] = true,
		["genericcontainer_right_height"] = 460,
		["statusbar_alpha"] = 0.7,
		["targetcontainer_height"] = 140.0000457763672,
		["nest_pet_spells_by_name"] = false,
		["nest_players_spells_with_same_name"] = true,
		["blockspell_spark_offset"] = -1,
		["genericcontainer_enabled"] = true,
		["genericcontainer_headers"] = {
		},
		["blockcontainer_height"] = 270.0000610351563,
		["statusbar_background_alpha"] = 0.7,
		["spellcontainer_headers"] = {
		},
		["targetcontainer_islocked"] = true,
		["genericcontainer_height"] = 481,
	},
	["always_use_profile_name"] = "",
	["profile_by_spec"] = {
	},
	["combat_id_global"] = 557,
	["displays_by_spec"] = {
	},
	["plugin_window_pos"] = {
		["y"] = 0,
		["x"] = 0,
		["point"] = "CENTER",
		["scale"] = 1,
	},
	["last_changelog_size"] = 24479,
	["immersion_unit_special_icons"] = true,
	["lastUpdateWarning"] = 0,
	["npcid_pool"] = {
		[0] = "[*] Not Edible",
		[205749] = "Dazed",
		[203831] = "Crystalline Guardian",
		[186696] = "Quaking Totem <Bromach>",
		[39705] = "Ascendant Lord Obsidius",
		[190405] = "Infuser Sariya",
		[203832] = "Dread Rift <Kazzara, the Hellforged>",
		[54123] = "Echo of Sylvanas",
		[44980] = "Neferset Theurgist",
		[189895] = "Primalist Infiltrator",
		[45268] = "Servant of Siamat <[*] Static Shock>",
		[54507] = "Time-Twisted Scourge Beast",
		[43286] = "Crystal Shard",
		[190407] = "Aqua Rager",
		[129602] = "Irontide Enforcer",
		[26822] = "Ursula Direbrew",
		[98081] = "Bellowing Idol <Ularogg Cragshaper>",
		[27893] = "Rune Weapon <Gutterboy>",
		[61029] = "Primal Fire Elemental <Aucas>",
		[54923] = "Infinite Warden",
		[194373] = "Brackenhide Gnoll",
		[44981] = "Oathsworn Skinner",
		[126918] = "Irontide Crackshot",
		[39994] = "Conflagration",
		[202814] = "Twisted Aberration <Neltharion>",
		[208441] = "물의 정령 <Arcanemagek-Tichondrius>",
		[193352] = "Hextrick Totem <Tricktotem>",
		[54700] = "Time-Twisted Nightsaber",
		[184018] = "Bromach",
		[193353] = "Plainsbound Slyvern",
		[126983] = "Harlan Sweete",
		[127111] = "Irontide Oarsman",
		[189901] = "Warlord Sargha",
		[184019] = "Burly Rock-Thrower",
		[42808] = "Stonecore Flayer",
		[187600] = "Qalashi Stonemender",
		[43927] = "Harbinger of Darkness",
		[44982] = "Neferset Darkcaster",
		[184020] = "Hulking Berserker",
		[50417] = "Bound Flames",
		[192333] = "Alpha Eagle",
		[168932] = "Doomguard <Allaeda>",
		[54701] = "Time-Twisted Huntress",
		[201413] = "Inflammable Wall",
		[189265] = "Qalashi Bonetender",
		[206784] = "Deceiver Hr'qoth",
		[189905] = "High Thaumaturge Fural",
		[184023] = "Vicious Basilisk",
		[39708] = "Twilight Flame Caller",
		[208959] = "Future Self <Doubleblank>",
		[196044] = "Unruly Textbook",
		[192464] = "Raging Ember",
		[98406] = "Embershard Scorpion",
		[49267] = "Crystal Shard",
		[196045] = "Corrupted Manafiend",
		[201288] = "Sundered Champion",
		[54574] = "Moonlance <Echo of Tyrande>",
		[62982] = "Mindbender <Woozil>",
		[101476] = "Molten Charskin <Dargrul>",
		[195919] = "Burning Chain Caster",
		[205638] = "Sundered Flame Banner <Sundered Siegemaster>",
		[42810] = "Crystalspawn Giant",
		[46007] = "Ertan's Vortex",
		[185691] = "Vicious Hyena",
		[54511] = "Time-Twisted Geist",
		[54543] = "Time-Twisted Drake",
		[191574] = "Choking Rotcloud <Decatriarch Wratheye>",
		[201677] = "Winglord Dezran",
		[194389] = "Lava Spawn <Qalashi Lavamancer>",
		[129547] = "Blacktooth Knuckleduster",
		[45912] = "Wild Vortex",
		[201934] = "Shadowflame Amalgamation",
		[49045] = "Augh",
		[186206] = "Cruel Bonecrusher",
		[190426] = "Decay Totem <Fetid Rotsinger>",
		[189531] = "Decayed Elder",
		[200912] = "Neldris",
		[54512] = "Time-Twisted Sentinel",
		[205644] = "Oozing Sludge",
		[129548] = "Blacktooth Brute",
		[200913] = "Thadrion",
		[42428] = "Devout Follower",
		[187231] = "Wither Biter",
		[196694] = "Arcane Forager",
		[105636] = "Understone Drudge",
		[181861] = "Magmatusk",
		[39679] = "Corla, Herald of Twilight",
		[52019] = "Skyfall Nova <Asaad>",
		[198869] = "Sundered Devastator",
		[126928] = "Irontide Corsair",
		[198870] = "Sundered Preserver",
		[193244] = "Titan Defense Matrix",
		[42333] = "High Priestess Azil",
		[198871] = "Sundered Scaleguard",
		[40447] = "Chains of Woe <Rom'ogg Bonecrusher>",
		[43612] = "High Prophet Barim",
		[200918] = "Rionthus",
		[129359] = "Sawtooth Shark",
		[42845] = "Rock Borer",
		[198873] = "Sundered Edgelord",
		[129743] = "Sharkbait",
		[90997] = "Mightstone Breaker",
		[3527] = "Healing Stream Totem <Slutdawg-Stormrage>",
		[205651] = "Bubbling Slime",
		[198874] = "Sundered Siegemaster",
		[191841] = "Primalist Infiltrator",
		[205396] = "Molten Cinders",
		[187238] = "Witherling",
		[192481] = "Decaying Slime <Treemouth>",
		[198236] = "Divine Image <Matook>",
		[189669] = "Binding Spear",
		[194273] = "Witherling",
		[45915] = "Armored Mistral",
		[44924] = "Oathsworn Myrmidon",
		[191844] = "Primalist Infiltrator",
		[165374] = "Yu'lon <Dovamonk>",
		[130896] = "Blackout Barrel <Captain Raoul>",
		[196576] = "Spellbound Scepter",
		[205656] = "Sundered Chemist",
		[196577] = "Spellbound Battleaxe",
		[202971] = "Null Glimmer <Sarkareth>",
		[91000] = "Vileshard Hulk",
		[44541] = "Cloud Burst",
		[186220] = "Brackenhide Shaper",
		[43614] = "Lockmaw",
		[197857] = "Gutstabber",
		[43934] = "Soul Fragment",
		[197219] = "Vile Lasher",
		[204508] = "Scavenging Slicer",
		[203230] = "Dragonfire Golem",
		[200289] = "Siege Arbalest",
		[185584] = "Blasphemy <Kaydun>",
		[91002] = "Rotdrool Grabber",
		[17252] = "Rinngozin",
		[191212] = "Earthquake Totem",
		[202593] = "Monstrous Mud",
		[45917] = "Cloud Prince",
		[200931] = "Primal Nightflame",
		[205407] = "Incarnated Wick",
		[186226] = "Fetid Rotsinger",
		[196712] = "Nullification Device",
		[201955] = "Arcane Image",
		[92538] = "Tarspitter Grub",
		[186227] = "Monstrous Decay",
		[196202] = "Spectral Invoker",
		[96247] = "Vileshard Crawler",
		[2732] = "Ridge Huntress",
		[205410] = "Incarnated Gravel",
		[186229] = "Wilted Oak",
		[129559] = "Cutwater Duelist",
		[91005] = "Naraxas",
		[189299] = "Decaying Slime",
		[189811] = "Agitated Keystone",
		[201320] = "Rashok",
		[54550] = "Undying Flame",
		[91006] = "Rockback Gnasher <Stoneclaw Hunter>",
		[199659] = "Warlord Kagni",
		[208994] = "Infected Lasher <Brackenhide Shaper>",
		[44704] = "Minion of Siamat",
		[195184] = "Defense Orb",
		[97720] = "Blightshard Skitter <Rokmora>",
		[43873] = "Altairus",
		[91007] = "Dargrul",
		[196336] = "Qalashi Flameslinger",
		[201579] = "Magmorax",
		[2830] = "Parched Buzzard",
		[89] = "Infernal <Kaydun>",
		[26764] = "Ilsa Direbrew",
		[205672] = "Flame Additive <Sundered Chemist>",
		[60849] = "Jade Serpent Statue <Dirtysquatch>",
		[91008] = "Rockbound Pelter",
		[44577] = "General Husam",
		[43650] = "Dust Flail",
		[42691] = "Stonecore Rift Conjurer",
		[209510] = "Shade of Travard <Deceiver Hr'qoth>",
		[204651] = "Quicksmack Magk",
		[184319] = "Refti Custodian",
		[44897] = "Pygmy Scout",
		[191736] = "Crawth",
		[26125] = "Toothrumbler",
		[130011] = "Irontide Buccaneer",
		[206059] = "Stormforged Tactician",
		[24207] = "Army of the Dead|T1392565:0|t",
		[54552] = "Time-Twisted Breaker",
		[45377] = "Augh",
		[206060] = "Titanium Vanguard",
		[130012] = "Irontide Ravager",
		[42692] = "Stonecore Bruiser",
		[44898] = "Pygmy Firebreather",
		[186242] = "Skulking Gutstabber",
		[45122] = "Oathsworn Captain",
		[184580] = "Olaf",
		[92610] = "Understone Drummer",
		[54553] = "Time-Twisted Seer",
		[184581] = "Baelog",
		[129758] = "Irontide Grenadier",
		[201333] = "Awakened Avalanche <Cliffkeeper Bouldani>",
		[186116] = "Gutshot",
		[202612] = "Cliffkeeper Bouldani",
		[23872] = "Coren Direbrew",
		[184582] = "Eric \"The Swift\"",
		[42789] = "Stonecore Magmalord",
		[45922] = "Empyrean Assassin",
		[187908] = "Qalashi Scaleripper",
		[186246] = "Fleshripper Vulture",
		[103673] = "Darkglare <Doomboltz>",
		[44260] = "Venomfang Crocolisk",
		[201464] = "Cinderstep Weaver",
		[45379] = "Augh",
		[186120] = "Treemouth",
		[190340] = "Refti Defender",
		[194816] = "Forgewrought Monstrosity",
		[6112] = "Windfury Totem <Nezaren-Hyjal>",
		[203384] = "Scavenging Slicer",
		[186121] = "Decatriarch Wratheye",
		[44932] = "Oathsworn Pathfinder",
		[199037] = "Primalist Shocktrooper",
		[186122] = "Rira Hackclaw",
		[190342] = "Containment Apparatus",
		[101437] = "Burning Geode",
		[44261] = "Sharptalon Eagle",
		[201468] = "Stonebreath Landslider",
		[201852] = "Plagued Clicker",
		[43430] = "Stonecore Berserker",
		[190983] = "Qalashi Pillager",
		[45572] = "Howling Gale",
		[196482] = "Overgrown Ancient",
		[101438] = "Vileshard Chunk",
		[202109] = "Djaradin Commander",
		[42695] = "Stonecore Sentry",
		[194181] = "Vexamus <Magic Book>",
		[201470] = "Flickering Flame",
		[190345] = "Primalist Geomancer",
		[192519] = "Monstrous Mud",
		[45924] = "Turbulent Squall",
		[129699] = "Ludwig Von Tortollan",
		[130850] = "Irontide Cannon",
		[201471] = "Earthborne Charger",
		[39978] = "Twilight Torturer",
		[199809] = "Swooping Flayer",
		[193799] = "Rotchanting Totem",
		[199298] = "Qalashi Skullhauler",
		[201472] = "Torch Revenant",
		[204669] = "Umbral Seer",
		[205820] = "Crawling Goo",
		[45477] = "Gust Soldier",
		[163366] = "Magus of the Dead <Blackcoffeë-Tichondrius>",
		[190348] = "Primalist Ravager",
		[62005] = "Beast <Ogeez>",
		[42696] = "Stonecore Warbringer",
		[130404] = "Vermin Trapper",
		[204671] = "Leeching Parasite",
		[199812] = "Zaqali Wallclimber",
		[193291] = "Apex Blazewing",
		[97285] = "Wind Rush Totem <Flaconmeth>",
		[166949] = "Chi-Ji <Gnarmony>",
		[200836] = "Obsidian Guard",
		[199941] = "Sundered Defender",
		[128551] = "Irontide Mastiff",
		[199942] = "Sundered Mender",
		[193293] = "Qalashi Warden",
		[190609] = "Echo of Doragosa",
		[45063] = "Bonesnapper Scorpid",
		[39980] = "Twilight Sadist",
		[200840] = "Flamebound Huntsman",
		[202375] = "Zskarn",
		[129448] = "Hammer Shark",
		[201736] = "Sundered Arcanist",
		[199946] = "Sundered Researcher",
		[130024] = "Soggy Shiprat",
		[192786] = "Qalashi Plunderer",
		[144961] = "Akaari's Soul <Llamabush>",
		[416] = "Laznik",
		[192787] = "Qalashi Spinecrusher",
		[417] = "Bruufum <Palumba>",
		[187033] = "Stinkbreath",
		[102404] = "Stoneclaw Grubmaster",
		[189719] = "Watcher Irideus",
		[54431] = "Echo of Baine",
		[204297] = "Burned Ravager",
		[108926] = "Lava Geyser",
		[190359] = "Skulking Zealot",
		[189464] = "Qalashi Irontorch",
		[111292] = "Silver Hand Knight <Ellegie-ShatteredHalls>",
		[198032] = "Dragon's Eruption",
		[182815] = "Summoned Lava Elemental",
		[43658] = "Frenzied Crocolisk",
		[45928] = "Executor of the Caliph",
		[189722] = "Gulping Goliath",
		[45001] = "Enslaved Bandit",
		[45065] = "Tol'vir Merchant",
		[39982] = "Crazed Mage",
		[189467] = "Qalashi Bonesplitter",
		[54432] = "Murozond",
		[42188] = "Ozruk",
		[189340] = "Chargath, Bane of Scales",
		[193944] = "Qalashi Lavamancer",
		[202256] = "Djaradin Lavamancer",
		[202257] = "Djaradin Magmashaper",
		[4846] = "Shadowforge Digger",
		[201746] = "Sundered Naturalist",
		[202258] = "Djaradin Skullcrusher",
		[204432] = "Mischievous Stagnose",
		[194330] = "Decaying Slime",
		[94224] = "Petrifying Totem <Blightshard Shaper>",
		[189471] = "Qalashi Blacksmith",
		[189727] = "Khajin the Unyielding",
		[202259] = "Djaradin Wallclimber",
		[189472] = "Qalashi Lavabearer",
		[205968] = "Fragment of Shadow",
		[190368] = "Flamecaller Aymi",
		[199703] = "Magma Mystic",
		[189729] = "Primal Tsunami",
		[204435] = "Sneaky Darkfang",
		[189474] = "The Scorching Forge",
		[45930] = "Minister of Air",
		[202262] = "Blazing Dreadsquall",
		[190370] = "Squallbringer Cyraz",
		[205971] = "Fragment of Fire",
		[187813] = "Qalashi Wallcrasher",
		[207378] = "Wildfire Mote",
		[190371] = "Primalist Earthshaker",
		[202264] = "Primal Lava Elemental",
		[204566] = "Tunneling Rockborer",
		[201753] = "Sundered Destroyer",
		[203927] = "Failed Prototype",
		[205078] = "Crystal Snapper Matriarch",
		[39665] = "Rom'ogg Bonecrusher",
		[197406] = "Aggravated Skitterfly",
		[190373] = "Primalist Galesinger",
		[201754] = "Sarkareth",
		[174773] = "Spiteful Shade",
		[39985] = "Mad Prisoner",
		[40017] = "Twilight Element Warden",
		[43214] = "Slabhide",
		[194467] = "Brackenhide Slasher",
		[43438] = "Corborus",
		[40401] = "Quake",
		[186284] = "Gutchewer Bear",
		[196642] = "Hungry Lasher",
		[43662] = "Unbound Earth Rager",
		[39698] = "Karsh Steelbender",
		[194469] = "Fledgling Slasher",
		[45932] = "Skyfall Star",
		[189227] = "Qalashi Hunter",
		[192680] = "Guardian Sentry",
		[29264] = "Spirit Wolf <Imbiss>",
		[50376] = "Angered Earth <Quake>",
		[203806] = "Whisper in the Dark",
		[102287] = "Emberhusk Dominator",
		[165189] = "Weevil",
		[189869] = "Primalist Infiltrator",
		[48906] = "Blaze of the Heavens",
		[190381] = "Rotburst Totem <Decatriarch Wratheye>",
		[1860] = "Kal'krit",
		[39987] = "Evolved Twilight Zealot",
		[203809] = "Entropic Hatred",
		[77936] = "Greater Storm Elemental <Kihnshar>",
		[59764] = "Healing Tide Totem <Doubleblank>",
		[126919] = "Irontide Stormcaller",
		[204670] = "Monstrous Behemoth",
		[206058] = "Clockwork Sapper",
		[100818] = "Bellowing Idol",
		[206037] = "Winterskorn Vrykul",
		[196043] = "Primalist Infuser",
		[201467] = "Stonebreath Summoner",
		[54688] = "Time-Twisted Nightsaber",
		[45704] = "Lurking Tempest",
		[91004] = "Ularogg Cragshaper",
		[126841] = "Sharkbait",
		[2729] = "Elder Crag Coyote",
		[126969] = "Trothak",
		[203811] = "Incarnation of Entropy",
		[203939] = "Animation Fluid",
		[189230] = "Earthshaker Theurgist",
		[202613] = "Portalkeeper Cimbra",
		[196200] = "Algeth'ar Echoknight",
		[202610] = "Winglord Dezran",
		[44926] = "Oathsworn Wanderer",
		[129527] = "Bilge Rat Buccaneer",
		[203812] = "Voice From Beyond",
		[1863] = "Domantia",
		[101075] = "Wormspeaker Devout",
		[45126] = "Earthquake",
		[45007] = "Enslaved Bandit",
		[47085] = "Grounding Field",
		[189235] = "Overseer Lahar",
		[189363] = "Infected Lasher",
		[45062] = "Oathsworn Scorpid Keeper",
		[201773] = "Eternal Blaze",
		[99541] = "Risen Skulker",
		[43242] = "Lava Fissure",
		[26776] = "Direbrew Minion",
		[186124] = "Gashtooth",
		[100820] = "Spirit Wolf <Spicyhot-Zul'jin>",
		[54566] = "Ruptured Ground <Time-Twisted Breaker>",
		[202791] = "Ignara",
		[185528] = "Trickclaw Mystic",
		[185656] = "Filth Caller",
		[205734] = "Sundered Edgelord",
		[189470] = "Lava Flare",
		[102232] = "Rockbound Trapper",
		[43537] = "Stonecore Earthshaper",
		[190085] = "Grounding Spear <Chargath, Bane of Scales>",
		[45259] = "Servant of Siamat <[*] Static Shock>",
		[185529] = "Bracken Warscourge",
		[61056] = "Primal Earth Elemental",
		[186125] = "Tricktotem",
		[44896] = "Pygmy Brute",
		[205478] = "Conduit Guardian",
		[40817] = "Shadow of Obsidius",
		[129529] = "Blacktooth Scrapper",
		[43391] = "Millhouse Manastorm",
		[45935] = "Temple Adept",
		[196203] = "Ethereal Restorer",
		[44976] = "Neferset Plaguebringer",
		[102430] = "Tarspitter Slug",
		[190023] = "Lava Tentacles <Magmatusk>",
		[184124] = "Sentinel Talondras",
		[205735] = "Sundered Preserver",
		[40021] = "Incendiary Spark",
		[186658] = "Stonevault Geomancer",
		[186191] = "Decay Speaker",
		[45926] = "Servant of Asaad",
		[200115] = "Deepflayer Broodmatron",
		[47342] = "Twister",
		[187224] = "Vile Rothexer",
		[205736] = "Sundered Siegemaster",
		[205628] = "Twisted Elementium",
		[129601] = "Cutwater Harpooner",
		[43875] = "Asaad",
		[205673] = "Sundered Devourer",
		[201261] = "Kazzara, the Hellforged",
		[63508] = "Xuen <Treemnk-Stormrage>",
		[186208] = "Rotbow Stalker",
		[202668] = "Astral Formation <Sarkareth>",
		[203819] = "Nal ks'kol Defense Orb",
		[43801] = "Heaven's Fury",
		[187599] = "Qalashi Bonebreaker",
		[169421] = "Felguard",
		[54983] = "Treant <Mcjiggs>",
		[45919] = "Young Storm Dragon",
		[187315] = "Disease Slasher",
		[54521] = "Geist Toss",
		[201774] = "Essence of Shadow",
		[185534] = "Bonebolt Hunter",
		[199984] = "Scalecommander Sarkareth",
		[44977] = "Neferset Torturer",
		[31216] = "Mirror Image <Qamari-Area52>",
		[203825] = "Voracious Magma Worm",
		[205611] = "Molten Hound",
		[39990] = "Twilight Zealot",
		[90998] = "Blightshard Shaper",
		[50284] = "Twilight Zealot",
		[190923] = "Zephyrling",
		[200113] = "Scavenging Flayer",
		[196671] = "Arcane Ravager",
		[40084] = "Bellows Slave",
		[44234] = "Vicious Leech",
		[192788] = "Qalashi Thaumaturge",
		[44922] = "Oathsworn Axemaster",
		[197398] = "Hungry Lasher",
		[201668] = "Neltharion",
		[129788] = "Irontide Bonesaw",
		[203594] = "Lumbering Boulder",
		[126847] = "Captain Raoul",
		[184130] = "Earthen Custodian",
		[194745] = "Rotfang Hyena",
		[201465] = "Cinderstep Melter",
		[201466] = "Cinderstep Igniter",
		[54920] = "Infinite Suppressor",
		[169425] = "Felhound",
		[201469] = "Restless Pebble",
		[40019] = "Twilight Obsidian Borer",
		[201522] = "Summitshaper Lorac",
		[54544] = "Echo of Tyrande",
		[109137] = "Angry Crowd",
		[192699] = "Forge-Keep Overseer",
		[195399] = "Curious Swoglet",
		[169426] = "Infernal",
		[186945] = "Searing Cannonfire",
		[126848] = "Captain Eudora",
		[189247] = "Tamed Phoenix",
		[19668] = "Shadowfiend <Picklechick>",
		[40023] = "Defiled Earth Rager",
		[187666] = "Ezrigeth",
		[202108] = "Djaradin Dragonhunter",
		[192781] = "Ore Elemental",
		[204337] = "Lurking Tempest",
		[201552] = "Overseer Stonetongue",
		[205622] = "Krono Sandtongue",
		[47238] = "Whipping Wind",
		[203826] = "Colossal Draconic Golem",
		[40164] = "Fire Cyclone",
		[91003] = "Rokmora",
		[169428] = "Wrathguard",
		[184022] = "Stonevault Geomancer",
		[190366] = "Curious Swoglet",
		[184134] = "Scavenging Leaper",
		[186783] = "Cauldronbearer Blakor",
		[54952] = "Brittle Ghoul",
		[105720] = "Understone Drudge",
		[185508] = "Claw Fighter",
		[169429] = "Shivarra",
		[4844] = "Shadowforge Surveyor",
		[126832] = "Skycap'n Kragg",
		[44819] = "Siamat",
		[203700] = "Flamebringer Shaman",
		[129599] = "Cutwater Knife Juggler",
		[198872] = "Sundered Manaweaver",
		[203466] = "Kapraku",
		[169430] = "Ur'zul",
		[91001] = "Tarspitter Lurker",
		[73967] = "Niuzao <Onedragon-Stormrage>",
		[186664] = "Stonevault Ambusher",
		[205671] = "Shadow Additive <Sundered Chemist>",
		[204852] = "Blazing Spear",
		[127106] = "Irontide Officer",
		[202910] = "Desolate Blossom",
		[202167] = "Ray of Anguish <Kazzara, the Hellforged>",
		[189266] = "Qalashi Trainee",
		[190362] = "Dazzling Dragonfly",
		[205620] = "Malgosa Spellbinder",
		[190403] = "Glacial Proto-Dragon",
		[129600] = "Bilge Rat Brinescale",
		[192329] = "Territorial Eagle",
		[190377] = "Primalist Icecaller",
		[189478] = "Forgemaster Gorek",
		[43878] = "Grand Vizier Ertan",
		[43014] = "Imp",
		[91332] = "Stoneclaw Hunter",
	},
	["death_recap"] = {
		["show_segments"] = false,
		["enabled"] = true,
		["show_life_percent"] = false,
		["relevance_time"] = 7,
	},
	["spell_pool"] = {
		12, -- [1]
		3, -- [2]
		"Environment (Falling)", -- [3]
		[387985] = "Unstable Tear <Apoplectic-Alexstrasza>",
		[61447] = 11,
		[53385] = 2,
		[321442] = 5,
		[103171] = "[*] Blighted Arrows",
		[279469] = 6,
		[386963] = 10,
		[408462] = "Thadrion",
		[405391] = "Rionthus",
		[321444] = 5,
		[405392] = "Rionthus",
		[394131] = 4,
		[411535] = 10,
		[404369] = "Luddyxdxd-Kel'Thuzad",
		[393108] = 2,
		[127230] = 3,
		[90887] = 8,
		[405394] = "Shadowflame Amalgamation",
		[47755] = 5,
		[95750] = 9,
		[256477] = "Hammer Shark",
		[411539] = 1,
		[408468] = 11,
		[410516] = "Warlord Kagni",
		[395160] = "Luddyxdxd-Kel'Thuzad",
		[265144] = 5,
		[255966] = "Skycap'n Kragg",
		[351140] = 8,
		[88073] = "Cloud Prince",
		[414613] = 11,
		[367521] = "Bonebolt Hunter",
		[389020] = 3,
		[385949] = 4,
		[401306] = 2,
		[94472] = 5,
		[115203] = 10,
		[51723] = 4,
		[385951] = 4,
		[209388] = 2,
		[24394] = 3,
		[419737] = 11,
		[404381] = "Luddyxdxd-Kel'Thuzad",
		[384930] = "Skulking Gutstabber",
		[385954] = 1,
		[382883] = "Vile Rothexer",
		[107270] = 10,
		[57994] = 7,
		[527] = 5,
		[409502] = 5,
		[2139] = 8,
		[153596] = 8,
		[396195] = 1,
		[385958] = "Vexamus <Magic Book>",
		[370602] = 11,
		[388007] = 2,
		[401316] = "Kazzara, the Hellforged",
		[385960] = 4,
		[382889] = 7,
		[278467] = "Rummy Mancomb",
		[395175] = 11,
		[388009] = 2,
		[401318] = "Kazzara, the Hellforged",
		[383915] = 1,
		[401319] = "Kazzara, the Hellforged",
		[385963] = "Khajin the Unyielding",
		[370607] = 5,
		[388011] = 2,
		[346038] = 6,
		[327611] = 6,
		[410535] = "Warlord Kagni",
		[224239] = 2,
		[388013] = 2,
		[395180] = 2,
		[396204] = 1,
		[190456] = 1,
		[407466] = 5,
		[401324] = 2,
		[407467] = 2,
		[76561] = "Twilight Zealot",
		[401325] = "Sarkareth",
		[207349] = 6,
		[407468] = 5,
		[200183] = 5,
		[82192] = 8,
		[401327] = "Sarkareth",
		[5221] = 11,
		[274383] = "Vermin Trapper",
		[329666] = 3,
		[198137] = 2,
		[267218] = 9,
		[391092] = 5,
		[383926] = 1,
		[386998] = 9,
		[392117] = 11,
		[404403] = "Sarkareth",
		[376762] = 2,
		[407475] = 2,
		[388024] = 10,
		[417713] = 11,
		[403381] = 7,
		[49039] = 6,
		[417714] = 11,
		[114954] = 8,
		[403382] = 2,
		[388026] = 10,
		[256494] = "Trothak",
		[407478] = 2,
		[322507] = 10,
		[315341] = 4,
		[391099] = 5,
		[408503] = 10,
		[89105] = "Lurking Tempest",
		[385981] = "[*] Arcane Orb",
		[423860] = 8,
		[408504] = 11,
		[405433] = "Neltharion",
		[369602] = "Olaf",
		[403386] = 11,
		[383935] = "Watcher Irideus",
		[47632] = 6,
		[373698] = "Brackenhide Shaper",
		[395197] = 7,
		[155145] = 2,
		[389055] = "Arcane Forager",
		[418744] = 7,
		[226296] = "Vileshard Hulk",
		[384961] = "Rotbow Stalker",
		[369605] = "Bromach",
		[374724] = "Flamecaller Aymi",
		[183811] = 2,
		[405437] = "Shadowflame Amalgamation",
		[423865] = 7,
		[416699] = 9,
		[95249] = "Blaze of the Heavens",
		[403391] = 3,
		[388035] = "Spirit Beast <Derringerr>",
		[389059] = "Chargath, Bane of Scales",
		[403392] = 3,
		[383941] = 11,
		[274400] = "Cutwater Duelist",
		[403393] = 3,
		[388037] = 6,
		[86292] = "Ertan's Vortex",
		[391109] = 5,
		[307162] = 9,
		[120588] = 7,
		[401348] = "Magmorax",
		[30283] = 9,
		[414658] = 8,
		[378827] = "Qalashi Plunderer",
		[196100] = 9,
		[81942] = "Heaven's Fury",
		[350163] = "Spiteful Shade",
		[3355] = 3,
		[307166] = 5,
		[414660] = 8,
		[845] = 1,
		[200196] = 5,
		[6789] = 9,
		[80151] = "Stonecore Magmalord",
		[374735] = "Flamecaller Aymi",
		[376783] = "Warlord Sargha",
		[414662] = 8,
		[378831] = "Qalashi Plunderer",
		[388045] = 3,
		[319454] = 11,
		[414663] = 8,
		[388046] = "Stinkbreath",
		[190984] = 11,
		[264173] = 9,
		[408522] = 11,
		[217090] = "Dargrul",
		[388048] = 10,
		[386001] = 6,
		[195592] = 7,
		[376788] = "Osykrond-Proudmoore",
		[390097] = "Darkglare <Vonzur-Azralon>",
		[16591] = 3,
		[386003] = 6,
		[387028] = 7,
		[392147] = 11,
		[394195] = 8,
		[101908] = "Geist Toss",
		[405457] = 3,
		[323558] = 4,
		[91415] = "Augh",
		[412625] = "[*] Shadowflame Spill",
		[323559] = 4,
		[370652] = 7,
		[343011] = 12,
		[323560] = 4,
		[122128] = 5,
		[155158] = 8,
		[372701] = "Sentinel Talondras",
		[406485] = 11,
		[343013] = 12,
		[376797] = "Treemouth",
		[72221] = 8,
		[388060] = "Stinkbreath",
		[406488] = 11,
		[228358] = 8,
		[307185] = 10,
		[31884] = 2,
		[227847] = 1,
		[378849] = 6,
		[48020] = 9,
		[84251] = "Earthquake",
		[419800] = 8,
		[105238] = "Undying Flame",
		[228360] = 5,
		[44949] = 1,
		[373733] = "Chargath, Bane of Scales",
		[186387] = 3,
		[388788] = "[*] Rogue Waves",
		[218164] = 10,
		[372711] = "Brackenhide Shaper",
		[377830] = "Rira Hackclaw",
		[1066] = 11,
		[404448] = "Rashok",
		[122] = 8,
		[313015] = 10,
		[370665] = "Osykrond-Proudmoore",
		[392164] = 6,
		[200721] = "Dargrul",
		[211793] = 6,
		[407521] = 12,
		[388070] = 9,
		[244067] = 3,
		[418783] = 11,
		[370667] = "Lizardmage-Illidan",
		[408546] = 11,
		[93806] = 3,
		[1126] = 11,
		[313424] = 10,
		[363502] = "Guanl-Ner'zhul",
		[376811] = "Treemouth",
		[113942] = 9,
		[321529] = 8,
		[383978] = 1,
		[401382] = "Past Self <Scytale-Arthas>",
		[122281] = 10,
		[45334] = 11,
		[383979] = "Gutshot",
		[401383] = "Sarkareth",
		[373742] = "Chargath, Bane of Scales",
		[389533] = 1,
		[400360] = 11,
		[372719] = "Sentinel Talondras",
		[117014] = 7,
		[399337] = 4,
		[392171] = "Neltharus Weapons",
		[385005] = "Understone Drudge",
		[13737] = "Twilight Zealot",
		[203796] = 12,
		[385042] = 1,
		[409576] = "Whisper in the Dark",
		[254472] = 2,
		[344006] = 10,
		[382866] = 9,
		[185358] = 3,
		[343963] = 10,
		[280849] = 1,
		[382865] = 9,
		[409578] = "Entropic Hatred",
		[193007] = 9,
		[389007] = "[*] Wild Energy",
		[408458] = 2,
		[382864] = 9,
		[378057] = "Decaying Slime <Treemouth>",
		[81440] = "Millhouse Manastorm",
		[388081] = 9,
		[383997] = 8,
		[254474] = 2,
		[382963] = 10,
		[16593] = 3,
		[409581] = "Whisper in the Dark",
		[215572] = 1,
		[408457] = 10,
		[388083] = 9,
		[188443] = 7,
		[84256] = "Oathsworn Axemaster",
		[387264] = "Decatriarch Wratheye",
		[5302] = 1,
		[385013] = 1,
		[198813] = 12,
		[346111] = 5,
		[260734] = 7,
		[401394] = 9,
		[410608] = "Rionthus",
		[407537] = 3,
		[405681] = "Klekkazul <Dotvader-Antonidas>",
		[409560] = "Luddyxdxd-Kel'Thuzad",
		[361469] = "Partikle",
		[411633] = "[*] Burning Chains",
		[375802] = "Arcodis",
		[381955] = 7,
		[369660] = "Quaking Totem <Bromach>",
		[350209] = "[*] Spiteful Fixation",
		[393099] = 10,
		[405492] = "Thadrion",
		[406516] = "Kazzara, the Hellforged",
		[118297] = "Primal Fire Elemental <Daffné-Zul'jin>",
		[201754] = "Spirit Beast <Derringerr>",
		[383169] = 2,
		[369662] = "Quaking Totem <Bromach>",
		[387066] = 9,
		[408737] = 12,
		[405383] = "Thadrion",
		[369663] = "Quaking Totem <Bromach>",
		[372838] = 5,
		[288675] = 7,
		[401400] = "Flamebound Huntsman",
		[414875] = "Jellydragon-Illidan",
		[404456] = "Sarkareth",
		[408567] = "Warlord Kagni",
		[153640] = 8,
		[383883] = 8,
		[411639] = 1,
		[382859] = 8,
		[376832] = "Dragonpeace-Lightning'sBlade",
		[291843] = 11,
		[409476] = "Voracious Magma Worm",
		[77575] = 6,
		[157736] = 9,
		[406522] = 5,
		[391166] = 12,
		[296863] = 9,
		[319504] = 4,
		[394238] = "Shadowy Tear <Apoplectic-Alexstrasza>",
		[407547] = "Rashok",
		[72968] = 2,
		[376835] = 6,
		[48792] = 6,
		[272413] = "Cutwater Harpooner",
		[73510] = 5,
		[407480] = 2,
		[390145] = 12,
		[405641] = "Shadowflame Amalgamation",
		[396288] = "Luddyxdxd-Kel'Thuzad",
		[376837] = 2,
		[381956] = 7,
		[195617] = 6,
		[6262] = 9,
		[409598] = "Neltharion",
		[381957] = 7,
		[391171] = 12,
		[384150] = "Claw Fighter",
		[385029] = "Fleshripper Vulture",
		[390148] = "Scytale-Arthas",
		[407552] = "Rionthus",
		[408576] = "Rionthus",
		[377738] = "Refti Custodian",
		[369674] = "Stonevault Geomancer",
		[327574] = 6,
		[157228] = 11,
		[327701] = 2,
		[369675] = "Stonevault Geomancer",
		[257044] = 3,
		[48025] = "Kalythra-Sargeras",
		[262161] = 1,
		[394246] = "Chaos Tear <Apoplectic-Alexstrasza>",
		[259092] = "Irontide Stormcaller",
		[363534] = "Osykrond-Proudmoore",
		[384161] = "Qalashi Irontorch",
		[369677] = "Olaf",
		[257045] = 3,
		[383816] = 6,
		[327704] = 5,
		[86309] = "Ertan's Vortex",
		[222238] = 6,
		[416771] = 2,
		[409605] = 4,
		[409473] = "Voracious Magma Worm",
		[218617] = 1,
		[378760] = 8,
		[409606] = 4,
		[365585] = "Partikle",
		[378054] = "[*] Withering Away!",
		[76584] = "Twilight Zealot",
		[1714] = 9,
		[236060] = 8,
		[280615] = 7,
		[384014] = "Watcher Irideus",
		[225311] = 2,
		[381967] = 3,
		[346136] = 7,
		[384015] = "Watcher Irideus",
		[385039] = "Skulking Gutstabber",
		[398467] = 4,
		[406530] = "[*] Riftburn",
		[382854] = 8,
		[376850] = "Arcodis",
		[1766] = 4,
		[64790] = 1,
		[210042] = 12,
		[101411] = "Echo of Sylvanas",
		[403408] = 7,
		[375985] = 7,
		[7] = "Environment (Lava)",
		[409612] = "Whisper in the Dark",
		[193065] = 5,
		[377991] = "Guardian Sentry",
		[384019] = "Chargath, Bane of Scales",
		[246287] = 5,
		[315584] = 4,
		[411661] = 7,
		[1822] = 11,
		[184364] = 1,
		[410638] = 5,
		[272432] = "Wrathguard <Flickers-Area52>",
		[353263] = "Osykrond-Proudmoore",
		[372760] = 5,
		[85288] = 1,
		[382998] = 8,
		[382089] = 7,
		[385046] = "Skulking Gutstabber",
		[390165] = "Arcodis",
		[321538] = "Scalehide <Wargrimz>",
		[202719] = 12,
		[375939] = 4,
		[207400] = 7,
		[272435] = "Darkhound <Flickers-Area52>",
		[193505] = "Vileshard Hulk",
		[401428] = 8,
		[402617] = "Eternal Blaze",
		[387096] = 9,
		[2948] = 8,
		[187874] = 7,
		[382850] = 11,
		[374812] = "Forgemaster Gorek",
		[81706] = "Lockmaw",
		[184367] = 1,
		[394111] = 11,
		[195630] = 10,
		[189998] = 3,
		[44425] = 8,
		[390170] = 4,
		[203819] = 12,
		[265273] = 9,
		[7814] = "Bronwen <Kolswlk-Area52>",
		[369696] = "Scavenging Leaper",
		[132157] = 5,
		[1966] = 4,
		[335913] = 10,
		[369697] = "Scavenging Leaper",
		[407576] = 10,
		[384030] = 2,
		[382849] = 11,
		[8936] = 11,
		[132158] = 11,
		[334934] = 1,
		[382028] = 7,
		[361509] = "Luddyxdxd-Kel'Thuzad",
		[378818] = "Qalashi Thaumaturge",
		[391058] = 12,
		[372610] = 5,
		[267325] = 12,
		[383009] = 7,
		[76589] = "Twilight Zealot",
		[408578] = 2,
		[410651] = "Luddyxdxd-Kel'Thuzad",
		[370562] = "Osykrond-Proudmoore",
		[385126] = 2,
		[385058] = "Skulking Gutstabber",
		[267327] = 12,
		[395296] = "Luddyxdxd-Kel'Thuzad",
		[408605] = "Sundered Devastator",
		[385059] = 1,
		[369703] = "Bromach",
		[386173] = "Vexamus <Magic Book>",
		[372829] = 7,
		[385060] = 1,
		[410654] = "Sarkareth",
		[374823] = "Squallbringer Cyraz",
		[229976] = 2,
		[385061] = 1,
		[267330] = 12,
		[387109] = 9,
		[384038] = 8,
		[409632] = 6,
		[267331] = 12,
		[383015] = "Poison Cleansing Totem <Stormart>",
		[209426] = 12,
		[407597] = "Rashok",
		[633] = 2,
		[376934] = "Treemouth",
		[394324] = 4,
		[75823] = "Corla, Herald of Twilight",
		[108839] = 8,
		[383017] = 7,
		[373862] = "Osykrond-Proudmoore",
		[114255] = 5,
		[373804] = "Brackenhide Shaper",
		[387113] = 2,
		[228477] = 12,
		[274555] = "Soggy Shiprat",
		[23510] = 7,
		[115450] = 10,
		[243241] = 5,
		[185311] = 4,
		[406566] = "Primal Lava Elemental",
		[383020] = 7,
		[408614] = "Sundered Devastator",
		[280715] = 1,
		[386092] = 6,
		[409689] = 7,
		[173184] = 7,
		[406428] = "Sarkareth",
		[256551] = "Hammer Shark",
		[403497] = "Astral Formation <Sarkareth>",
		[413786] = 2,
		[344120] = 3,
		[205364] = 5,
		[217694] = 8,
		[111400] = 9,
		[344121] = 3,
		[256552] = "Hammer Shark",
		[359317] = 7,
		[404523] = 7,
		[372787] = 5,
		[315508] = 4,
		[391215] = 12,
		[408619] = "Sundered Devastator",
		[390242] = 11,
		[390192] = 12,
		[407596] = "Rashok",
		[408620] = "Obsidian Guard",
		[205386] = 5,
		[390193] = 9,
		[2580] = 1,
		[367484] = "Claw Fighter",
		[409645] = 12,
		[394289] = 5,
		[10444] = 7,
		[400432] = "Kazzara, the Hellforged",
		[25046] = 4,
		[390195] = 12,
		[132169] = 1,
		[84784] = "Augh",
		[403459] = "Essence of Shadow",
		[105771] = 1,
		[381966] = 3,
		[408624] = "Obsidian Guard",
		[193534] = 3,
		[377912] = "Guardian Sentry",
		[409442] = 2,
		[381006] = "Lizardmage-Illidan",
		[397364] = 1,
		[398388] = 3,
		[374842] = "Forgemaster Gorek",
		[75571] = "Rom'ogg Bonecrusher",
		[79922] = "Stonecore Flayer",
		[108843] = 8,
		[389054] = "Arcane Forager",
		[84785] = "Augh",
		[198715] = "Val'kyr Battlemaiden <Angelofdeãth-Dalaran>",
		[191037] = 11,
		[411547] = 1,
		[403671] = "Magmorax",
		[409652] = 9,
		[410676] = "Magmorax",
		[403510] = "Sarkareth",
		[84521] = "Servant of Siamat <[*] Static Shock>",
		[2060] = 5,
		[408431] = "Sarkareth",
		[120361] = 3,
		[55090] = 6,
		[79923] = "Stonecore Flayer",
		[396167] = 10,
		[88625] = 5,
		[2908] = 11,
		[331850] = 4,
		[370666] = "Osykrond-Proudmoore",
		[81459] = "Stonecore Earthshaper",
		[294133] = 2,
		[389181] = "Watcher Irideus",
		[406585] = "Warlord Kagni",
		[160839] = 12,
		[326733] = 2,
		[362361] = "Guanl-Ner'zhul",
		[8092] = 5,
		[116267] = 8,
		[56222] = 6,
		[108589] = "Murozond",
		[80180] = "Stonecore Bruiser",
		[392303] = 11,
		[311193] = 1,
		[401469] = 7,
		[115192] = 4,
		[192090] = 11,
		[197209] = 7,
		[49184] = 6,
		[409604] = 4,
		[226361] = "Rockbound Pelter",
		[106830] = 11,
		[397376] = 7,
		[207317] = 6,
		[391234] = 12,
		[413546] = "Magmorax",
		[198103] = 7,
		[382021] = 7,
		[414866] = 2,
		[195181] = 6,
		[6343] = 1,
		[390212] = 12,
		[226388] = "[*] Rancid Ooze",
		[400450] = "Warlord Kagni",
		[409664] = 3,
		[270569] = 9,
		[185438] = 4,
		[119381] = 10,
		[369791] = "Eric \"The Swift\"",
		[382024] = 7,
		[387143] = 9,
		[52128] = 7,
		[57723] = 12,
		[373835] = "Osykrond-Proudmoore",
		[115191] = 4,
		[382079] = 8,
		[376907] = 6,
		[390216] = 6,
		[126507] = 4,
		[102193] = "Echo of Tyrande",
		[397383] = "Magma Mystic",
		[406597] = "Kazzara, the Hellforged",
		[395336] = 11,
		[404550] = 7,
		[78903] = "Ozruk",
		[394313] = 1,
		[388973] = "Darlys-Area52",
		[404551] = 7,
		[401480] = "Neltharion",
		[6807] = 11,
		[374863] = "Squallbringer Cyraz",
		[333889] = 9,
		[397386] = "Magma Mystic",
		[406600] = 4,
		[81463] = "Stonecore Earthshaper",
		[392268] = "Luddyxdxd-Kel'Thuzad",
		[229438] = 3,
		[406601] = "Kazzara, the Hellforged",
		[383104] = 1,
		[1850] = 11,
		[401257] = 5,
		[383018] = 7,
		[390137] = 12,
		[375890] = "Magmatusk",
		[58499] = 1,
		[80184] = "Stonecore Bruiser",
		[370772] = 7,
		[7268] = 8,
		[257478] = "Irontide Mastiff",
		[390224] = 12,
		[370773] = 7,
		[384050] = 11,
		[36901] = 8,
		[384004] = 12,
		[387154] = 9,
		[375893] = 3,
		[107570] = 1,
		[409445] = "Voracious Magma Worm",
		[54049] = "Jhuulum <Mersan-Arthas>",
		[33702] = 9,
		[409678] = "Luddyxdxd-Kel'Thuzad",
		[75590] = "Twilight Sadist",
		[383061] = "Liquid Magma Totem <Edie-Bloodhoof>",
		[384035] = 8,
		[372824] = "Neltharus Weapons",
		[406608] = 4,
		[387157] = 9,
		[390197] = 12,
		[3716] = "Charnar <Smokeey-Muradin>",
		[369754] = "Bromach",
		[387158] = 9,
		[24858] = 11,
		[256060] = "Skycap'n Kragg",
		[394325] = 4,
		[202770] = 11,
		[384088] = 7,
		[188493] = "Naraxas",
		[165961] = 11,
		[185422] = 4,
		[381802] = 4,
		[48181] = 9,
		[390232] = 3,
		[387161] = 9,
		[212552] = 6,
		[188494] = "[*] Rancid Maw",
		[394328] = 4,
		[108853] = 8,
		[375901] = 5,
		[395110] = 11,
		[390234] = 7,
		[403543] = "[*] Lava Wave",
		[371807] = "Dovahkeen-BloodFurnace",
		[327786] = 2,
		[377950] = "Tricktotem",
		[378974] = 2,
		[87618] = "Asaad",
		[88060] = "Armored Mistral",
		[212431] = 3,
		[262115] = 1,
		[375904] = 5,
		[404425] = "Desolate Blossom",
		[381965] = 3,
		[407641] = "Rashok",
		[408665] = 8,
		[372834] = 7,
		[178173] = 10,
		[388025] = 10,
		[392329] = 11,
		[413785] = "Entropic Hatred",
		[390239] = 10,
		[246851] = 3,
		[200657] = 2,
		[397406] = "Lizardmage-Illidan",
		[385948] = 4,
		[114165] = 2,
		[388193] = 10,
		[207311] = 6,
		[86331] = "Grand Vizier Ertan",
		[246852] = 3,
		[405439] = "[*] Tactical Destruction",
		[107574] = 1,
		[263297] = "Lizardmage-Illidan",
		[401500] = "Sarkareth",
		[192082] = 7,
		[405599] = "Thadrion",
		[385168] = "Primalist Galesinger",
		[246853] = 3,
		[410625] = "Sarkareth",
		[200656] = 2,
		[223819] = 2,
		[403460] = 2,
		[17] = 5,
		[405601] = "Thadrion",
		[390118] = "Khajin the Unyielding",
		[370794] = 6,
		[408673] = 8,
		[385127] = 2,
		[81216] = "Millhouse Manastorm",
		[393057] = 10,
		[408674] = 8,
		[383843] = 2,
		[390247] = 1,
		[272412] = "Cutwater Harpooner",
		[408675] = 12,
		[344179] = 7,
		[394080] = 4,
		[411747] = "Twisted Elementium",
		[392296] = 3,
		[401510] = "Rashok",
		[393056] = 10,
		[387178] = 2,
		[82750] = "Neferset Torturer",
		[206930] = 6,
		[377965] = "Tricktotem",
		[387179] = 10,
		[388203] = 10,
		[204883] = 5,
		[404472] = "Neldris",
		[411750] = "Twisted Elementium",
		[414865] = 2,
		[377859] = "Treemouth",
		[373872] = "Monstrous Decay",
		[378991] = 11,
		[294020] = 7,
		[393055] = 12,
		[408533] = 2,
		[378992] = 11,
		[404358] = 2,
		[115767] = 1,
		[386159] = 3,
		[90708] = 3,
		[388207] = 10,
		[84031] = "Oathsworn Skinner",
		[406635] = 12,
		[387184] = 10,
		[84799] = "Augh",
		[97340] = 2,
		[369781] = "Eric \"The Swift\"",
		[411755] = "Conduit Guardian",
		[375924] = "Eric \"The Swift\"",
		[401518] = 1,
		[406637] = 2,
		[226385] = "Tarspitter Lurker",
		[5176] = 11,
		[401519] = "Luddyxdxd-Kel'Thuzad",
		[393054] = 12,
		[244813] = 8,
		[83776] = "Pygmy Firebreather",
		[84032] = "Neferset Darkcaster",
		[386164] = 1,
		[197721] = 11,
		[281465] = 2,
		[270481] = "Demonic Tyrant <Kkyzz-Akama>",
		[390260] = 6,
		[373917] = "Decatriarch Wratheye",
		[406678] = "Zskarn",
		[195627] = 4,
		[97341] = 5,
		[280720] = 4,
		[82753] = "Neferset Theurgist",
		[405618] = "Warlord Kagni",
		[43688] = 5,
		[35079] = 3,
		[78674] = 11,
		[374776] = 6,
		[216521] = 10,
		[333957] = 7,
		[378847] = "Qalashi Spinecrusher",
		[401525] = "Sarkareth",
		[256589] = "Captain Raoul",
		[126519] = 6,
		[378015] = 3,
		[193538] = 4,
		[392170] = 7,
		[207407] = 12,
		[343173] = 4,
		[31707] = "Water Elemental <Xyluh-Thrall>",
		[211545] = 11,
		[268440] = "Irontide Crackshot",
		[83778] = "Pygmy Firebreather",
		[200652] = 2,
		[406647] = 2,
		[414873] = "Jellydragon-Illidan",
		[388220] = 10,
		[260174] = 2,
		[382078] = 12,
		[55078] = 6,
		[171620] = "Kalythra-Sargeras",
		[390155] = 12,
		[197214] = 7,
		[406358] = "Neldris",
		[47528] = 6,
		[405626] = "Magmorax",
		[107837] = 8,
		[333964] = 7,
		[2643] = 3,
		[409722] = 6,
		[390271] = 6,
		[84547] = "[*] Static Shock",
		[384129] = 8,
		[356488] = 6,
		[81220] = "Millhouse Manastorm",
		[199775] = "Naraxas",
		[390178] = 6,
		[376997] = "Crawth",
		[345228] = 6,
		[197626] = 11,
		[119611] = 10,
		[409725] = 9,
		[279709] = 11,
		[409616] = "Whisper in the Dark",
		[83780] = "Pygmy Scout",
		[97547] = 11,
		[345230] = 9,
		[390339] = 2,
		[214621] = 5,
		[205345] = 8,
		[386181] = "Vexamus <Magic Book>",
		[191587] = 6,
		[119085] = 10,
		[192611] = 12,
		[373897] = "Decayed Elder",
		[12051] = 8,
		[127802] = 6,
		[369828] = "Vicious Basilisk",
		[382126] = 11,
		[376666] = 7,
		[257620] = 3,
		[247402] = "Yzira-MoonGuard",
		[373899] = "Decayed Elder",
		[225822] = 11,
		[17735] = "Jhomphog <Phenanthrene-Frostwolf>",
		[270501] = 5,
		[377995] = "Forgemaster Gorek",
		[51714] = 6,
		[204301] = 2,
		[390105] = 10,
		[369806] = "Hulking Berserker",
		[379020] = "Neltharus Weapons",
		[396424] = "Chargath, Bane of Scales",
		[376780] = "Warlord Sargha",
		[75] = 3,
		[102132] = "Time-Twisted Breaker",
		[257622] = 3,
		[376974] = 6,
		[412618] = 5,
		[84550] = "Minion of Siamat",
		[408711] = 6,
		[405640] = "Shadowflame Amalgamation",
		[34477] = 3,
		[183401] = "Vileshard Crawler",
		[414661] = 8,
		[34861] = 5,
		[410760] = "Wild Vortex",
		[193639] = "Rockback Gnasher <Stoneclaw Hunter>",
		[82759] = "Neferset Theurgist",
		[372718] = "Sentinel Talondras",
		[369811] = "Hulking Berserker",
		[399500] = 4,
		[83783] = "Pygmy Brute",
		[135286] = 11,
		[390287] = 7,
		[366741] = 5,
		[76617] = "Conflagration",
		[32409] = "[*] Shadow Word: Death",
		[378003] = "Guardian Sentry",
		[399502] = 7,
		[209862] = "[*] Volcanic Plume",
		[405645] = "Shadowflame Amalgamation",
		[173183] = 7,
		[193641] = 4,
		[408717] = "Essence of Shadow",
		[200758] = 4,
		[390290] = "Infuser Sariya",
		[379029] = 8,
		[384148] = 1,
		[29722] = 9,
		[386196] = 1,
		[370840] = "Dovahkeen-BloodFurnace",
		[76618] = "Conflagration",
		[108366] = 9,
		[373912] = "Decatriarch Wratheye",
		[57984] = "Greater Fire Elemental <Stormhummer-Ragnaros>",
		[388245] = "Gulping Goliath",
		[214980] = 12,
		[369818] = "Hulking Berserker",
		[268467] = 8,
		[117526] = 3,
		[205766] = 8,
		[414864] = 6,
		[395413] = 10,
		[83785] = "Pygmy Brute",
		[75851] = "Karsh Steelbender",
		[373915] = "Decatriarch Wratheye",
		[117313] = 1,
		[43308] = 8,
		[184362] = 1,
		[386201] = "[*] Corrupted Mana",
		[183407] = "[*] Acid Splatter",
		[192109] = 7,
		[278708] = 6,
		[386202] = "Vexamus <Magic Book>",
		[82506] = "High Prophet Barim",
		[202347] = 11,
		[409749] = "Flamebound Huntsman",
		[402583] = 12,
		[377807] = "Rira Hackclaw",
		[374612] = "Skulking Zealot",
		[319836] = 8,
		[121153] = 4,
		[268473] = 8,
		[403380] = 7,
		[385181] = "Gulping Goliath",
		[195182] = 6,
		[411799] = "Oozing Sludge",
		[171636] = 1,
		[196718] = 12,
		[369826] = "Vicious Basilisk",
		[231435] = 2,
		[82763] = "Oathsworn Axemaster",
		[47666] = 5,
		[47788] = 5,
		[379041] = 2,
		[371875] = "Qalashi Trainee",
		[405316] = "Rashok",
		[386208] = 1,
		[274283] = 11,
		[44461] = 8,
		[400204] = 11,
		[228287] = 10,
		[263165] = 5,
		[371877] = "Darlys-Area52",
		[409756] = "Djaradin Commander",
		[2061] = 5,
		[274282] = 11,
		[82764] = "Oathsworn Pathfinder",
		[409757] = "Djaradin Commander",
		[406686] = "Djaradin Magmashaper",
		[225788] = 7,
		[371879] = "Darlys-Area52",
		[200732] = "Dargrul",
		[143924] = 12,
		[121411] = 4,
		[384165] = 2,
		[117828] = 9,
		[274281] = 11,
		[383928] = "Overseer Lahar",
		[57724] = "Spiroheals-Kalecgos",
		[102472] = "Echo of Tyrande",
		[366742] = 7,
		[411808] = "Bubbling Slime",
		[82765] = "Neferset Darkcaster",
		[406448] = 11,
		[12975] = 1,
		[263274] = "Skycap'n Kragg",
		[403376] = 4,
		[410814] = 4,
		[80206] = "Raz the Crazed",
		[52127] = 7,
		[405802] = 9,
		[397478] = 3,
		[260708] = 1,
		[411811] = "Bubbling Slime",
		[392360] = 11,
		[135299] = 3,
		[374606] = 6,
		[411839] = "Fragment of Fire",
		[375981] = 5,
		[409765] = 9,
		[378029] = "Gashtooth",
		[411813] = "Bubbling Slime",
		[271465] = "Malitosis",
		[217200] = 3,
		[410790] = 6,
		[274389] = "[*] Rat Traps",
		[164812] = 11,
		[382106] = 8,
		[373936] = "Wilted Oak",
		[403625] = "Sarkareth",
		[375984] = 7,
		[377008] = "Crawth",
		[82255] = "Harbinger of Darkness",
		[280776] = 1,
		[82767] = "Venomfang Crocolisk <Oathsworn Wanderer>",
		[377009] = "Crawth",
		[152108] = 9,
		[297157] = 8,
		[375986] = 7,
		[315585] = 4,
		[373939] = "Rotburst Totem <Decatriarch Wratheye>",
		[201846] = 7,
		[408388] = "Primalist Earthshaker",
		[405413] = "Rionthus",
		[382130] = 9,
		[212084] = 12,
		[411767] = "Warlord Kagni",
		[121836] = 10,
		[382131] = 9,
		[51490] = 7,
		[82768] = "Neferset Plaguebringer",
		[256106] = "Skycap'n Kragg",
		[373942] = "Decatriarch Wratheye",
		[403631] = "Luddyxdxd-Kel'Thuzad",
		[382851] = 11,
		[375215] = "Gulping Goliath",
		[373943] = "Wilted Oak",
		[2645] = 7,
		[378208] = "Gashtooth",
		[206967] = 6,
		[373944] = "Decatriarch Wratheye",
		[257460] = "[*] Fiery Debris",
		[396194] = 1,
		[409776] = "Arcodis",
		[382135] = 12,
		[374969] = "Forgemaster Gorek",
		[82769] = "[*] Infectious Plague",
		[377017] = "Warlord Sargha",
		[385228] = 1,
		[75347] = "Quake",
		[408754] = 12,
		[377018] = "Warlord Sargha",
		[228354] = 8,
		[374699] = "Flamecaller Aymi",
		[392375] = 7,
		[390981] = 5,
		[369853] = "Burly Rock-Thrower",
		[183433] = "Tarspitter Lurker",
		[411730] = "Molten Hound",
		[406730] = "Eternal Blaze",
		[382139] = 12,
		[407733] = "Neldris",
		[78675] = 11,
		[22812] = 11,
		[62124] = 2,
		[372134] = "Gitaxias-WyrmrestAccord",
		[359618] = "Arcodis",
		[196733] = 10,
		[406711] = 4,
		[80467] = "Ozruk",
		[386256] = 9,
		[408383] = 2,
		[406712] = "[*] Lava",
		[391356] = 11,
		[321469] = 3,
		[55342] = 8,
		[390181] = 12,
		[370901] = "Luddyxdxd-Kel'Thuzad",
		[47536] = 5,
		[378269] = 7,
		[418999] = 1,
		[387263] = 9,
		[853] = 2,
		[406414] = "[*] Azure Might",
		[382145] = 2,
		[391359] = 5,
		[384193] = 3,
		[155166] = 6,
		[382146] = 2,
		[386270] = 4,
		[382787] = "Brackenhide Slasher",
		[406333] = "Rashok",
		[410812] = 4,
		[350631] = 12,
		[102149] = "Moonlance <Echo of Tyrande>",
		[115989] = 6,
		[382148] = 8,
		[411837] = "Fragment of Fire",
		[371911] = 2,
		[15407] = 5,
		[382149] = 6,
		[376643] = 2,
		[401621] = "Sarkareth",
		[76588] = "Twilight Zealot",
		[382150] = 5,
		[370889] = "Osykrond-Proudmoore",
		[392388] = 4,
		[386959] = 10,
		[197625] = 11,
		[212105] = 12,
		[155777] = 11,
		[80195] = "Stonecore Bruiser",
		[382152] = 3,
		[227255] = 12,
		[408770] = 12,
		[377034] = "Crawth",
		[382153] = 11,
		[411842] = "Fragment of Fire",
		[408377] = 6,
		[267329] = 7,
		[382154] = 11,
		[114923] = 8,
		[382156] = 12,
		[188550] = 11,
		[390345] = 2,
		[391369] = 12,
		[49206] = 6,
		[62618] = 5,
		[386251] = 9,
		[403655] = "Kazzara, the Hellforged",
		[388998] = 3,
		[196741] = 10,
		[393019] = 2,
		[400185] = 9,
		[213011] = 12,
		[405704] = "Shadowflame Amalgamation",
		[406728] = "Eternal Blaze",
		[342232] = 8,
		[81751] = 5,
		[389325] = 10,
		[406729] = "Essence of Shadow",
		[370898] = "Luddyxdxd-Kel'Thuzad",
		[123725] = 10,
		[123981] = 6,
		[390350] = 1,
		[391374] = 12,
		[199176] = "Naraxas",
		[367503] = "Decay Speaker",
		[382161] = 2,
		[387461] = 11,
		[397514] = "Warlord Kagni",
		[385233] = 1,
		[406732] = "Nozzie-Illidan",
		[183435] = 2,
		[218100] = 6,
		[385234] = 1,
		[316643] = 1,
		[384827] = "Gutshot",
		[392401] = 4,
		[422090] = "Treant <Caobi-Tichondrius>",
		[395647] = "[*] Fiery Surge",
		[387283] = 9,
		[75610] = "Corla, Herald of Twilight",
		[137211] = 6,
		[291944] = 11,
		[42292] = 5,
		[392403] = 4,
		[2818] = 4,
		[82263] = "Soul Fragment",
		[199817] = "Naraxas",
		[401407] = "Flamebound Huntsman",
		[377048] = 6,
		[390357] = 12,
		[215479] = 10,
		[401516] = 1,
		[422094] = "Treant <Caobi-Tichondrius>",
		[394453] = 10,
		[342242] = 8,
		[200700] = "Dargrul",
		[320763] = 7,
		[275699] = 6,
		[383193] = 11,
		[391191] = 12,
		[113746] = 10,
		[386265] = 9,
		[41635] = 5,
		[73564] = "Siamat",
		[393432] = "Refti Defender",
		[394456] = 11,
		[82522] = "High Prophet Barim",
		[408370] = "Kazzara, the Hellforged",
		[78939] = "Ozruk",
		[408946] = "Sundered Preserver",
		[342246] = 8,
		[162243] = 12,
		[372538] = "Lava Flare",
		[285515] = 7,
		[411862] = "Animation Fluid",
		[408791] = 1,
		[75817] = "Corla, Herald of Twilight",
		[406744] = 9,
		[212106] = 12,
		[335082] = 1,
		[394036] = 4,
		[414935] = 12,
		[256553] = "Hammer Shark",
		[74589] = 4,
		[408368] = 6,
		[378081] = 7,
		[386869] = 9,
		[264178] = 9,
		[393438] = 2,
		[406747] = 9,
		[93825] = 12,
		[408367] = "Kazzara, the Hellforged",
		[385897] = 4,
		[2006] = 5,
		[191034] = 11,
		[188499] = 12,
		[221322] = 6,
		[213644] = 2,
		[411437] = "Sundered Siegemaster",
		[5308] = 1,
		[376186] = "Overseer Lahar",
		[281420] = "Bilge Rat Brinescale",
		[383204] = "[*] Crashing Tsunami",
		[66] = 8,
		[148039] = 2,
		[386276] = 10,
		[407775] = "Thadrion",
		[407913] = 10,
		[20484] = 11,
		[1079] = 11,
		[404269] = "Sarkareth",
		[51124] = 6,
		[393444] = "Refti Defender",
		[382183] = 2,
		[415967] = 5,
		[47541] = 6,
		[374854] = "Grounding Spear <Chargath, Bane of Scales>",
		[394031] = 4,
		[128594] = 3,
		[61336] = 11,
		[377066] = 5,
		[390375] = 2,
		[88814] = "High Prophet Barim",
		[369792] = "Eric \"The Swift\"",
		[413922] = 1,
		[197277] = 2,
		[391400] = 10,
		[122708] = 7,
		[200851] = 11,
		[201363] = 1,
		[391401] = 5,
		[388911] = "Spellbound Battleaxe",
		[362877] = "Osykrond-Proudmoore",
		[328953] = 12,
		[61999] = 6,
		[335096] = 1,
		[205472] = 8,
		[201364] = 1,
		[391403] = 5,
		[50613] = 6,
		[405736] = "Zskarn",
		[374000] = 7,
		[110168] = "The Black Brewmaiden <Fenduh-Thrall>",
		[404713] = "Neldris",
		[385262] = 3,
		[414951] = 12,
		[255546] = 4,
		[51637] = 4,
		[409833] = 7,
		[374002] = 7,
		[383346] = 2,
		[115175] = 10,
		[409834] = 7,
		[114919] = 2,
		[48438] = 11,
		[408811] = "Sundered Siegemaster",
		[377102] = "Dragonpeace-Lightning'sBlade",
		[406764] = 1,
		[341260] = 6,
		[126436] = 5,
		[393456] = 3,
		[365362] = 8,
		[19801] = 3,
		[408813] = "Sundered Flame Banner <Sundered Siegemaster>",
		[377077] = 6,
		[390386] = "Lizardmage-Illidan",
		[403695] = 2,
		[343294] = 6,
		[198069] = 5,
		[419052] = "Iizzie-Stormreaver",
		[17057] = 11,
		[408815] = 11,
		[377079] = 10,
		[307046] = 12,
		[406311] = "Neldris",
		[404721] = "Magmorax",
		[387079] = 9,
		[45470] = 6,
		[383223] = 7,
		[157348] = "Greater Storm Elemental <Orclanraider-Rivendare>",
		[8676] = 4,
		[378105] = "Luddyxdxd-Kel'Thuzad",
		[403699] = "Essence of Shadow",
		[326918] = 6,
		[327942] = 7,
		[148135] = 10,
		[316220] = 4,
		[412914] = "Fragment of Shadow",
		[368893] = 6,
		[386297] = 3,
		[407796] = "Neltharion",
		[253595] = 6,
		[45438] = 8,
		[391430] = 12,
		[411892] = "[*] Viscous Bile",
		[86881] = "Corborus",
		[387350] = "Gitaxias-WyrmrestAccord",
		[118] = 8,
		[407544] = "Rashok",
		[81441] = "Millhouse Manastorm",
		[199852] = 1,
		[410870] = "Wild Vortex",
		[379134] = "Stonebreath Summoner",
		[1943] = 4,
		[1459] = 8,
		[386301] = 3,
		[400734] = 11,
		[1490] = 12,
		[377088] = "Spiroheals-Kalecgos",
		[129250] = 5,
		[383231] = "Qalashi Lavamancer",
		[81644] = "[*] Dust Flail",
		[411901] = "Sundered Chemist",
		[410873] = "Gust Soldier",
		[387327] = 9,
		[8042] = 7,
		[393566] = 10,
		[378055] = "Decaying Slime <Treemouth>",
		[378213] = "Osykrond-Proudmoore",
		[404732] = "Eternal Blaze",
		[374569] = "Monstrous Decay",
		[374020] = "Containment Apparatus",
		[81508] = "Stonecore Earthshaper",
		[383818] = 1,
		[122470] = 10,
		[387877] = 6,
		[383235] = 7,
		[411417] = "Magmorax",
		[115804] = 10,
		[234153] = 9,
		[375046] = "Forgemaster Gorek",
		[138927] = 11,
		[603] = 9,
		[406783] = "Shadowflame Amalgamation",
		[411902] = "Sundered Chemist",
		[99] = 11,
		[260242] = 3,
		[410879] = 6,
		[101984] = "Murozond",
		[100] = 1,
		[196770] = 6,
		[406785] = 2,
		[82533] = "Harbinger of Darkness",
		[82789] = "Oathsworn Skinner",
		[260243] = 3,
		[79206] = 7,
		[124507] = 10,
		[392537] = 1,
		[196771] = 6,
		[205473] = 8,
		[387336] = 3,
		[408835] = 11,
		[189363] = 11,
		[114014] = 4,
		[73320] = 10,
		[102241] = "Echo of Tyrande",
		[393480] = 3,
		[45242] = 5,
		[115294] = 10,
		[384267] = 8,
		[123996] = "Xuen <Brewgami-Area52>",
		[418588] = 6,
		[199844] = 8,
		[212641] = 2,
		[389387] = 10,
		[375061] = "Forgemaster Gorek",
		[370960] = "Osykrond-Proudmoore",
		[404744] = "Kazzara, the Hellforged",
		[377103] = 6,
		[1719] = 1,
		[183465] = "Tarspitter Lurker",
		[376080] = 1,
		[400777] = "Rashok",
		[406793] = 9,
		[375057] = "Chargath, Bane of Scales",
		[199600] = 4,
		[260247] = 3,
		[219809] = 6,
		[411913] = "Sundered Devourer",
		[32223] = 2,
		[389391] = 10,
		[406795] = 9,
		[13750] = 4,
		[280735] = 1,
		[199658] = 1,
		[81256] = 6,
		[48018] = 9,
		[190446] = 8,
		[192231] = "Liquid Magma Totem <Edie-Bloodhoof>",
		[374037] = 7,
		[370966] = 12,
		[49020] = 6,
		[405643] = "Shadowflame Amalgamation",
		[365350] = 8,
		[411917] = "Sundered Devourer",
		[163505] = 11,
		[257542] = 8,
		[88423] = 11,
		[409899] = "Osykrond-Proudmoore",
		[371992] = "[*] Burning Chain",
		[390371] = 7,
		[382230] = 2,
		[370969] = 12,
		[95248] = "Blaze of the Heavens",
		[5225] = 11,
		[382231] = 3,
		[375065] = "Fetid Rotsinger",
		[404754] = "Null Glimmer <Sarkareth>",
		[167105] = 1,
		[341282] = 5,
		[370971] = 12,
		[253597] = 6,
		[274739] = 1,
		[64695] = "Earthgrab Totem <Bartank-Scilla>",
		[51963] = "Ebon Gargoyle <Tayro-Area52>",
		[247455] = 12,
		[274740] = 1,
		[114018] = 4,
		[199851] = 1,
		[120] = 8,
		[274741] = 1,
		[382235] = 3,
		[585] = 5,
		[82794] = "Oathsworn Wanderer",
		[274742] = 1,
		[382236] = 9,
		[195757] = 6,
		[96103] = 1,
		[256016] = "[*] Vile Coating",
		[414977] = "Corßan",
		[375071] = "Lava Tentacles <Magmatusk>",
		[388380] = 3,
		[373024] = "Brackenhide Shaper",
		[378143] = "Stonebreath Landslider",
		[390941] = 7,
		[226406] = "Emberhusk Dominator",
		[188592] = 7,
		[382245] = 4,
		[228532] = 12,
		[408857] = "Rashok",
		[83051] = "Cloud Burst",
		[162487] = 3,
		[199854] = 1,
		[403225] = 3,
		[88170] = "Turbulent Squall",
		[341291] = 5,
		[403740] = "Magmorax",
		[8122] = 5,
		[392128] = 2,
		[200166] = 12,
		[403741] = "Sarkareth",
		[335150] = 7,
		[375583] = "Lizardmage-Illidan",
		[275773] = 2,
		[53563] = 2,
		[130] = 8,
		[405790] = 2,
		[2094] = 4,
		[374045] = "Containment Apparatus",
		[212653] = 8,
		[88171] = "Turbulent Squall",
		[133] = 8,
		[391459] = 6,
		[376103] = 8,
		[347462] = 12,
		[341296] = 6,
		[375080] = "Squallbringer Cyraz",
		[384294] = 12,
		[1953] = 8,
		[382247] = 1,
		[373700] = 5,
		[211881] = 12,
		[377129] = 2,
		[139] = 5,
		[203953] = 11,
		[369439] = 3,
		[409890] = 9,
		[382249] = "Trickclaw Mystic",
		[84589] = "Siamat",
		[213134] = 3,
		[65081] = 5,
		[378155] = "Tricktotem",
		[81947] = "High Prophet Barim",
		[33697] = 10,
		[259760] = 8,
		[198300] = 7,
		[81642] = "Lockmaw",
		[255654] = 11,
		[252071] = 11,
		[387474] = "Primal Tsunami",
		[3110] = "Jubyap <Ellawart-Madoran>",
		[392490] = 6,
		[409363] = "Blazing Dreadsquall",
		[17877] = 9,
		[375087] = "Arcodis",
		[81269] = 11,
		[19236] = 5,
		[387174] = 2,
		[86040] = 9,
		[196278] = 9,
		[409896] = "Osykrond-Proudmoore",
		[189112] = 12,
		[81690] = "Lockmaw",
		[408873] = "Warlord Kagni",
		[198838] = 7,
		[400187] = 5,
		[167898] = 5,
		[4987] = 2,
		[409898] = 11,
		[5019] = 9,
		[385354] = 2,
		[396590] = 1,
		[81008] = "Crystalspawn Giant",
		[386353] = "Arcodis",
		[203958] = 11,
		[290121] = 11,
		[376170] = "Decatriarch Wratheye",
		[390933] = 5,
		[406780] = "Shadowflame Amalgamation",
		[411908] = "Sundered Chemist",
		[375576] = 2,
		[5211] = 11,
		[93985] = 11,
		[120679] = 3,
		[88175] = "Turbulent Squall",
		[207267] = 6,
		[409359] = "Warlord Kagni",
		[50622] = 1,
		[377143] = 7,
		[17253] = "DankeKong <Wargrimz>",
		[407856] = "Neltharion",
		[53652] = 2,
		[381301] = 5,
		[374073] = "Primalist Geomancer",
		[205021] = 8,
		[202425] = 11,
		[315720] = 1,
		[382791] = "Qalashi Lavamancer",
		[203961] = 11,
		[172] = 9,
		[116841] = 10,
		[415025] = "[*] Paracausal Fragment of Frostmourne",
		[420144] = 11,
		[2782] = 11,
		[405812] = "Zskarn",
		[42650] = 6,
		[114282] = 11,
		[404789] = "Kazzara, the Hellforged",
		[387385] = 9,
		[378172] = "Ore Elemental",
		[391481] = 6,
		[376149] = "Choking Rotcloud <Decatriarch Wratheye>",
		[102158] = "Time-Twisted Seer",
		[325461] = 6,
		[371033] = 11,
		[108396] = 9,
		[118038] = 1,
		[783] = 11,
		[383762] = 1,
		[290132] = 6,
		[409587] = 4,
		[162480] = 3,
		[384321] = 4,
		[384318] = 1,
		[264571] = 9,
		[272172] = "Shivarra <Flickers-Area52>",
		[377656] = 6,
		[290134] = 7,
		[35395] = 2,
		[382272] = 8,
		[403771] = "Sarkareth",
		[317792] = "Magus of the Dead <Cocnballs-Barthilas>",
		[405819] = "Rashok",
		[415033] = 11,
		[214203] = 10,
		[392511] = 5,
		[325984] = 2,
		[406282] = "Sundered Naturalist",
		[216251] = 7,
		[49088] = 6,
		[405821] = "Rashok",
		[409895] = "Osykrond-Proudmoore",
		[411903] = "Sundered Chemist",
		[367971] = 5,
		[405822] = "Rashok",
		[385806] = 4,
		[399680] = 9,
		[16870] = 11,
		[389443] = "Nullification Device",
		[374087] = "Lizardmage-Illidan",
		[102156] = "Time-Twisted Seer",
		[384325] = 12,
		[75645] = "Corla, Herald of Twilight",
		[415038] = 11,
		[232633] = 5,
		[394550] = 2,
		[368970] = "Lizardmage-Illidan",
		[101602] = 8,
		[358733] = "Luddyxdxd-Kel'Thuzad",
		[355689] = "Lizardmage-Illidan",
		[389446] = "Nullification Device",
		[378016] = 3,
		[387110] = 9,
		[406526] = "Kazzara, the Hellforged",
		[385352] = 2,
		[415041] = 5,
		[405255] = 12,
		[388424] = "Primal Tsunami",
		[389448] = "Spirit Beast <Derringerr>",
		[408947] = "Sundered Preserver",
		[191685] = 6,
		[81782] = 5,
		[414019] = 2,
		[110959] = 8,
		[115310] = 10,
		[407302] = "Neldris",
		[389450] = 3,
		[406854] = "Malgosa Spellbinder",
		[334168] = 7,
		[344955] = 6,
		[6795] = 11,
		[120692] = 5,
		[371024] = 7,
		[91408] = "Augh",
		[227518] = 12,
		[374075] = "Primalist Geomancer",
		[406889] = 9,
		[200389] = 11,
		[87933] = "Gust Soldier",
		[110960] = 8,
		[317791] = "Magus of the Dead <Cocnballs-Barthilas>",
		[406887] = 12,
		[19750] = 2,
		[410953] = "[*] Volcanic Heart",
		[383312] = 6,
		[403747] = "Magmorax",
		[116847] = 10,
		[109791] = 9,
		[371028] = 7,
		[385036] = "Primalist Galesinger",
		[409931] = "Djaradin Commander",
		[406860] = "Malgosa Spellbinder",
		[387409] = 9,
		[404813] = "Kazzara, the Hellforged",
		[320338] = 12,
		[377101] = 6,
		[395519] = 10,
		[145109] = 11,
		[407907] = 10,
		[415052] = 11,
		[203975] = 11,
		[413005] = "Flame Additive <Sundered Chemist>",
		[196809] = "Divine Image <Icecreamvato-Khadgar>",
		[387847] = 9,
		[116189] = 10,
		[145110] = 11,
		[389422] = 10,
		[124273] = 10,
		[395603] = 2,
		[55233] = 6,
		[196810] = "Divine Image <Icecreamvato-Khadgar>",
		[86392] = 4,
		[387414] = 9,
		[384343] = "Gutshot",
		[393515] = 10,
		[403202] = "Sarkareth",
		[393988] = 10,
		[58180] = 11,
		[196811] = "Divine Image <Icecreamvato-Khadgar>",
		[378202] = "Ore Elemental",
		[56641] = 3,
		[387018] = 9,
		[48707] = 6,
		[15284] = "Karsh Steelbender",
		[81530] = "Stonecore Earthshaper",
		[204490] = 12,
		[196812] = "Divine Image <Icecreamvato-Khadgar>",
		[152279] = 6,
		[88194] = "Young Storm Dragon",
		[413012] = "Shadow Additive <Sundered Chemist>",
		[83066] = "Siamat",
		[372019] = 11,
		[386002] = 6,
		[214743] = 12,
		[196813] = "Divine Image <Icecreamvato-Khadgar>",
		[152280] = 6,
		[390915] = "Vile Lasher",
		[388444] = 8,
		[393565] = 10,
		[386397] = 1,
		[407896] = 7,
		[382217] = 7,
		[87779] = "Temple Adept",
		[382303] = "Bromach",
		[375204] = "[*] Liquid Hot Magma",
		[384351] = "Watcher Irideus",
		[405850] = "Sundered Destroyer",
		[386399] = "Arcodis",
		[383328] = 2,
		[384352] = 7,
		[88186] = "Empyrean Assassin",
		[148187] = 10,
		[383329] = 2,
		[384353] = "Gutshot",
		[113780] = 4,
		[32612] = 8,
		[410365] = "Warlord Kagni",
		[188114] = "Rokmora",
		[196816] = "Divine Image <Icecreamvato-Khadgar>",
		[213708] = 11,
		[114050] = 7,
		[91002] = "Grändeeney-Azralon",
		[145629] = 6,
		[124274] = 10,
		[7384] = 1,
		[382723] = "Cruel Bonecrusher",
		[385794] = 4,
		[213709] = 11,
		[210126] = 8,
		[384357] = 7,
		[298836] = 12,
		[378215] = 3,
		[407904] = 2,
		[367978] = 5,
		[377192] = 6,
		[382311] = 7,
		[176151] = 2,
		[376169] = "High Thaumaturge Fural",
		[390912] = "Vile Lasher",
		[124275] = 10,
		[334196] = 7,
		[384360] = 8,
		[196819] = 4,
		[410978] = "Djaradin Dragonhunter",
		[391527] = 6,
		[376171] = "Primalist Icecaller",
		[377195] = 6,
		[370984] = "Osykrond-Proudmoore",
		[391528] = 11,
		[384362] = 1,
		[372014] = "Luddyxdxd-Kel'Thuzad",
		[201427] = 12,
		[370] = 7,
		[256979] = "Captain Eudora",
		[104318] = "Wild Imp <Kkyzz-Akama>",
		[378221] = "Ore Elemental",
		[383269] = 6,
		[200404] = "Dargrul",
		[382912] = 11,
		[108920] = 5,
		[416101] = 7,
		[400745] = 2,
		[2383] = "Spiroheals-Kalecgos",
		[75539] = "Rom'ogg Bonecrusher",
		[366962] = 1,
		[401339] = "Sarkareth",
		[404218] = 10,
		[13877] = 4,
		[416103] = 12,
		[408937] = 4,
		[385391] = 1,
		[377222] = "[*] Consume",
		[114214] = 5,
		[389407] = 9,
		[390942] = "Aggravated Skitterfly",
		[201430] = 3,
		[395630] = 7,
		[207771] = 12,
		[360823] = "Osykrond-Proudmoore",
		[316802] = "Arcodis",
		[387441] = 2,
		[5116] = 3,
		[409964] = 8,
		[369409] = "Earthen Custodian",
		[407917] = "Neltharion",
		[404846] = "Magmorax",
		[387359] = "[*] Waterlogged",
		[378229] = "Gashtooth",
		[208086] = 1,
		[372571] = "Luddyxdxd-Kel'Thuzad",
		[360826] = 4,
		[378230] = "Gashtooth",
		[407919] = "Neltharion",
		[88959] = "Temple Adept",
		[360827] = "Luddyxdxd-Kel'Thuzad",
		[81281] = 11,
		[411738] = "Rashok",
		[257739] = "Blacktooth Scrapper",
		[360828] = 6,
		[363916] = "Luddyxdxd-Kel'Thuzad",
		[31230] = 4,
		[408310] = 11,
		[91263] = "General Husam",
		[406898] = "Djaradin Lavamancer",
		[5484] = 9,
		[120696] = 5,
		[360830] = 4,
		[414976] = "Corßan",
		[11426] = 8,
		[348] = 9,
		[374194] = "Kalythra-Sargeras",
		[378235] = "Gashtooth",
		[411905] = "[*] Blaze Boil",
		[418826] = 4,
		[274837] = 11,
		[415091] = 2,
		[355] = 1,
		[235219] = 8,
		[385403] = 7,
		[410997] = "Gust Soldier",
		[91776] = "Gravelslobber <Cocnballs-Barthilas>",
		[256735] = 4,
		[116858] = 9,
		[410998] = "Gust Soldier",
		[197835] = 4,
		[102659] = 12,
		[409975] = "Djaradin Commander",
		[388376] = 12,
		[114738] = 7,
		[163558] = 1,
		[51271] = 6,
		[51399] = 6,
		[405236] = 3,
		[406921] = "Luddyxdxd-Kel'Thuzad",
		[108416] = 9,
		[163024] = 1,
		[298765] = 7,
		[388479] = 10,
		[385408] = 4,
		[385424] = 4,
		[379] = 7,
		[388480] = 10,
		[385409] = 7,
		[372971] = "Qalashi Blacksmith",
		[420217] = 9,
		[359816] = "Guanl-Ner'zhul",
		[410353] = "Warlord Kagni",
		[390529] = 9,
		[86659] = 2,
		[396672] = "Chargath, Bane of Scales",
		[405886] = "Dragonfire Golem",
		[124280] = 10,
		[91778] = "Gravelslobber <Cocnballs-Barthilas>",
		[210150] = "Naraxas",
		[328082] = 4,
		[411376] = 10,
		[387460] = 11,
		[408959] = "Warlord Kagni",
		[409983] = 1,
		[465] = 2,
		[407936] = "Neltharion",
		[257747] = "Blacktooth Brute",
		[102364] = 11,
		[411024] = 6,
		[201953] = "Emberhusk Dominator",
		[384391] = 1,
		[373130] = 5,
		[387402] = 9,
		[183526] = "Understone Drummer",
		[200418] = "Dargrul",
		[17962] = 9,
		[410351] = "Warlord Kagni",
		[6572] = 1,
		[129914] = 10,
		[409987] = 4,
		[396047] = "Spiroheals-Kalecgos",
		[93827] = 11,
		[256171] = 4,
		[394994] = 8,
		[411012] = "Young Storm Dragon",
		[156910] = 2,
		[277925] = 4,
		[414445] = 2,
		[406918] = "Djaradin Lavamancer",
		[183528] = "Understone Drummer",
		[408966] = "Magmorax",
		[397041] = 7,
		[22482] = 4,
		[382708] = "Qalashi Warden",
		[76680] = "Twilight Element Warden",
		[401801] = "Sarkareth",
		[109952] = "Time-Twisted Geist",
		[93828] = 2,
		[372113] = "Infected Lasher",
		[393969] = 4,
		[6940] = 2,
		[370970] = 12,
		[155722] = 11,
		[91143] = 7,
		[60103] = 7,
		[377588] = 6,
		[408970] = "Sundered Preserver",
		[381329] = "Qalashi Lavabearer",
		[271788] = 3,
		[268717] = "Sharkbait",
		[408] = 4,
		[114051] = 7,
		[411019] = "Skyfall Star",
		[391568] = 6,
		[192081] = 11,
		[196840] = 7,
		[258777] = "Irontide Oarsman",
		[66188] = 6,
		[83339] = "[*] Hard Impact",
		[453] = 5,
		[402831] = "Neltharion",
		[167152] = 5,
		[375902] = 5,
		[215785] = 7,
		[406927] = "Luddyxdxd-Kel'Thuzad",
		[121471] = 4,
		[408975] = "Sundered Edgelord",
		[401809] = "Essence of Shadow",
		[85384] = 1,
		[93830] = 5,
		[408976] = "Sundered Edgelord",
		[401810] = "Sarkareth",
		[258779] = "Irontide Oarsman",
		[114052] = 7,
		[203794] = 12,
		[385442] = "Gulping Goliath",
		[415132] = 9,
		[52042] = "Healing Stream Totem <Stormart>",
		[257756] = "Bilge Rat Buccaneer",
		[47633] = 6,
		[389890] = 12,
		[383385] = "Filth Caller",
		[101888] = "Time-Twisted Scourge Beast",
		[401825] = "Neltharion",
		[15286] = 5,
		[78859] = "Ozruk",
		[257757] = "Bilge Rat Buccaneer",
		[22570] = 11,
		[11319] = 3,
		[210153] = 12,
		[546] = 7,
		[377245] = 6,
		[406934] = "Djaradin Lavamancer",
		[390918] = "Vile Lasher",
		[47310] = "Coren Direbrew",
		[145152] = 11,
		[217832] = 12,
		[383389] = 2,
		[359843] = "Corßan",
		[410007] = 10,
		[406936] = "Djaradin Lavamancer",
		[279303] = 6,
		[359844] = 3,
		[63560] = 6,
		[498] = 2,
		[407961] = 8,
		[388510] = 10,
		[401819] = "Sarkareth",
		[166646] = 10,
		[383392] = "Filth Caller",
		[384416] = "Gutshot",
		[356084] = 5,
		[64712] = 5,
		[375535] = "Magmatusk",
		[372141] = 1,
		[403559] = "Essence of Shadow",
		[378275] = 7,
		[183539] = "Rotdrool Grabber",
		[388513] = 10,
		[98440] = 4,
		[102793] = 11,
		[383395] = 8,
		[388514] = 10,
		[377253] = 6,
		[378277] = 7,
		[221885] = 2,
		[401642] = "Sarkareth",
		[389539] = 2,
		[415133] = 9,
		[53390] = 7,
		[404896] = "Eternal Blaze",
		["DEBUFF"] = 7,
		[210833] = 8,
		[409848] = "Arcodis",
		[373762] = "Chargath, Bane of Scales",
		[389541] = "White Tiger Statue <Staggerbot-Korgath>",
		[410871] = 5,
		[383399] = "[*] Rotting Surge",
		[405221] = 3,
		[81630] = "Lockmaw",
		[378281] = "Qalashi Thaumaturge",
		[236777] = 3,
		[391519] = 6,
		[410018] = 7,
		[378282] = "Qalashi Thaumaturge",
		[403876] = 2,
		[76687] = "[*] Shadow Prison",
		[405924] = "Krono Sandtongue",
		[385942] = 3,
		[204018] = 2,
		[400806] = 1,
		[190357] = 8,
		[115078] = 10,
		[76511] = "Mad Prisoner",
		[207386] = 11,
		[385451] = "Gulping Goliath",
		[396718] = 1,
		[372459] = "[*] Burning",
		[87772] = "Servant of Asaad",
		[403171] = 6,
		[378286] = 2,
		[395690] = "Primalist Shocktrooper",
		[76688] = "Twilight Obsidian Borer",
		[227723] = 12,
		[415142] = 9,
		[395691] = "Primalist Shocktrooper",
		[66196] = 6,
		[406957] = 2,
		[386478] = 1,
		[387502] = "Keegoril <Deadlysins-Eredar>",
		[390885] = 5,
		[195321] = 10,
		[419239] = 12,
		[204021] = 12,
		[208628] = 12,
		[394667] = 2,
		[372152] = 11,
		[395694] = "Primalist Shocktrooper",
		[404908] = 7,
		[381684] = 7,
		[93402] = 11,
		[25771] = 2,
		[192249] = 7,
		[642] = 2,
		[82320] = "High Prophet Barim",
		[281036] = 3,
		[404910] = "Eternal Blaze",
		[49998] = 6,
		[79249] = "[*] Gravity Well",
		[407982] = 8,
		[372151] = "Gutchewer Bear",
		[686] = 9,
		[5277] = 4,
		[210166] = "Naraxas",
		[255723] = 1,
		[54861] = 1,
		[81297] = 2,
		[383414] = 4,
		[389372] = 9,
		[384441] = 1,
		[390581] = 1,
		[334275] = 9,
		[373181] = 5,
		[373178] = 5,
		[394677] = 7,
		[412081] = "Colossal Draconic Golem",
		[52174] = 1,
		[36554] = 4,
		[255937] = 2,
		[64843] = 5,
		[388536] = 2,
		[401119] = "Blazing Spear",
		[394679] = 9,
		[412083] = "Colossal Draconic Golem",
		[395705] = "Dovahkeen-BloodFurnace",
		[2823] = 4,
		[411060] = 2,
		[66198] = 6,
		[41425] = 8,
		[371124] = 2,
		[396719] = 1,
		[228597] = 8,
		[388539] = 1,
		[373183] = 5,
		[263642] = 12,
		[228598] = 8,
		[740] = 11,
		[369610] = "Quaking Totem <Bromach>",
		[393951] = 1,
		[264667] = 3,
		[409307] = "Blazing Dreadsquall",
		[118922] = 3,
		[31850] = 2,
		[102543] = 11,
		[47568] = 6,
		[2983] = 4,
		[217851] = "Naraxas",
		[375234] = "Lizardmage-Illidan",
		[409018] = "Failed Prototype",
		[213243] = 12,
		[406971] = "Kalythra-Sargeras",
		[64844] = 5,
		[774] = 11,
		[221886] = 2,
		[114216] = 5,
		[228600] = 8,
		[768] = 11,
		[381379] = "Gashtooth",
		[772] = 1,
		[201983] = "Emberhusk Dominator",
		[384451] = 7,
		[57934] = 4,
		[12472] = 8,
		[387523] = "Spellbound Battleaxe",
		[409022] = 8,
		[390899] = 2,
		[406975] = 2,
		[369573] = "Baelog",
		[415676] = 5,
		[274912] = 10,
		[406976] = "Siege Arbalest",
		[19647] = "Jhuulum <Mersan-Arthas>",
		[8921] = 11,
		[414143] = 10,
		[82139] = "High Prophet Barim",
		[375241] = "The Scorching Forge",
		[202497] = 11,
		[82760] = "Neferset Darkcaster",
		[387528] = "Earthborne Charger",
		[232698] = 5,
		[382410] = "Trickclaw Mystic",
		[131347] = 12,
		[243955] = 2,
		[403908] = "Neltharion",
		[191043] = 3,
		[332246] = "Kalythra-Sargeras",
		[236282] = 1,
		[387529] = "Earthborne Charger",
		[111759] = 5,
		[194310] = 6,
		[82326] = 2,
		[408005] = "Luddyxdxd-Kel'Thuzad",
		[384459] = 11,
		[83094] = "Siamat",
		[382412] = "Trickclaw Mystic",
		[183560] = "Rotdrool Grabber",
		[388555] = 10,
		[61391] = 11,
		[406983] = 2,
		[188046] = "Denizen of the Dream <Rac-Thrall>",
		[368081] = "[*] Withering",
		[401854] = "Essence of Shadow",
		[419539] = 11,
		[257272] = "Sharkbait",
		[76185] = "Ascendant Lord Obsidius",
		[389056] = "Watcher Irideus",
		[32747] = 12,
		[47442] = "Ursula Direbrew",
		[194311] = 6,
		[402894] = 7,
		[413131] = "Harlan Sweete",
		[91797] = "Gravelchomp <Angelofdeãth-Dalaran>",
		[188169] = "Rokmora",
		[405963] = 5,
		[374227] = "Luddyxdxd-Kel'Thuzad",
		[375251] = "Magmatusk",
		[390993] = 5,
		[373204] = 5,
		[264689] = 6,
		[393943] = 1,
		[404941] = 4,
		[102547] = 11,
		[185099] = 10,
		[33110] = 5,
		[404942] = "Zskarn",
		[378020] = "Gashtooth",
		[402897] = 7,
		[362969] = "Luddyxdxd-Kel'Thuzad",
		[368091] = "Vicious Hyena",
		[406227] = "Rionthus",
		[402896] = 7,
		[215816] = 8,
		[384469] = 8,
		[109714] = 3,
		[325092] = 10,
		[383704] = 1,
		[343520] = "[*] Storming",
		[387547] = 9,
		[402898] = 7,
		[193803] = "Tarspitter Grub",
		[409041] = "Failed Prototype",
		[119952] = 2,
		[394709] = 2,
		[183566] = "[*] Rancid Pool",
		[412117] = "Neldris",
		[405202] = 8,
		[382425] = 3,
		[317929] = 2,
		[275779] = 2,
		[402903] = 7,
		[382426] = 3,
		[91800] = "Risen Ghoul <Ugahboogah-Thrall>",
		[50259] = 11,
		[344548] = 7,
		[390617] = 5,
		[393955] = 11,
		[45524] = 6,
		[353759] = "Osykrond-Proudmoore",
		[382428] = 3,
		[371167] = 3,
		[392666] = "Forgemaster Gorek",
		[84122] = "Oathsworn Scorpid Keeper",
		[76188] = "Ascendant Lord Obsidius",
		[982] = 3,
		[343527] = 2,
		[211210] = 2,
		[373464] = 5,
		[89753] = "奥里克西努尔 <Kkyzz-Akama>",
		[236645] = 8,
		[262652] = 7,
		[391891] = 11,
		[20271] = 2,
		[314867] = 5,
		[401883] = "Neltharion",
		[203533] = 9,
		[216331] = 2,
		[413145] = "Harlan Sweete",
		[84123] = "Oathsworn Scorpid Keeper",
		[213771] = 11,
		[371172] = 12,
		[374245] = "[*] Rotting Creek",
		[414170] = 2,
		[385141] = "Primalist Galesinger",
		[1022] = 2,
		[413147] = "Harlan Sweete",
		[372201] = "Qalashi Irontorch",
		[382435] = "Decay Speaker",
		[30153] = "奥里克西努尔 <Kkyzz-Akama>",
		[391889] = 11,
		[1044] = 2,
		[382440] = 8,
		[387036] = 7,
		[413387] = "Executor of the Caliph",
		[84125] = "Bonesnapper Scorpid",
		[1064] = 7,
		[157981] = 8,
		[105682] = 7,
		[236298] = 8,
		[209921] = "Dargrul",
		[179478] = 12,
		[413151] = "Grand Vizier Ertan",
		[394958] = 12,
		[197908] = 10,
		[375273] = 12,
		[403203] = "Eternal Blaze",
		[414176] = 2,
		[374250] = 8,
		[387559] = "Primal Tsunami",
		[409058] = "Neltharion",
		[410082] = 10,
		[374251] = "Luddyxdxd-Kel'Thuzad",
		[375275] = "Failed Prototype",
		[383696] = 10,
		[279043] = 4,
		[271877] = 4,
		[375276] = 12,
		[382445] = 8,
		[381419] = "Rira Hackclaw",
		[1160] = 1,
		[22703] = 9,
		[271881] = 4,
		[157982] = 11,
		[236299] = 8,
		[289555] = "Corßan",
		[192106] = 7,
		[257284] = 3,
		[386540] = 8,
		[410089] = "Luddyxdxd-Kel'Thuzad",
		[372208] = "[*] Djaradin Lava",
		[270058] = 7,
		[390636] = 5,
		[31661] = 8,
		[122773] = 2,
		[401898] = "Kazzara, the Hellforged",
		[374706] = "Flamecaller Aymi",
		[371186] = 9,
		[292359] = 11,
		[385519] = 7,
		[408694] = 12,
		[389614] = 9,
		[394729] = 5,
		[385520] = 7,
		[52437] = 1,
		[197509] = "Bloodworm <Umarekawari-BleedingHollow>",
		[80800] = "Lava Fissure",
		[5374] = 4,
		[292360] = 6,
		[81568] = "Stonecore Berserker",
		[372213] = "Qalashi Lavabearer",
		[344572] = "Spirit Beast <Derringerr>",
		[292361] = 11,
		[387570] = 9,
		[5246] = 1,
		[220543] = 5,
		[224126] = 7,
		[375286] = "Longboat Raid",
		[29166] = 11,
		[116888] = 6,
		[422382] = "Treant <Caobi-Tichondrius>",
		[1604] = "Time-Twisted Drake",
		[80801] = "Lava Fissure",
		[35546] = 4,
		[361582] = 3,
		[81569] = "Stonecore Berserker",
		[404977] = "Lizardmage-Illidan",
		[6673] = 1,
		[375950] = "Primalist Icecaller",
		[383479] = 8,
		[191877] = 7,
		[393717] = 1,
		[207640] = 11,
		[91807] = 6,
		[394951] = 10,
		[414193] = 2,
		[374271] = 6,
		[375291] = "Forgemaster Gorek",
		[392903] = 2,
		[260364] = 8,
		[114074] = 7,
		[381444] = "Rira Hackclaw",
		[394454] = 2,
		[23920] = 1,
		[377344] = "Territorial Eagle",
		[197916] = 10,
		[198428] = "Ularogg Cragshaper",
		[414196] = 2,
		[394745] = 5,
		[75428] = "Rom'ogg Bonecrusher",
		[372223] = "Qalashi Bonetender",
		[101625] = "Echo of Baine",
		[271896] = 4,
		[383485] = 1,
		[372224] = "Qalashi Bonesplitter",
		[385533] = 2,
		[1464] = 1,
		[264735] = 3,
		[372225] = "Qalashi Bonesplitter",
		[102558] = 11,
		[108446] = 9,
		[260369] = 8,
		[372226] = "Qalashi Bonetender",
		[115867] = 10,
		[386559] = "Khajin the Unyielding",
		[420343] = 3,
		[273947] = 6,
		[192800] = "[*] Choking Dust",
		[371213] = 5,
		[371204] = 5,
		[132403] = 2,
		[382474] = "Decay Speaker",
		[407036] = "Voice From Beyond",
		[387585] = "Primal Tsunami",
		[102352] = 11,
		[258321] = "Irontide Bonesaw",
		[386562] = "Khajin the Unyielding",
		[115356] = 7,
		[417275] = 1,
		[414204] = 2,
		[260881] = 7,
		[383492] = 8,
		[355851] = 5,
		[385540] = 3,
		[407039] = "Voice From Beyond",
		[289308] = 8,
		[220540] = "Sundered Edgelord",
		[386757] = "Khajin the Unyielding",
		[292380] = 6,
		[77478] = 7,
		[188196] = 7,
		[369162] = 7,
		[221883] = 2,
		[115357] = 7,
		[372234] = "Osykrond-Proudmoore",
		[86949] = 8,
		[394757] = 4,
		[268836] = 2,
		[83877] = "Oathsworn Wanderer",
		[80038] = "Stonecore Magmalord",
		[394758] = 4,
		[117405] = 3,
		[404996] = 2,
		[157997] = 8,
		[187174] = 7,
		[379403] = 11,
		[417282] = 9,
		[214397] = 1,
		[146739] = 9,
		[132404] = 1,
		[409093] = "Magmorax",
		[406207] = "[*] Tactical Destruction",
		[407046] = "Dread Rift <Kazzara, the Hellforged>",
		[409095] = 12,
		[384524] = "Watcher Irideus",
		[379406] = "Qalashi Lavabearer",
		[32175] = 7,
		[403976] = 2,
		[80807] = "Slabhide",
		[207230] = 6,
		[407048] = "Neltharion",
		[379407] = 11,
		[405001] = 4,
		[373265] = 3,
		[131894] = 3,
		[403978] = "Zskarn",
		[396812] = "Spellbound Scepter",
		[385551] = "Gulping Goliath",
		[263725] = 8,
		[204069] = 11,
		[391688] = 1,
		[373267] = "Osykrond-Proudmoore",
		[375306] = "Forgemaster Gorek",
		[379410] = "Qalashi Lavabearer",
		[384529] = "Rotfang Hyena <Gutshot>",
		[373268] = "Osykrond-Proudmoore",
		[1784] = 4,
		[81576] = "Stonecore Earthshaper",
		[372245] = "Luddyxdxd-Kel'Thuzad",
		[267999] = "Vilefiend <Flickers-Area52>",
		[325153] = 10,
		[115360] = 7,
		[384531] = "Rotfang Hyena",
		[184707] = 1,
		[188290] = 6,
		[110745] = 5,
		[409479] = 5,
		[84136] = "Tol'vir Merchant",
		[204066] = 11,
		[132409] = 9,
		[327193] = 2,
		[81574] = "Stonecore Berserker",
		[85416] = 2,
		[408836] = 11,
		[122783] = 10,
		[228128] = 8,
		[390677] = 5,
		[373279] = "Thing From Beyond <Odemp-Nagrand>",
		[87762] = "Minister of Air",
		[83113] = "General Husam",
		[378393] = 9,
		[257308] = "Harlan Sweete",
		[124991] = 11,
		[287280] = 2,
		[385727] = 4,
		[385062] = 1,
		[93095] = 7,
		[373276] = 5,
		[15290] = 5,
		[85673] = 2,
		[272439] = "Ur'zul <Flickers-Area52>",
		[373277] = 5,
		[131900] = 3,
		[406043] = "Luddyxdxd-Kel'Thuzad",
		[82858] = "High Priestess Azil",
		[32176] = 7,
		[183088] = "Mightstone Breaker",
		[257310] = "Irontide Cannon",
		[341541] = 4,
		[84138] = "Tol'vir Merchant",
		[196911] = 4,
		[408087] = 5,
		[76716] = "Defiled Earth Rager",
		[219432] = 11,
		[114083] = 7,
		[390844] = 5,
		[139068] = 4,
		[373281] = 5,
		[407065] = 2,
		[387618] = "Primalist Infuser",
		[105421] = 2,
		[198013] = 12,
		[23922] = 1,
		[346665] = 12,
		[53595] = 2,
		[410138] = 1,
		[207150] = 6,
		[257902] = "[*] Shell Bounce",
		[76717] = "Defiled Earth Rager",
		[410139] = 10,
		[381416] = "Rira Hackclaw",
		[403997] = 10,
		[403127] = 1,
		[381475] = 3,
		[407069] = "Kazzara, the Hellforged",
		[322098] = 5,
		[372262] = "Qalashi Bonesplitter",
		[381476] = 3,
		[387620] = 11,
		[228649] = 10,
		[413364] = "Magmorax",
		[401952] = "Sarkareth",
		[391710] = 11,
		[375335] = "Osykrond-Proudmoore",
		[76718] = "Incendiary Spark",
		[377383] = "Alpha Eagle",
		[390692] = 5,
		[322101] = 10,
		[258925] = 12,
		[377384] = "Aqua Rager",
		[394944] = 10,
		[267326] = 7,
		[372266] = "Qalashi Bonesplitter",
		[381933] = 7,
		[325174] = 7,
		[257316] = "Harlan Sweete",
		[84141] = "Tol'vir Merchant",
		[315961] = 1,
		[76719] = "Incendiary Spark",
		[101033] = 7,
		[30449] = 8,
		[198963] = "Naraxas",
		[69041] = 7,
		[322105] = 5,
		[257314] = "Irontide Grenadier",
		[102569] = "Murozond",
		[378412] = 2,
		[387626] = 9,
		[210738] = 6,
		[406054] = "Lizardmage-Illidan",
		[330038] = 3,
		[375342] = 6,
		[361195] = "Luddyxdxd-Kel'Thuzad",
		[84142] = "Tol'vir Merchant",
		[108968] = 5,
		[375343] = 10,
		[157503] = 7,
		[408763] = 8,
		[118594] = 5,
		[322109] = 10,
		[384558] = "Rotfang Hyena",
		[871] = 1,
		[5215] = 11,
		[375345] = 6,
		[157504] = 7,
		[100780] = 10,
		[394797] = 10,
		[75441] = "Chains of Woe <Rom'ogg Bonecrusher>",
		[75697] = 8,
		[387766] = 10,
		[88751] = 11,
		[268877] = 3,
		[198455] = "Spirit Wolf <Taie-Elune>",
		[373304] = 5,
		[402989] = "Magmorax",
		[77489] = 5,
		[204598] = 12,
		[34914] = 5,
		[375351] = "Glacial Proto-Dragon",
		[216371] = 2,
		[57820] = 2,
		[393777] = 3,
		[183100] = "Mightstone Breaker",
		[232752] = 6,
		[102057] = "Undying Flame",
		[378426] = 10,
		[390707] = 5,
		[387636] = 9,
		[273104] = 1,
		[389684] = 10,
		[114089] = 7,
		[383974] = "Gutshot",
		[413231] = 5,
		[389685] = 10,
		[386614] = 9,
		[322118] = 10,
		[235313] = 8,
		[397827] = 3,
		[248622] = 1,
		[5487] = 11,
		[388663] = 10,
		[116680] = 10,
		[258860] = 12,
		[10060] = 5,
		[235314] = 12,
		[122278] = 10,
		[199483] = 3,
		[204090] = 3,
		[212792] = 8,
		[102151] = "Echo of Tyrande",
		[384974] = "Rotbow Stalker",
		[387642] = "Dovahkeen-BloodFurnace",
		[57821] = 3,
		[121253] = 10,
		[415403] = 3,
		[216376] = "Lava Geyser",
		[33763] = 11,
		[311886] = 5,
		[394810] = 9,
		[117418] = 10,
		[28730] = 8,
		[400956] = 6,
		[386621] = 9,
		[388672] = 6,
		[274009] = 6,
		[65116] = 7,
		[196608] = 10,
		[27827] = 5,
		[384575] = "Rotfang Hyena",
		[194879] = 6,
		[199486] = 5,
		[212283] = 4,
		[225080] = 7,
		[418360] = 10,
		[374339] = "Refti Defender",
		[408123] = 2,
		[384577] = "Rotfang Hyena",
		[373316] = 5,
		[386625] = 6,
		[102063] = "Time-Twisted Scourge Beast",
		[408117] = "Warlord Kagni",
		[417452] = 2,
		[374451] = "Burning Chain Caster",
		[374343] = "Echo of Doragosa",
		[57822] = 8,
		[336463] = 3,
		[325202] = 10,
		[404031] = "Neldris",
		[404032] = "Thadrion",
		[91853] = "Siamat",
		[100784] = 10,
		[408127] = "Spiroheals-Kalecgos",
		[355916] = "Luddyxdxd-Kel'Thuzad",
		[207167] = 6,
		[114093] = 7,
		[114852] = 2,
		[386631] = 1,
		[123051] = "Mindbender <Arripriest-Area52>",
		[366155] = "Osykrond-Proudmoore",
		[33891] = 11,
		[47585] = 5,
		[210291] = 2,
		[83381] = "Spirit Beast <Derringerr>",
		[392776] = 1,
		[374349] = "Luddyxdxd-Kel'Thuzad",
		[414273] = 2,
		[386632] = 1,
		[408131] = "Voice From Beyond",
		[30451] = 8,
		[324184] = 12,
		[374348] = "Luddyxdxd-Kel'Thuzad",
		[406086] = 2,
		[212800] = 12,
		[210714] = 7,
		[325209] = 10,
		[53600] = 2,
		[127915] = 5,
		[373326] = "Echo of Doragosa",
		[400959] = 6,
		[373424] = "Chargath, Bane of Scales",
		[392778] = 1,
		[343295] = 6,
		[50401] = 6,
		[418361] = 10,
		[181113] = "Dragonfire Golem",
		[381637] = 4,
		[374352] = "Echo of Doragosa",
		[102066] = "Time-Twisted Geist",
		[408340] = 11,
		[386556] = 2,
		[19574] = 3,
		[289277] = 1,
		[256358] = "Trothak",
		[389710] = 1,
		[258352] = "Captain Eudora",
		[189999] = "Corßan",
		[360022] = "Grändeeney-Azralon",
		[385616] = 4,
		[374355] = "The Scorching Forge",
		[76473] = "Twilight Flame Caller",
		[117679] = 11,
		[377427] = 5,
		[207685] = 12,
		[386730] = 2,
		[327264] = 10,
		[384290] = 12,
		[325217] = 10,
		[3408] = 4,
		[384595] = 7,
		[389714] = 8,
		[325218] = 10,
		[391762] = 6,
		[372311] = "Qalashi Trainee",
		[413136] = "Harlan Sweete",
		[57755] = 1,
		[190837] = 11,
		[384597] = "Qalashi Warden",
		[51505] = 7,
		[93622] = 11,
		[375384] = "Primalist Earthshaker",
		[384598] = 6,
		[346719] = 7,
		[258875] = "Blackout Barrel <Captain Raoul>",
		[193356] = 4,
		[413264] = "Skyfall Nova <Asaad>",
		[2008] = 7,
		[386647] = 9,
		[108211] = 4,
		[198475] = "Ularogg Cragshaper",
		[381529] = 6,
		[292463] = 11,
		[411916] = "Sundered Devourer",
		[392791] = 1,
		[97462] = 1,
		[383168] = 2,
		[374365] = "Magmatusk",
		[201428] = 12,
		[386652] = 2,
		[193357] = 4,
		[373735] = "Chargath, Bane of Scales",
		[392793] = 1,
		[398938] = "Warlord Kagni",
		[382556] = "Bracken Warscourge",
		[343648] = 11,
		[409174] = "Incarnation of Entropy",
		[196941] = 2,
		[193358] = 4,
		[405082] = "Essence of Shadow",
		[52697] = 6,
		[97463] = 1,
		[411223] = "Djaradin Lavamancer",
		[183633] = "Rockbound Pelter",
		[400986] = 6,
		[215405] = 2,
		[193359] = 4,
		[391773] = "Dragon's Eruption",
		[409177] = "Entropic Hatred",
		[368297] = "Bonebolt Hunter",
		[194384] = 5,
		[281209] = 6,
		[92089] = 12,
		[364343] = "Osykrond-Proudmoore",
		[263806] = 7,
		[281210] = 6,
		[405084] = "Essence of Shadow",
		[391140] = 11,
		[81340] = 6,
		[49379] = 7,
		[391722] = 11,
		[215916] = 9,
		[222026] = 6,
		[404062] = "Sarkareth",
		[419279] = 11,
		[180612] = 6,
		[292474] = 11,
		[383651] = "Qalashi Lavamancer",
		[205648] = 7,
		[50276] = "Ilsa Direbrew",
		[411230] = "Warlord Kagni",
		[76478] = "Twilight Torturer",
		[384613] = 9,
		[410207] = "Warlord Kagni",
		[209261] = 12,
		[408160] = "Neltharion",
		[85948] = 6,
		[385638] = 3,
		[258883] = 12,
		[259395] = 2,
		[355941] = "Osykrond-Proudmoore",
		[393957] = 11,
		[33778] = 11,
		[351338] = "Luddyxdxd-Kel'Thuzad",
		[92091] = 3,
		[184662] = 2,
		[403044] = 2,
		[404068] = "Neltharion",
		[393939] = 8,
		[393831] = 12,
		[76500] = "Twilight Sadist",
		[127923] = 5,
		[273977] = 6,
		[73920] = 7,
		[411236] = "Sarkareth",
		[82622] = "High Prophet Barim",
		[182104] = 2,
		[409242] = "Magma Mystic",
		[390762] = 1,
		[391786] = 11,
		[347765] = 12,
		[280375] = 2,
		[267964] = "Keegoril <Deadlysins-Eredar>",
		[204079] = 2,
		[423861] = 3,
		[377455] = 9,
		[114871] = 2,
		[403050] = 4,
		[184689] = 2,
		[73921] = 7,
		[411240] = "Sarkareth",
		[341678] = 9,
		[384623] = "Qalashi Blacksmith",
		[16595] = 3,
		[408714] = "Eternal Blaze",
		[394864] = 3,
		[384624] = 9,
		[410218] = 1,
		[272012] = "Illidari Satyr <Flickers-Area52>",
		[198509] = "Ularogg Cragshaper",
		[24275] = 2,
		[410219] = 1,
		[101819] = 11,
		[77505] = 7,
		[77761] = 11,
		[387691] = "Vexamus <Magic Book>",
		[374389] = "Curious Swoglet",
		[258338] = "Captain Raoul",
		[409238] = "Magmorax",
		[400456] = 3,
		[382620] = "Bonebolt Hunter",
		[373406] = "Overseer Lahar",
		[347812] = 7,
		[386295] = "Ice Boulder",
		[34026] = 3,
		[11327] = 4,
		[343727] = "Shadowfiend <Icecreamvato-Khadgar>",
		[377463] = 12,
		[403057] = "Neltharion",
		[200025] = 2,
		[77762] = 7,
		[276111] = 2,
		[115129] = 10,
		[272013] = "Vicious Hellhound <Flickers-Area52>",
		[384631] = 4,
		[387393] = 9,
		[367230] = "Osykrond-Proudmoore",
		[383608] = 8,
		[396917] = 3,
		[410226] = 1,
		[410228] = 1,
		[26297] = 5,
		[396918] = 9,
		[48743] = 6,
		[414444] = 2,
		[191837] = 10,
		[396919] = 7,
		[205146] = 9,
		[361500] = "Luddyxdxd-Kel'Thuzad",
		[202075] = "Burning Geode",
		[396920] = 11,
		[371355] = 1,
		[5760] = 4,
		[375416] = "Infected Lasher",
		[257870] = "Irontide Buccaneer",
		[356995] = "Osykrond-Proudmoore",
		[181089] = "Altairus",
		[409233] = "Colossal Draconic Golem",
		[375449] = "Magmatusk",
		[410231] = 6,
		[77764] = 11,
		[406161] = "[*] Lava Explosion",
		[34795] = 8,
		[410232] = 6,
		[193375] = "Ularogg Cragshaper",
		[132463] = 10,
		[127928] = 11,
		[198496] = "Ularogg Cragshaper",
		[390782] = 5,
		[191840] = 10,
		[196447] = 9,
		[406139] = 10,
		[382593] = "Cruel Bonecrusher",
		[20153] = "Blasphemy <Mersan-Arthas>",
		[114113] = 11,
		[58984] = 12,
		[114108] = 11,
		[118459] = "Spirit Beast <Derringerr>",
		[20473] = 2,
		[53351] = 3,
		[211805] = 6,
		[401022] = "Neltharion",
		[405118] = 7,
		[377477] = "Warlord Sargha",
		[403071] = 3,
		[399032] = 12,
		[388739] = 8,
		[88263] = 2,
		[386692] = 1,
		[367241] = 5,
		[384646] = 10,
		[101568] = 6,
		[16827] = "Spirit Beast <Derringerr>",
		[51690] = 4,
		[409216] = "Sundered Manaweaver",
		[402050] = "Sarkareth",
		[371354] = 1,
		[214366] = 11,
		[409217] = "Sundered Manaweaver",
		[402051] = "Sarkareth",
		[374410] = "Magmatusk",
		[371339] = 7,
		[382551] = 1,
		[375397] = "Chargath, Bane of Scales",
		[202028] = 11,
		[132467] = 10,
		[410243] = "Sarkareth",
		[402053] = "Sarkareth",
		[390787] = 5,
		[375436] = "Magmatusk",
		[196448] = 9,
		[382444] = "Rotchanting Totem",
		[374407] = 6,
		[179057] = 12,
		[264878] = 3,
		[219788] = 6,
		[390706] = 5,
		[390833] = 3,
		[116670] = 10,
		[406152] = "Rashok",
		[225119] = 8,
		[375439] = "Magmatusk",
		[389774] = 1,
		[207203] = 6,
		[77768] = "Conflagration",
		[27576] = 4,
		[135029] = "Water Elemental <Xyluh-Thrall>",
		[406153] = "Rashok",
		[107203] = 5,
		[315496] = 4,
		[413319] = "Altairus",
		[369299] = "Osykrond-Proudmoore",
		[88963] = "Minister of Air",
		[83655] = "General Husam",
		[368276] = 5,
		[156000] = 6,
		[32375] = 5,
		[371348] = 7,
		[372372] = "Qalashi Trainee",
		[59913] = 9,
		[21562] = 5,
		[6552] = 1,
		[200551] = "Dargrul",
		[367231] = "Osykrond-Proudmoore",
		[272046] = "Sharkbait",
		[371350] = 7,
		[32182] = 7,
		[25912] = 2,
		[403087] = 9,
		[371351] = 7,
		[388755] = 9,
		[242014] = 10,
		[257871] = "Irontide Buccaneer",
		[383637] = 8,
		[409231] = "Colossal Draconic Golem",
		[117952] = 10,
		[386709] = 1,
		[371353] = 7,
		[384662] = "Forgewrought Monstrosity",
		[410256] = "Luddyxdxd-Kel'Thuzad",
		[193376] = "Ularogg Cragshaper",
		[202089] = "Burning Geode",
		[384663] = "Forgewrought Monstrosity",
		[378990] = 11,
		[22842] = 11,
		[281265] = 5,
		[48107] = 8,
		[88747] = 11,
		[335467] = 5,
		[202090] = 10,
		[202602] = 1,
		[393879] = 2,
		[258381] = "Captain Eudora",
		[192799] = "Blightshard Skitter <Rokmora>",
		[413331] = "Altairus",
		[406165] = "Rashok",
		[403094] = 6,
		[374361] = "Echo of Doragosa",
		[368287] = "Bonebolt Hunter",
		[385691] = "Gulping Goliath",
		[272055] = "Sharkbait",
		[228645] = 6,
		[31224] = 4,
		[209258] = 12,
		[7744] = 8,
		[375209] = "The Scorching Forge",
		[190319] = 8,
		[410263] = "Lizardmage-Illidan",
		[411242] = "Sarkareth",
		[405233] = 11,
		[102342] = 11,
		[102598] = "Infinite Warden",
		[374839] = "Forgemaster Gorek",
		[359077] = "Arcodis",
		[343721] = 2,
		[410265] = 1,
		[170869] = 7,
		[383648] = 7,
		[48108] = 8,
		[106898] = 11,
		[313010] = 10,
		[415339] = 3,
		[271971] = "Dreadstalker <Kkyzz-Akama>",
		[406172] = "Rashok",
		[407196] = "Kazzara, the Hellforged",
		[386486] = 1,
		[379404] = "Qalashi Lavabearer",
		[102599] = "Infinite Warden",
		[377004] = "Crawth",
		[123586] = 10,
		[77758] = 11,
		[319238] = 6,
		[407198] = "Kazzara, the Hellforged",
		[386633] = 1,
		[5761] = 4,
		[415388] = 2,
		[407199] = "Kazzara, the Hellforged",
		[222024] = 6,
		[339632] = 3,
		[410271] = "[*] Clinging Void",
		[407200] = "Kazzara, the Hellforged",
		[51052] = 6,
		[387678] = 6,
		[102600] = "Infinite Suppressor",
		[55531] = 3,
		[82637] = "[*] Plague of Ages",
		[368299] = "Bonebolt Hunter",
		[25914] = 2,
		[391634] = "Glacial Proto-Dragon",
		[382555] = "Bracken Warscourge",
		[82362] = "Twilight Zealot",
		[160124] = "Uvuros <Malfi-Proudmoore>",
		[384601] = "Neltharus Weapons",
		[383062] = "Decayed Elder",
		[407207] = "Neltharion",
		[113862] = 8,
		[125355] = 10,
		[343312] = 12,
		[413263] = "Skyfall Nova <Asaad>",
		[102601] = "Infinite Suppressor",
		[415395] = 3,
		[195292] = 6,
		[101592] = "Murozond",
		[203123] = 11,
		[386731] = 2,
		[405069] = 11,
		[384684] = "Sundered Siegemaster",
		[406183] = "Krono Sandtongue",
		[42223] = 9,
		[285381] = 11,
		[384685] = 8,
		[393899] = 2,
		[387504] = "Primal Tsunami",
		[17364] = 7,
		[265931] = 9,
		[116768] = 10,
		[382538] = 2,
		[115399] = 10,
		[343737] = "Yu'lon <Macpunch-Bonechewer>",
		[83151] = "Siamat",
		[404027] = "Sarkareth",
		[404139] = 2,
		[373305] = 5,
		[377522] = "Raging Ember",
		[258920] = 12,
		[199373] = "Army of the Dead|T1392565:0|t <Cocnballs-Barthilas>",
		[205196] = "Dreadstalker <Flickers-Area52>",
		[393903] = 11,
		[80308] = "Stonecore Rift Conjurer",
		[80052] = "Stonecore Magmalord",
		[160029] = 11,
		[316099] = 9,
		[258921] = 12,
		[82640] = "Arcodis",
		[196414] = 9,
		[406233] = "Rionthus",
		[5217] = 11,
		[387763] = "Luddyxdxd-Kel'Thuzad",
		[405167] = 5,
		[414381] = 8,
		[258922] = 12,
		[210294] = 2,
		[392883] = 10,
		[256363] = "Trothak",
		[405042] = "Thadrion",
		[375353] = "Glacial Proto-Dragon",
		[257899] = "Irontide Ravager",
		[381623] = 4,
		[59628] = 4,
		[371386] = 2,
		[319175] = 4,
		[211319] = 5,
		[386743] = "Khajin the Unyielding",
		[371387] = 2,
		[417456] = 2,
		[108199] = 6,
		[201594] = 3,
		[2120] = 8,
		[393763] = 11,
		[382043] = 7,
		[199547] = 12,
		[89808] = "Lazqua <Grindlock-Shadowsong>",
		[417458] = 2,
		[2825] = 7,
		[407221] = "Neltharion",
		[387621] = 10,
		[15487] = 5,
		[385723] = 2,
		[415412] = 3,
		[87761] = "Executor of the Caliph",
		[75732] = "Corla, Herald of Twilight",
		[385724] = 2,
		[258926] = 12,
		[202108] = "Blightshard Shaper",
		[409271] = "Magma Mystic",
		[389820] = 7,
		[215929] = "Blightshard Skitter <Rokmora>",
		[126664] = 1,
		[73685] = 7,
		[205180] = 9,
		[390845] = 5,
		[381470] = "Tricktotem",
		[405016] = "Essence of Shadow",
		[373442] = "Mindbender <Dubwubz-Illidan>",
		[379425] = 9,
		[204157] = 12,
		[257904] = "Ludwig Von Tortollan",
		[387571] = "Primal Tsunami",
		[267997] = "Vilefiend <Flickers-Area52>",
		[412346] = "Irontide Corsair",
		[409275] = "Magma Mystic",
		[393919] = 5,
		[388615] = 10,
		[383501] = 8,
		[102351] = 11,
		[377540] = 6,
		[45297] = 7,
		[221562] = 6,
		[15496] = "Stonecore Warbringer",
		[406206] = "[*] Tactical Destruction",
		[199552] = 12,
		[108238] = 11,
		[75543] = "Rom'ogg Bonecrusher",
		[377542] = "[*] Burning Ground",
		[374471] = "Grounding Spear <Chargath, Bane of Scales>",
		[76502] = "Twilight Sadist",
		[383939] = 2,
		[6353] = 9,
		[101840] = "Echo of Baine",
		[391876] = 11,
		[319190] = 4,
		[184709] = 1,
		[242551] = 8,
		[589] = 5,
		[102560] = 11,
		[402115] = "Neltharion",
		[394949] = 10,
		[373257] = "Lizardmage-Illidan",
		[257908] = "Irontide Officer",
		[197919] = 10,
		[386760] = 9,
		[385531] = "Gulping Goliath",
		[384713] = 2,
		[19505] = "Luuzhem <Gulbann-Illidan>",
		[224125] = 7,
		[163212] = 10,
		[405189] = 11,
		[131476] = 6,
		[386553] = 2,
		[184575] = 2,
		[78807] = "Ozruk",
		[256374] = 8,
		[203651] = 11,
		[391882] = 11,
		[389179] = "Watcher Irideus",
		[402120] = "Neltharion",
		[3409] = 4,
		[402420] = "[*] Molten Scar",
		[198533] = "Jade Serpent Statue <Macpunch-Bonechewer>",
		[393931] = 1,
		[224127] = 7,
		[412359] = "Arcodis",
		[392908] = 2,
		[414407] = 2,
		[317920] = 2,
		[387790] = 6,
		[77472] = 7,
		[414408] = 2,
		[374482] = "Grounding Spear <Chargath, Bane of Scales>",
		[195975] = 6,
		[178963] = 12,
		[389839] = 7,
		[32379] = 5,
		[36213] = "Greater Earth Elemental <Stormart>",
		[274156] = 6,
		[393935] = 8,
		[407244] = "Luddyxdxd-Kel'Thuzad",
		[61295] = 7,
		[405197] = 8,
		[372203] = "Qalashi Irontorch",
		[386770] = 8,
		[198024] = "Rokmora",
		[76186] = "Ascendant Lord Obsidius",
		[373462] = 5,
		[393971] = 4,
		[257402] = "Harlan Sweete",
		[1715] = 1,
		[361178] = "Kalythra-Sargeras",
		[373213] = 5,
		[383701] = 10,
		[384725] = "Rotfang Hyena <Gutshot>",
		[377559] = "Treemouth",
		[212680] = 3,
		[980] = 9,
		[196490] = 5,
		[82137] = "Rom'ogg Bonecrusher",
		[82393] = "Ascendant Lord Obsidius",
		[382290] = 8,
		[388822] = "Echo of Doragosa",
		[246854] = 3,
		[419535] = 5,
		[87768] = "Minister of Air",
		[417488] = 8,
		[389847] = 12,
		[197568] = 7,
		[212739] = 6,
		[210824] = 8,
		[211336] = 5,
		[257274] = "[*] Vile Coating",
		[383706] = 1,
		[417490] = 8,
		[396752] = 1,
		[406989] = "Sarkareth",
		[198028] = "[*] Crystalline Ground",
		[57841] = 4,
		[91352] = 1,
		[407254] = "Luddyxdxd-Kel'Thuzad",
		[360194] = 4,
		[417492] = 8,
		[198030] = 12,
		[80279] = "Stonecore Rift Conjurer",
		[76508] = "Crazed Mage",
		[388828] = 6,
		[381662] = "Apex Blazewing",
		[415446] = 2,
		[201633] = "Earthen Wall Totem <Shrêk-Hydraxis>",
		[405209] = 6,
		[381663] = "Apex Blazewing",
		[205708] = 8,
		[395996] = 4,
		[186257] = 3,
		[381664] = 4,
		[256896] = 5,
		[411912] = "Sundered Devourer",
		[290819] = 3,
		[120954] = 10,
		[84544] = "Servant of Siamat <[*] Static Shock>",
		[405946] = "Krono Sandtongue",
		[186258] = 3,
		[101591] = 11,
		[85467] = "Lurking Tempest",
		[98008] = 7,
		[57330] = 6,
		[419563] = 5,
		[27243] = 9,
		[414133] = 2,
		[57842] = 4,
		[381668] = 7,
		[378597] = 7,
		[87771] = "Servant of Asaad",
		[136] = 3,
		[702] = 9,
		[264663] = 3,
		[387812] = 2,
		[389860] = 12,
		[381670] = "Apex Blazewing",
		[394979] = "Void Lasher <Odemp-Nagrand>",
		[404911] = 3,
		[183548] = "Stoneclaw Grubmaster",
		[373481] = 5,
		[403170] = 6,
		[198034] = 2,
		[409313] = "Neltharion",
		[418527] = 6,
		[207760] = 12,
		[404195] = "Luddyxdxd-Kel'Thuzad",
		[52212] = 6,
		[193273] = "Ularogg Cragshaper",
		[317177] = 7,
		[334581] = 9,
		[405220] = 3,
		[393959] = 11,
		[89212] = "Sharptalon Eagle <Oathsworn Pathfinder>",
		[77535] = 6,
		[372461] = "Overseer Lahar",
		[246152] = 3,
		[1161] = 1,
		[193941] = "Embershard Scorpion",
		[392937] = 1,
		[393961] = 11,
		[163025] = 4,
		[191894] = 10,
		[191634] = 7,
		[395521] = 10,
		[116849] = 10,
		[121557] = 5,
		[392939] = 2,
		[389868] = 9,
		[371982] = 11,
		[371441] = "Osykrond-Proudmoore",
		[147362] = 3,
		[411900] = "[*] Gloom Fluid",
		[375055] = "Chargath, Bane of Scales",
		[374533] = "Forgemaster Gorek",
		[186265] = 3,
		[395414] = 10,
		[388524] = 10,
		[31821] = 2,
		[124974] = 11,
		[406251] = 12,
		[260798] = 1,
		[19434] = 3,
		[319233] = 6,
		[411906] = "Sundered Chemist",
		[390896] = 7,
		[118905] = 7,
		[2479] = 7,
		[53365] = 6,
		[596] = 5,
		[411909] = "Sundered Chemist",
		[372470] = "Lizardmage-Illidan",
		[137639] = 10,
		[215956] = 9,
		[285452] = 7,
		[347901] = 2,
		[76002] = "Karsh Steelbender",
		[80353] = 8,
		[383733] = 10,
		[1329] = 4,
		[377591] = 6,
		[220890] = 6,
		[397734] = 11,
		[413423] = 11,
		[384029] = 2,
		[185245] = 12,
		[390435] = 2,
		[186269] = "Blightshard Shaper",
		[414448] = 2,
		[382712] = "Wilted Oak",
		[375068] = "Lava Tentacles <Magmatusk>",
		[405235] = 7,
		[81677] = "Frenzied Crocolisk",
		[80354] = 8,
		[382234] = 2,
		[413426] = "Partikle",
		[410355] = "Lizardmage-Illidan",
		[407284] = "Djaradin Skullcrusher",
		[205025] = 8,
		[49143] = 6,
		[88075] = "Cloud Prince",
		[407285] = "Djaradin Skullcrusher",
		[386029] = 1,
		[319243] = 6,
		[385787] = 11,
		[203981] = 12,
		[91872] = "Servant of Siamat <[*] Static Shock>",
		[384764] = "Rotfang Hyena <Gutshot>",
		[58127] = "Servant of Asaad",
		[1449] = 8,
		[375056] = "Chargath, Bane of Scales",
		[319245] = 6,
		[381694] = "Gashtooth",
		[199581] = 9,
		[46968] = 1,
		[392956] = 3,
		[378149] = "Ore Elemental",
		[375079] = "Squallbringer Cyraz",
		[5938] = 4,
		[388862] = "Corrupted Manafiend",
		[83171] = "[*] Mystic Trap",
		[341770] = 9,
		[367364] = "Osykrond-Proudmoore",
		[388863] = "Corrupted Manafiend",
		[305485] = 7,
		[272156] = "Void Terror <Kkyzz-Akama>",
		[22568] = 11,
		[392959] = 10,
		[372015] = 11,
		[268062] = 6,
		[400126] = 11,
		[401150] = 1,
		[381699] = 2,
		[313108] = 8,
		[185763] = 4,
		[388866] = "Corrupted Manafiend",
		[381700] = 2,
		[374534] = "Forgemaster Gorek",
		[257426] = "Irontide Enforcer",
		[388867] = 10,
		[213405] = 12,
		[374535] = "Forgemaster Gorek",
		[205549] = "Naraxas",
		[388868] = "[*] Mana Void",
		[414462] = 8,
		[403748] = "Eternal Blaze",
		[415007] = 10,
		[228478] = 12,
		[135601] = 11,
		[59638] = 8,
		[387846] = 9,
		[405914] = "Shadowflame Amalgamation",
		[410369] = "Warlord Kagni",
		[268068] = 6,
		[87780] = "Temple Adept",
		[392966] = 1,
		[406648] = 2,
		[274838] = 11,
		[400133] = 4,
		[205523] = 10,
		[256405] = "Trothak",
		[403515] = "Astral Formation <Sarkareth>",
		[342857] = 12,
		[194249] = 5,
		[385802] = 4,
		[18562] = 11,
		[202147] = 1,
		[390964] = 5,
		[378011] = "Guardian Sentry",
		[272167] = "Bilescourge <Flickers-Area52>",
		[383756] = 12,
		[278310] = 8,
		[33917] = 11,
		[383290] = 1,
		[400137] = 4,
		[201959] = "Emberhusk Dominator",
		[385805] = "Stinkbreath",
		[374544] = "Fetid Rotsinger",
		[76686] = "Twilight Obsidian Borer",
		[409352] = "Blazing Dreadsquall",
		[114911] = 7,
		[210152] = 12,
		[31935] = 2,
		[90898] = 9,
		[70890] = 6,
		[419591] = 6,
		[204197] = 5,
		[409354] = 7,
		[197628] = 11,
		[370452] = "Arcodis",
		[383761] = 6,
		[266030] = 9,
		[402461] = "Kazzara, the Hellforged",
		[396092] = 7,
		[289577] = 5,
		[405261] = 1,
		[256706] = "Trothak",
		[257732] = "Irontide Enforcer",
		[385347] = 2,
		[388882] = "Infuser Sariya",
		[382867] = 9,
		[148022] = 8,
		[212988] = 12,
		[257946] = 3,
		[164273] = 3,
		[1833] = 4,
		[76522] = "Twilight Zealot",
		[388884] = "Spellbound Scepter",
		[370511] = 6,
		[156287] = 1,
		[98021] = "Spirit Link Totem <Huulia-Zul'jin>",
		[372505] = 11,
		[76572] = "Twilight Sadist",
		[14914] = 5,
		[197834] = 4,
		[388886] = "Spellbound Scepter",
		[123904] = 10,
		[409877] = 12,
		[43900] = "Kalythra-Sargeras",
		[116705] = 10,
		[385816] = 2,
		[409921] = "Djaradin Commander",
		[406851] = "Rashok",
		[392983] = 10,
		[269576] = 3,
		[390936] = 2,
		[387865] = 6,
		[33206] = 5,
		[385359] = "Gutshot",
		[374557] = 6,
		[387866] = 6,
		[383313] = 6,
		[394009] = 6,
		[390938] = "Aggravated Skitterfly",
		[342076] = 3,
		[96231] = 2,
		[372652] = "[*] Resonating Orb",
		[383316] = 1,
		[76524] = "Twilight Zealot",
		[409367] = "Neldris",
		[394011] = 3,
		[31616] = 7,
		[414022] = 2,
		[195707] = 11,
		[381727] = 1,
		[193455] = 3,
		[411910] = "Young Storm Dragon",
		[76575] = 1,
		[377633] = 6,
		[79340] = "High Priestess Azil",
		[586] = 5,
		[387413] = 9,
		[49966] = "Scalehide <Wargrimz>",
		[374563] = "Dazzling Dragonfly",
		[227291] = "Niuzao <Staggerbot-Korgath>",
		[80158] = "Stonecore Warbringer",
		[373540] = "Binding Spear",
		[390944] = "Aggravated Skitterfly",
		[85739] = 1,
		[2050] = 5,
		[45181] = 4,
		[50842] = 6,
		[387874] = 6,
		[194481] = 11,
		[402207] = "[*] Ray of Anguish",
		[2098] = 4,
		[187827] = 12,
		[390898] = 2,
		[205231] = "Darkglare <Vonzur-Azralon>",
		[407327] = "Thadrion",
		[383781] = 10,
		[337819] = 12,
		[81439] = "Millhouse Manastorm",
		[385375] = 7,
		[85740] = 8,
		[401186] = 11,
		[25504] = 7,
		[407329] = "Neltharion",
		[383783] = 8,
		[401187] = 11,
		[394021] = 4,
		[385890] = 1,
		[391974] = 11,
		[410968] = "Neltharion",
		[377642] = 6,
		[163073] = 12,
		[198067] = 7,
		[274516] = "Lizardmage-Illidan",
		[391172] = 12,
		[199603] = 4,
		[408356] = 6,
		[27285] = 9,
		[45182] = 4,
		[258773] = "Skycap'n Kragg",
		[82670] = "Oathsworn Captain",
		[20707] = 9,
		[357170] = "Osykrond-Proudmoore",
		[374641] = "Forgemaster Gorek",
		[8599] = "Mad Prisoner",
		[199667] = 1,
		[394026] = 4,
		[227034] = 11,
		[202164] = 1,
		[58875] = 7,
		[34433] = 5,
		[101866] = 11,
		[407790] = "Neltharion",
		[377204] = "Warlord Sargha",
		[406313] = "Neldris",
		[82415] = "Corborus",
		[82671] = "Oathsworn Myrmidon",
		[408422] = "Sarkareth",
		[410981] = "Djaradin Dragonhunter",
		[374578] = "Dazzling Dragonfly",
		[204213] = 5,
		[409386] = 7,
		[272554] = "[*] Bloody Mess",
		[703] = 4,
		[202166] = 1,
		[388912] = "Spellbound Battleaxe",
		[402221] = 2,
		[101867] = 12,
		[285514] = 7,
		[217011] = "Angry Crowd",
		[385842] = 1,
		[193530] = 3,
		[157122] = 2,
		[87023] = 8,
		[381748] = "Luddyxdxd-Kel'Thuzad",
		[79345] = "High Priestess Azil",
		[204215] = 5,
		[371070] = 11,
		[129253] = 5,
		[280398] = 5,
		[202168] = 1,
		[409391] = 7,
		[384379] = 8,
		[411439] = "Sundered Siegemaster",
		[102124] = "Time-Twisted Breaker",
		[76677] = "Twilight Element Warden",
		[406321] = "[*] Lava Vortex",
		[374585] = 6,
		[82673] = "Oathsworn Myrmidon",
		[87024] = 8,
		[418607] = 5,
		[374586] = "Forgemaster Gorek",
		[383800] = 10,
		[282449] = 4,
		[394618] = 9,
		[226287] = "Vileshard Chunk",
		[84721] = 8,
		[44544] = 8,
		[207289] = 6,
		[390968] = "Treemouth",
		[408372] = "Kazzara, the Hellforged",
		[102381] = "Murozond",
		[381755] = 7,
		[268474] = 8,
		[408373] = "Kazzara, the Hellforged",
		[78835] = "Ozruk",
		[345231] = 1,
		[385186] = "Stinkbreath",
		[375614] = "Decaying Slime",
		[409398] = "Crystalline Guardian",
		[781] = 3,
		[390971] = 5,
		[408375] = 6,
		[198589] = 12,
		[101614] = "Echo of Baine",
		[386877] = 3,
		[408376] = 6,
		[200637] = "Dargrul",
		[320334] = 12,
		[43265] = 6,
		[412472] = "Neltharion",
		[198590] = 9,
		[381760] = 1,
		[107550] = "Murozond",
		[377234] = 6,
		[115994] = 6,
		[381761] = 7,
		[256489] = "Trothak",
		[84522] = "Servant of Siamat <[*] Static Shock>",
		[397118] = 3,
		[394047] = 11,
		[386452] = 6,
		[395152] = "Luddyxdxd-Kel'Thuzad",
		[388929] = 5,
		[20549] = 11,
		[193473] = "Void Tendril <Odemp-Nagrand>",
		[383811] = 8,
		[401215] = 10,
		[394049] = 11,
		[390978] = 5,
		[257458] = "Harlan Sweete",
		[101412] = "Echo of Sylvanas",
		[394050] = 11,
		[403264] = "Luddyxdxd-Kel'Thuzad",
		[383813] = 7,
		[324540] = 9,
		[81141] = 6,
		[403265] = "Luddyxdxd-Kel'Thuzad",
		[76594] = "Twilight Zealot",
		[245686] = 5,
		[20572] = 1,
		[115181] = 10,
		[408385] = 2,
		[157644] = 8,
		[346554] = 6,
		[83445] = "General Husam",
		[108271] = 7,
		[327510] = 2,
		[88308] = "Altairus",
		[378287] = 4,
		[383405] = 4,
		[235450] = 8,
		[381770] = "Decaying Slime <Treemouth>",
		[325464] = 6,
		[69369] = 11,
		[266087] = 9,
		[73976] = "Neferset Plaguebringer",
		[382795] = "Qalashi Lavamancer",
		[106785] = 11,
		[411754] = "Conduit Guardian",
		[386997] = 9,
		[83446] = "Minion of Siamat",
		[183752] = 12,
		[265202] = 5,
		[202198] = "Stoneclaw Hunter",
		[403272] = "Neltharion",
		[325983] = 2,
		[388940] = "Arcane Ravager",
		[101643] = 10,
		[288613] = 3,
		[383934] = 5,
		[372561] = "Qalashi Hunter",
		[32216] = 1,
		[390989] = 5,
		[412488] = "Crawling Goo",
		[388942] = "Arcane Ravager",
		[394061] = 11,
		[403275] = "Osykrond-Proudmoore",
		[289639] = 7,
		[393038] = 2,
		[308514] = 10,
		[164815] = 11,
		[49576] = 6,
		[194594] = 3,
		[101619] = "[*] Magma",
		[382802] = "Vile Rothexer",
		[102131] = "Ruptured Ground <Time-Twisted Breaker>",
		[171982] = 9,
		[357209] = "Luddyxdxd-Kel'Thuzad",
		[201671] = 11,
		[256522] = 4,
		[372566] = "Qalashi Hunter",
		[357210] = "Osykrond-Proudmoore",
		[321379] = 5,
		[120360] = 3,
		[88055] = "Armored Mistral",
		[259756] = 8,
		[382805] = "Wilted Oak",
		[408399] = 2,
		[88182] = "Empyrean Assassin",
		[357212] = "Arcodis",
		[203720] = 12,
		[408400] = 2,
		[3714] = 6,
		[80240] = 9,
		[82425] = "Harbinger of Darkness",
		[405458] = "Shadowflame Amalgamation",
		[372570] = "Qalashi Hunter",
		[219589] = 8,
		[382808] = "[*] Withering Contagion",
		[377825] = "[*] Burning Pitch",
		[88056] = "Armored Mistral",
		[132168] = 1,
		[403284] = "Sarkareth",
		[234946] = 5,
		[393047] = 10,
		[12654] = 8,
		[390111] = "Khajin the Unyielding",
		[407512] = 12,
		[401238] = 5,
		[388068] = 9,
		[91196] = "Blaze of the Heavens",
		[226757] = 8,
		[194509] = 5,
		[308078] = 7,
		[76612] = "Twilight Zealot",
		[1330] = 4,
		[393050] = 10,
		[385884] = 11,
		[321388] = 8,
		[351077] = 1,
		[214985] = 12,
		[377844] = "Rira Hackclaw",
		[247456] = 12,
		[102134] = "Time-Twisted Drake",
		[388957] = "Arcane Ravager",
		[90361] = "Spirit Beast <Derringerr>",
		[321390] = 8,
		[396124] = "Gutshot",
		[393053] = 10,
		[226347] = "Stoneclaw Hunter",
		[82757] = "Neferset Theurgist",
		[383840] = "Watcher Irideus",
		[200654] = 2,
		[88314] = "Twister",
		[405462] = "[*] Dragonfire Traps",
		[401521] = "Osykrond-Proudmoore",
		[84987] = "Siamat",
		[162264] = 12,
		[381954] = 7,
		[102135] = "Time-Twisted Drake",
		[188370] = 2,
		[406365] = "Neldris",
		[93795] = 1,
		[400223] = 11,
		[409437] = "Voracious Magma Worm",
		[59052] = 6,
		[96312] = 7,
		[281469] = 5,
		[372583] = "Qalashi Hunter",
		[308087] = 7,
		[390276] = 6,
		[385187] = "Gulping Goliath",
		[127797] = 11,
		[394083] = 11,
		[370537] = "Osykrond-Proudmoore",
		[410631] = "Sarkareth",
		[405345] = 2,
		[411911] = "Young Storm Dragon",
		[51460] = 6,
		[132578] = 10,
		[3411] = 1,
		[124988] = 11,
		[382824] = 8,
		[257476] = "Irontide Mastiff",
		[30213] = "奥里克西努尔 <Kkyzz-Akama>",
		[386296] = 3,
		[374635] = "Forgemaster Gorek",
		[48517] = 11,
		[255941] = 2,
		[394087] = 9,
		[406550] = 6,
		[204242] = 2,
		[386081] = 4,
		[377708] = 2,
		[66050] = 3,
		[104773] = 9,
		[405350] = 2,
		[373756] = "Chargath, Bane of Scales",
		[83454] = "[*] Shockwave",
		[108280] = 7,
		[88061] = "Armored Mistral",
		[275335] = 1,
		[272402] = "Cutwater Knife Juggler",
		[109304] = 3,
		[409447] = 2,
		[63106] = 9,
		[55095] = 6,
		[77568] = "Mad Prisoner",
		[401258] = "Warlord Kagni",
		[262232] = 1,
		[90621] = 7,
		[408425] = "Sarkareth",
		[271466] = 5,
		[47750] = 5,
		[83455] = "Minion of Siamat",
		[108281] = 7,
		[400430] = "Kazzara, the Hellforged",
		[401401] = "Flamebound Huntsman",
		[152173] = 10,
		[48518] = 11,
		[113656] = 10,
		[101627] = "Echo of Baine",
		[32645] = 4,
		[369563] = "Baelog",
		[82744] = "Neferset Torturer",
		[8004] = 7,
		[407405] = 3,
		[396144] = 5,
		[374704] = "Chargath, Bane of Scales",
		[385907] = 4,
		[386931] = 9,
		[54149] = 2,
		[135700] = 11,
		[383882] = 8,
		[358267] = "Luddyxdxd-Kel'Thuzad",
		[367481] = "Claw Fighter",
		[372600] = "Sentinel Talondras",
		[382022] = 7,
		[370553] = "Luddyxdxd-Kel'Thuzad",
		[8680] = 4,
		[225919] = 12,
		[94462] = 3,
		[386124] = 9,
		[347008] = "Felguard <Flickers-Area52>",
		[388982] = "Arcane Ravager",
		[394101] = 2,
		[342240] = 7,
		[200154] = "Molten Charskin <Dargrul>",
		[373960] = "Decatriarch Wratheye",
		[157331] = "Greater Storm Elemental <Orclanraider-Rivendare>",
		[194153] = 11,
		[367485] = "Claw Fighter",
		[388984] = "Arcane Ravager",
		[389328] = 10,
		[378747] = 3,
		[297871] = 6,
		[392166] = "Neltharus Weapons",
		[94463] = 2,
		[415603] = 5,
		[11366] = 8,
		[372847] = 5,
		[372835] = 5,
		[382844] = 11,
		[392058] = 3,
		[270232] = 8,
		[376933] = "Treemouth",
		[382845] = 11,
		[256594] = "Captain Raoul",
		[397405] = 9,
		[77130] = 7,
		[382846] = 11,
		[118522] = 7,
		[415673] = 5,
		[394108] = 11,
		[382847] = 11,
		[392061] = 3,
		[255952] = "Skycap'n Kragg",
		[378989] = 11,
		[382848] = 11,
		[386237] = 4,
		[196099] = 9,
		[408677] = "Sundered Scaleguard",
		[32390] = 9,
		[383873] = 1,
		[408682] = 12,
		[231895] = 2,
		[236502] = 7,
		[400254] = 11,
		[12294] = 1,
		[377732] = "Refti Custodian",
		[403326] = "Kazzara, the Hellforged",
		[383875] = "Treemouth",
		[384899] = "Rotbow Stalker",
		[256005] = "Sharkbait",
		[382852] = 8,
		[373896] = "Decatriarch Wratheye",
		[405375] = "Thadrion",
		[406399] = "Malgosa Spellbinder",
		[382853] = 8,
		[375687] = "Decay Totem <Fetid Rotsinger>",
		[205448] = 5,
		[312215] = 5,
		[162794] = 12,
		[8679] = 4,
		[388976] = "Arcane Ravager",
		[317614] = 6,
		[382855] = 8,
		[124682] = 10,
		[91139] = 5,
		[47753] = 5,
		[382856] = 8,
		[367500] = "Bracken Warscourge",
		[188389] = 7,
		[48265] = 6,
		[382857] = 8,
		[64901] = 5,
		[369823] = "Vicious Basilisk",
		[381834] = "Rira Hackclaw",
		[382858] = 8,
		[187878] = 7,
		[384906] = 2,
		[114942] = "Healing Tide Totem <Huulia-Zul'jin>",
		[378764] = "Treemouth",
		[396168] = 10,
		[411798] = "Oozing Sludge",
		[361361] = "Darlys-Area52",
		[75272] = "Rom'ogg Bonecrusher",
		[367504] = "Decay Speaker",
		[372623] = "Sentinel Talondras",
		[50313] = "Direbrew Minion",
		[403336] = 11,
		[402600] = "Arcane Image",
		[54792] = "Crazed Mage",
		[369854] = "Burly Rock-Thrower",
		[130654] = 10,
		[336126] = "Manzzanita-Ragnaros",
		[343960] = 10,
		[402314] = 11,
		[382863] = 9,
		[19658] = "Luuzhem <Gulbann-Illidan>",
		[231390] = 3,
		[23881] = 1,
		[391054] = 2,
		[359318] = 2,
		[96260] = "Asaad",
		[378076] = 7,
		[378770] = 3,
		[396174] = 2,
		[409483] = 4,
		[319236] = 6,
		[101891] = "Time-Twisted Scourge Beast",
		[383226] = 1,
	},
	["shield_spellid_cache"] = {
	},
	["latest_encounter_spell_pool_access"] = 1695698514,
	["auto_open_news_window"] = false,
	["got_first_run"] = true,
	["raid_data"] = {
	},
	["spell_category_latest_sent"] = 0,
	["merge_pet_abilities"] = false,
	["all_switch_config"] = {
		["scale"] = 1,
		["font_size"] = 10,
	},
	["plater"] = {
		["realtime_dps_enabled"] = false,
		["realtime_dps_size"] = 12,
		["realtime_dps_player_shadow"] = true,
		["damage_taken_enabled"] = false,
		["realtime_dps_player_size"] = 12,
		["damage_taken_size"] = 12,
		["realtime_dps_color"] = {
			1, -- [1]
			1, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["realtime_dps_anchor"] = {
			["y"] = 0,
			["x"] = 0,
			["side"] = 7,
		},
		["damage_taken_shadow"] = true,
		["damage_taken_anchor"] = {
			["y"] = 0,
			["x"] = 0,
			["side"] = 7,
		},
		["damage_taken_color"] = {
			1, -- [1]
			1, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["realtime_dps_player_color"] = {
			1, -- [1]
			1, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["realtime_dps_player_anchor"] = {
			["y"] = 0,
			["x"] = 0,
			["side"] = 7,
		},
		["realtime_dps_player_enabled"] = false,
		["realtime_dps_shadow"] = true,
	},
	["__profiles"] = {
		["Elyyine-Mal'Ganis"] = {
			["overall_clear_newtorghast"] = true,
			["use_realtimedps"] = false,
			["row_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["streamer_config"] = {
				["faster_updates"] = false,
				["quick_detection"] = false,
				["reset_spec_cache"] = false,
				["no_alerts"] = false,
				["use_animation_accel"] = true,
				["disable_mythic_dungeon"] = false,
			},
			["all_players_are_group"] = false,
			["use_row_animations"] = true,
			["report_heal_links"] = false,
			["remove_realm_from_name"] = true,
			["minimum_overall_combat_time"] = 10,
			["event_tracker"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["show_crowdcontrol_pvm"] = false,
				["line_color"] = {
					0.1, -- [1]
					0.1, -- [2]
					0.1, -- [3]
					0.3, -- [4]
				},
				["font_shadow"] = "NONE",
				["font_size"] = 10,
				["font_face"] = "Friz Quadrata TT",
				["line_height"] = 16,
				["show_crowdcontrol_pvp"] = true,
				["frame"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0.1921, -- [1]
						0.1921, -- [2]
						0.1921, -- [3]
						0.3869, -- [4]
					},
					["locked"] = false,
					["height"] = 300,
					["width"] = 250,
				},
				["line_texture"] = "Details Serenity",
				["options_frame"] = {
				},
			},
			["report_to_who"] = "",
			["class_specs_coords"] = {
				[62] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[1467] = {
					0.5, -- [1]
					0.625, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[63] = {
					0.375, -- [1]
					0.5, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[250] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[251] = {
					0.125, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[252] = {
					0.25, -- [1]
					0.375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[1468] = {
					0.625, -- [1]
					0.75, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[253] = {
					0.875, -- [1]
					1, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[254] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[255] = {
					0.125, -- [1]
					0.25, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[66] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[257] = {
					0.5, -- [1]
					0.625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[258] = {
					0.6328125, -- [1]
					0.75, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[259] = {
					0.125, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[260] = {
					0, -- [1]
					0.125, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[577] = {
					0.25, -- [1]
					0.375, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[262] = {
					0.125, -- [1]
					0.25, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[581] = {
					0.375, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[264] = {
					0.375, -- [1]
					0.5, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[265] = {
					0.5, -- [1]
					0.625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[266] = {
					0.625, -- [1]
					0.75, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[267] = {
					0.75, -- [1]
					0.875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[268] = {
					0.625, -- [1]
					0.75, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[269] = {
					0.875, -- [1]
					1, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[270] = {
					0.75, -- [1]
					0.875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[70] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[102] = {
					0.375, -- [1]
					0.5, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[71] = {
					0.875, -- [1]
					1, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[103] = {
					0.5, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[72] = {
					0, -- [1]
					0.125, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[104] = {
					0.625, -- [1]
					0.75, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[64] = {
					0.5, -- [1]
					0.625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[73] = {
					0.125, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[65] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[105] = {
					0.75, -- [1]
					0.875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[256] = {
					0.375, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[261] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[263] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[1473] = {
					0.75, -- [1]
					0.875, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
			},
			["all_in_one_windows"] = {
			},
			["tooltip"] = {
				["tooltip_max_abilities"] = 6,
				["bar_color"] = {
					0.396, -- [1]
					0.396, -- [2]
					0.396, -- [3]
					0.87, -- [4]
				},
				["tooltip_max_pets"] = 2,
				["abbreviation"] = 2,
				["header_text_color"] = {
					1, -- [1]
					0.9176, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["background"] = {
					0.0941, -- [1]
					0.0941, -- [2]
					0.0941, -- [3]
					0.8, -- [4]
				},
				["divisor_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["fontshadow"] = false,
				["anchor_screen_pos"] = {
					507.7, -- [1]
					-350.5, -- [2]
				},
				["header_statusbar"] = {
					0.3, -- [1]
					0.3, -- [2]
					0.3, -- [3]
					0.8, -- [4]
					false, -- [5]
					false, -- [6]
					"WorldState Score", -- [7]
				},
				["fontcolor_right"] = {
					1, -- [1]
					0.7, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["line_height"] = 17,
				["tooltip_max_targets"] = 2,
				["icon_size"] = {
					["W"] = 13,
					["H"] = 13,
				},
				["anchor_relative"] = "top",
				["anchored_to"] = 1,
				["show_amount"] = false,
				["submenu_wallpaper"] = true,
				["fontsize_title"] = 10,
				["commands"] = {
				},
				["fontface"] = "Friz Quadrata TT",
				["border_color"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["border_texture"] = "Details BarBorder 3",
				["menus_bg_texture"] = "Interface\\SPELLBOOK\\Spellbook-Page-1",
				["icon_border_texcoord"] = {
					["B"] = 0.921875,
					["L"] = 0.078125,
					["T"] = 0.078125,
					["R"] = 0.921875,
				},
				["fontsize"] = 10,
				["border_size"] = 14,
				["maximize_method"] = 1,
				["anchor_offset"] = {
					0, -- [1]
					0, -- [2]
				},
				["anchor_point"] = "bottom",
				["menus_bg_coords"] = {
					0.309777336120606, -- [1]
					0.924000015258789, -- [2]
					0.213000011444092, -- [3]
					0.279000015258789, -- [4]
				},
				["fontcolor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["menus_bg_color"] = {
					0.8, -- [1]
					0.8, -- [2]
					0.8, -- [3]
					0.2, -- [4]
				},
			},
			["ps_abbreviation"] = 3,
			["world_combat_is_trash"] = false,
			["pvp_as_group"] = true,
			["bookmark_text_size"] = 11,
			["animation_speed_mintravel"] = 0.45,
			["track_item_level"] = false,
			["fade_speed"] = 0.15,
			["death_tooltip_spark"] = false,
			["windows_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["instances_menu_click_to_open"] = false,
			["overall_clear_newchallenge"] = true,
			["use_self_color"] = false,
			["data_cleanup_logout"] = false,
			["instances_disable_bar_highlight"] = false,
			["profile_save_pos"] = true,
			["default_bg_alpha"] = 0.5,
			["trash_concatenate"] = false,
			["deny_score_messages"] = false,
			["disable_stretch_from_toolbar"] = false,
			["realtime_dps_meter"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["arena_enabled"] = true,
				["font_shadow"] = "NONE",
				["font_size"] = 18,
				["mythic_dungeon_enabled"] = false,
				["sample_size"] = 3,
				["frame_settings"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["point"] = "TOP",
					["scale"] = 1,
					["width"] = 300,
					["y"] = -110,
					["x"] = 0,
					["backdrop_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.2, -- [4]
					},
					["locked"] = true,
					["height"] = 23,
				},
				["update_interval"] = 0.3,
				["text_offset"] = 2,
				["font_face"] = "Friz Quadrata TT",
				["options_frame"] = {
				},
			},
			["animation_speed"] = 33,
			["animate_scroll"] = false,
			["standard_skin"] = false,
			["disable_lock_ungroup_buttons"] = false,
			["memory_ram"] = 64,
			["use_battleground_server_parser"] = false,
			["death_tooltip_width"] = 350,
			["disable_window_groups"] = false,
			["clear_ungrouped"] = true,
			["force_activity_time_pvp"] = true,
			["instances_suppress_trash"] = 0,
			["class_icons_small"] = "Interface\\AddOns\\Details\\images\\classes_small",
			["options_window"] = {
				["scale"] = 1,
			},
			["animation_speed_maxtravel"] = 3,
			["time_type_original"] = 2,
			["player_details_window"] = {
				["scale"] = 1,
				["bar_texture"] = "Skyline",
				["skin"] = "ElvUI",
			},
			["font_faces"] = {
				["menus"] = "Friz Quadrata TT",
			},
			["auto_swap_to_dynamic_overall"] = false,
			["instances"] = {
				{
					["__pos"] = {
						["normal"] = {
							["y"] = -190.3589782714844,
							["x"] = 284.4451904296875,
							["w"] = 310.0000305175781,
							["h"] = 158.0001068115234,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["show_statusbar"] = false,
					["menu_icons_size"] = 0.82,
					["titlebar_shown"] = false,
					["menu_anchor"] = {
						20, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.243,
					["fullborder_size"] = 0.5,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons_2_shadow",
					["skin_custom"] = "",
					["use_auto_align_multi_fontstrings"] = true,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["switch_all_roles_in_combat"] = false,
					["clickthrough_toolbaricons"] = false,
					["row_info"] = {
						["show_arena_role_icon"] = false,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = false,
						["textR_outline_small"] = true,
						["textL_outline_small"] = true,
						["textL_enable_custom_text"] = false,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["textL_offset"] = 0,
						["text_yoffset"] = 0,
						["texture_background_class_color"] = false,
						["start_after_icon"] = true,
						["font_face_file"] = "Interface\\Addons\\Details\\fonts\\Accidental Presidency.ttf",
						["faction_icon_size_offset"] = -10,
						["backdrop"] = {
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["size"] = 12,
							["enabled"] = false,
							["texture"] = "Details BarBorder 2",
						},
						["percent_type"] = 1,
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["texture_custom_file"] = "Interface\\",
						["textL_translit_text"] = false,
						["height"] = 21,
						["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_hyanda",
						["icon_size_offset"] = 0,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["overlay_color"] = {
							0.7, -- [1]
							0.7, -- [2]
							0.7, -- [3]
							0, -- [4]
						},
						["textR_outline"] = false,
						["arena_role_icon_size_offset"] = -10,
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
						["icon_grayscale"] = false,
						["textR_enable_custom_text"] = false,
						["textR_bracket"] = "(",
						["texture_custom"] = "",
						["texture_background"] = "Details D'ictum (reverse)",
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["textR_class_colors"] = false,
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "Details Hyanda",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar4_reverse",
						["overlay_texture"] = "Details D'ictum",
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.150228589773178, -- [4]
						},
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 1,
						},
						["textL_class_colors"] = false,
						["alpha"] = 1,
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["use_spec_icons"] = true,
						["font_face"] = "Accidental Presidency",
						["texture_class_colors"] = true,
						["show_faction_icon"] = true,
						["fast_ps_update"] = false,
						["textR_separator"] = "NONE",
						["font_size"] = 16,
					},
					["titlebar_texture"] = "Details Serenity",
					["switch_tank"] = false,
					["plugins_grow_direction"] = 1,
					["icon_desaturated"] = false,
					["switch_damager"] = false,
					["micro_displays_side"] = 2,
					["window_scale"] = 1,
					["hide_icon"] = false,
					["toolbar_side"] = 1,
					["fullborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["menu_icons_alpha"] = 0.92,
					["bg_b"] = 0.2588,
					["rowareaborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["color"] = {
						0.1215, -- [1]
						0.1176, -- [2]
						0.1294, -- [3]
						0.91, -- [4]
					},
					["hide_on_context"] = {
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [1]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [2]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [3]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [4]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [5]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [6]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [7]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [8]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [9]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [10]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [11]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [12]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [13]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [14]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [15]
					},
					["__was_opened"] = true,
					["use_multi_fontstrings"] = true,
					["skin"] = "Minimalistic",
					["fullborder_shown"] = false,
					["following"] = {
						["enabled"] = false,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["show_sidebars"] = false,
					["switch_healer"] = false,
					["fontstrings_text2_anchor"] = 73,
					["stretch_button_side"] = 1,
					["fontstrings_text_limit_offset"] = -10,
					["clickthrough_window"] = false,
					["menu_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						true, -- [5]
						false, -- [6]
						["space"] = -2,
						["shadow"] = false,
					},
					["rowareaborder_shown"] = false,
					["StatusBarSaved"] = {
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["textXMod"] = 0,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 3,
								["textStyle"] = 2,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textXMod"] = 0,
								["textAlign"] = 1,
								["textStyle"] = 2,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["textFace"] = "Accidental Presidency",
								["textXMod"] = 6,
								["textAlign"] = 2,
								["textStyle"] = 2,
								["timeType"] = 1,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
						},
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
					},
					["switch_healer_in_combat"] = false,
					["switch_tank_in_combat"] = false,
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["version"] = 3,
					["fontstrings_text4_anchor"] = 0,
					["__locked"] = false,
					["menu_alpha"] = {
						["enabled"] = false,
						["onenter"] = 1,
						["iconstoo"] = true,
						["ignorebars"] = false,
						["onleave"] = 1,
					},
					["backdrop_texture"] = "Details Ground",
					["bg_g"] = 0.2352,
					["ignore_mass_showhide"] = false,
					["rowareaborder_size"] = 0.5,
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
					},
					["micro_displays_locked"] = true,
					["hide_in_combat_alpha"] = 0,
					["desaturated_menu"] = false,
					["switch_damager_in_combat"] = false,
					["libwindow"] = {
						["y"] = -190.3590240478516,
						["x"] = 284.4451293945313,
						["point"] = "CENTER",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0.3777777777777,
						["overlay"] = {
							0.333333333333333, -- [1]
							0.333333333333333, -- [2]
							0.333333333333333, -- [3]
						},
					},
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["hide_in_combat_type"] = 1,
					["switch_all_roles_after_wipe"] = false,
					["bars_grow_direction"] = 1,
					["grab_on_top"] = false,
					["strata"] = "LOW",
					["attribute_text"] = {
						["enabled"] = true,
						["shadow"] = false,
						["side"] = 1,
						["text_size"] = 12,
						["custom_text"] = "{name}",
						["show_timer_arena"] = true,
						["text_face"] = "Accidental Presidency",
						["show_timer_always"] = true,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = {
							1.4, -- [1]
							2, -- [2]
						},
						["enable_custom_text"] = false,
						["show_timer"] = true,
						["show_timer_bg"] = true,
					},
					["auto_current"] = true,
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["clickthrough_rows"] = false,
					["bg_alpha"] = 0.6,
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = -190.3589782714844,
							["x"] = 284.4451904296875,
							["w"] = 310.0000305175781,
							["h"] = 158.0001068115234,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["bars_sort_direction"] = 1,
					["fontstrings_text3_anchor"] = 38,
					["wallpaper"] = {
						["enabled"] = false,
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["height"] = 114.042518615723,
						["anchor"] = "all",
						["level"] = 2,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["titlebar_height"] = 16,
					["bars_inverted"] = false,
					["menu_icons_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["titlebar_texture_color"] = {
						0.2, -- [1]
						0.2, -- [2]
						0.2, -- [3]
						0.8, -- [4]
					},
				}, -- [1]
			},
			["report_lines"] = 5,
			["segments_amount"] = 40,
			["overall_clear_pvp"] = true,
			["overall_clear_newboss"] = true,
			["capture_real"] = {
				["heal"] = true,
				["spellcast"] = true,
				["miscdata"] = true,
				["aura"] = true,
				["energy"] = true,
				["damage"] = true,
			},
			["skin"] = "Minimalistic",
			["override_spellids"] = true,
			["windows_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["realtimedps_always_arena"] = false,
			["minimum_combat_time"] = 5,
			["font_sizes"] = {
				["menus"] = 10,
			},
			["overall_clear_logout"] = false,
			["window_clamp"] = {
				-8, -- [1]
				0, -- [2]
				21, -- [3]
				-14, -- [4]
			},
			["cloud_capture"] = true,
			["damage_taken_everything"] = false,
			["scroll_speed"] = 2,
			["new_window_size"] = {
				["height"] = 158,
				["width"] = 310,
			},
			["memory_threshold"] = 3,
			["deadlog_events"] = 32,
			["default_bg_color"] = 0.0941,
			["close_shields"] = false,
			["class_coords"] = {
				["HUNTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["WARRIOR"] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["SHAMAN"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["MAGE"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["PET"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["DRUID"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["MONK"] = {
					0.25, -- [1]
					0.369140625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["DEATHKNIGHT"] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["MONSTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["ROGUE"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["UNKNOW"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["PRIEST"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["WARLOCK"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["Alliance"] = {
					0.248046875, -- [1]
					0.02968748, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["ENEMY"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["DEMONHUNTER"] = {
					0.36914063, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["Horde"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["PALADIN"] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["EVOKER"] = {
					0.50390625, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["UNGROUPPLAYER"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
			},
			["total_abbreviation"] = 2,
			["disable_alldisplays_window"] = false,
			["trash_auto_remove"] = false,
			["broadcaster_enabled"] = false,
			["hotcorner_topleft"] = {
				["hide"] = false,
			},
			["segments_auto_erase"] = 1,
			["clear_graphic"] = true,
			["class_colors"] = {
				["HUNTER"] = {
					0.67, -- [1]
					0.83, -- [2]
					0.45, -- [3]
				},
				["WARRIOR"] = {
					0.78, -- [1]
					0.61, -- [2]
					0.43, -- [3]
				},
				["PALADIN"] = {
					0.96, -- [1]
					0.55, -- [2]
					0.73, -- [3]
				},
				["MAGE"] = {
					0.41, -- [1]
					0.8, -- [2]
					0.94, -- [3]
				},
				["ARENA_YELLOW"] = {
					1, -- [1]
					1, -- [2]
					0.25, -- [3]
				},
				["UNGROUPPLAYER"] = {
					0.4, -- [1]
					0.4, -- [2]
					0.4, -- [3]
				},
				["DRUID"] = {
					1, -- [1]
					0.49, -- [2]
					0.04, -- [3]
				},
				["MONK"] = {
					0, -- [1]
					1, -- [2]
					0.59, -- [3]
				},
				["DEATHKNIGHT"] = {
					0.77, -- [1]
					0.12, -- [2]
					0.23, -- [3]
				},
				["SELF"] = {
					0.89019, -- [1]
					0.32156, -- [2]
					0.89019, -- [3]
				},
				["ARENA_GREEN"] = {
					0.686, -- [1]
					0.372, -- [2]
					0.905, -- [3]
				},
				["SHAMAN"] = {
					0, -- [1]
					0.44, -- [2]
					0.87, -- [3]
				},
				["UNKNOW"] = {
					0.2, -- [1]
					0.2, -- [2]
					0.2, -- [3]
				},
				["PRIEST"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
				},
				["PET"] = {
					0.3, -- [1]
					0.4, -- [2]
					0.5, -- [3]
				},
				["ENEMY"] = {
					0.94117, -- [1]
					0, -- [2]
					0.0196, -- [3]
					1, -- [4]
				},
				["WARLOCK"] = {
					0.58, -- [1]
					0.51, -- [2]
					0.79, -- [3]
				},
				["DEMONHUNTER"] = {
					0.64, -- [1]
					0.19, -- [2]
					0.79, -- [3]
				},
				["version"] = 1,
				["NEUTRAL"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
				},
				["EVOKER"] = {
					0.2, -- [1]
					0.5764, -- [2]
					0.498, -- [3]
				},
				["ROGUE"] = {
					1, -- [1]
					0.96, -- [2]
					0.41, -- [3]
				},
			},
			["animation_speed_triggertravel"] = 5,
			["options_group_edit"] = true,
			["segments_amount_to_save"] = 40,
			["minimap"] = {
				["onclick_what_todo"] = 1,
				["radius"] = 160,
				["text_type"] = 1,
				["minimapPos"] = 220,
				["text_format"] = 3,
				["hide"] = false,
			},
			["instances_amount"] = 5,
			["max_window_size"] = {
				["height"] = 450,
				["width"] = 480,
			},
			["chat_tab_embed"] = {
				["enabled"] = false,
				["y_offset"] = 0,
				["x_offset"] = 0,
				["tab_name"] = "",
				["single_window"] = false,
			},
			["only_pvp_frags"] = false,
			["disable_stretch_button"] = false,
			["color_by_arena_team"] = true,
			["use_scroll"] = false,
			["overall_flag"] = 16,
			["segments_panic_mode"] = false,
			["realtimedps_order_bars"] = false,
			["show_arena_role_icon"] = false,
			["row_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["numerical_system"] = 1,
			["time_type"] = 2,
			["update_speed"] = 0.2,
			["report_schema"] = 1,
			["numerical_system_symbols"] = "auto",
			["death_tooltip_texture"] = "Details Serenity",
			["disable_reset_button"] = false,
			["data_broker_text"] = "",
			["instances_no_libwindow"] = false,
			["instances_segments_locked"] = true,
			["deadlog_limit"] = 16,
			["death_log_colors"] = {
				["debuff"] = "purple",
				["buff"] = "silver",
				["friendlyfire"] = "darkorange",
				["heal"] = "green",
				["cooldown"] = "yellow",
				["damage"] = "red",
			},
		},
		["Skelay-Mal'Ganis"] = {
			["overall_clear_newtorghast"] = true,
			["use_realtimedps"] = false,
			["row_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["streamer_config"] = {
				["faster_updates"] = false,
				["quick_detection"] = false,
				["reset_spec_cache"] = false,
				["no_alerts"] = false,
				["use_animation_accel"] = true,
				["disable_mythic_dungeon"] = false,
			},
			["all_players_are_group"] = false,
			["use_row_animations"] = true,
			["report_heal_links"] = false,
			["remove_realm_from_name"] = true,
			["minimum_overall_combat_time"] = 10,
			["event_tracker"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["show_crowdcontrol_pvm"] = false,
				["line_color"] = {
					0.1, -- [1]
					0.1, -- [2]
					0.1, -- [3]
					0.3, -- [4]
				},
				["font_shadow"] = "NONE",
				["font_size"] = 10,
				["font_face"] = "Friz Quadrata TT",
				["line_height"] = 16,
				["show_crowdcontrol_pvp"] = true,
				["frame"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0.1921, -- [1]
						0.1921, -- [2]
						0.1921, -- [3]
						0.3869, -- [4]
					},
					["locked"] = false,
					["height"] = 300,
					["width"] = 250,
				},
				["line_texture"] = "Details Serenity",
				["options_frame"] = {
				},
			},
			["report_to_who"] = "",
			["class_specs_coords"] = {
				[62] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[1467] = {
					0.5, -- [1]
					0.625, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[63] = {
					0.375, -- [1]
					0.5, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[250] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[251] = {
					0.125, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[252] = {
					0.25, -- [1]
					0.375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[1468] = {
					0.625, -- [1]
					0.75, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[253] = {
					0.875, -- [1]
					1, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[254] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[255] = {
					0.125, -- [1]
					0.25, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[66] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[257] = {
					0.5, -- [1]
					0.625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[258] = {
					0.6328125, -- [1]
					0.75, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[259] = {
					0.125, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[260] = {
					0, -- [1]
					0.125, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[577] = {
					0.25, -- [1]
					0.375, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[262] = {
					0.125, -- [1]
					0.25, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[581] = {
					0.375, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[264] = {
					0.375, -- [1]
					0.5, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[265] = {
					0.5, -- [1]
					0.625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[266] = {
					0.625, -- [1]
					0.75, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[267] = {
					0.75, -- [1]
					0.875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[268] = {
					0.625, -- [1]
					0.75, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[269] = {
					0.875, -- [1]
					1, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[270] = {
					0.75, -- [1]
					0.875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[70] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[102] = {
					0.375, -- [1]
					0.5, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[71] = {
					0.875, -- [1]
					1, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[103] = {
					0.5, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[72] = {
					0, -- [1]
					0.125, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[104] = {
					0.625, -- [1]
					0.75, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[64] = {
					0.5, -- [1]
					0.625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[73] = {
					0.125, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[65] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[105] = {
					0.75, -- [1]
					0.875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[256] = {
					0.375, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[261] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[263] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[1473] = {
					0.75, -- [1]
					0.875, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
			},
			["all_in_one_windows"] = {
			},
			["tooltip"] = {
				["anchor_offset"] = {
					0, -- [1]
					0, -- [2]
				},
				["bar_color"] = {
					0.396, -- [1]
					0.396, -- [2]
					0.396, -- [3]
					0.87, -- [4]
				},
				["tooltip_max_pets"] = 2,
				["abbreviation"] = 2,
				["header_text_color"] = {
					1, -- [1]
					0.9176, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["background"] = {
					0.0941, -- [1]
					0.0941, -- [2]
					0.0941, -- [3]
					0.8, -- [4]
				},
				["divisor_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["fontshadow"] = false,
				["anchor_screen_pos"] = {
					507.7, -- [1]
					-350.5, -- [2]
				},
				["header_statusbar"] = {
					0.3, -- [1]
					0.3, -- [2]
					0.3, -- [3]
					0.8, -- [4]
					false, -- [5]
					false, -- [6]
					"WorldState Score", -- [7]
				},
				["fontcolor_right"] = {
					1, -- [1]
					0.7, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["line_height"] = 17,
				["tooltip_max_targets"] = 2,
				["icon_size"] = {
					["W"] = 17,
					["H"] = 17,
				},
				["anchor_relative"] = "top",
				["anchored_to"] = 1,
				["show_amount"] = false,
				["submenu_wallpaper"] = true,
				["fontsize_title"] = 10,
				["commands"] = {
				},
				["fontface"] = "Friz Quadrata TT",
				["border_color"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["border_texture"] = "Details BarBorder 3",
				["menus_bg_texture"] = "Interface\\SPELLBOOK\\Spellbook-Page-1",
				["icon_border_texcoord"] = {
					["B"] = 0.921875,
					["L"] = 0.078125,
					["T"] = 0.078125,
					["R"] = 0.921875,
				},
				["fontsize"] = 10,
				["border_size"] = 14,
				["maximize_method"] = 1,
				["tooltip_max_abilities"] = 6,
				["anchor_point"] = "bottom",
				["menus_bg_coords"] = {
					0.309777336120606, -- [1]
					0.924000015258789, -- [2]
					0.213000011444092, -- [3]
					0.279000015258789, -- [4]
				},
				["fontcolor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["menus_bg_color"] = {
					0.8, -- [1]
					0.8, -- [2]
					0.8, -- [3]
					0.2, -- [4]
				},
			},
			["ps_abbreviation"] = 3,
			["world_combat_is_trash"] = false,
			["pvp_as_group"] = true,
			["bookmark_text_size"] = 11,
			["animation_speed_mintravel"] = 0.45,
			["track_item_level"] = false,
			["fade_speed"] = 0.15,
			["death_tooltip_spark"] = false,
			["windows_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["instances_menu_click_to_open"] = false,
			["overall_clear_newchallenge"] = true,
			["use_self_color"] = false,
			["data_cleanup_logout"] = false,
			["instances_disable_bar_highlight"] = false,
			["profile_save_pos"] = true,
			["default_bg_alpha"] = 0.5,
			["trash_concatenate"] = false,
			["deny_score_messages"] = false,
			["disable_stretch_from_toolbar"] = false,
			["realtime_dps_meter"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["arena_enabled"] = true,
				["font_shadow"] = "NONE",
				["font_size"] = 18,
				["mythic_dungeon_enabled"] = false,
				["sample_size"] = 3,
				["frame_settings"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["point"] = "TOP",
					["scale"] = 1,
					["width"] = 300,
					["y"] = -110,
					["x"] = 0,
					["backdrop_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.2, -- [4]
					},
					["locked"] = true,
					["height"] = 23,
				},
				["update_interval"] = 0.3,
				["text_offset"] = 2,
				["font_face"] = "Friz Quadrata TT",
				["options_frame"] = {
				},
			},
			["animation_speed"] = 33,
			["animate_scroll"] = false,
			["standard_skin"] = false,
			["disable_lock_ungroup_buttons"] = false,
			["memory_ram"] = 64,
			["use_battleground_server_parser"] = false,
			["death_tooltip_width"] = 350,
			["disable_window_groups"] = false,
			["clear_ungrouped"] = true,
			["force_activity_time_pvp"] = true,
			["instances_suppress_trash"] = 0,
			["class_icons_small"] = "Interface\\AddOns\\Details\\images\\classes_small",
			["options_window"] = {
				["scale"] = 1,
			},
			["animation_speed_maxtravel"] = 3,
			["time_type_original"] = 2,
			["player_details_window"] = {
				["scale"] = 1,
				["bar_texture"] = "Skyline",
				["skin"] = "ElvUI",
			},
			["font_faces"] = {
				["menus"] = "Friz Quadrata TT",
			},
			["auto_swap_to_dynamic_overall"] = false,
			["instances"] = {
				{
					["__pos"] = {
						["normal"] = {
							["y"] = -511.769172668457,
							["x"] = 596.7864990234375,
							["w"] = 280.4614868164063,
							["h"] = 158.0001068115234,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["show_statusbar"] = false,
					["menu_icons_size"] = 0.82,
					["titlebar_shown"] = false,
					["menu_anchor"] = {
						20, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.243,
					["fullborder_size"] = 0.5,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons_2_shadow",
					["skin_custom"] = "",
					["use_auto_align_multi_fontstrings"] = true,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["switch_all_roles_in_combat"] = false,
					["clickthrough_toolbaricons"] = false,
					["row_info"] = {
						["show_arena_role_icon"] = false,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = false,
						["textR_outline_small"] = true,
						["textL_outline_small"] = true,
						["textL_enable_custom_text"] = false,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["textL_offset"] = 0,
						["text_yoffset"] = 0,
						["texture_background_class_color"] = false,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["font_face_file"] = "Interface\\Addons\\Details\\fonts\\Accidental Presidency.ttf",
						["faction_icon_size_offset"] = -10,
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["height"] = 21,
						["font_size"] = 16,
						["backdrop"] = {
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["size"] = 12,
							["enabled"] = false,
							["texture"] = "Details BarBorder 2",
						},
						["start_after_icon"] = true,
						["textL_translit_text"] = false,
						["texture_custom_file"] = "Interface\\",
						["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_hyanda",
						["icon_size_offset"] = 0,
						["percent_type"] = 1,
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["overlay_color"] = {
							0.7, -- [1]
							0.7, -- [2]
							0.7, -- [3]
							0, -- [4]
						},
						["textR_bracket"] = "(",
						["texture_custom"] = "",
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
						["icon_grayscale"] = false,
						["textR_outline"] = false,
						["use_spec_icons"] = true,
						["textR_enable_custom_text"] = false,
						["textL_class_colors"] = false,
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["texture_background"] = "Details D'ictum (reverse)",
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "Details Hyanda",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar4_reverse",
						["overlay_texture"] = "Details D'ictum",
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.150228589773178, -- [4]
						},
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 1,
						},
						["textR_class_colors"] = false,
						["alpha"] = 1,
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["arena_role_icon_size_offset"] = -10,
						["font_face"] = "Accidental Presidency",
						["texture_class_colors"] = true,
						["show_faction_icon"] = true,
						["fast_ps_update"] = false,
						["textR_separator"] = "NONE",
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
					},
					["titlebar_texture"] = "Details Serenity",
					["switch_tank"] = false,
					["plugins_grow_direction"] = 1,
					["icon_desaturated"] = false,
					["switch_damager"] = false,
					["micro_displays_side"] = 2,
					["window_scale"] = 1,
					["hide_icon"] = false,
					["toolbar_side"] = 1,
					["fullborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["menu_icons_alpha"] = 0.92,
					["bg_b"] = 0.2588,
					["switch_healer_in_combat"] = false,
					["color"] = {
						0.1215, -- [1]
						0.1176, -- [2]
						0.1294, -- [3]
						0.91, -- [4]
					},
					["hide_on_context"] = {
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [1]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [2]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [3]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [4]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [5]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [6]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [7]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [8]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [9]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [10]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [11]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [12]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [13]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [14]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [15]
					},
					["rowareaborder_shown"] = false,
					["switch_tank_in_combat"] = false,
					["skin"] = "Minimalistic",
					["__was_opened"] = true,
					["following"] = {
						["enabled"] = false,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["show_sidebars"] = false,
					["switch_healer"] = false,
					["fontstrings_text2_anchor"] = 73,
					["fontstrings_text3_anchor"] = 38,
					["stretch_button_side"] = 1,
					["use_multi_fontstrings"] = true,
					["bars_grow_direction"] = 1,
					["bars_inverted"] = false,
					["StatusBarSaved"] = {
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["textXMod"] = 0,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 3,
								["textStyle"] = 2,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textXMod"] = 0,
								["textAlign"] = 1,
								["textStyle"] = 2,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["textFace"] = "Accidental Presidency",
								["textXMod"] = 6,
								["textAlign"] = 2,
								["textStyle"] = 2,
								["timeType"] = 1,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
						},
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
					},
					["menu_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						true, -- [5]
						false, -- [6]
						["space"] = -2,
						["shadow"] = false,
					},
					["switch_damager_in_combat"] = false,
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["version"] = 3,
					["fontstrings_text4_anchor"] = 0,
					["__locked"] = false,
					["menu_alpha"] = {
						["enabled"] = false,
						["onenter"] = 1,
						["iconstoo"] = true,
						["ignorebars"] = false,
						["onleave"] = 1,
					},
					["clickthrough_rows"] = false,
					["bg_g"] = 0.2352,
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["rowareaborder_size"] = 0.5,
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
					},
					["desaturated_menu"] = false,
					["hide_in_combat_alpha"] = 0,
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["micro_displays_locked"] = true,
					["libwindow"] = {
						["y"] = 0,
						["x"] = -313.2392578125,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0.3777777777777,
						["overlay"] = {
							0.333333333333333, -- [1]
							0.333333333333333, -- [2]
							0.333333333333333, -- [3]
						},
					},
					["switch_all_roles_after_wipe"] = false,
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["hide_in_combat_type"] = 1,
					["rowareaborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["strata"] = "LOW",
					["grab_on_top"] = false,
					["attribute_text"] = {
						["enabled"] = true,
						["shadow"] = false,
						["side"] = 1,
						["text_size"] = 12,
						["custom_text"] = "{name}",
						["show_timer_arena"] = true,
						["text_face"] = "Accidental Presidency",
						["show_timer_always"] = true,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = {
							1.4, -- [1]
							2, -- [2]
						},
						["enable_custom_text"] = false,
						["show_timer"] = true,
						["show_timer_bg"] = true,
					},
					["ignore_mass_showhide"] = false,
					["auto_current"] = true,
					["bars_sort_direction"] = 1,
					["bg_alpha"] = 0.6,
					["fullborder_shown"] = false,
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = -511.769172668457,
							["x"] = 596.7864990234375,
							["w"] = 280.4614868164063,
							["h"] = 158.0001068115234,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["clickthrough_window"] = false,
					["fontstrings_text_limit_offset"] = -10,
					["wallpaper"] = {
						["enabled"] = false,
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["height"] = 114.042518615723,
						["anchor"] = "all",
						["level"] = 2,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["titlebar_height"] = 16,
					["backdrop_texture"] = "Details Ground",
					["menu_icons_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["titlebar_texture_color"] = {
						0.2, -- [1]
						0.2, -- [2]
						0.2, -- [3]
						0.8, -- [4]
					},
				}, -- [1]
			},
			["report_lines"] = 5,
			["segments_amount"] = 40,
			["overall_clear_pvp"] = true,
			["overall_clear_newboss"] = true,
			["capture_real"] = {
				["heal"] = true,
				["spellcast"] = true,
				["miscdata"] = true,
				["aura"] = true,
				["energy"] = true,
				["damage"] = true,
			},
			["skin"] = "Minimalistic",
			["override_spellids"] = true,
			["windows_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["realtimedps_always_arena"] = false,
			["minimum_combat_time"] = 5,
			["font_sizes"] = {
				["menus"] = 10,
			},
			["overall_clear_logout"] = false,
			["window_clamp"] = {
				-8, -- [1]
				0, -- [2]
				21, -- [3]
				-14, -- [4]
			},
			["cloud_capture"] = true,
			["damage_taken_everything"] = false,
			["scroll_speed"] = 2,
			["new_window_size"] = {
				["height"] = 158,
				["width"] = 310,
			},
			["memory_threshold"] = 3,
			["deadlog_events"] = 32,
			["default_bg_color"] = 0.0941,
			["close_shields"] = false,
			["class_coords"] = {
				["HUNTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["WARRIOR"] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["PALADIN"] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["MAGE"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["PET"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["DRUID"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["MONK"] = {
					0.25, -- [1]
					0.369140625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["DEATHKNIGHT"] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["ROGUE"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["SHAMAN"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["UNKNOW"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["PRIEST"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["MONSTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["Alliance"] = {
					0.248046875, -- [1]
					0.02968748, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["WARLOCK"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["DEMONHUNTER"] = {
					0.36914063, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["Horde"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["UNGROUPPLAYER"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["EVOKER"] = {
					0.50390625, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["ENEMY"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
			},
			["total_abbreviation"] = 2,
			["disable_alldisplays_window"] = false,
			["trash_auto_remove"] = false,
			["broadcaster_enabled"] = false,
			["hotcorner_topleft"] = {
				["hide"] = false,
			},
			["segments_auto_erase"] = 1,
			["clear_graphic"] = true,
			["class_colors"] = {
				["HUNTER"] = {
					0.67, -- [1]
					0.83, -- [2]
					0.45, -- [3]
				},
				["WARRIOR"] = {
					0.78, -- [1]
					0.61, -- [2]
					0.43, -- [3]
				},
				["SHAMAN"] = {
					0, -- [1]
					0.44, -- [2]
					0.87, -- [3]
				},
				["MAGE"] = {
					0.41, -- [1]
					0.8, -- [2]
					0.94, -- [3]
				},
				["ARENA_YELLOW"] = {
					1, -- [1]
					1, -- [2]
					0.25, -- [3]
				},
				["UNGROUPPLAYER"] = {
					0.4, -- [1]
					0.4, -- [2]
					0.4, -- [3]
				},
				["DRUID"] = {
					1, -- [1]
					0.49, -- [2]
					0.04, -- [3]
				},
				["MONK"] = {
					0, -- [1]
					1, -- [2]
					0.59, -- [3]
				},
				["DEATHKNIGHT"] = {
					0.77, -- [1]
					0.12, -- [2]
					0.23, -- [3]
				},
				["SELF"] = {
					0.89019, -- [1]
					0.32156, -- [2]
					0.89019, -- [3]
				},
				["PET"] = {
					0.3, -- [1]
					0.4, -- [2]
					0.5, -- [3]
				},
				["PALADIN"] = {
					0.96, -- [1]
					0.55, -- [2]
					0.73, -- [3]
				},
				["UNKNOW"] = {
					0.2, -- [1]
					0.2, -- [2]
					0.2, -- [3]
				},
				["PRIEST"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
				},
				["ARENA_GREEN"] = {
					0.686, -- [1]
					0.372, -- [2]
					0.905, -- [3]
				},
				["ENEMY"] = {
					0.94117, -- [1]
					0, -- [2]
					0.0196, -- [3]
					1, -- [4]
				},
				["version"] = 1,
				["DEMONHUNTER"] = {
					0.64, -- [1]
					0.19, -- [2]
					0.79, -- [3]
				},
				["WARLOCK"] = {
					0.58, -- [1]
					0.51, -- [2]
					0.79, -- [3]
				},
				["NEUTRAL"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
				},
				["EVOKER"] = {
					0.2, -- [1]
					0.5764, -- [2]
					0.498, -- [3]
				},
				["ROGUE"] = {
					1, -- [1]
					0.96, -- [2]
					0.41, -- [3]
				},
			},
			["animation_speed_triggertravel"] = 5,
			["options_group_edit"] = true,
			["segments_amount_to_save"] = 40,
			["minimap"] = {
				["onclick_what_todo"] = 1,
				["radius"] = 160,
				["text_type"] = 1,
				["minimapPos"] = 65.73913056334577,
				["text_format"] = 3,
				["hide"] = false,
			},
			["instances_amount"] = 5,
			["max_window_size"] = {
				["height"] = 450,
				["width"] = 480,
			},
			["chat_tab_embed"] = {
				["enabled"] = false,
				["y_offset"] = 0,
				["x_offset"] = 0,
				["tab_name"] = "",
				["single_window"] = false,
			},
			["only_pvp_frags"] = false,
			["disable_stretch_button"] = false,
			["color_by_arena_team"] = true,
			["use_scroll"] = false,
			["overall_flag"] = 16,
			["segments_panic_mode"] = false,
			["realtimedps_order_bars"] = false,
			["show_arena_role_icon"] = false,
			["row_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["numerical_system"] = 1,
			["time_type"] = 2,
			["update_speed"] = 0.2,
			["report_schema"] = 1,
			["numerical_system_symbols"] = "auto",
			["death_tooltip_texture"] = "Details Serenity",
			["disable_reset_button"] = false,
			["data_broker_text"] = "",
			["instances_no_libwindow"] = false,
			["instances_segments_locked"] = true,
			["deadlog_limit"] = 16,
			["death_log_colors"] = {
				["debuff"] = "purple",
				["buff"] = "silver",
				["friendlyfire"] = "darkorange",
				["heal"] = "green",
				["cooldown"] = "yellow",
				["damage"] = "red",
			},
		},
		["Ryanmage-Mal'Ganis"] = {
			["overall_clear_newtorghast"] = true,
			["use_realtimedps"] = false,
			["row_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["streamer_config"] = {
				["faster_updates"] = false,
				["quick_detection"] = false,
				["reset_spec_cache"] = false,
				["no_alerts"] = false,
				["use_animation_accel"] = true,
				["disable_mythic_dungeon"] = false,
			},
			["all_players_are_group"] = false,
			["use_row_animations"] = true,
			["report_heal_links"] = false,
			["remove_realm_from_name"] = true,
			["minimum_overall_combat_time"] = 10,
			["event_tracker"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["show_crowdcontrol_pvm"] = false,
				["line_color"] = {
					0.1, -- [1]
					0.1, -- [2]
					0.1, -- [3]
					0.3, -- [4]
				},
				["font_shadow"] = "NONE",
				["font_size"] = 10,
				["font_face"] = "Friz Quadrata TT",
				["line_height"] = 16,
				["show_crowdcontrol_pvp"] = true,
				["frame"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0.1921, -- [1]
						0.1921, -- [2]
						0.1921, -- [3]
						0.3869, -- [4]
					},
					["locked"] = false,
					["height"] = 300,
					["width"] = 250,
				},
				["line_texture"] = "Details Serenity",
				["options_frame"] = {
				},
			},
			["report_to_who"] = "",
			["class_specs_coords"] = {
				[62] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[1467] = {
					0.5, -- [1]
					0.625, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[63] = {
					0.375, -- [1]
					0.5, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[250] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[251] = {
					0.125, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[252] = {
					0.25, -- [1]
					0.375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[1468] = {
					0.625, -- [1]
					0.75, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[253] = {
					0.875, -- [1]
					1, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[254] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[255] = {
					0.125, -- [1]
					0.25, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[66] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[257] = {
					0.5, -- [1]
					0.625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[258] = {
					0.6328125, -- [1]
					0.75, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[259] = {
					0.125, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[260] = {
					0, -- [1]
					0.125, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[577] = {
					0.25, -- [1]
					0.375, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[262] = {
					0.125, -- [1]
					0.25, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[581] = {
					0.375, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[264] = {
					0.375, -- [1]
					0.5, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[265] = {
					0.5, -- [1]
					0.625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[266] = {
					0.625, -- [1]
					0.75, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[267] = {
					0.75, -- [1]
					0.875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[268] = {
					0.625, -- [1]
					0.75, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[269] = {
					0.875, -- [1]
					1, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[270] = {
					0.75, -- [1]
					0.875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[70] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[102] = {
					0.375, -- [1]
					0.5, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[71] = {
					0.875, -- [1]
					1, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[103] = {
					0.5, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[72] = {
					0, -- [1]
					0.125, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[104] = {
					0.625, -- [1]
					0.75, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[1473] = {
					0.75, -- [1]
					0.875, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[73] = {
					0.125, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[263] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[105] = {
					0.75, -- [1]
					0.875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[261] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[256] = {
					0.375, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[65] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[64] = {
					0.5, -- [1]
					0.625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
			},
			["all_in_one_windows"] = {
			},
			["tooltip"] = {
				["anchor_offset"] = {
					0, -- [1]
					0, -- [2]
				},
				["bar_color"] = {
					0.396, -- [1]
					0.396, -- [2]
					0.396, -- [3]
					0.87, -- [4]
				},
				["tooltip_max_pets"] = 2,
				["abbreviation"] = 2,
				["header_text_color"] = {
					1, -- [1]
					0.9176, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["background"] = {
					0.0941, -- [1]
					0.0941, -- [2]
					0.0941, -- [3]
					0.8, -- [4]
				},
				["divisor_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["fontshadow"] = false,
				["anchor_screen_pos"] = {
					507.7, -- [1]
					-350.5, -- [2]
				},
				["header_statusbar"] = {
					0.3, -- [1]
					0.3, -- [2]
					0.3, -- [3]
					0.8, -- [4]
					false, -- [5]
					false, -- [6]
					"WorldState Score", -- [7]
				},
				["fontcolor_right"] = {
					1, -- [1]
					0.7, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["line_height"] = 17,
				["tooltip_max_targets"] = 2,
				["icon_size"] = {
					["W"] = 13,
					["H"] = 13,
				},
				["anchor_relative"] = "top",
				["anchored_to"] = 1,
				["show_amount"] = false,
				["submenu_wallpaper"] = true,
				["fontsize_title"] = 10,
				["commands"] = {
				},
				["fontface"] = "Friz Quadrata TT",
				["border_color"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["border_texture"] = "Details BarBorder 3",
				["menus_bg_texture"] = "Interface\\SPELLBOOK\\Spellbook-Page-1",
				["icon_border_texcoord"] = {
					["B"] = 0.921875,
					["L"] = 0.078125,
					["T"] = 0.078125,
					["R"] = 0.921875,
				},
				["fontsize"] = 10,
				["border_size"] = 14,
				["maximize_method"] = 1,
				["tooltip_max_abilities"] = 6,
				["anchor_point"] = "bottom",
				["menus_bg_coords"] = {
					0.309777336120606, -- [1]
					0.924000015258789, -- [2]
					0.213000011444092, -- [3]
					0.279000015258789, -- [4]
				},
				["fontcolor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["menus_bg_color"] = {
					0.8, -- [1]
					0.8, -- [2]
					0.8, -- [3]
					0.2, -- [4]
				},
			},
			["ps_abbreviation"] = 3,
			["world_combat_is_trash"] = false,
			["pvp_as_group"] = true,
			["bookmark_text_size"] = 11,
			["animation_speed_mintravel"] = 0.45,
			["track_item_level"] = false,
			["fade_speed"] = 0.15,
			["death_tooltip_spark"] = false,
			["windows_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["instances_menu_click_to_open"] = false,
			["overall_clear_newchallenge"] = true,
			["use_self_color"] = false,
			["data_cleanup_logout"] = false,
			["instances_disable_bar_highlight"] = false,
			["profile_save_pos"] = true,
			["default_bg_alpha"] = 0.5,
			["trash_concatenate"] = false,
			["deny_score_messages"] = false,
			["standard_skin"] = false,
			["disable_lock_ungroup_buttons"] = false,
			["animation_speed"] = 33,
			["animate_scroll"] = false,
			["disable_stretch_from_toolbar"] = false,
			["realtime_dps_meter"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["arena_enabled"] = true,
				["font_shadow"] = "NONE",
				["font_size"] = 18,
				["mythic_dungeon_enabled"] = false,
				["sample_size"] = 3,
				["frame_settings"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["point"] = "TOP",
					["scale"] = 1,
					["width"] = 300,
					["y"] = -110,
					["x"] = 0,
					["backdrop_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.2, -- [4]
					},
					["locked"] = true,
					["height"] = 23,
				},
				["update_interval"] = 0.3,
				["text_offset"] = 2,
				["font_face"] = "Friz Quadrata TT",
				["options_frame"] = {
				},
			},
			["memory_ram"] = 64,
			["use_battleground_server_parser"] = false,
			["death_tooltip_width"] = 350,
			["disable_window_groups"] = false,
			["clear_ungrouped"] = true,
			["force_activity_time_pvp"] = true,
			["instances_suppress_trash"] = 0,
			["class_icons_small"] = "Interface\\AddOns\\Details\\images\\classes_small",
			["options_window"] = {
				["scale"] = 1,
			},
			["animation_speed_maxtravel"] = 3,
			["time_type_original"] = 2,
			["player_details_window"] = {
				["scale"] = 1,
				["bar_texture"] = "Skyline",
				["skin"] = "ElvUI",
			},
			["font_faces"] = {
				["menus"] = "Friz Quadrata TT",
			},
			["auto_swap_to_dynamic_overall"] = false,
			["segments_amount"] = 40,
			["report_lines"] = 5,
			["instances"] = {
				{
					["__pos"] = {
						["normal"] = {
							["y"] = -510.1281585693359,
							["x"] = 558.495849609375,
							["w"] = 225.7607879638672,
							["h"] = 154.7180938720703,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["hide_in_combat_type"] = 1,
					["menu_icons_size"] = 0.82,
					["titlebar_shown"] = false,
					["menu_anchor"] = {
						20, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.243,
					["fullborder_size"] = 0.5,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons_2_shadow",
					["skin_custom"] = "",
					["use_auto_align_multi_fontstrings"] = true,
					["rowareaborder_shown"] = false,
					["fullborder_shown"] = false,
					["clickthrough_toolbaricons"] = false,
					["clickthrough_rows"] = false,
					["titlebar_texture"] = "Details Serenity",
					["ignore_mass_showhide"] = false,
					["switch_all_roles_after_wipe"] = false,
					["icon_desaturated"] = false,
					["switch_damager"] = false,
					["micro_displays_side"] = 2,
					["window_scale"] = 1,
					["hide_icon"] = false,
					["toolbar_side"] = 1,
					["bg_g"] = 0.2352,
					["menu_icons_alpha"] = 0.92,
					["bg_b"] = 0.2588,
					["switch_healer_in_combat"] = false,
					["color"] = {
						0.1215, -- [1]
						0.1176, -- [2]
						0.1294, -- [3]
						0.91, -- [4]
					},
					["hide_on_context"] = {
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [1]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [2]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [3]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [4]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [5]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [6]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [7]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [8]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [9]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [10]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [11]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [12]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [13]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [14]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [15]
					},
					["rowareaborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["menu_icons_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["skin"] = "Minimalistic",
					["show_sidebars"] = false,
					["following"] = {
						["enabled"] = false,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["attribute_text"] = {
						["enabled"] = true,
						["shadow"] = false,
						["side"] = 1,
						["text_size"] = 12,
						["custom_text"] = "{name}",
						["show_timer_arena"] = true,
						["text_face"] = "Accidental Presidency",
						["show_timer_always"] = true,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = {
							1.4, -- [1]
							2, -- [2]
						},
						["enable_custom_text"] = false,
						["show_timer"] = true,
						["show_timer_bg"] = true,
					},
					["switch_healer"] = false,
					["fontstrings_text2_anchor"] = 73,
					["stretch_button_side"] = 1,
					["menu_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						true, -- [5]
						false, -- [6]
						["space"] = -2,
						["shadow"] = false,
					},
					["row_info"] = {
						["textR_outline"] = false,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = false,
						["textR_outline_small"] = true,
						["textL_outline_small"] = true,
						["textL_enable_custom_text"] = false,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["textL_offset"] = 0,
						["text_yoffset"] = 0,
						["texture_background_class_color"] = false,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["font_face_file"] = "Interface\\Addons\\Details\\fonts\\Accidental Presidency.ttf",
						["faction_icon_size_offset"] = -10,
						["backdrop"] = {
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["size"] = 12,
							["enabled"] = false,
							["texture"] = "Details BarBorder 2",
						},
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
						["show_faction_icon"] = true,
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["textL_translit_text"] = false,
						["height"] = 21,
						["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_hyanda",
						["icon_size_offset"] = 0,
						["percent_type"] = 1,
						["start_after_icon"] = true,
						["overlay_color"] = {
							0.7, -- [1]
							0.7, -- [2]
							0.7, -- [3]
							0, -- [4]
						},
						["texture_custom_file"] = "Interface\\",
						["arena_role_icon_size_offset"] = -10,
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
						["icon_grayscale"] = false,
						["texture_custom"] = "",
						["use_spec_icons"] = true,
						["textR_enable_custom_text"] = false,
						["textR_class_colors"] = false,
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["textL_class_colors"] = false,
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "Details Hyanda",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar4_reverse",
						["overlay_texture"] = "Details D'ictum",
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.150228589773178, -- [4]
						},
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 1,
						},
						["texture_background"] = "Details D'ictum (reverse)",
						["alpha"] = 1,
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["textR_bracket"] = "(",
						["font_face"] = "Accidental Presidency",
						["texture_class_colors"] = true,
						["show_arena_role_icon"] = false,
						["fast_ps_update"] = false,
						["textR_separator"] = "NONE",
						["font_size"] = 16,
					},
					["bars_inverted"] = false,
					["bars_sort_direction"] = 1,
					["StatusBarSaved"] = {
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["textYMod"] = 1,
								["textXMod"] = 0,
								["textFace"] = "Accidental Presidency",
								["textStyle"] = 2,
								["textAlign"] = 3,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["textYMod"] = 1,
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textXMod"] = 0,
								["textStyle"] = 2,
								["textAlign"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["textYMod"] = 1,
								["textXMod"] = 6,
								["textFace"] = "Accidental Presidency",
								["timeType"] = 1,
								["textStyle"] = 2,
								["textAlign"] = 2,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
						},
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
					},
					["fontstrings_text3_anchor"] = 38,
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["switch_tank_in_combat"] = false,
					["version"] = 3,
					["fontstrings_text4_anchor"] = 0,
					["__locked"] = false,
					["menu_alpha"] = {
						["enabled"] = false,
						["onenter"] = 1,
						["iconstoo"] = true,
						["ignorebars"] = false,
						["onleave"] = 1,
					},
					["clickthrough_window"] = false,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["rowareaborder_size"] = 0.5,
					["strata"] = "LOW",
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
					},
					["switch_all_roles_in_combat"] = false,
					["hide_in_combat_alpha"] = 0,
					["micro_displays_locked"] = true,
					["grab_on_top"] = false,
					["libwindow"] = {
						["y"] = 3.282021760940552,
						["x"] = -378.8802490234375,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0.3777777777777,
						["overlay"] = {
							0.333333333333333, -- [1]
							0.333333333333333, -- [2]
							0.333333333333333, -- [3]
						},
					},
					["bg_alpha"] = 0.6,
					["bars_grow_direction"] = 1,
					["switch_tank"] = false,
					["backdrop_texture"] = "Details Ground",
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["switch_damager_in_combat"] = false,
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["show_statusbar"] = false,
					["auto_current"] = true,
					["fullborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["plugins_grow_direction"] = 1,
					["desaturated_menu"] = false,
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = -510.1281585693359,
							["x"] = 558.495849609375,
							["w"] = 225.7607879638672,
							["h"] = 154.7180938720703,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["__was_opened"] = true,
					["wallpaper"] = {
						["enabled"] = false,
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["height"] = 114.042518615723,
						["anchor"] = "all",
						["level"] = 2,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["titlebar_height"] = 16,
					["fontstrings_text_limit_offset"] = -10,
					["use_multi_fontstrings"] = true,
					["titlebar_texture_color"] = {
						0.2, -- [1]
						0.2, -- [2]
						0.2, -- [3]
						0.8, -- [4]
					},
				}, -- [1]
			},
			["overall_clear_pvp"] = true,
			["overall_clear_newboss"] = true,
			["capture_real"] = {
				["heal"] = true,
				["spellcast"] = true,
				["miscdata"] = true,
				["aura"] = true,
				["energy"] = true,
				["damage"] = true,
			},
			["skin"] = "Minimalistic",
			["override_spellids"] = true,
			["windows_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["minimum_combat_time"] = 5,
			["realtimedps_always_arena"] = false,
			["font_sizes"] = {
				["menus"] = 10,
			},
			["overall_clear_logout"] = false,
			["new_window_size"] = {
				["height"] = 158,
				["width"] = 310,
			},
			["cloud_capture"] = true,
			["damage_taken_everything"] = false,
			["scroll_speed"] = 2,
			["window_clamp"] = {
				-8, -- [1]
				0, -- [2]
				21, -- [3]
				-14, -- [4]
			},
			["chat_tab_embed"] = {
				["enabled"] = false,
				["y_offset"] = 0,
				["x_offset"] = 0,
				["tab_name"] = "",
				["single_window"] = false,
			},
			["deadlog_events"] = 32,
			["default_bg_color"] = 0.0941,
			["close_shields"] = false,
			["class_coords"] = {
				["HUNTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["WARRIOR"] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["SHAMAN"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["MAGE"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["PET"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["DRUID"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["MONK"] = {
					0.25, -- [1]
					0.369140625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["DEATHKNIGHT"] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["ROGUE"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["UNGROUPPLAYER"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["UNKNOW"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["PRIEST"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["MONSTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["Alliance"] = {
					0.248046875, -- [1]
					0.02968748, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["ENEMY"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["DEMONHUNTER"] = {
					0.36914063, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["Horde"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["WARLOCK"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["EVOKER"] = {
					0.50390625, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["PALADIN"] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
			},
			["hotcorner_topleft"] = {
				["hide"] = false,
			},
			["disable_alldisplays_window"] = false,
			["class_colors"] = {
				["HUNTER"] = {
					0.67, -- [1]
					0.83, -- [2]
					0.45, -- [3]
				},
				["WARRIOR"] = {
					0.78, -- [1]
					0.61, -- [2]
					0.43, -- [3]
				},
				["ROGUE"] = {
					1, -- [1]
					0.96, -- [2]
					0.41, -- [3]
				},
				["MAGE"] = {
					0.41, -- [1]
					0.8, -- [2]
					0.94, -- [3]
				},
				["ARENA_YELLOW"] = {
					1, -- [1]
					1, -- [2]
					0.25, -- [3]
				},
				["UNGROUPPLAYER"] = {
					0.4, -- [1]
					0.4, -- [2]
					0.4, -- [3]
				},
				["DRUID"] = {
					1, -- [1]
					0.49, -- [2]
					0.04, -- [3]
				},
				["MONK"] = {
					0, -- [1]
					1, -- [2]
					0.59, -- [3]
				},
				["DEATHKNIGHT"] = {
					0.77, -- [1]
					0.12, -- [2]
					0.23, -- [3]
				},
				["SELF"] = {
					0.89019, -- [1]
					0.32156, -- [2]
					0.89019, -- [3]
				},
				["PET"] = {
					0.3, -- [1]
					0.4, -- [2]
					0.5, -- [3]
				},
				["SHAMAN"] = {
					0, -- [1]
					0.44, -- [2]
					0.87, -- [3]
				},
				["UNKNOW"] = {
					0.2, -- [1]
					0.2, -- [2]
					0.2, -- [3]
				},
				["PRIEST"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
				},
				["ARENA_GREEN"] = {
					0.686, -- [1]
					0.372, -- [2]
					0.905, -- [3]
				},
				["ENEMY"] = {
					0.94117, -- [1]
					0, -- [2]
					0.0196, -- [3]
					1, -- [4]
				},
				["WARLOCK"] = {
					0.58, -- [1]
					0.51, -- [2]
					0.79, -- [3]
				},
				["DEMONHUNTER"] = {
					0.64, -- [1]
					0.19, -- [2]
					0.79, -- [3]
				},
				["version"] = 1,
				["NEUTRAL"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
				},
				["EVOKER"] = {
					0.2, -- [1]
					0.5764, -- [2]
					0.498, -- [3]
				},
				["PALADIN"] = {
					0.96, -- [1]
					0.55, -- [2]
					0.73, -- [3]
				},
			},
			["broadcaster_enabled"] = false,
			["total_abbreviation"] = 2,
			["segments_auto_erase"] = 1,
			["clear_graphic"] = true,
			["trash_auto_remove"] = false,
			["animation_speed_triggertravel"] = 5,
			["options_group_edit"] = true,
			["segments_amount_to_save"] = 40,
			["minimap"] = {
				["onclick_what_todo"] = 1,
				["radius"] = 160,
				["text_type"] = 1,
				["minimapPos"] = 220,
				["text_format"] = 3,
				["hide"] = false,
			},
			["instances_amount"] = 5,
			["max_window_size"] = {
				["height"] = 450,
				["width"] = 480,
			},
			["memory_threshold"] = 3,
			["only_pvp_frags"] = false,
			["disable_stretch_button"] = false,
			["color_by_arena_team"] = true,
			["use_scroll"] = false,
			["overall_flag"] = 16,
			["segments_panic_mode"] = false,
			["realtimedps_order_bars"] = false,
			["show_arena_role_icon"] = false,
			["row_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["numerical_system"] = 1,
			["time_type"] = 2,
			["update_speed"] = 0.2,
			["report_schema"] = 1,
			["numerical_system_symbols"] = "auto",
			["death_tooltip_texture"] = "Details Serenity",
			["disable_reset_button"] = false,
			["data_broker_text"] = "",
			["instances_no_libwindow"] = false,
			["instances_segments_locked"] = true,
			["deadlog_limit"] = 16,
			["death_log_colors"] = {
				["debuff"] = "purple",
				["buff"] = "silver",
				["friendlyfire"] = "darkorange",
				["heal"] = "green",
				["cooldown"] = "yellow",
				["damage"] = "red",
			},
		},
		["Stormart-Mal'Ganis"] = {
			["overall_clear_newtorghast"] = true,
			["use_realtimedps"] = false,
			["row_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["streamer_config"] = {
				["faster_updates"] = false,
				["quick_detection"] = false,
				["reset_spec_cache"] = false,
				["no_alerts"] = false,
				["use_animation_accel"] = true,
				["disable_mythic_dungeon"] = false,
			},
			["all_players_are_group"] = false,
			["use_row_animations"] = true,
			["report_heal_links"] = false,
			["remove_realm_from_name"] = true,
			["minimum_overall_combat_time"] = 10,
			["event_tracker"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["show_crowdcontrol_pvm"] = false,
				["line_color"] = {
					0.1, -- [1]
					0.1, -- [2]
					0.1, -- [3]
					0.3, -- [4]
				},
				["font_shadow"] = "NONE",
				["font_size"] = 10,
				["font_face"] = "Friz Quadrata TT",
				["line_height"] = 16,
				["show_crowdcontrol_pvp"] = true,
				["frame"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0.1921, -- [1]
						0.1921, -- [2]
						0.1921, -- [3]
						0.3869, -- [4]
					},
					["locked"] = false,
					["height"] = 300,
					["width"] = 250,
				},
				["line_texture"] = "Details Serenity",
				["options_frame"] = {
				},
			},
			["report_to_who"] = "",
			["class_specs_coords"] = {
				[62] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[1467] = {
					0.5, -- [1]
					0.625, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[63] = {
					0.375, -- [1]
					0.5, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[250] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[251] = {
					0.125, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[252] = {
					0.25, -- [1]
					0.375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[1468] = {
					0.625, -- [1]
					0.75, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[253] = {
					0.875, -- [1]
					1, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[254] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[255] = {
					0.125, -- [1]
					0.25, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[66] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[257] = {
					0.5, -- [1]
					0.625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[258] = {
					0.6328125, -- [1]
					0.75, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[259] = {
					0.125, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[260] = {
					0, -- [1]
					0.125, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[577] = {
					0.25, -- [1]
					0.375, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[262] = {
					0.125, -- [1]
					0.25, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[581] = {
					0.375, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[264] = {
					0.375, -- [1]
					0.5, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[265] = {
					0.5, -- [1]
					0.625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[266] = {
					0.625, -- [1]
					0.75, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[267] = {
					0.75, -- [1]
					0.875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[268] = {
					0.625, -- [1]
					0.75, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[269] = {
					0.875, -- [1]
					1, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[270] = {
					0.75, -- [1]
					0.875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[70] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[102] = {
					0.375, -- [1]
					0.5, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[71] = {
					0.875, -- [1]
					1, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[103] = {
					0.5, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[72] = {
					0, -- [1]
					0.125, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[104] = {
					0.625, -- [1]
					0.75, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[64] = {
					0.5, -- [1]
					0.625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[73] = {
					0.125, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[65] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[105] = {
					0.75, -- [1]
					0.875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[256] = {
					0.375, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[261] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[263] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[1473] = {
					0.75, -- [1]
					0.875, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
			},
			["all_in_one_windows"] = {
			},
			["tooltip"] = {
				["anchor_offset"] = {
					0, -- [1]
					0, -- [2]
				},
				["bar_color"] = {
					0.396, -- [1]
					0.396, -- [2]
					0.396, -- [3]
					0.87, -- [4]
				},
				["tooltip_max_pets"] = 2,
				["abbreviation"] = 2,
				["header_text_color"] = {
					1, -- [1]
					0.9176, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["background"] = {
					0.0941, -- [1]
					0.0941, -- [2]
					0.0941, -- [3]
					0.8, -- [4]
				},
				["divisor_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["fontshadow"] = false,
				["anchor_screen_pos"] = {
					507.7, -- [1]
					-350.5, -- [2]
				},
				["header_statusbar"] = {
					0.3, -- [1]
					0.3, -- [2]
					0.3, -- [3]
					0.8, -- [4]
					false, -- [5]
					false, -- [6]
					"WorldState Score", -- [7]
				},
				["fontcolor_right"] = {
					1, -- [1]
					0.7, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["line_height"] = 17,
				["tooltip_max_targets"] = 2,
				["icon_size"] = {
					["W"] = 17,
					["H"] = 17,
				},
				["anchor_relative"] = "top",
				["anchored_to"] = 1,
				["show_amount"] = false,
				["submenu_wallpaper"] = true,
				["fontsize_title"] = 10,
				["commands"] = {
				},
				["fontface"] = "Friz Quadrata TT",
				["border_color"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["border_texture"] = "Details BarBorder 3",
				["menus_bg_texture"] = "Interface\\SPELLBOOK\\Spellbook-Page-1",
				["icon_border_texcoord"] = {
					["B"] = 0.921875,
					["L"] = 0.078125,
					["T"] = 0.078125,
					["R"] = 0.921875,
				},
				["fontsize"] = 10,
				["border_size"] = 14,
				["maximize_method"] = 1,
				["tooltip_max_abilities"] = 6,
				["anchor_point"] = "bottom",
				["menus_bg_coords"] = {
					0.309777336120606, -- [1]
					0.924000015258789, -- [2]
					0.213000011444092, -- [3]
					0.279000015258789, -- [4]
				},
				["fontcolor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["menus_bg_color"] = {
					0.8, -- [1]
					0.8, -- [2]
					0.8, -- [3]
					0.2, -- [4]
				},
			},
			["ps_abbreviation"] = 3,
			["world_combat_is_trash"] = false,
			["pvp_as_group"] = true,
			["bookmark_text_size"] = 11,
			["animation_speed_mintravel"] = 0.45,
			["track_item_level"] = false,
			["fade_speed"] = 0.15,
			["death_tooltip_spark"] = false,
			["windows_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["instances_menu_click_to_open"] = false,
			["overall_clear_newchallenge"] = true,
			["use_self_color"] = false,
			["data_cleanup_logout"] = false,
			["instances_disable_bar_highlight"] = false,
			["profile_save_pos"] = true,
			["default_bg_alpha"] = 0.5,
			["trash_concatenate"] = false,
			["deny_score_messages"] = false,
			["disable_stretch_from_toolbar"] = false,
			["realtime_dps_meter"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["arena_enabled"] = true,
				["font_shadow"] = "NONE",
				["font_size"] = 18,
				["mythic_dungeon_enabled"] = false,
				["sample_size"] = 3,
				["frame_settings"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["point"] = "TOP",
					["scale"] = 1,
					["width"] = 300,
					["y"] = -110,
					["x"] = 0,
					["backdrop_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.2, -- [4]
					},
					["locked"] = true,
					["height"] = 23,
				},
				["update_interval"] = 0.3,
				["text_offset"] = 2,
				["font_face"] = "Friz Quadrata TT",
				["options_frame"] = {
				},
			},
			["animation_speed"] = 33,
			["animate_scroll"] = false,
			["standard_skin"] = false,
			["disable_lock_ungroup_buttons"] = false,
			["memory_ram"] = 64,
			["use_battleground_server_parser"] = false,
			["death_tooltip_width"] = 350,
			["disable_window_groups"] = false,
			["clear_ungrouped"] = true,
			["force_activity_time_pvp"] = true,
			["instances_suppress_trash"] = 0,
			["class_icons_small"] = "Interface\\AddOns\\Details\\images\\classes_small",
			["options_window"] = {
				["scale"] = 1,
			},
			["animation_speed_maxtravel"] = 3,
			["time_type_original"] = 2,
			["player_details_window"] = {
				["scale"] = 1,
				["bar_texture"] = "Skyline",
				["skin"] = "ElvUI",
			},
			["font_faces"] = {
				["menus"] = "Friz Quadrata TT",
			},
			["auto_swap_to_dynamic_overall"] = false,
			["instances"] = {
				{
					["__pos"] = {
						["normal"] = {
							["y"] = -548.8460235595703,
							["x"] = 557.9527587890625,
							["w"] = 197.8463439941406,
							["h"] = 83.8463363647461,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["hide_in_combat_type"] = 1,
					["menu_icons_size"] = 0.82,
					["titlebar_shown"] = false,
					["menu_anchor"] = {
						20, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.243,
					["fullborder_size"] = 0.5,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons_2_shadow",
					["bars_sort_direction"] = 1,
					["use_auto_align_multi_fontstrings"] = true,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["switch_all_roles_in_combat"] = false,
					["clickthrough_toolbaricons"] = false,
					["row_info"] = {
						["show_arena_role_icon"] = false,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = false,
						["textR_outline_small"] = true,
						["textL_outline_small"] = true,
						["textL_enable_custom_text"] = false,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["textL_offset"] = 0,
						["text_yoffset"] = 0,
						["texture_background_class_color"] = false,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["font_face_file"] = "Interface\\Addons\\Details\\fonts\\Accidental Presidency.ttf",
						["faction_icon_size_offset"] = -10,
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["backdrop"] = {
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["size"] = 12,
							["enabled"] = false,
							["texture"] = "Details BarBorder 2",
						},
						["font_size"] = 16,
						["start_after_icon"] = true,
						["height"] = 21,
						["textL_translit_text"] = false,
						["texture_custom_file"] = "Interface\\",
						["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_hyanda",
						["icon_size_offset"] = 0,
						["percent_type"] = 1,
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["overlay_color"] = {
							0.7, -- [1]
							0.7, -- [2]
							0.7, -- [3]
							0, -- [4]
						},
						["textR_outline"] = false,
						["use_spec_icons"] = true,
						["arena_role_icon_size_offset"] = -10,
						["icon_grayscale"] = false,
						["texture_custom"] = "",
						["textR_bracket"] = "(",
						["textR_enable_custom_text"] = false,
						["textL_class_colors"] = false,
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["texture_background"] = "Details D'ictum (reverse)",
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "Details Hyanda",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar4_reverse",
						["overlay_texture"] = "Details D'ictum",
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.150228589773178, -- [4]
						},
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 1,
						},
						["textR_class_colors"] = false,
						["alpha"] = 1,
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
						["font_face"] = "Accidental Presidency",
						["texture_class_colors"] = true,
						["show_faction_icon"] = true,
						["fast_ps_update"] = false,
						["textR_separator"] = "NONE",
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
					},
					["titlebar_texture"] = "Details Serenity",
					["ignore_mass_showhide"] = false,
					["switch_all_roles_after_wipe"] = false,
					["icon_desaturated"] = false,
					["desaturated_menu"] = false,
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["window_scale"] = 1,
					["hide_icon"] = false,
					["toolbar_side"] = 1,
					["bg_g"] = 0.2352,
					["menu_icons_alpha"] = 0.92,
					["bg_b"] = 0.2588,
					["switch_healer_in_combat"] = false,
					["color"] = {
						0.1215, -- [1]
						0.1176, -- [2]
						0.1294, -- [3]
						0.91, -- [4]
					},
					["hide_on_context"] = {
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [1]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [2]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [3]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [4]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [5]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [6]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [7]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [8]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [9]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [10]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [11]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [12]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [13]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [14]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [15]
					},
					["micro_displays_locked"] = true,
					["use_multi_fontstrings"] = true,
					["__was_opened"] = true,
					["skin"] = "Minimalistic",
					["fontstrings_text_limit_offset"] = -10,
					["following"] = {
						["enabled"] = false,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["switch_healer"] = false,
					["fontstrings_text2_anchor"] = 73,
					["rowareaborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["attribute_text"] = {
						["enabled"] = true,
						["shadow"] = false,
						["side"] = 1,
						["text_size"] = 12,
						["custom_text"] = "{name}",
						["show_timer_arena"] = true,
						["text_face"] = "Accidental Presidency",
						["show_timer_always"] = true,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = {
							1.4, -- [1]
							2, -- [2]
						},
						["enable_custom_text"] = false,
						["show_timer"] = true,
						["show_timer_bg"] = true,
					},
					["fontstrings_text3_anchor"] = 38,
					["clickthrough_rows"] = false,
					["StatusBarSaved"] = {
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["textXMod"] = 0,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 3,
								["textStyle"] = 2,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textXMod"] = 0,
								["textAlign"] = 1,
								["textStyle"] = 2,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["textFace"] = "Accidental Presidency",
								["textXMod"] = 6,
								["textAlign"] = 2,
								["textStyle"] = 2,
								["timeType"] = 1,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
						},
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
					},
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["clickthrough_window"] = false,
					["switch_tank_in_combat"] = false,
					["version"] = 3,
					["fontstrings_text4_anchor"] = 0,
					["__locked"] = false,
					["menu_alpha"] = {
						["enabled"] = false,
						["onenter"] = 1,
						["iconstoo"] = true,
						["ignorebars"] = false,
						["onleave"] = 1,
					},
					["fullborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["rowareaborder_shown"] = false,
					["backdrop_texture"] = "Details Ground",
					["rowareaborder_size"] = 0.5,
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
						[4] = 2,
					},
					["switch_damager"] = false,
					["hide_in_combat_alpha"] = 0,
					["grab_on_top"] = false,
					["show_statusbar"] = false,
					["libwindow"] = {
						["y"] = 3.591207132558338e-05,
						["x"] = -393.380615234375,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0.3777777777777,
						["overlay"] = {
							0.333333333333333, -- [1]
							0.333333333333333, -- [2]
							0.333333333333333, -- [3]
						},
					},
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["bars_grow_direction"] = 1,
					["plugins_grow_direction"] = 1,
					["__snapV"] = true,
					["switch_tank"] = false,
					["switch_damager_in_combat"] = false,
					["skin_custom"] = "",
					["strata"] = "LOW",
					["auto_current"] = true,
					["micro_displays_side"] = 2,
					["fullborder_shown"] = false,
					["bg_alpha"] = 0.6,
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = -548.8460235595703,
							["x"] = 557.9527587890625,
							["w"] = 197.8463439941406,
							["h"] = 83.8463363647461,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["menu_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						true, -- [5]
						false, -- [6]
						["space"] = -2,
						["shadow"] = false,
					},
					["show_sidebars"] = false,
					["wallpaper"] = {
						["enabled"] = false,
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["height"] = 114.042518615723,
						["anchor"] = "all",
						["level"] = 2,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["stretch_button_side"] = 1,
					["titlebar_height"] = 16,
					["bars_inverted"] = false,
					["menu_icons_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["titlebar_texture_color"] = {
						0.2, -- [1]
						0.2, -- [2]
						0.2, -- [3]
						0.8, -- [4]
					},
				}, -- [1]
				{
					["__pos"] = {
						["normal"] = {
							["y"] = -450.9228515625,
							["x"] = 557.9527587890625,
							["w"] = 197.8463439941406,
							["h"] = 72.00003051757812,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["hide_in_combat_type"] = 1,
					["menu_icons_size"] = 0.82,
					["titlebar_shown"] = false,
					["menu_anchor"] = {
						20, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.243,
					["fullborder_size"] = 0.5,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons_2_shadow",
					["bars_sort_direction"] = 1,
					["use_auto_align_multi_fontstrings"] = true,
					["rowareaborder_shown"] = false,
					["switch_all_roles_in_combat"] = false,
					["clickthrough_toolbaricons"] = false,
					["row_info"] = {
						["textR_outline"] = false,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = false,
						["textR_outline_small"] = true,
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["percent_type"] = 1,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["textL_offset"] = 0,
						["text_yoffset"] = 0,
						["texture_background_class_color"] = false,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["font_face_file"] = "Interface\\Addons\\Details\\fonts\\Accidental Presidency.ttf",
						["faction_icon_size_offset"] = -10,
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["backdrop"] = {
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["texture"] = "Details BarBorder 2",
							["enabled"] = false,
							["size"] = 12,
						},
						["font_size"] = 16,
						["start_after_icon"] = true,
						["texture_custom_file"] = "Interface\\",
						["textL_translit_text"] = false,
						["height"] = 21,
						["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_hyanda",
						["icon_size_offset"] = 0,
						["show_faction_icon"] = true,
						["textL_outline_small"] = true,
						["overlay_color"] = {
							0.7, -- [1]
							0.7, -- [2]
							0.7, -- [3]
							0, -- [4]
						},
						["show_arena_role_icon"] = false,
						["textR_bracket"] = "(",
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
						["icon_grayscale"] = false,
						["textR_enable_custom_text"] = false,
						["use_spec_icons"] = true,
						["texture_custom"] = "",
						["texture_background"] = "Details D'ictum (reverse)",
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["alpha"] = 1,
						["textR_class_colors"] = false,
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "Details Hyanda",
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 1,
						},
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.150228589773178, -- [4]
						},
						["overlay_texture"] = "Details D'ictum",
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar4_reverse",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["textL_class_colors"] = false,
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["arena_role_icon_size_offset"] = -10,
						["font_face"] = "Accidental Presidency",
						["texture_class_colors"] = true,
						["textL_enable_custom_text"] = false,
						["fast_ps_update"] = false,
						["textR_separator"] = "NONE",
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
					},
					["titlebar_texture"] = "Details Serenity",
					["ignore_mass_showhide"] = false,
					["plugins_grow_direction"] = 1,
					["icon_desaturated"] = false,
					["switch_damager"] = false,
					["micro_displays_side"] = 2,
					["window_scale"] = 1,
					["hide_icon"] = false,
					["toolbar_side"] = 1,
					["fullborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["menu_icons_alpha"] = 0.92,
					["bg_b"] = 0.2588,
					["switch_healer_in_combat"] = false,
					["color"] = {
						0.1215, -- [1]
						0.1176, -- [2]
						0.1294, -- [3]
						0.91, -- [4]
					},
					["hide_on_context"] = {
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [1]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [2]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [3]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [4]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [5]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [6]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [7]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [8]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [9]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [10]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [11]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [12]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [13]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [14]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [15]
					},
					["fontstrings_text3_anchor"] = 38,
					["use_multi_fontstrings"] = true,
					["__was_opened"] = true,
					["fontstrings_text_limit_offset"] = -10,
					["skin"] = "Minimalistic",
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["following"] = {
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["enabled"] = false,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["clickthrough_window"] = false,
					["switch_healer"] = false,
					["fontstrings_text2_anchor"] = 73,
					["menu_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						true, -- [5]
						false, -- [6]
						["space"] = -2,
						["shadow"] = false,
					},
					["fullborder_shown"] = false,
					["attribute_text"] = {
						["enabled"] = true,
						["shadow"] = false,
						["side"] = 1,
						["text_size"] = 12,
						["custom_text"] = "{name}",
						["show_timer_arena"] = true,
						["text_face"] = "Accidental Presidency",
						["show_timer_always"] = true,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = {
							1.4, -- [1]
							2, -- [2]
						},
						["show_timer"] = true,
						["enable_custom_text"] = false,
						["show_timer_bg"] = true,
					},
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["menu_alpha"] = {
						["enabled"] = false,
						["onleave"] = 1,
						["ignorebars"] = false,
						["iconstoo"] = true,
						["onenter"] = 1,
					},
					["StatusBarSaved"] = {
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["textXMod"] = 0,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 3,
								["textStyle"] = 2,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textXMod"] = 0,
								["textAlign"] = 1,
								["textStyle"] = 2,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["textFace"] = "Accidental Presidency",
								["textXMod"] = 6,
								["textAlign"] = 2,
								["textStyle"] = 2,
								["timeType"] = 1,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
						},
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
					},
					["backdrop_texture"] = "Details Ground",
					["bg_g"] = 0.2352,
					["switch_tank_in_combat"] = false,
					["bg_alpha"] = 0.6,
					["fontstrings_text4_anchor"] = 0,
					["__locked"] = false,
					["__snapH"] = false,
					["micro_displays_locked"] = true,
					["show_statusbar"] = false,
					["desaturated_menu"] = false,
					["rowareaborder_size"] = 0.5,
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
						[2] = 1,
					},
					["switch_damager_in_combat"] = false,
					["hide_in_combat_alpha"] = 0,
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["rowareaborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["libwindow"] = {
						["y"] = 103.8463592529297,
						["x"] = -393.380615234375,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0.3777777777777,
						["overlay"] = {
							0.333333333333333, -- [1]
							0.333333333333333, -- [2]
							0.333333333333333, -- [3]
						},
					},
					["bars_grow_direction"] = 1,
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["__snapV"] = true,
					["switch_all_roles_after_wipe"] = false,
					["switch_tank"] = false,
					["grab_on_top"] = false,
					["strata"] = "LOW",
					["skin_custom"] = "",
					["auto_current"] = true,
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["version"] = 3,
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = -450.9228515625,
							["x"] = 557.9527587890625,
							["w"] = 197.8463439941406,
							["h"] = 72.00003051757812,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["clickthrough_rows"] = false,
					["bars_inverted"] = false,
					["wallpaper"] = {
						["enabled"] = false,
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["anchor"] = "all",
						["height"] = 114.042518615723,
						["level"] = 2,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["stretch_button_side"] = 1,
					["titlebar_height"] = 16,
					["show_sidebars"] = false,
					["menu_icons_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["titlebar_texture_color"] = {
						0.2, -- [1]
						0.2, -- [2]
						0.2, -- [3]
						0.8, -- [4]
					},
				}, -- [2]
			},
			["report_lines"] = 5,
			["segments_amount"] = 40,
			["overall_clear_pvp"] = true,
			["overall_clear_newboss"] = true,
			["capture_real"] = {
				["heal"] = true,
				["spellcast"] = true,
				["miscdata"] = true,
				["aura"] = true,
				["energy"] = true,
				["damage"] = true,
			},
			["skin"] = "Minimalistic",
			["override_spellids"] = true,
			["windows_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["realtimedps_always_arena"] = false,
			["minimum_combat_time"] = 5,
			["font_sizes"] = {
				["menus"] = 10,
			},
			["overall_clear_logout"] = false,
			["window_clamp"] = {
				-8, -- [1]
				0, -- [2]
				21, -- [3]
				-14, -- [4]
			},
			["cloud_capture"] = true,
			["damage_taken_everything"] = false,
			["scroll_speed"] = 2,
			["new_window_size"] = {
				["height"] = 158,
				["width"] = 310,
			},
			["memory_threshold"] = 3,
			["deadlog_events"] = 32,
			["default_bg_color"] = 0.0941,
			["close_shields"] = false,
			["class_coords"] = {
				["HUNTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["WARRIOR"] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["PALADIN"] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["MAGE"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["PET"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["DRUID"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["MONK"] = {
					0.25, -- [1]
					0.369140625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["DEATHKNIGHT"] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["SHAMAN"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["MONSTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["UNKNOW"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["PRIEST"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["ENEMY"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["Alliance"] = {
					0.248046875, -- [1]
					0.02968748, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["WARLOCK"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["DEMONHUNTER"] = {
					0.36914063, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["Horde"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["UNGROUPPLAYER"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["EVOKER"] = {
					0.50390625, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["ROGUE"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
			},
			["total_abbreviation"] = 2,
			["disable_alldisplays_window"] = false,
			["trash_auto_remove"] = false,
			["broadcaster_enabled"] = false,
			["hotcorner_topleft"] = {
				["hide"] = false,
			},
			["segments_auto_erase"] = 1,
			["clear_graphic"] = true,
			["class_colors"] = {
				["HUNTER"] = {
					0.67, -- [1]
					0.83, -- [2]
					0.45, -- [3]
				},
				["WARRIOR"] = {
					0.78, -- [1]
					0.61, -- [2]
					0.43, -- [3]
				},
				["SHAMAN"] = {
					0, -- [1]
					0.44, -- [2]
					0.87, -- [3]
				},
				["MAGE"] = {
					0.41, -- [1]
					0.8, -- [2]
					0.94, -- [3]
				},
				["ARENA_YELLOW"] = {
					1, -- [1]
					1, -- [2]
					0.25, -- [3]
				},
				["UNGROUPPLAYER"] = {
					0.4, -- [1]
					0.4, -- [2]
					0.4, -- [3]
				},
				["DRUID"] = {
					1, -- [1]
					0.49, -- [2]
					0.04, -- [3]
				},
				["MONK"] = {
					0, -- [1]
					1, -- [2]
					0.59, -- [3]
				},
				["DEATHKNIGHT"] = {
					0.77, -- [1]
					0.12, -- [2]
					0.23, -- [3]
				},
				["SELF"] = {
					0.89019, -- [1]
					0.32156, -- [2]
					0.89019, -- [3]
				},
				["PET"] = {
					0.3, -- [1]
					0.4, -- [2]
					0.5, -- [3]
				},
				["PALADIN"] = {
					0.96, -- [1]
					0.55, -- [2]
					0.73, -- [3]
				},
				["UNKNOW"] = {
					0.2, -- [1]
					0.2, -- [2]
					0.2, -- [3]
				},
				["PRIEST"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
				},
				["ARENA_GREEN"] = {
					0.686, -- [1]
					0.372, -- [2]
					0.905, -- [3]
				},
				["ENEMY"] = {
					0.94117, -- [1]
					0, -- [2]
					0.0196, -- [3]
					1, -- [4]
				},
				["version"] = 1,
				["DEMONHUNTER"] = {
					0.64, -- [1]
					0.19, -- [2]
					0.79, -- [3]
				},
				["WARLOCK"] = {
					0.58, -- [1]
					0.51, -- [2]
					0.79, -- [3]
				},
				["NEUTRAL"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
				},
				["EVOKER"] = {
					0.2, -- [1]
					0.5764, -- [2]
					0.498, -- [3]
				},
				["ROGUE"] = {
					1, -- [1]
					0.96, -- [2]
					0.41, -- [3]
				},
			},
			["animation_speed_triggertravel"] = 5,
			["options_group_edit"] = true,
			["segments_amount_to_save"] = 40,
			["minimap"] = {
				["onclick_what_todo"] = 1,
				["radius"] = 160,
				["text_type"] = 1,
				["minimapPos"] = 80.72444304979324,
				["text_format"] = 3,
				["hide"] = false,
			},
			["instances_amount"] = 5,
			["max_window_size"] = {
				["height"] = 450,
				["width"] = 480,
			},
			["chat_tab_embed"] = {
				["enabled"] = false,
				["y_offset"] = 0,
				["x_offset"] = 0,
				["tab_name"] = "",
				["single_window"] = false,
			},
			["only_pvp_frags"] = false,
			["disable_stretch_button"] = false,
			["color_by_arena_team"] = true,
			["use_scroll"] = false,
			["overall_flag"] = 16,
			["segments_panic_mode"] = false,
			["realtimedps_order_bars"] = false,
			["show_arena_role_icon"] = false,
			["row_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["numerical_system"] = 1,
			["time_type"] = 2,
			["update_speed"] = 0.2,
			["report_schema"] = 1,
			["numerical_system_symbols"] = "auto",
			["death_tooltip_texture"] = "Details Serenity",
			["disable_reset_button"] = false,
			["data_broker_text"] = "",
			["instances_no_libwindow"] = false,
			["instances_segments_locked"] = true,
			["deadlog_limit"] = 16,
			["death_log_colors"] = {
				["debuff"] = "purple",
				["buff"] = "silver",
				["friendlyfire"] = "darkorange",
				["heal"] = "green",
				["cooldown"] = "yellow",
				["damage"] = "red",
			},
		},
		["Janwa-Mal'Ganis"] = {
			["overall_clear_newtorghast"] = true,
			["use_realtimedps"] = false,
			["row_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["streamer_config"] = {
				["faster_updates"] = false,
				["quick_detection"] = false,
				["reset_spec_cache"] = false,
				["no_alerts"] = false,
				["use_animation_accel"] = true,
				["disable_mythic_dungeon"] = false,
			},
			["all_players_are_group"] = false,
			["use_row_animations"] = true,
			["report_heal_links"] = false,
			["remove_realm_from_name"] = true,
			["minimum_overall_combat_time"] = 10,
			["event_tracker"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["show_crowdcontrol_pvm"] = false,
				["line_color"] = {
					0.1, -- [1]
					0.1, -- [2]
					0.1, -- [3]
					0.3, -- [4]
				},
				["font_shadow"] = "NONE",
				["font_size"] = 10,
				["font_face"] = "Friz Quadrata TT",
				["line_height"] = 16,
				["show_crowdcontrol_pvp"] = true,
				["frame"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0.1921, -- [1]
						0.1921, -- [2]
						0.1921, -- [3]
						0.3869, -- [4]
					},
					["locked"] = false,
					["height"] = 300,
					["width"] = 250,
				},
				["line_texture"] = "Details Serenity",
				["options_frame"] = {
				},
			},
			["report_to_who"] = "",
			["class_specs_coords"] = {
				[62] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[1467] = {
					0.5, -- [1]
					0.625, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[63] = {
					0.375, -- [1]
					0.5, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[250] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[251] = {
					0.125, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[252] = {
					0.25, -- [1]
					0.375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[1468] = {
					0.625, -- [1]
					0.75, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[253] = {
					0.875, -- [1]
					1, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[254] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[255] = {
					0.125, -- [1]
					0.25, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[66] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[257] = {
					0.5, -- [1]
					0.625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[258] = {
					0.6328125, -- [1]
					0.75, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[259] = {
					0.125, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[260] = {
					0, -- [1]
					0.125, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[577] = {
					0.25, -- [1]
					0.375, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[262] = {
					0.125, -- [1]
					0.25, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[581] = {
					0.375, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[264] = {
					0.375, -- [1]
					0.5, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[265] = {
					0.5, -- [1]
					0.625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[266] = {
					0.625, -- [1]
					0.75, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[267] = {
					0.75, -- [1]
					0.875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[268] = {
					0.625, -- [1]
					0.75, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[269] = {
					0.875, -- [1]
					1, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[270] = {
					0.75, -- [1]
					0.875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[70] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[102] = {
					0.375, -- [1]
					0.5, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[71] = {
					0.875, -- [1]
					1, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[103] = {
					0.5, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[72] = {
					0, -- [1]
					0.125, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[104] = {
					0.625, -- [1]
					0.75, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[1473] = {
					0.75, -- [1]
					0.875, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[73] = {
					0.125, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[263] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[105] = {
					0.75, -- [1]
					0.875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[261] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[256] = {
					0.375, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[65] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[64] = {
					0.5, -- [1]
					0.625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
			},
			["all_in_one_windows"] = {
			},
			["tooltip"] = {
				["anchor_offset"] = {
					0, -- [1]
					0, -- [2]
				},
				["bar_color"] = {
					0.396, -- [1]
					0.396, -- [2]
					0.396, -- [3]
					0.87, -- [4]
				},
				["tooltip_max_pets"] = 2,
				["abbreviation"] = 2,
				["header_text_color"] = {
					1, -- [1]
					0.9176, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["background"] = {
					0.0941, -- [1]
					0.0941, -- [2]
					0.0941, -- [3]
					0.8, -- [4]
				},
				["divisor_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["fontshadow"] = false,
				["anchor_screen_pos"] = {
					507.7, -- [1]
					-350.5, -- [2]
				},
				["header_statusbar"] = {
					0.3, -- [1]
					0.3, -- [2]
					0.3, -- [3]
					0.8, -- [4]
					false, -- [5]
					false, -- [6]
					"WorldState Score", -- [7]
				},
				["fontcolor_right"] = {
					1, -- [1]
					0.7, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["line_height"] = 17,
				["tooltip_max_targets"] = 2,
				["icon_size"] = {
					["W"] = 13,
					["H"] = 13,
				},
				["anchor_relative"] = "top",
				["anchored_to"] = 1,
				["show_amount"] = false,
				["submenu_wallpaper"] = true,
				["fontsize_title"] = 10,
				["commands"] = {
				},
				["fontface"] = "Friz Quadrata TT",
				["border_color"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["border_texture"] = "Details BarBorder 3",
				["menus_bg_texture"] = "Interface\\SPELLBOOK\\Spellbook-Page-1",
				["icon_border_texcoord"] = {
					["B"] = 0.921875,
					["L"] = 0.078125,
					["T"] = 0.078125,
					["R"] = 0.921875,
				},
				["fontsize"] = 10,
				["border_size"] = 14,
				["maximize_method"] = 1,
				["tooltip_max_abilities"] = 6,
				["anchor_point"] = "bottom",
				["menus_bg_coords"] = {
					0.309777336120606, -- [1]
					0.924000015258789, -- [2]
					0.213000011444092, -- [3]
					0.279000015258789, -- [4]
				},
				["fontcolor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["menus_bg_color"] = {
					0.8, -- [1]
					0.8, -- [2]
					0.8, -- [3]
					0.2, -- [4]
				},
			},
			["ps_abbreviation"] = 3,
			["world_combat_is_trash"] = false,
			["pvp_as_group"] = true,
			["bookmark_text_size"] = 11,
			["animation_speed_mintravel"] = 0.45,
			["track_item_level"] = false,
			["fade_speed"] = 0.15,
			["death_tooltip_spark"] = false,
			["windows_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["instances_menu_click_to_open"] = false,
			["overall_clear_newchallenge"] = true,
			["use_self_color"] = false,
			["data_cleanup_logout"] = false,
			["instances_disable_bar_highlight"] = false,
			["profile_save_pos"] = true,
			["default_bg_alpha"] = 0.5,
			["trash_concatenate"] = false,
			["deny_score_messages"] = false,
			["standard_skin"] = false,
			["disable_lock_ungroup_buttons"] = false,
			["animation_speed"] = 33,
			["animate_scroll"] = false,
			["disable_stretch_from_toolbar"] = false,
			["realtime_dps_meter"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["arena_enabled"] = true,
				["font_shadow"] = "NONE",
				["font_size"] = 18,
				["mythic_dungeon_enabled"] = false,
				["sample_size"] = 3,
				["frame_settings"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["point"] = "TOP",
					["scale"] = 1,
					["width"] = 300,
					["y"] = -110,
					["x"] = 0,
					["backdrop_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.2, -- [4]
					},
					["locked"] = true,
					["height"] = 23,
				},
				["update_interval"] = 0.3,
				["text_offset"] = 2,
				["font_face"] = "Friz Quadrata TT",
				["options_frame"] = {
				},
			},
			["memory_ram"] = 64,
			["use_battleground_server_parser"] = false,
			["death_tooltip_width"] = 350,
			["disable_window_groups"] = false,
			["clear_ungrouped"] = true,
			["force_activity_time_pvp"] = true,
			["instances_suppress_trash"] = 0,
			["class_icons_small"] = "Interface\\AddOns\\Details\\images\\classes_small",
			["options_window"] = {
				["scale"] = 1,
			},
			["animation_speed_maxtravel"] = 3,
			["time_type_original"] = 2,
			["player_details_window"] = {
				["scale"] = 1,
				["bar_texture"] = "Skyline",
				["skin"] = "ElvUI",
			},
			["font_faces"] = {
				["menus"] = "Friz Quadrata TT",
			},
			["auto_swap_to_dynamic_overall"] = false,
			["segments_amount"] = 40,
			["report_lines"] = 5,
			["instances"] = {
				{
					["__pos"] = {
						["normal"] = {
							["y"] = -508.4871368408203,
							["x"] = 602.803466796875,
							["w"] = 246.5469818115234,
							["h"] = 164.5641784667969,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["hide_in_combat_type"] = 1,
					["menu_icons_size"] = 0.82,
					["titlebar_shown"] = false,
					["menu_anchor"] = {
						20, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.243,
					["fullborder_size"] = 0.5,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons_2_shadow",
					["skin_custom"] = "",
					["use_auto_align_multi_fontstrings"] = true,
					["rowareaborder_shown"] = false,
					["fullborder_shown"] = false,
					["clickthrough_toolbaricons"] = false,
					["clickthrough_rows"] = false,
					["titlebar_texture"] = "Details Serenity",
					["ignore_mass_showhide"] = false,
					["switch_all_roles_after_wipe"] = false,
					["icon_desaturated"] = false,
					["switch_damager"] = false,
					["micro_displays_side"] = 2,
					["window_scale"] = 1,
					["hide_icon"] = false,
					["toolbar_side"] = 1,
					["bg_g"] = 0.2352,
					["menu_icons_alpha"] = 0.92,
					["bg_b"] = 0.2588,
					["switch_healer_in_combat"] = false,
					["color"] = {
						0.1215, -- [1]
						0.1176, -- [2]
						0.1294, -- [3]
						0.91, -- [4]
					},
					["hide_on_context"] = {
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [1]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [2]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [3]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [4]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [5]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [6]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [7]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [8]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [9]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [10]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [11]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [12]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [13]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [14]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [15]
					},
					["rowareaborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["menu_icons_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["skin"] = "Minimalistic",
					["show_sidebars"] = false,
					["following"] = {
						["enabled"] = false,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["attribute_text"] = {
						["enabled"] = true,
						["shadow"] = false,
						["side"] = 1,
						["text_size"] = 12,
						["custom_text"] = "{name}",
						["show_timer_arena"] = true,
						["text_face"] = "Accidental Presidency",
						["show_timer_always"] = true,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = {
							1.4, -- [1]
							2, -- [2]
						},
						["enable_custom_text"] = false,
						["show_timer"] = true,
						["show_timer_bg"] = true,
					},
					["switch_healer"] = false,
					["fontstrings_text2_anchor"] = 73,
					["stretch_button_side"] = 1,
					["menu_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						true, -- [5]
						false, -- [6]
						["space"] = -2,
						["shadow"] = false,
					},
					["row_info"] = {
						["textR_outline"] = false,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = false,
						["textR_outline_small"] = true,
						["textL_outline_small"] = true,
						["textL_enable_custom_text"] = false,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["textL_offset"] = 0,
						["text_yoffset"] = 0,
						["texture_background_class_color"] = false,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["font_face_file"] = "Interface\\Addons\\Details\\fonts\\Accidental Presidency.ttf",
						["faction_icon_size_offset"] = -10,
						["backdrop"] = {
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["size"] = 12,
							["enabled"] = false,
							["texture"] = "Details BarBorder 2",
						},
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
						["show_faction_icon"] = true,
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["textL_translit_text"] = false,
						["height"] = 21,
						["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_hyanda",
						["icon_size_offset"] = 0,
						["percent_type"] = 1,
						["start_after_icon"] = true,
						["overlay_color"] = {
							0.7, -- [1]
							0.7, -- [2]
							0.7, -- [3]
							0, -- [4]
						},
						["texture_custom_file"] = "Interface\\",
						["arena_role_icon_size_offset"] = -10,
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
						["icon_grayscale"] = false,
						["texture_custom"] = "",
						["use_spec_icons"] = true,
						["textR_enable_custom_text"] = false,
						["textL_class_colors"] = false,
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["texture_background"] = "Details D'ictum (reverse)",
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "Details Hyanda",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar4_reverse",
						["overlay_texture"] = "Details D'ictum",
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.150228589773178, -- [4]
						},
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 1,
						},
						["textR_class_colors"] = false,
						["alpha"] = 1,
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["textR_bracket"] = "(",
						["font_face"] = "Accidental Presidency",
						["texture_class_colors"] = true,
						["show_arena_role_icon"] = false,
						["fast_ps_update"] = false,
						["textR_separator"] = "NONE",
						["font_size"] = 16,
					},
					["bars_inverted"] = false,
					["bars_sort_direction"] = 1,
					["StatusBarSaved"] = {
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["textYMod"] = 1,
								["textXMod"] = 0,
								["textFace"] = "Accidental Presidency",
								["textStyle"] = 2,
								["textAlign"] = 3,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["textYMod"] = 1,
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textXMod"] = 0,
								["textStyle"] = 2,
								["textAlign"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["textYMod"] = 1,
								["textXMod"] = 6,
								["textFace"] = "Accidental Presidency",
								["timeType"] = 1,
								["textStyle"] = 2,
								["textAlign"] = 2,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
						},
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
					},
					["fontstrings_text3_anchor"] = 38,
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["switch_tank_in_combat"] = false,
					["version"] = 3,
					["fontstrings_text4_anchor"] = 0,
					["__locked"] = false,
					["menu_alpha"] = {
						["enabled"] = false,
						["onenter"] = 1,
						["iconstoo"] = true,
						["ignorebars"] = false,
						["onleave"] = 1,
					},
					["clickthrough_window"] = false,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["rowareaborder_size"] = 0.5,
					["strata"] = "LOW",
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
					},
					["switch_all_roles_in_combat"] = false,
					["hide_in_combat_alpha"] = 0,
					["micro_displays_locked"] = true,
					["grab_on_top"] = false,
					["libwindow"] = {
						["y"] = 0,
						["x"] = -324.1795654296875,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0.3777777777777,
						["overlay"] = {
							0.333333333333333, -- [1]
							0.333333333333333, -- [2]
							0.333333333333333, -- [3]
						},
					},
					["bg_alpha"] = 0.6,
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["switch_tank"] = false,
					["backdrop_texture"] = "Details Ground",
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["switch_damager_in_combat"] = false,
					["bars_grow_direction"] = 1,
					["show_statusbar"] = false,
					["auto_current"] = true,
					["fullborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["plugins_grow_direction"] = 1,
					["desaturated_menu"] = false,
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = -508.4871368408203,
							["x"] = 602.803466796875,
							["w"] = 246.5469818115234,
							["h"] = 164.5641784667969,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["__was_opened"] = true,
					["wallpaper"] = {
						["enabled"] = false,
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["height"] = 114.042518615723,
						["anchor"] = "all",
						["level"] = 2,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["titlebar_height"] = 16,
					["fontstrings_text_limit_offset"] = -10,
					["use_multi_fontstrings"] = true,
					["titlebar_texture_color"] = {
						0.2, -- [1]
						0.2, -- [2]
						0.2, -- [3]
						0.8, -- [4]
					},
				}, -- [1]
			},
			["overall_clear_pvp"] = true,
			["overall_clear_newboss"] = true,
			["capture_real"] = {
				["heal"] = true,
				["spellcast"] = true,
				["miscdata"] = true,
				["aura"] = true,
				["energy"] = true,
				["damage"] = true,
			},
			["skin"] = "Minimalistic",
			["override_spellids"] = true,
			["windows_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["minimum_combat_time"] = 5,
			["realtimedps_always_arena"] = false,
			["font_sizes"] = {
				["menus"] = 10,
			},
			["overall_clear_logout"] = false,
			["new_window_size"] = {
				["height"] = 158,
				["width"] = 310,
			},
			["cloud_capture"] = true,
			["damage_taken_everything"] = false,
			["scroll_speed"] = 2,
			["window_clamp"] = {
				-8, -- [1]
				0, -- [2]
				21, -- [3]
				-14, -- [4]
			},
			["chat_tab_embed"] = {
				["enabled"] = false,
				["y_offset"] = 0,
				["x_offset"] = 0,
				["tab_name"] = "",
				["single_window"] = false,
			},
			["deadlog_events"] = 32,
			["default_bg_color"] = 0.0941,
			["close_shields"] = false,
			["class_coords"] = {
				["HUNTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["WARRIOR"] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["SHAMAN"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["MAGE"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["PET"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["DRUID"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["MONK"] = {
					0.25, -- [1]
					0.369140625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["DEATHKNIGHT"] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["ROGUE"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["UNGROUPPLAYER"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["UNKNOW"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["PRIEST"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["MONSTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["Alliance"] = {
					0.248046875, -- [1]
					0.02968748, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["ENEMY"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["DEMONHUNTER"] = {
					0.36914063, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["Horde"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["WARLOCK"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["EVOKER"] = {
					0.50390625, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["PALADIN"] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
			},
			["hotcorner_topleft"] = {
				["hide"] = false,
			},
			["disable_alldisplays_window"] = false,
			["class_colors"] = {
				["HUNTER"] = {
					0.67, -- [1]
					0.83, -- [2]
					0.45, -- [3]
				},
				["WARRIOR"] = {
					0.78, -- [1]
					0.61, -- [2]
					0.43, -- [3]
				},
				["ROGUE"] = {
					1, -- [1]
					0.96, -- [2]
					0.41, -- [3]
				},
				["MAGE"] = {
					0.41, -- [1]
					0.8, -- [2]
					0.94, -- [3]
				},
				["ARENA_YELLOW"] = {
					1, -- [1]
					1, -- [2]
					0.25, -- [3]
				},
				["UNGROUPPLAYER"] = {
					0.4, -- [1]
					0.4, -- [2]
					0.4, -- [3]
				},
				["DRUID"] = {
					1, -- [1]
					0.49, -- [2]
					0.04, -- [3]
				},
				["MONK"] = {
					0, -- [1]
					1, -- [2]
					0.59, -- [3]
				},
				["DEATHKNIGHT"] = {
					0.77, -- [1]
					0.12, -- [2]
					0.23, -- [3]
				},
				["SELF"] = {
					0.89019, -- [1]
					0.32156, -- [2]
					0.89019, -- [3]
				},
				["PET"] = {
					0.3, -- [1]
					0.4, -- [2]
					0.5, -- [3]
				},
				["SHAMAN"] = {
					0, -- [1]
					0.44, -- [2]
					0.87, -- [3]
				},
				["UNKNOW"] = {
					0.2, -- [1]
					0.2, -- [2]
					0.2, -- [3]
				},
				["PRIEST"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
				},
				["ARENA_GREEN"] = {
					0.686, -- [1]
					0.372, -- [2]
					0.905, -- [3]
				},
				["ENEMY"] = {
					0.94117, -- [1]
					0, -- [2]
					0.0196, -- [3]
					1, -- [4]
				},
				["WARLOCK"] = {
					0.58, -- [1]
					0.51, -- [2]
					0.79, -- [3]
				},
				["DEMONHUNTER"] = {
					0.64, -- [1]
					0.19, -- [2]
					0.79, -- [3]
				},
				["version"] = 1,
				["NEUTRAL"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
				},
				["EVOKER"] = {
					0.2, -- [1]
					0.5764, -- [2]
					0.498, -- [3]
				},
				["PALADIN"] = {
					0.96, -- [1]
					0.55, -- [2]
					0.73, -- [3]
				},
			},
			["broadcaster_enabled"] = false,
			["total_abbreviation"] = 2,
			["segments_auto_erase"] = 1,
			["clear_graphic"] = true,
			["trash_auto_remove"] = false,
			["animation_speed_triggertravel"] = 5,
			["options_group_edit"] = true,
			["segments_amount_to_save"] = 40,
			["minimap"] = {
				["onclick_what_todo"] = 1,
				["radius"] = 160,
				["text_type"] = 1,
				["minimapPos"] = 220,
				["text_format"] = 3,
				["hide"] = false,
			},
			["instances_amount"] = 5,
			["max_window_size"] = {
				["height"] = 450,
				["width"] = 480,
			},
			["memory_threshold"] = 3,
			["only_pvp_frags"] = false,
			["disable_stretch_button"] = false,
			["color_by_arena_team"] = true,
			["use_scroll"] = false,
			["overall_flag"] = 16,
			["segments_panic_mode"] = false,
			["realtimedps_order_bars"] = false,
			["show_arena_role_icon"] = false,
			["row_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["numerical_system"] = 1,
			["time_type"] = 2,
			["update_speed"] = 0.2,
			["report_schema"] = 1,
			["numerical_system_symbols"] = "auto",
			["death_tooltip_texture"] = "Details Serenity",
			["disable_reset_button"] = false,
			["data_broker_text"] = "",
			["instances_no_libwindow"] = false,
			["instances_segments_locked"] = true,
			["deadlog_limit"] = 16,
			["death_log_colors"] = {
				["debuff"] = "purple",
				["buff"] = "silver",
				["friendlyfire"] = "darkorange",
				["heal"] = "green",
				["cooldown"] = "yellow",
				["damage"] = "red",
			},
		},
		["Gelosia-Mal'Ganis"] = {
			["overall_clear_newtorghast"] = true,
			["use_realtimedps"] = false,
			["row_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["streamer_config"] = {
				["faster_updates"] = false,
				["quick_detection"] = false,
				["reset_spec_cache"] = false,
				["no_alerts"] = false,
				["disable_mythic_dungeon"] = false,
				["use_animation_accel"] = true,
			},
			["all_players_are_group"] = false,
			["use_row_animations"] = true,
			["report_heal_links"] = false,
			["remove_realm_from_name"] = true,
			["minimum_overall_combat_time"] = 10,
			["event_tracker"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["show_crowdcontrol_pvm"] = false,
				["line_color"] = {
					0.1, -- [1]
					0.1, -- [2]
					0.1, -- [3]
					0.3, -- [4]
				},
				["font_shadow"] = "NONE",
				["font_size"] = 10,
				["font_face"] = "Friz Quadrata TT",
				["line_height"] = 16,
				["show_crowdcontrol_pvp"] = true,
				["frame"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0.1921, -- [1]
						0.1921, -- [2]
						0.1921, -- [3]
						0.3869, -- [4]
					},
					["locked"] = false,
					["height"] = 300,
					["width"] = 250,
				},
				["line_texture"] = "Details Serenity",
				["options_frame"] = {
				},
			},
			["report_to_who"] = "",
			["class_specs_coords"] = {
				[62] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[1467] = {
					0.5, -- [1]
					0.625, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[63] = {
					0.375, -- [1]
					0.5, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[250] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[251] = {
					0.125, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[252] = {
					0.25, -- [1]
					0.375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[1468] = {
					0.625, -- [1]
					0.75, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[253] = {
					0.875, -- [1]
					1, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[254] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[255] = {
					0.125, -- [1]
					0.25, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[66] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[257] = {
					0.5, -- [1]
					0.625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[258] = {
					0.6328125, -- [1]
					0.75, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[259] = {
					0.125, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[260] = {
					0, -- [1]
					0.125, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[577] = {
					0.25, -- [1]
					0.375, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[262] = {
					0.125, -- [1]
					0.25, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[581] = {
					0.375, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[264] = {
					0.375, -- [1]
					0.5, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[265] = {
					0.5, -- [1]
					0.625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[266] = {
					0.625, -- [1]
					0.75, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[267] = {
					0.75, -- [1]
					0.875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[268] = {
					0.625, -- [1]
					0.75, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[269] = {
					0.875, -- [1]
					1, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[270] = {
					0.75, -- [1]
					0.875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[70] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[102] = {
					0.375, -- [1]
					0.5, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[71] = {
					0.875, -- [1]
					1, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[103] = {
					0.5, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[72] = {
					0, -- [1]
					0.125, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[104] = {
					0.625, -- [1]
					0.75, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[1473] = {
					0.75, -- [1]
					0.875, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[73] = {
					0.125, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[263] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[105] = {
					0.75, -- [1]
					0.875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[261] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[256] = {
					0.375, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[65] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[64] = {
					0.5, -- [1]
					0.625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
			},
			["all_in_one_windows"] = {
			},
			["tooltip"] = {
				["tooltip_max_abilities"] = 6,
				["bar_color"] = {
					0.396, -- [1]
					0.396, -- [2]
					0.396, -- [3]
					0.87, -- [4]
				},
				["tooltip_max_pets"] = 2,
				["abbreviation"] = 2,
				["header_text_color"] = {
					1, -- [1]
					0.9176, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["background"] = {
					0.0941, -- [1]
					0.0941, -- [2]
					0.0941, -- [3]
					0.8, -- [4]
				},
				["divisor_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["fontshadow"] = false,
				["anchor_screen_pos"] = {
					507.7, -- [1]
					-350.5, -- [2]
				},
				["header_statusbar"] = {
					0.3, -- [1]
					0.3, -- [2]
					0.3, -- [3]
					0.8, -- [4]
					false, -- [5]
					false, -- [6]
					"WorldState Score", -- [7]
				},
				["fontcolor_right"] = {
					1, -- [1]
					0.7, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["line_height"] = 17,
				["tooltip_max_targets"] = 2,
				["icon_size"] = {
					["W"] = 17,
					["H"] = 17,
				},
				["anchor_relative"] = "top",
				["anchored_to"] = 1,
				["show_amount"] = false,
				["submenu_wallpaper"] = true,
				["fontsize_title"] = 10,
				["commands"] = {
				},
				["fontface"] = "Friz Quadrata TT",
				["border_color"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["border_texture"] = "Details BarBorder 3",
				["menus_bg_texture"] = "Interface\\SPELLBOOK\\Spellbook-Page-1",
				["fontcolor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["fontsize"] = 10,
				["border_size"] = 14,
				["maximize_method"] = 1,
				["anchor_offset"] = {
					0, -- [1]
					0, -- [2]
				},
				["anchor_point"] = "bottom",
				["menus_bg_coords"] = {
					0.309777336120606, -- [1]
					0.924000015258789, -- [2]
					0.213000011444092, -- [3]
					0.279000015258789, -- [4]
				},
				["icon_border_texcoord"] = {
					["R"] = 0.921875,
					["L"] = 0.078125,
					["T"] = 0.078125,
					["B"] = 0.921875,
				},
				["menus_bg_color"] = {
					0.8, -- [1]
					0.8, -- [2]
					0.8, -- [3]
					0.2, -- [4]
				},
			},
			["ps_abbreviation"] = 3,
			["world_combat_is_trash"] = false,
			["pvp_as_group"] = true,
			["bookmark_text_size"] = 11,
			["animation_speed_mintravel"] = 0.45,
			["track_item_level"] = false,
			["fade_speed"] = 0.15,
			["death_tooltip_spark"] = false,
			["windows_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["instances_menu_click_to_open"] = false,
			["overall_clear_newchallenge"] = true,
			["use_self_color"] = false,
			["data_cleanup_logout"] = false,
			["instances_disable_bar_highlight"] = false,
			["death_log_colors"] = {
				["debuff"] = "purple",
				["buff"] = "silver",
				["friendlyfire"] = "darkorange",
				["heal"] = "green",
				["cooldown"] = "yellow",
				["damage"] = "red",
			},
			["deadlog_limit"] = 16,
			["trash_concatenate"] = false,
			["deny_score_messages"] = false,
			["instances_segments_locked"] = true,
			["instances_no_libwindow"] = false,
			["animation_speed"] = 33,
			["data_broker_text"] = "",
			["standard_skin"] = false,
			["disable_lock_ungroup_buttons"] = false,
			["memory_ram"] = 64,
			["use_battleground_server_parser"] = false,
			["death_tooltip_width"] = 350,
			["disable_window_groups"] = false,
			["numerical_system_symbols"] = "auto",
			["report_schema"] = 1,
			["instances_suppress_trash"] = 0,
			["update_speed"] = 0.2,
			["options_window"] = {
				["scale"] = 1,
			},
			["animation_speed_maxtravel"] = 3,
			["time_type"] = 2,
			["numerical_system"] = 1,
			["font_faces"] = {
				["menus"] = "Friz Quadrata TT",
			},
			["row_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["show_arena_role_icon"] = false,
			["overall_clear_pvp"] = true,
			["segments_amount"] = 40,
			["report_lines"] = 5,
			["overall_clear_newboss"] = true,
			["overall_flag"] = 16,
			["skin"] = "Minimalistic",
			["override_spellids"] = true,
			["use_scroll"] = false,
			["color_by_arena_team"] = true,
			["overall_clear_logout"] = false,
			["new_window_size"] = {
				["height"] = 158,
				["width"] = 310,
			},
			["minimum_combat_time"] = 5,
			["memory_threshold"] = 3,
			["cloud_capture"] = true,
			["damage_taken_everything"] = false,
			["scroll_speed"] = 2,
			["font_sizes"] = {
				["menus"] = 10,
			},
			["chat_tab_embed"] = {
				["enabled"] = false,
				["y_offset"] = 0,
				["x_offset"] = 0,
				["tab_name"] = "",
				["single_window"] = false,
			},
			["deadlog_events"] = 32,
			["default_bg_color"] = 0.0941,
			["close_shields"] = false,
			["class_coords"] = {
				["HUNTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["WARRIOR"] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["SHAMAN"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["MAGE"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["PET"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["DRUID"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["MONK"] = {
					0.25, -- [1]
					0.369140625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["DEATHKNIGHT"] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["UNGROUPPLAYER"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["PALADIN"] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["UNKNOW"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["PRIEST"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["ROGUE"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["Alliance"] = {
					0.248046875, -- [1]
					0.02968748, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["WARLOCK"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["DEMONHUNTER"] = {
					0.36914063, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["Horde"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["ENEMY"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["EVOKER"] = {
					0.50390625, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["MONSTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
			},
			["class_colors"] = {
				["HUNTER"] = {
					0.67, -- [1]
					0.83, -- [2]
					0.45, -- [3]
				},
				["WARRIOR"] = {
					0.78, -- [1]
					0.61, -- [2]
					0.43, -- [3]
				},
				["SHAMAN"] = {
					0, -- [1]
					0.44, -- [2]
					0.87, -- [3]
				},
				["MAGE"] = {
					0.41, -- [1]
					0.8, -- [2]
					0.94, -- [3]
				},
				["ARENA_YELLOW"] = {
					1, -- [1]
					1, -- [2]
					0.25, -- [3]
				},
				["UNGROUPPLAYER"] = {
					0.4, -- [1]
					0.4, -- [2]
					0.4, -- [3]
				},
				["DRUID"] = {
					1, -- [1]
					0.49, -- [2]
					0.04, -- [3]
				},
				["MONK"] = {
					0, -- [1]
					1, -- [2]
					0.59, -- [3]
				},
				["DEATHKNIGHT"] = {
					0.77, -- [1]
					0.12, -- [2]
					0.23, -- [3]
				},
				["PALADIN"] = {
					0.96, -- [1]
					0.55, -- [2]
					0.73, -- [3]
				},
				["ARENA_GREEN"] = {
					0.686, -- [1]
					0.372, -- [2]
					0.905, -- [3]
				},
				["ROGUE"] = {
					1, -- [1]
					0.96, -- [2]
					0.41, -- [3]
				},
				["UNKNOW"] = {
					0.2, -- [1]
					0.2, -- [2]
					0.2, -- [3]
				},
				["PRIEST"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
				},
				["WARLOCK"] = {
					0.58, -- [1]
					0.51, -- [2]
					0.79, -- [3]
				},
				["version"] = 1,
				["ENEMY"] = {
					0.94117, -- [1]
					0, -- [2]
					0.0196, -- [3]
					1, -- [4]
				},
				["DEMONHUNTER"] = {
					0.64, -- [1]
					0.19, -- [2]
					0.79, -- [3]
				},
				["PET"] = {
					0.3, -- [1]
					0.4, -- [2]
					0.5, -- [3]
				},
				["NEUTRAL"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
				},
				["EVOKER"] = {
					0.2, -- [1]
					0.5764, -- [2]
					0.498, -- [3]
				},
				["SELF"] = {
					0.89019, -- [1]
					0.32156, -- [2]
					0.89019, -- [3]
				},
			},
			["disable_alldisplays_window"] = false,
			["total_abbreviation"] = 2,
			["segments_amount_to_save"] = 40,
			["trash_auto_remove"] = false,
			["animation_speed_triggertravel"] = 5,
			["clear_graphic"] = true,
			["hotcorner_topleft"] = {
				["hide"] = false,
			},
			["segments_auto_erase"] = 1,
			["options_group_edit"] = true,
			["broadcaster_enabled"] = false,
			["minimap"] = {
				["onclick_what_todo"] = 1,
				["radius"] = 160,
				["hide"] = false,
				["minimapPos"] = 220,
				["text_format"] = 3,
				["text_type"] = 1,
			},
			["instances_amount"] = 5,
			["max_window_size"] = {
				["height"] = 450,
				["width"] = 480,
			},
			["window_clamp"] = {
				-8, -- [1]
				0, -- [2]
				21, -- [3]
				-14, -- [4]
			},
			["only_pvp_frags"] = false,
			["disable_stretch_button"] = false,
			["realtimedps_always_arena"] = false,
			["windows_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["capture_real"] = {
				["heal"] = true,
				["spellcast"] = true,
				["miscdata"] = true,
				["aura"] = true,
				["energy"] = true,
				["damage"] = true,
			},
			["segments_panic_mode"] = false,
			["realtimedps_order_bars"] = false,
			["instances"] = {
				{
					["__pos"] = {
						["normal"] = {
							["y"] = -540.2132339477539,
							["x"] = 561.7772216796875,
							["w"] = 208.2562408447266,
							["h"] = 96.7350845336914,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["show_statusbar"] = false,
					["menu_icons_size"] = 0.82,
					["titlebar_shown"] = false,
					["menu_anchor"] = {
						20, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.243,
					["fullborder_size"] = 0.5,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons_2_shadow",
					["skin_custom"] = "",
					["use_auto_align_multi_fontstrings"] = true,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["switch_all_roles_in_combat"] = false,
					["clickthrough_toolbaricons"] = false,
					["row_info"] = {
						["textR_outline"] = false,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = false,
						["textR_outline_small"] = true,
						["textL_outline_small"] = true,
						["show_faction_icon"] = true,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["textL_offset"] = 0,
						["text_yoffset"] = 0,
						["texture_background_class_color"] = false,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["font_face_file"] = "Interface\\Addons\\Details\\fonts\\Accidental Presidency.ttf",
						["faction_icon_size_offset"] = -10,
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["font_size"] = 16,
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
						["start_after_icon"] = true,
						["texture_custom_file"] = "Interface\\",
						["textL_translit_text"] = false,
						["height"] = 21,
						["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_hyanda",
						["icon_size_offset"] = 0,
						["percent_type"] = 1,
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["overlay_color"] = {
							0.7, -- [1]
							0.7, -- [2]
							0.7, -- [3]
							0, -- [4]
						},
						["show_arena_role_icon"] = false,
						["arena_role_icon_size_offset"] = -10,
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
						["icon_grayscale"] = false,
						["texture_custom"] = "",
						["use_spec_icons"] = true,
						["textR_enable_custom_text"] = false,
						["textL_class_colors"] = false,
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["alpha"] = 1,
						["texture_background"] = "Details D'ictum (reverse)",
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "Details Hyanda",
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 1,
						},
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.150228589773178, -- [4]
						},
						["overlay_texture"] = "Details D'ictum",
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar4_reverse",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["textR_class_colors"] = false,
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["textR_bracket"] = "(",
						["font_face"] = "Accidental Presidency",
						["texture_class_colors"] = true,
						["textL_enable_custom_text"] = false,
						["fast_ps_update"] = false,
						["textR_separator"] = "NONE",
						["backdrop"] = {
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["texture"] = "Details BarBorder 2",
							["enabled"] = false,
							["size"] = 12,
						},
					},
					["titlebar_texture"] = "Details Serenity",
					["switch_tank"] = false,
					["plugins_grow_direction"] = 1,
					["icon_desaturated"] = false,
					["switch_damager"] = false,
					["micro_displays_side"] = 2,
					["window_scale"] = 1,
					["hide_icon"] = false,
					["toolbar_side"] = 1,
					["fullborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["menu_icons_alpha"] = 0.92,
					["bg_b"] = 0.2588,
					["switch_healer_in_combat"] = false,
					["color"] = {
						0.1215, -- [1]
						0.1176, -- [2]
						0.1294, -- [3]
						0.91, -- [4]
					},
					["hide_on_context"] = {
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [1]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [2]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [3]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [4]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [5]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [6]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [7]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [8]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [9]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [10]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [11]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [12]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [13]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [14]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [15]
					},
					["rowareaborder_shown"] = false,
					["menu_icons_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["skin"] = "Minimalistic",
					["backdrop_texture"] = "Details Ground",
					["following"] = {
						["enabled"] = false,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["fontstrings_text3_anchor"] = 38,
					["switch_healer"] = false,
					["fontstrings_text2_anchor"] = 73,
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["__was_opened"] = true,
					["fontstrings_text_limit_offset"] = -10,
					["clickthrough_window"] = false,
					["clickthrough_rows"] = false,
					["StatusBarSaved"] = {
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["textYMod"] = 1,
								["textXMod"] = 0,
								["textFace"] = "Accidental Presidency",
								["textStyle"] = 2,
								["textAlign"] = 3,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["textYMod"] = 1,
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textXMod"] = 0,
								["textStyle"] = 2,
								["textAlign"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["textYMod"] = 1,
								["textXMod"] = 6,
								["textFace"] = "Accidental Presidency",
								["timeType"] = 1,
								["textStyle"] = 2,
								["textAlign"] = 2,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
						},
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
					},
					["fullborder_shown"] = false,
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["switch_tank_in_combat"] = false,
					["version"] = 3,
					["fontstrings_text4_anchor"] = 0,
					["__locked"] = false,
					["menu_alpha"] = {
						["enabled"] = false,
						["onleave"] = 1,
						["ignorebars"] = false,
						["iconstoo"] = true,
						["onenter"] = 1,
					},
					["bg_alpha"] = 0.6,
					["bars_sort_direction"] = 1,
					["micro_displays_locked"] = true,
					["rowareaborder_size"] = 0.5,
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
					},
					["ignore_mass_showhide"] = false,
					["hide_in_combat_alpha"] = 0,
					["attribute_text"] = {
						["enabled"] = true,
						["shadow"] = false,
						["side"] = 1,
						["text_size"] = 12,
						["custom_text"] = "{name}",
						["show_timer_arena"] = true,
						["text_face"] = "Accidental Presidency",
						["show_timer_always"] = true,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = {
							1.4, -- [1]
							2, -- [2]
						},
						["show_timer"] = true,
						["enable_custom_text"] = false,
						["show_timer_bg"] = true,
					},
					["grab_on_top"] = false,
					["libwindow"] = {
						["y"] = 2.188445806503296,
						["x"] = -384.35107421875,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0.3777777777777,
						["overlay"] = {
							0.333333333333333, -- [1]
							0.333333333333333, -- [2]
							0.333333333333333, -- [3]
						},
					},
					["strata"] = "LOW",
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["rowareaborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["hide_in_combat_type"] = 1,
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["switch_damager_in_combat"] = false,
					["bars_grow_direction"] = 1,
					["switch_all_roles_after_wipe"] = false,
					["auto_current"] = true,
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["desaturated_menu"] = false,
					["bg_g"] = 0.2352,
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = -540.2132339477539,
							["x"] = 561.7772216796875,
							["w"] = 208.2562408447266,
							["h"] = 96.7350845336914,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["menu_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						true, -- [5]
						false, -- [6]
						["space"] = -2,
						["shadow"] = false,
					},
					["bars_inverted"] = false,
					["wallpaper"] = {
						["enabled"] = false,
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["anchor"] = "all",
						["height"] = 114.042518615723,
						["level"] = 2,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["stretch_button_side"] = 1,
					["titlebar_height"] = 16,
					["show_sidebars"] = false,
					["use_multi_fontstrings"] = true,
					["titlebar_texture_color"] = {
						0.2, -- [1]
						0.2, -- [2]
						0.2, -- [3]
						0.8, -- [4]
					},
				}, -- [1]
			},
			["auto_swap_to_dynamic_overall"] = false,
			["player_details_window"] = {
				["scale"] = 1,
				["skin"] = "ElvUI",
				["bar_texture"] = "Skyline",
			},
			["time_type_original"] = 2,
			["class_icons_small"] = "Interface\\AddOns\\Details\\images\\classes_small",
			["force_activity_time_pvp"] = true,
			["clear_ungrouped"] = true,
			["death_tooltip_texture"] = "Details Serenity",
			["disable_reset_button"] = false,
			["animate_scroll"] = false,
			["realtime_dps_meter"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["arena_enabled"] = true,
				["font_shadow"] = "NONE",
				["font_size"] = 18,
				["mythic_dungeon_enabled"] = false,
				["sample_size"] = 3,
				["frame_settings"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["point"] = "TOP",
					["scale"] = 1,
					["width"] = 300,
					["y"] = -110,
					["x"] = 0,
					["backdrop_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.2, -- [4]
					},
					["locked"] = true,
					["height"] = 23,
				},
				["font_face"] = "Friz Quadrata TT",
				["text_offset"] = 2,
				["update_interval"] = 0.3,
				["options_frame"] = {
				},
			},
			["disable_stretch_from_toolbar"] = false,
			["default_bg_alpha"] = 0.5,
			["profile_save_pos"] = true,
		},
		["Allaeda-Mal'Ganis"] = {
			["overall_clear_newtorghast"] = true,
			["use_realtimedps"] = false,
			["row_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["streamer_config"] = {
				["faster_updates"] = false,
				["quick_detection"] = false,
				["reset_spec_cache"] = false,
				["no_alerts"] = false,
				["disable_mythic_dungeon"] = false,
				["use_animation_accel"] = true,
			},
			["all_players_are_group"] = false,
			["use_row_animations"] = true,
			["report_heal_links"] = false,
			["remove_realm_from_name"] = true,
			["minimum_overall_combat_time"] = 10,
			["event_tracker"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["show_crowdcontrol_pvm"] = false,
				["line_color"] = {
					0.1, -- [1]
					0.1, -- [2]
					0.1, -- [3]
					0.3, -- [4]
				},
				["font_shadow"] = "NONE",
				["font_size"] = 10,
				["font_face"] = "Friz Quadrata TT",
				["line_height"] = 16,
				["show_crowdcontrol_pvp"] = true,
				["frame"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0.1921, -- [1]
						0.1921, -- [2]
						0.1921, -- [3]
						0.3869, -- [4]
					},
					["locked"] = false,
					["height"] = 300,
					["width"] = 250,
				},
				["line_texture"] = "Details Serenity",
				["options_frame"] = {
				},
			},
			["report_to_who"] = "",
			["class_specs_coords"] = {
				[62] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[1467] = {
					0.5, -- [1]
					0.625, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[63] = {
					0.375, -- [1]
					0.5, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[250] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[251] = {
					0.125, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[252] = {
					0.25, -- [1]
					0.375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[1468] = {
					0.625, -- [1]
					0.75, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[253] = {
					0.875, -- [1]
					1, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[254] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[255] = {
					0.125, -- [1]
					0.25, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[66] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[257] = {
					0.5, -- [1]
					0.625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[258] = {
					0.6328125, -- [1]
					0.75, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[259] = {
					0.125, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[260] = {
					0, -- [1]
					0.125, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[577] = {
					0.25, -- [1]
					0.375, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[262] = {
					0.125, -- [1]
					0.25, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[581] = {
					0.375, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[264] = {
					0.375, -- [1]
					0.5, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[265] = {
					0.5, -- [1]
					0.625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[266] = {
					0.625, -- [1]
					0.75, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[267] = {
					0.75, -- [1]
					0.875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[268] = {
					0.625, -- [1]
					0.75, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[269] = {
					0.875, -- [1]
					1, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[270] = {
					0.75, -- [1]
					0.875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[70] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[102] = {
					0.375, -- [1]
					0.5, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[71] = {
					0.875, -- [1]
					1, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[103] = {
					0.5, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[72] = {
					0, -- [1]
					0.125, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[104] = {
					0.625, -- [1]
					0.75, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[64] = {
					0.5, -- [1]
					0.625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[73] = {
					0.125, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[65] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[105] = {
					0.75, -- [1]
					0.875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[256] = {
					0.375, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[261] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[263] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[1473] = {
					0.75, -- [1]
					0.875, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
			},
			["all_in_one_windows"] = {
			},
			["tooltip"] = {
				["tooltip_max_abilities"] = 6,
				["bar_color"] = {
					0.396, -- [1]
					0.396, -- [2]
					0.396, -- [3]
					0.87, -- [4]
				},
				["tooltip_max_pets"] = 2,
				["abbreviation"] = 2,
				["header_text_color"] = {
					1, -- [1]
					0.9176, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["background"] = {
					0.0941, -- [1]
					0.0941, -- [2]
					0.0941, -- [3]
					0.8, -- [4]
				},
				["divisor_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["fontshadow"] = false,
				["anchor_screen_pos"] = {
					507.7, -- [1]
					-350.5, -- [2]
				},
				["header_statusbar"] = {
					0.3, -- [1]
					0.3, -- [2]
					0.3, -- [3]
					0.8, -- [4]
					false, -- [5]
					false, -- [6]
					"WorldState Score", -- [7]
				},
				["fontcolor_right"] = {
					1, -- [1]
					0.7, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["line_height"] = 17,
				["tooltip_max_targets"] = 2,
				["icon_size"] = {
					["W"] = 17,
					["H"] = 17,
				},
				["anchor_relative"] = "top",
				["anchored_to"] = 1,
				["show_amount"] = false,
				["submenu_wallpaper"] = true,
				["fontsize_title"] = 10,
				["commands"] = {
				},
				["fontface"] = "Friz Quadrata TT",
				["border_color"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["border_texture"] = "Details BarBorder 3",
				["menus_bg_texture"] = "Interface\\SPELLBOOK\\Spellbook-Page-1",
				["fontcolor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["fontsize"] = 10,
				["border_size"] = 14,
				["maximize_method"] = 1,
				["anchor_offset"] = {
					0, -- [1]
					0, -- [2]
				},
				["anchor_point"] = "bottom",
				["menus_bg_coords"] = {
					0.309777336120606, -- [1]
					0.924000015258789, -- [2]
					0.213000011444092, -- [3]
					0.279000015258789, -- [4]
				},
				["icon_border_texcoord"] = {
					["R"] = 0.921875,
					["L"] = 0.078125,
					["T"] = 0.078125,
					["B"] = 0.921875,
				},
				["menus_bg_color"] = {
					0.8, -- [1]
					0.8, -- [2]
					0.8, -- [3]
					0.2, -- [4]
				},
			},
			["ps_abbreviation"] = 3,
			["world_combat_is_trash"] = false,
			["pvp_as_group"] = true,
			["bookmark_text_size"] = 11,
			["animation_speed_mintravel"] = 0.45,
			["track_item_level"] = false,
			["fade_speed"] = 0.15,
			["death_tooltip_spark"] = false,
			["windows_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["instances_menu_click_to_open"] = false,
			["overall_clear_newchallenge"] = true,
			["use_self_color"] = false,
			["data_cleanup_logout"] = false,
			["instances_disable_bar_highlight"] = false,
			["death_log_colors"] = {
				["debuff"] = "purple",
				["buff"] = "silver",
				["friendlyfire"] = "darkorange",
				["heal"] = "green",
				["cooldown"] = "yellow",
				["damage"] = "red",
			},
			["deadlog_limit"] = 16,
			["trash_concatenate"] = false,
			["deny_score_messages"] = false,
			["instances_segments_locked"] = true,
			["instances_no_libwindow"] = false,
			["animation_speed"] = 33,
			["data_broker_text"] = "",
			["disable_stretch_from_toolbar"] = false,
			["realtime_dps_meter"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["arena_enabled"] = true,
				["font_shadow"] = "NONE",
				["font_size"] = 18,
				["mythic_dungeon_enabled"] = false,
				["sample_size"] = 3,
				["frame_settings"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["point"] = "TOP",
					["scale"] = 1,
					["width"] = 300,
					["y"] = -110,
					["x"] = 0,
					["backdrop_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.2, -- [4]
					},
					["locked"] = true,
					["height"] = 23,
				},
				["font_face"] = "Friz Quadrata TT",
				["text_offset"] = 2,
				["update_interval"] = 0.3,
				["options_frame"] = {
				},
			},
			["memory_ram"] = 64,
			["use_battleground_server_parser"] = false,
			["death_tooltip_width"] = 350,
			["disable_window_groups"] = false,
			["numerical_system_symbols"] = "auto",
			["report_schema"] = 1,
			["instances_suppress_trash"] = 0,
			["update_speed"] = 0.2,
			["options_window"] = {
				["scale"] = 1,
			},
			["animation_speed_maxtravel"] = 3,
			["time_type"] = 2,
			["numerical_system"] = 1,
			["font_faces"] = {
				["menus"] = "Friz Quadrata TT",
			},
			["row_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["show_arena_role_icon"] = false,
			["overall_clear_pvp"] = true,
			["instances"] = {
				{
					["__pos"] = {
						["normal"] = {
							["y"] = -527.3162841796875,
							["x"] = 624.68310546875,
							["w"] = 180.9060363769531,
							["h"] = 125.1796112060547,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["show_statusbar"] = false,
					["menu_icons_size"] = 0.82,
					["titlebar_shown"] = false,
					["menu_anchor"] = {
						20, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.243,
					["fullborder_size"] = 0.5,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons_2_shadow",
					["skin_custom"] = "",
					["use_auto_align_multi_fontstrings"] = true,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["switch_all_roles_in_combat"] = false,
					["clickthrough_toolbaricons"] = false,
					["row_info"] = {
						["textR_outline"] = false,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = false,
						["textR_outline_small"] = true,
						["textL_outline_small"] = true,
						["show_faction_icon"] = true,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["textL_offset"] = 0,
						["text_yoffset"] = 0,
						["texture_background_class_color"] = false,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["font_face_file"] = "Interface\\Addons\\Details\\fonts\\Accidental Presidency.ttf",
						["faction_icon_size_offset"] = -10,
						["backdrop"] = {
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["texture"] = "Details BarBorder 2",
							["enabled"] = false,
							["size"] = 12,
						},
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["font_size"] = 16,
						["start_after_icon"] = true,
						["height"] = 21,
						["textL_translit_text"] = false,
						["texture_custom_file"] = "Interface\\",
						["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_hyanda",
						["icon_size_offset"] = 0,
						["percent_type"] = 1,
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["overlay_color"] = {
							0.7, -- [1]
							0.7, -- [2]
							0.7, -- [3]
							0, -- [4]
						},
						["show_arena_role_icon"] = false,
						["use_spec_icons"] = true,
						["arena_role_icon_size_offset"] = -10,
						["icon_grayscale"] = false,
						["texture_custom"] = "",
						["textR_bracket"] = "(",
						["textR_enable_custom_text"] = false,
						["texture_background"] = "Details D'ictum (reverse)",
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["alpha"] = 1,
						["textR_class_colors"] = false,
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "Details Hyanda",
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 1,
						},
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.150228589773178, -- [4]
						},
						["overlay_texture"] = "Details D'ictum",
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar4_reverse",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["textL_class_colors"] = false,
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
						["font_face"] = "Accidental Presidency",
						["texture_class_colors"] = true,
						["textL_enable_custom_text"] = false,
						["fast_ps_update"] = false,
						["textR_separator"] = "NONE",
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
					},
					["titlebar_texture"] = "Details Serenity",
					["switch_tank"] = false,
					["plugins_grow_direction"] = 1,
					["icon_desaturated"] = false,
					["switch_damager"] = false,
					["micro_displays_side"] = 2,
					["window_scale"] = 1,
					["hide_icon"] = false,
					["toolbar_side"] = 1,
					["fullborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["menu_icons_alpha"] = 0.92,
					["bg_b"] = 0.2588,
					["switch_healer_in_combat"] = false,
					["color"] = {
						0.1215, -- [1]
						0.1176, -- [2]
						0.1294, -- [3]
						0.91, -- [4]
					},
					["hide_on_context"] = {
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [1]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [2]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [3]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [4]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [5]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [6]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [7]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [8]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [9]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [10]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [11]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [12]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [13]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [14]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [15]
					},
					["rowareaborder_shown"] = false,
					["use_multi_fontstrings"] = true,
					["skin"] = "Minimalistic",
					["show_sidebars"] = false,
					["following"] = {
						["enabled"] = false,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["fontstrings_text3_anchor"] = 38,
					["switch_healer"] = false,
					["fontstrings_text2_anchor"] = 73,
					["stretch_button_side"] = 1,
					["__was_opened"] = true,
					["bars_inverted"] = false,
					["menu_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						true, -- [5]
						false, -- [6]
						["space"] = -2,
						["shadow"] = false,
					},
					["clickthrough_rows"] = false,
					["StatusBarSaved"] = {
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["textXMod"] = 0,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 3,
								["textStyle"] = 2,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textXMod"] = 0,
								["textAlign"] = 1,
								["textStyle"] = 2,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["textFace"] = "Accidental Presidency",
								["textXMod"] = 6,
								["textAlign"] = 2,
								["textStyle"] = 2,
								["timeType"] = 1,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
						},
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
					},
					["fullborder_shown"] = false,
					["bg_g"] = 0.2352,
					["switch_tank_in_combat"] = false,
					["version"] = 3,
					["fontstrings_text4_anchor"] = 0,
					["__locked"] = false,
					["menu_alpha"] = {
						["enabled"] = false,
						["onleave"] = 1,
						["ignorebars"] = false,
						["iconstoo"] = true,
						["onenter"] = 1,
					},
					["desaturated_menu"] = false,
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["micro_displays_locked"] = true,
					["rowareaborder_size"] = 0.5,
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
					},
					["switch_all_roles_after_wipe"] = false,
					["hide_in_combat_alpha"] = 0,
					["bars_grow_direction"] = 1,
					["switch_damager_in_combat"] = false,
					["libwindow"] = {
						["y"] = 0.8631376624107361,
						["x"] = -335.1202392578125,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0.3777777777777,
						["overlay"] = {
							0.333333333333333, -- [1]
							0.333333333333333, -- [2]
							0.333333333333333, -- [3]
						},
					},
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["hide_in_combat_type"] = 1,
					["rowareaborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["strata"] = "LOW",
					["grab_on_top"] = false,
					["attribute_text"] = {
						["enabled"] = true,
						["shadow"] = false,
						["side"] = 1,
						["text_size"] = 12,
						["custom_text"] = "{name}",
						["show_timer_arena"] = true,
						["text_face"] = "Accidental Presidency",
						["show_timer_always"] = true,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = {
							1.4, -- [1]
							2, -- [2]
						},
						["show_timer"] = true,
						["enable_custom_text"] = false,
						["show_timer_bg"] = true,
					},
					["ignore_mass_showhide"] = false,
					["auto_current"] = true,
					["bars_sort_direction"] = 1,
					["bg_alpha"] = 0.6,
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = -527.3162841796875,
							["x"] = 624.68310546875,
							["w"] = 180.9060363769531,
							["h"] = 125.1796112060547,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["clickthrough_window"] = false,
					["fontstrings_text_limit_offset"] = -10,
					["wallpaper"] = {
						["enabled"] = false,
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["anchor"] = "all",
						["height"] = 114.042518615723,
						["level"] = 2,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["titlebar_height"] = 16,
					["backdrop_texture"] = "Details Ground",
					["menu_icons_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["titlebar_texture_color"] = {
						0.2, -- [1]
						0.2, -- [2]
						0.2, -- [3]
						0.8, -- [4]
					},
				}, -- [1]
			},
			["report_lines"] = 5,
			["overall_clear_newboss"] = true,
			["overall_flag"] = 16,
			["skin"] = "Minimalistic",
			["override_spellids"] = true,
			["use_scroll"] = false,
			["color_by_arena_team"] = true,
			["overall_clear_logout"] = false,
			["window_clamp"] = {
				-8, -- [1]
				0, -- [2]
				21, -- [3]
				-14, -- [4]
			},
			["realtimedps_always_arena"] = false,
			["chat_tab_embed"] = {
				["enabled"] = false,
				["y_offset"] = 0,
				["x_offset"] = 0,
				["tab_name"] = "",
				["single_window"] = false,
			},
			["cloud_capture"] = true,
			["damage_taken_everything"] = false,
			["scroll_speed"] = 2,
			["font_sizes"] = {
				["menus"] = 10,
			},
			["memory_threshold"] = 3,
			["deadlog_events"] = 32,
			["default_bg_color"] = 0.0941,
			["close_shields"] = false,
			["class_coords"] = {
				["HUNTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["WARRIOR"] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["SHAMAN"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["MAGE"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["PET"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["DRUID"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["MONK"] = {
					0.25, -- [1]
					0.369140625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["DEATHKNIGHT"] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["UNGROUPPLAYER"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["ROGUE"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["UNKNOW"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["PRIEST"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["ENEMY"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["Alliance"] = {
					0.248046875, -- [1]
					0.02968748, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["WARLOCK"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["DEMONHUNTER"] = {
					0.36914063, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["Horde"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["PALADIN"] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["EVOKER"] = {
					0.50390625, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["MONSTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
			},
			["trash_auto_remove"] = false,
			["disable_alldisplays_window"] = false,
			["hotcorner_topleft"] = {
				["hide"] = false,
			},
			["segments_amount_to_save"] = 40,
			["class_colors"] = {
				["HUNTER"] = {
					0.67, -- [1]
					0.83, -- [2]
					0.45, -- [3]
				},
				["WARRIOR"] = {
					0.78, -- [1]
					0.61, -- [2]
					0.43, -- [3]
				},
				["PALADIN"] = {
					0.96, -- [1]
					0.55, -- [2]
					0.73, -- [3]
				},
				["MAGE"] = {
					0.41, -- [1]
					0.8, -- [2]
					0.94, -- [3]
				},
				["ARENA_YELLOW"] = {
					1, -- [1]
					1, -- [2]
					0.25, -- [3]
				},
				["UNGROUPPLAYER"] = {
					0.4, -- [1]
					0.4, -- [2]
					0.4, -- [3]
				},
				["DRUID"] = {
					1, -- [1]
					0.49, -- [2]
					0.04, -- [3]
				},
				["MONK"] = {
					0, -- [1]
					1, -- [2]
					0.59, -- [3]
				},
				["DEATHKNIGHT"] = {
					0.77, -- [1]
					0.12, -- [2]
					0.23, -- [3]
				},
				["ROGUE"] = {
					1, -- [1]
					0.96, -- [2]
					0.41, -- [3]
				},
				["ARENA_GREEN"] = {
					0.686, -- [1]
					0.372, -- [2]
					0.905, -- [3]
				},
				["SHAMAN"] = {
					0, -- [1]
					0.44, -- [2]
					0.87, -- [3]
				},
				["UNKNOW"] = {
					0.2, -- [1]
					0.2, -- [2]
					0.2, -- [3]
				},
				["PRIEST"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
				},
				["version"] = 1,
				["WARLOCK"] = {
					0.58, -- [1]
					0.51, -- [2]
					0.79, -- [3]
				},
				["ENEMY"] = {
					0.94117, -- [1]
					0, -- [2]
					0.0196, -- [3]
					1, -- [4]
				},
				["DEMONHUNTER"] = {
					0.64, -- [1]
					0.19, -- [2]
					0.79, -- [3]
				},
				["PET"] = {
					0.3, -- [1]
					0.4, -- [2]
					0.5, -- [3]
				},
				["NEUTRAL"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
				},
				["EVOKER"] = {
					0.2, -- [1]
					0.5764, -- [2]
					0.498, -- [3]
				},
				["SELF"] = {
					0.89019, -- [1]
					0.32156, -- [2]
					0.89019, -- [3]
				},
			},
			["animation_speed_triggertravel"] = 5,
			["clear_graphic"] = true,
			["total_abbreviation"] = 2,
			["segments_auto_erase"] = 1,
			["options_group_edit"] = true,
			["broadcaster_enabled"] = false,
			["minimap"] = {
				["onclick_what_todo"] = 1,
				["radius"] = 160,
				["hide"] = false,
				["minimapPos"] = 220,
				["text_format"] = 3,
				["text_type"] = 1,
			},
			["instances_amount"] = 5,
			["max_window_size"] = {
				["height"] = 450,
				["width"] = 480,
			},
			["new_window_size"] = {
				["height"] = 158,
				["width"] = 310,
			},
			["only_pvp_frags"] = false,
			["disable_stretch_button"] = false,
			["minimum_combat_time"] = 5,
			["windows_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["capture_real"] = {
				["heal"] = true,
				["spellcast"] = true,
				["miscdata"] = true,
				["aura"] = true,
				["energy"] = true,
				["damage"] = true,
			},
			["segments_panic_mode"] = false,
			["realtimedps_order_bars"] = false,
			["segments_amount"] = 40,
			["auto_swap_to_dynamic_overall"] = false,
			["player_details_window"] = {
				["scale"] = 1,
				["skin"] = "ElvUI",
				["bar_texture"] = "Skyline",
			},
			["time_type_original"] = 2,
			["class_icons_small"] = "Interface\\AddOns\\Details\\images\\classes_small",
			["force_activity_time_pvp"] = true,
			["clear_ungrouped"] = true,
			["death_tooltip_texture"] = "Details Serenity",
			["disable_reset_button"] = false,
			["animate_scroll"] = false,
			["disable_lock_ungroup_buttons"] = false,
			["standard_skin"] = false,
			["default_bg_alpha"] = 0.5,
			["profile_save_pos"] = true,
		},
	},
	["immersion_special_units"] = true,
	["latest_spell_pool_access"] = 1695698514,
	["boss_mods_timers"] = {
		["encounter_timers_bw"] = {
		},
		["latest_boss_mods_access"] = 1695700115,
		["encounter_timers_dbm"] = {
			["402994"] = {
				"402994", -- [1]
				"Timer402994cdcount	1", -- [2]
				"Lava Pools (1)", -- [3]
				16.6, -- [4]
				135810, -- [5]
				"cd", -- [6]
				402994, -- [7]
				3, -- [8]
				"2527", -- [9]
				["id"] = 2683,
			},
			["404382"] = {
				"404382", -- [1]
				"timerGuardsandHuntsmanCD	1-South", -- [2]
				"Big Adds (1-South)", -- [3]
				40, -- [4]
				2032595, -- [5]
				"cd", -- [6]
				404382, -- [7]
				1, -- [8]
				"2524", -- [9]
				["id"] = 2682,
			},
			["405437"] = {
				"405437", -- [1]
				"Timer405437cdcount	1", -- [2]
				"Gloom Conflagration (1)", -- [3]
				50, -- [4]
				4914678, -- [5]
				"cd", -- [6]
				405437, -- [7]
				3, -- [8]
				"2529", -- [9]
				["id"] = 2687,
			},
			["403741"] = {
				"403741", -- [1]
				"Timer403741cdcount	1", -- [2]
				"Ascension (1)", -- [3]
				7.2, -- [4]
				608955, -- [5]
				"cd", -- [6]
				403741, -- [7]
				1, -- [8]
				"2520", -- [9]
				["id"] = 2685,
			},
			["403699"] = {
				"403699", -- [1]
				"Timer403699cdcount	1", -- [2]
				"Shadow Spike (1)", -- [3]
				9.3, -- [4]
				1035040, -- [5]
				"cd", -- [6]
				403699, -- [7]
				5, -- [8]
				"2529", -- [9]
				["id"] = 2687,
			},
			["404027"] = {
				"404027", -- [1]
				"Timer404027cdcount	1", -- [2]
				"Bombs (1)", -- [3]
				17.3, -- [4]
				132886, -- [5]
				"cd", -- [6]
				404027, -- [7]
				3, -- [8]
				"2520", -- [9]
				["id"] = 2685,
			},
			["397383"] = {
				"397383", -- [1]
				"Timer397383cdcount	1", -- [2]
				"Molten Barrier (1)", -- [3]
				20, -- [4]
				134337, -- [5]
				"cd", -- [6]
				397383, -- [7]
				1, -- [8]
				"2524", -- [9]
				["id"] = 2682,
			},
			["405812"] = {
				"405812", -- [1]
				"Timer405812cdcount	1", -- [2]
				"Animate Golems (1)", -- [3]
				35, -- [4]
				254109, -- [5]
				"cd", -- [6]
				405812, -- [7]
				1, -- [8]
				"2532", -- [9]
				["id"] = 2689,
			},
			["403625"] = {
				"403625", -- [1]
				"Timer403625cdcount	1", -- [2]
				"Hide (1)", -- [3]
				46.1, -- [4]
				4914669, -- [5]
				"cd", -- [6]
				403625, -- [7]
				3, -- [8]
				"2520", -- [9]
				["id"] = 2685,
			},
			["407936"] = {
				"407936", -- [1]
				"Timer407936cdcount	1", -- [2]
				"Portals (1)", -- [3]
				19.5, -- [4]
				575535, -- [5]
				"cd", -- [6]
				407936, -- [7]
				5, -- [8]
				"2523", -- [9]
				["id"] = 2684,
			},
			["406783"] = {
				"406783", -- [1]
				"Timer406783cdcount	1", -- [2]
				"Shadowflame Burst (1)", -- [3]
				18.5, -- [4]
				4914677, -- [5]
				"cd", -- [6]
				406783, -- [7]
				5, -- [8]
				"2529", -- [9]
				["id"] = 2687,
			},
			["403203"] = {
				"403203", -- [1]
				"Timer403203cdcount	1", -- [2]
				"Flame Slash (1)", -- [3]
				9.3, -- [4]
				135827, -- [5]
				"cd", -- [6]
				403203, -- [7]
				5, -- [8]
				"2529", -- [9]
				["id"] = 2687,
			},
			["404472"] = {
				"404472", -- [1]
				"Timer404472cdcount	1", -- [2]
				"Massive Slam (1)", -- [3]
				35.2, -- [4]
				305703, -- [5]
				"cd", -- [6]
				404472, -- [7]
				3, -- [8]
				"2530", -- [9]
				["id"] = 2693,
			},
			["403459"] = {
				"403459", -- [1]
				"Timer403459cdcount	1", -- [2]
				"Coalescing Void (1)", -- [3]
				35.2, -- [4]
				1097742, -- [5]
				"cd", -- [6]
				403459, -- [7]
				2, -- [8]
				"2529", -- [9]
				["id"] = 2687,
			},
			["401500"] = {
				"401500", -- [1]
				"Timer401500cdcount	2", -- [2]
				"Bombs (2)", -- [3]
				62.3, -- [4]
				135819, -- [5]
				"cd", -- [6]
				401500, -- [7]
				3, -- [8]
				"2520", -- [9]
				["id"] = 2685,
			},
			["405375"] = {
				"405375", -- [1]
				"Timer405375cdcount	1", -- [2]
				"Violent Eruption (1)", -- [3]
				38.4, -- [4]
				3033715, -- [5]
				"cd", -- [6]
				405375, -- [7]
				2, -- [8]
				"2530", -- [9]
				["id"] = 2693,
			},
			["405492"] = {
				"405492", -- [1]
				"Timer405492cdcount	1", -- [2]
				"Volatile Spew (1)", -- [3]
				5.3, -- [4]
				1041233, -- [5]
				"cd", -- [6]
				405492, -- [7]
				3, -- [8]
				"2530", -- [9]
				["id"] = 2693,
			},
			["405433"] = {
				"405433", -- [1]
				"Timer405433cdcount	1", -- [2]
				"Umbral Annihilation (1)", -- [3]
				25.1, -- [4]
				4914667, -- [5]
				"cd", -- [6]
				405433, -- [7]
				2, -- [8]
				"2523", -- [9]
				["id"] = 2684,
			},
			["410625"] = {
				"410625", -- [1]
				"Timer410625cast", -- [2]
				"End Existence", -- [3]
				15, -- [4]
				4067372, -- [5]
				"cast", -- [6]
				410625, -- [7]
				4, -- [8]
				"2520", -- [9]
				["id"] = 2685,
			},
			["401215"] = {
				"401215", -- [1]
				"Timer401215fades", -- [2]
				"Emptiness Between Stars fades", -- [3]
				24.99899999999616, -- [4]
				4913234, -- [5]
				"target", -- [6]
				401215, -- [7]
				3, -- [8]
				"2520", -- [9]
				["id"] = 2685,
			},
			["406851"] = {
				"406851", -- [1]
				"Timer406851cdcount	1", -- [2]
				"Doom Flames (1)", -- [3]
				39.1, -- [4]
				4914676, -- [5]
				"cd", -- [6]
				406851, -- [7]
				5, -- [8]
				"2525", -- [9]
				["id"] = 2680,
			},
			["405316"] = {
				"405316", -- [1]
				"Timer405316cd", -- [2]
				"Ancient Fury", -- [3]
				100, -- [4]
				458971, -- [5]
				"cd", -- [6]
				405316, -- [7]
				2, -- [8]
				"2525", -- [9]
				["id"] = 2680,
			},
			["405642"] = {
				"405642", -- [1]
				"Timer405642cdcount	1", -- [2]
				"Bombs (1)", -- [3]
				20.2, -- [4]
				4914676, -- [5]
				"cd", -- [6]
				405642, -- [7]
				3, -- [8]
				"2529", -- [9]
				["id"] = 2687,
			},
			["408620"] = {
				"408620", -- [1]
				"Timer408620cd	Creature-0-3883-2569-3535-200836-000014A091", -- [2]
				"Scorching Roar", -- [3]
				9.7, -- [4]
				236297, -- [5]
				"cd", -- [6]
				408620, -- [7]
				2, -- [8]
				"2524", -- [9]
				["id"] = 2682,
			},
			["410351"] = {
				"410351", -- [1]
				"Timer410351cdcount	1", -- [2]
				"Flaming Cudgel (1)", -- [3]
				18.7, -- [4]
				4622273, -- [5]
				"cd", -- [6]
				410351, -- [7]
				5, -- [8]
				"2524", -- [9]
				["id"] = 2682,
			},
			["404743"] = {
				"404743", -- [1]
				"Timer404743cd", -- [2]
				"Terror Claws", -- [3]
				3.4, -- [4]
				5009071, -- [5]
				"cd", -- [6]
				404743, -- [7]
				5, -- [8]
				"2522", -- [9]
				["id"] = 2688,
			},
			["407302"] = {
				"407302", -- [1]
				"Timer407302fades", -- [2]
				"Infused Explosion fades", -- [3]
				20, -- [4]
				4638528, -- [5]
				"target", -- [6]
				407302, -- [7]
				5, -- [8]
				"2530", -- [9]
				["id"] = 2693,
			},
			["404732"] = {
				"404732", -- [1]
				"Timer404732cdcount	1", -- [2]
				"Fiery Meteor (1)", -- [3]
				35.2, -- [4]
				1033911, -- [5]
				"cd", -- [6]
				404732, -- [7]
				3, -- [8]
				"2529", -- [9]
				["id"] = 2687,
			},
			["410953"] = {
				"410953", -- [1]
				"Timer410953nextcount	1", -- [2]
				"Bombs (1)", -- [3]
				15.6, -- [4]
				514018, -- [5]
				"cd", -- [6]
				410953, -- [7]
				3, -- [8]
				"2523", -- [9]
				["id"] = 2684,
			},
			["401680"] = {
				"401680", -- [1]
				"Timer401680cdcount	1", -- [2]
				"Disintegrate (1)", -- [3]
				24.7, -- [4]
				135785, -- [5]
				"cd", -- [6]
				401680, -- [7]
				3, -- [8]
				"2520", -- [9]
				["id"] = 2685,
			},
			["409093"] = {
				"409093", -- [1]
				"Timer409093cdcount	1", -- [2]
				"Breath (1)", -- [3]
				33.3, -- [4]
				236216, -- [5]
				"cd", -- [6]
				409093, -- [7]
				3, -- [8]
				"2527", -- [9]
				["id"] = 2683,
			},
			["403740"] = {
				"403740", -- [1]
				"Timer403740cdcount	1", -- [2]
				"Roar (1)", -- [3]
				8.8, -- [4]
				134153, -- [5]
				"cd", -- [6]
				403740, -- [7]
				2, -- [8]
				"2527", -- [9]
				["id"] = 2683,
			},
			["405736"] = {
				"405736", -- [1]
				"Timer405736cdcount	1", -- [2]
				"Dragonfire Traps (1)", -- [3]
				20.3, -- [4]
				135824, -- [5]
				"cd", -- [6]
				405736, -- [7]
				3, -- [8]
				"2532", -- [9]
				["id"] = 2689,
			},
			["401810"] = {
				"401810", -- [1]
				"Timer401810cdcount	1", -- [2]
				"Glittering Surge (1)", -- [3]
				3.5, -- [4]
				4630438, -- [5]
				"cd", -- [6]
				401810, -- [7]
				2, -- [8]
				"2520", -- [9]
				["id"] = 2685,
			},
			["403978"] = {
				"403978", -- [1]
				"Timer403978cdcount	1", -- [2]
				"Knockback (1)", -- [3]
				10.7, -- [4]
				1029721, -- [5]
				"cd", -- [6]
				403978, -- [7]
				2, -- [8]
				"2532", -- [9]
				["id"] = 2689,
			},
			["407221"] = {
				"407221", -- [1]
				"Timer407221cdcount	1", -- [2]
				"Rushing Darkness (1)", -- [3]
				10.5, -- [4]
				4914668, -- [5]
				"cd", -- [6]
				407221, -- [7]
				3, -- [8]
				"2523", -- [9]
				["id"] = 2684,
			},
			["405036"] = {
				"405036", -- [1]
				"Timer405036cdcount	1", -- [2]
				"Bombs (1)", -- [3]
				14.2, -- [4]
				136201, -- [5]
				"cd", -- [6]
				405036, -- [7]
				3, -- [8]
				"2529", -- [9]
				["id"] = 2687,
			},
			["401383"] = {
				"401383", -- [1]
				"Timer401383next", -- [2]
				"Oppressing Howl", -- [3]
				15.3, -- [4]
				4622466, -- [5]
				"next", -- [6]
				401383, -- [7]
				2, -- [8]
				"2520", -- [9]
				["id"] = 2685,
			},
			["404456"] = {
				"404456", -- [1]
				"Timer404456cdcount	1", -- [2]
				"Breath (1)", -- [3]
				4, -- [4]
				4914668, -- [5]
				"cd", -- [6]
				404456, -- [7]
				1, -- [8]
				"2520", -- [9]
				["id"] = 2685,
			},
			["405392"] = {
				"405392", -- [1]
				"Timer405392cdcount	1", -- [2]
				"Disintegrate (1)", -- [3]
				6.2, -- [4]
				4622451, -- [5]
				"cd", -- [6]
				405392, -- [7]
				3, -- [8]
				"2530", -- [9]
				["id"] = 2693,
			},
			["404403"] = {
				"404403", -- [1]
				"Timer404403cdcount	1", -- [2]
				"Desolate Blossom (1)", -- [3]
				12, -- [4]
				136201, -- [5]
				"cd", -- [6]
				404403, -- [7]
				3, -- [8]
				"2520", -- [9]
				["id"] = 2685,
			},
			["401010"] = {
				"401010", -- [1]
				"Timer401010cdcount	1", -- [2]
				"Corruption (1)", -- [3]
				14, -- [4]
				136129, -- [5]
				"cd", -- [6]
				401010, -- [7]
				5, -- [8]
				"2523", -- [9]
				["id"] = 2684,
			},
			["405821"] = {
				"405821", -- [1]
				"Timer405821cdcount	1", -- [2]
				"Searing Slam (1)", -- [3]
				9.1, -- [4]
				236289, -- [5]
				"cd", -- [6]
				405821, -- [7]
				3, -- [8]
				"2525", -- [9]
				["id"] = 2680,
			},
			["408358"] = {
				"408358", -- [1]
				"Timer408358cd", -- [2]
				"Catastrophic Eruption", -- [3]
				335, -- [4]
				135822, -- [5]
				"cd", -- [6]
				408358, -- [7]
				2, -- [8]
				"2527", -- [9]
				["id"] = 2683,
			},
			["406333"] = {
				"406333", -- [1]
				"Timer406333cdcount	1", -- [2]
				"Shadowlava Blast (1)", -- [3]
				95, -- [4]
				4914680, -- [5]
				"cd", -- [6]
				406333, -- [7]
				3, -- [8]
				"2525", -- [9]
				["id"] = 2680,
			},
			["407196"] = {
				"407196", -- [1]
				"Timer407196cdcount	1", -- [2]
				"Dread Rifts (1)", -- [3]
				7, -- [4]
				4914676, -- [5]
				"cd", -- [6]
				407196, -- [7]
				3, -- [8]
				"2522", -- [9]
				["id"] = 2688,
			},
			["403671"] = {
				"403671", -- [1]
				"Timer403671cdcount	-0	1", -- [2]
				"Knockback (-0)", -- [3]
				76.6, -- [4]
				136025, -- [5]
				"cd", -- [6]
				403671, -- [7]
				2, -- [8]
				"2527", -- [9]
				["id"] = 2683,
			},
			["407069"] = {
				"407069", -- [1]
				"Timer407069cdcount	1", -- [2]
				"Rays of Anguish (1)", -- [3]
				24, -- [4]
				236216, -- [5]
				"cd", -- [6]
				407069, -- [7]
				3, -- [8]
				"2522", -- [9]
				["id"] = 2688,
			},
			["406678"] = {
				"406678", -- [1]
				"Timer406678cdcount	1", -- [2]
				"Tactical Destruction (1)", -- [3]
				70, -- [4]
				525024, -- [5]
				"cd", -- [6]
				406678, -- [7]
				3, -- [8]
				"2532", -- [9]
				["id"] = 2689,
			},
			["406358"] = {
				"406358", -- [1]
				"Timer406358cdcount	1", -- [2]
				"Rending Charge (1)", -- [3]
				19.4, -- [4]
				1396978, -- [5]
				"cd", -- [6]
				406358, -- [7]
				3, -- [8]
				"2530", -- [9]
				["id"] = 2693,
			},
			["407790"] = {
				"407790", -- [1]
				"Timer407790cdcount	1", -- [2]
				"Sunder Shadow (1)", -- [3]
				14.8, -- [4]
				237531, -- [5]
				"cd", -- [6]
				407790, -- [7]
				5, -- [8]
				"2523", -- [9]
				["id"] = 2684,
			},
			["402050"] = {
				"402050", -- [1]
				"Timer402050cdcount	1", -- [2]
				"Breath (1)", -- [3]
				28.2, -- [4]
				135822, -- [5]
				"cd", -- [6]
				402050, -- [7]
				3, -- [8]
				"2520", -- [9]
				["id"] = 2685,
			},
			["402115"] = {
				"402115", -- [1]
				"Timer402115cdcount	1", -- [2]
				"Fissure (1)", -- [3]
				33.6, -- [4]
				136025, -- [5]
				"cd", -- [6]
				402115, -- [7]
				2, -- [8]
				"2523", -- [9]
				["id"] = 2684,
			},
			["400430"] = {
				"400430", -- [1]
				"Timer400430cdcount	1", -- [2]
				"Breath (1)", -- [3]
				29.2, -- [4]
				236302, -- [5]
				"cd", -- [6]
				400430, -- [7]
				3, -- [8]
				"2522", -- [9]
				["id"] = 2688,
			},
			["nil"] = {
				"nil", -- [1]
				"DBMLFGTimer", -- [2]
				"LFG Invite", -- [3]
				40, -- [4]
				"237538", -- [5]
				"extratimer", -- [6]
				nil, -- [7]
				0, -- [8]
				["id"] = 1052,
			},
			["407552"] = {
				"407552", -- [1]
				"Timer407552cdcount	1", -- [2]
				"Temporal Anomaly (1)", -- [3]
				16.8, -- [4]
				4630480, -- [5]
				"cd", -- [6]
				407552, -- [7]
				5, -- [8]
				"2530", -- [9]
				["id"] = 2693,
			},
			["404713"] = {
				"404713", -- [1]
				"Timer404713cdcount	1", -- [2]
				"Bellowing Roar (1)", -- [3]
				10.9, -- [4]
				4622466, -- [5]
				"cd", -- [6]
				404713, -- [7]
				2, -- [8]
				"2530", -- [9]
				["id"] = 2693,
			},
			["405914"] = {
				"405914", -- [1]
				"Timer405914cdcount	1", -- [2]
				"Withering Vulnerability (1)", -- [3]
				15.8, -- [4]
				4914674, -- [5]
				"cd", -- [6]
				405914, -- [7]
				5, -- [8]
				"2529", -- [9]
				["id"] = 2687,
			},
			["404269"] = {
				"404269", -- [1]
				"Timer404269castcount", -- [2]
				"Immune (Unknown)", -- [3]
				11, -- [4]
				5061347, -- [5]
				"cast", -- [6]
				404269, -- [7]
				5, -- [8]
				"2520", -- [9]
				["id"] = 2685,
			},
			["406227"] = {
				"406227", -- [1]
				"Timer406227cdcount	1", -- [2]
				"Breath (1)", -- [3]
				30.4, -- [4]
				4622450, -- [5]
				"cd", -- [6]
				406227, -- [7]
				3, -- [8]
				"2530", -- [9]
				["id"] = 2693,
			},
			["404896"] = {
				"404896", -- [1]
				"Timer404896cdcount	1", -- [2]
				"Tornados (1)", -- [3]
				10.5, -- [4]
				451169, -- [5]
				"cd", -- [6]
				404896, -- [7]
				3, -- [8]
				"2529", -- [9]
				["id"] = 2687,
			},
			["401258"] = {
				"401258", -- [1]
				"Timer401258cdcount	1", -- [2]
				"Heavy Cudgel (1)", -- [3]
				11.9, -- [4]
				4622272, -- [5]
				"cd", -- [6]
				401258, -- [7]
				5, -- [8]
				"2524", -- [9]
				["id"] = 2682,
			},
			["403326"] = {
				"403326", -- [1]
				"Timer403326cdcount	1", -- [2]
				"Wings of Extinction (1)", -- [3]
				14.3, -- [4]
				2103916, -- [5]
				"cd", -- [6]
				403326, -- [7]
				2, -- [8]
				"2522", -- [9]
				["id"] = 2688,
			},
			["403510"] = {
				"403510", -- [1]
				"Timer403510cdcount", -- [2]
				"Pillar (Unknown)", -- [3]
				9.5, -- [4]
				1016245, -- [5]
				"cd", -- [6]
				403510, -- [7]
				5, -- [8]
				"2520", -- [9]
				["id"] = 2685,
			},
			["400777"] = {
				"400777", -- [1]
				"Timer400777cdcount	1", -- [2]
				"Charged Smash (1)", -- [3]
				21.1, -- [4]
				4914677, -- [5]
				"cd", -- [6]
				400777, -- [7]
				3, -- [8]
				"2525", -- [9]
				["id"] = 2680,
			},
			["407917"] = {
				"407917", -- [1]
				"Timer407917cdcount	1", -- [2]
				"Big Bang (1)", -- [3]
				40.2, -- [4]
				1354169, -- [5]
				"cd", -- [6]
				407917, -- [7]
				2, -- [8]
				"2523", -- [9]
				["id"] = 2684,
			},
			["408959"] = {
				"408959", -- [1]
				"Timer408959cdcount	1", -- [2]
				"Leap (1)", -- [3]
				95.9, -- [4]
				136025, -- [5]
				"cd", -- [6]
				408959, -- [7]
				3, -- [8]
				"2524", -- [9]
				["id"] = 2682,
			},
			["402902"] = {
				"402902", -- [1]
				"Timer402902cdcount	2", -- [2]
				"Twisted Earth (2)", -- [3]
				40, -- [4]
				1044087, -- [5]
				"cd", -- [6]
				402902, -- [7]
				3, -- [8]
				"2523", -- [9]
				["id"] = 2684,
			},
			["407641"] = {
				"407641", -- [1]
				"Timer407641cdcount	1", -- [2]
				"Tank Combo (1)", -- [3]
				29.1, -- [4]
				4823024, -- [5]
				"cd", -- [6]
				407641, -- [7]
				5, -- [8]
				"2525", -- [9]
				["id"] = 2680,
			},
			["401998"] = {
				"401998", -- [1]
				"Timer401998cdcount	1", -- [2]
				"Calamitous Strike (1)", -- [3]
				24.1, -- [4]
				252222, -- [5]
				"cd", -- [6]
				401998, -- [7]
				5, -- [8]
				"2523", -- [9]
				["id"] = 2684,
			},
			["410516"] = {
				"410516", -- [1]
				"Timer410516cdcount	1", -- [2]
				"Catastrophic Slam (1)", -- [3]
				25.6, -- [4]
				1016245, -- [5]
				"cd", -- [6]
				410516, -- [7]
				5, -- [8]
				"2524", -- [9]
				["id"] = 2682,
			},
			["407327"] = {
				"407327", -- [1]
				"Timer407327cdcount	1", -- [2]
				"Unstable Essence (1)", -- [3]
				16.5, -- [4]
				1041232, -- [5]
				"cd", -- [6]
				407327, -- [7]
				3, -- [8]
				"2530", -- [9]
				["id"] = 2693,
			},
		},
	},
	["check_stuttering"] = true,
	["custom"] = {
		{
			["source"] = false,
			["author"] = "Terciob",
			["icon"] = "Interface\\ICONS\\INV_Potion_03",
			["tooltip"] = "				local actorObject, combatObject, instanceObject = ...\n\n				local iconSize = 20\n				\n				local buffUptimeContainer = actorObject:GetSpellContainer(\"buff\")\n				if (buffUptimeContainer) then\n					for spellId, potionPower in pairs(LIB_OPEN_RAID_ALL_POTIONS) do\n						local spellTable = buffUptimeContainer:GetSpell(spellId)\n						if (spellTable) then\n							local used = spellTable.activedamt\n							if (used and used > 0) then\n								local spellName, _, spellIcon = GetSpellInfo(spellId)\n								GameCooltip:AddLine(spellName, used)\n								GameCooltip:AddIcon(spellIcon, 1, 1, iconSize, iconSize)\n								Details:AddTooltipBackgroundStatusbar()\n							end\n						end\n					end\n				end\n			",
			["percent_script"] = "				local value, top, total, combat, instance = ...\n				value = math.floor(value)\n				return \"\"\n			",
			["total_script"] = "				local value, top, total, combat, instance = ...\n				return math.floor(value) .. \" \"\n			",
			["spellid"] = false,
			["desc"] = "Show who in your raid used a potion during the encounter.",
			["name"] = "Potion Used",
			["attribute"] = false,
			["target"] = false,
			["script"] = "				local combatObject, customContainer, instanceObject = ...\n				local total, top, amount = 0, 0, 0\n				\n				--get the misc actor container\n				local listOfUtilityActors = combatObject:GetActorList(DETAILS_ATTRIBUTE_MISC)\n				\n				--do the loop:\n				for _, actorObject in ipairs(listOfUtilityActors) do\n					--only player in group\n					if (actorObject:IsGroupPlayer()) then\n						local bFoundPotion = false\n						\n						--get the spell debuff uptime container\n						local debuffUptimeContainer = actorObject:GetSpellContainer(\"debuff\")\n						if (debuffUptimeContainer) then\n							--potion of focus (can't use as pre-potion, so, its amount is always 1\n							local focusPotion = debuffUptimeContainer:GetSpell(DETAILS_FOCUS_POTION_ID)\n							if (focusPotion) then\n								total = total + 1\n								bFoundPotion = true\n								if (top < 1) then\n									top = 1\n								end\n								--add amount to the player\n								customContainer:AddValue(actorObject, 1)\n							end\n						end\n						\n						--get the spell buff uptime container\n						local buffUptimeContainer = actorObject:GetSpellContainer(\"buff\")\n						if (buffUptimeContainer) then\n							for spellId, potionPower in pairs(LIB_OPEN_RAID_ALL_POTIONS) do\n								local spellTable = buffUptimeContainer:GetSpell(spellId)\n								if (spellTable) then\n									local used = spellTable.activedamt\n									if (used and used > 0) then\n										total = total + used\n										bFoundPotion = true\n										if (used > top) then\n											top = used\n										end\n										\n										--add amount to the player\n										customContainer:AddValue(actorObject, used)\n									end\n								end\n							end\n						end\n						\n						if (bFoundPotion) then\n							amount = amount + 1\n						end\n					end\n				end\n				\n				--return:\n				return total, top, amount\n				",
			["import_string"] = "1EvBVnkoq4FlxKwDWDjCn6Q0kfD7kL(YwruUMOLK7JaoGPX3rSrgZwLV4F73yJ5LMxjPDfBBzHXZZZmEMhg7p0FHVxoRGhH9x57HkeRzCFVhWcejn)x89YWWROIG8iojt47LYIqPYWFGslW9LHcwM(3cuk83i2MvibCdHMlq0iSm8lYqhhh5e5e9s0pydsS2jjLX4w6hAREnhlk4uzyVEYWbdYfCc9fNeghm2Q3NCgM0RVb2)qd3Vn8MBSvohwYN6P8GCIVxmopY3ZBn7vz4RRzkMid3cXNmKJiXYWICm8BKmmJjim4LXfkKGyynqomnIvqfyUJVNgLpG4UkW2pQljV6Fg2tIyu)Nh(N3(5H367rrBW(EZn8CjqCyRkdNMsIv7vce)fSqD3oCSKnZw9V4ifNIkYfSn3ZOWwkfZBXYstA4Qz9vrvzmI2OYiAJUPV5hfBhmaq3K22qYJalJemUcEds1omLKlMLSuqsjITJvwLR9xBIo6jSq)QPGXwp84IXUt9cgVyX3DVB5Ihd(BxV7TlXnMzGfYLzJKtsuOg03qGQGsTXtYqeEU1bWhs(GBMidlVgmGrt3cffPOTaX1l(foRiRXesIm0QfcJCZFszXC9sSST1KI2SGQltsy13G8yC1Uje9jO0C8(MV)tANP17)a3XRksacvKjiBWVjNFe4lxXsT911cAE0oMGnbpfc1wy1RCH9S33Z6mYb97rZfnHuv7hdCscdQrbFfHO)Qq3IcScEqghBSd2CZzQkxrEtfjrDF6ROTWFhECSmjaniTs)hK41jG6kWVn7(LEbZNTWD2ZbUpyFCC0PJwOC2Kq1LUFtZjZD)(jJNQR9kOe8c85xMMMqRTm8Vay6mjBiBMgSoqqmn(8gnyakoUzpvu1BB6ep763rDB0444)rPU2UvTVoqNCr88WKVl9MxAN5v2xEYUYRPNulJQJb34(vFFCo71k9WsT0PU3fmB(Jph89XUpemE6utVH3okQNPBuJZc0Q0YpvEYwrdNS7yTDJRV4IBd5kNr4lTzPdSBq(bogTr0D3PPJzGdA9ShFf(a6fZStPvOD7f7PRu(4eX4x1QdxDOTRcZ1fwDs05891)SLTUszmvoXU7EVtjJtA07rBSujQvz2zlnAnRz1Th(BHVHb6)t5tGPdlh3EuZC3hCCw942ibCkJvfc9rFemwQGKvpf9Bt87mt9XMGUEK33POENfX)5iA)HksFPIYVtr4par32H)ZWHW6xE8IYqmYixwf5U0e2f8jQNqQ0NUut1KpfYIwTbQJD474gfRSQ5NAEhZpMdY7yQUDsb8cwJjVSwC632boywTc)fLo4ou0)Po2engoDQOiFfcoy07rCPQ12x47))d",
			["script_version"] = 8,
		}, -- [1]
		{
			["source"] = false,
			["total_script"] = false,
			["author"] = "Terciob",
			["percent_script"] = false,
			["desc"] = "Show who in your raid group used the healthstone or a heal potion.",
			["icon"] = "Interface\\ICONS\\INV_Stone_04",
			["spellid"] = false,
			["name"] = "Health Potion & Stone",
			["script"] = "				local combatObject, instanceContainer, instanceObject = ...\n				local total, top, amount = 0, 0, 0\n				\n				local listOfHealingActors = combatObject:GetActorList(DETAILS_ATTRIBUTE_HEAL)\n				for _, actorObject in ipairs(listOfHealingActors) do\n					local listOfSpells = actorObject:GetSpellList()\n					local found = false\n					\n					for spellId, spellTable in pairs(listOfSpells) do\n						if (LIB_OPEN_RAID_HEALING_POTIONS[spellId]) then\n							instanceContainer:AddValue(actorObject, spellTable.total)\n							total = total + spellTable.total\n							if (top < spellTable.total) then\n								top = spellTable.total\n							end\n							found = true\n						end\n					end\n					\n					if (found) then\n						amount = amount + 1\n					end\n				end\n				\n				return total, top, amount\n			",
			["target"] = false,
			["tooltip"] = "				local actorObject, combatObject, instanceObject = ...\n				local spellContainer = actorObject:GetSpellContainer(\"spell\")\n				\n				local iconSize = 20\n				\n				local allHealingPotions = {6262}\n				for spellId, potionPower in pairs(LIB_OPEN_RAID_ALL_POTIONS) do\n					allHealingPotions[#allHealingPotions+1] = spellId\n				end\n				\n				for i = 1, #allHealingPotions do\n					local spellId = allHealingPotions[i]\n					local spellTable = spellContainer:GetSpell(spellId)\n					if (spellTable) then\n						local spellName, _, spellIcon = GetSpellInfo(spellId)\n						GameCooltip:AddLine(spellName, Details:ToK(spellTable.total))\n						GameCooltip:AddIcon(spellIcon, 1, 1, iconSize, iconSize)\n						GameCooltip:AddStatusBar (100, 1, 0, 0, 0, 0.75)\n					end\n				end\n			",
			["attribute"] = false,
			["script_version"] = 18,
		}, -- [2]
		{
			["source"] = false,
			["author"] = "Details!",
			["tooltip"] = "\n			",
			["percent_script"] = "				local value, top, total, combat, instance = ...\n				return string.format(\"%.1f\", value/top*100)\n			",
			["desc"] = "Tells how much time each character spent doing damage.",
			["icon"] = "Interface\\Buttons\\UI-MicroStream-Red",
			["spellid"] = false,
			["name"] = "Damage Activity Time",
			["script"] = "				local combatObject, instanceContainer, instanceObject = ...\n				local total, amount = 0, 0\n\n				--get the damager actors\n				local listOfDamageActors = combatObject:GetActorList(DETAILS_ATTRIBUTE_DAMAGE)\n\n				for _, actorObject in ipairs(listOfDamageActors) do\n					if (actorObject:IsGroupPlayer()) then\n						local activity = actorObject:Tempo()\n						total = total + activity\n						amount = amount + 1\n						--add amount to the player\n						instanceContainer:AddValue(actorObject, activity)\n					end\n				end\n\n				--return:\n				return total, combatObject:GetCombatTime(), amount\n			",
			["target"] = false,
			["total_script"] = "				local value, top, total, combat, instance = ...\n				local minutos, segundos = math.floor(value/60), math.floor(value%60)\n				return minutos .. \"m \" .. segundos .. \"s\"\n			",
			["attribute"] = false,
			["script_version"] = 4,
		}, -- [3]
		{
			["source"] = false,
			["author"] = "Details!",
			["tooltip"] = "\n			",
			["percent_script"] = "				local value, top, total, combat, instance = ...\n				return string.format(\"%.1f\", value/top*100)\n			",
			["desc"] = "Tells how much time each character spent doing healing.",
			["icon"] = "Interface\\Buttons\\UI-MicroStream-Green",
			["spellid"] = false,
			["name"] = "Healing Activity Time",
			["script"] = "				local combatObject, instanceContainer, instanceObject = ...\n				local total, amount = 0, 0\n\n				--get the healing actors\n				local listOfHealingActors = combatObject:GetActorList(DETAILS_ATTRIBUTE_HEAL)\n\n				for _, actorObject in ipairs(listOfHealingActors) do\n					if (actorObject:IsGroupPlayer()) then\n						local activity = actorObject:Tempo()\n						total = total + activity\n						amount = amount + 1\n						--add amount to the player\n						instanceContainer:AddValue (actorObject, activity)\n					end\n				end\n\n				--return:\n				return total, combatObject:GetCombatTime(), amount\n			",
			["target"] = false,
			["total_script"] = "				local value, top, total, combat, instance = ...\n				local minutos, segundos = math.floor(value/60), math.floor(value%60)\n				return minutos .. \"m \" .. segundos .. \"s\"\n			",
			["attribute"] = false,
			["script_version"] = 3,
		}, -- [4]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Show the crowd control amount for each player.",
			["total_script"] = "				local value, top, total, combat, instance = ...\n				return floor(value)\n			",
			["icon"] = "Interface\\ICONS\\Spell_Frost_FreezingBreath",
			["spellid"] = false,
			["name"] = "Crowd Control Done",
			["tooltip"] = "				local actor, combat, instance = ...\n				local spells = {}\n				for spellid, spell in pairs(actor.cc_done_spells._ActorTable) do\n				    tinsert(spells, {spellid, spell.counter})\n				end\n\n				table.sort (spells, _detalhes.Sort2)\n\n				for index, spell in ipairs(spells) do\n				    local name, _, icon = GetSpellInfo(spell [1])\n				    GameCooltip:AddLine(name, spell [2])\n				    _detalhes:AddTooltipBackgroundStatusbar()\n				    GameCooltip:AddIcon (icon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				end\n\n				local targets = {}\n				for playername, amount in pairs(actor.cc_done_targets) do\n				    tinsert(targets, {playername, amount})\n				end\n\n				table.sort (targets, _detalhes.Sort2)\n\n				_detalhes:AddTooltipSpellHeaderText (\"Targets\", \"yellow\", #targets)\n				local class, _, _, _, _, r, g, b = _detalhes:GetClass(actor.nome)\n				_detalhes:AddTooltipHeaderStatusbar (1, 1, 1, 0.6)\n\n				for index, target in ipairs(targets) do\n				    GameCooltip:AddLine(target[1], target [2])\n				    _detalhes:AddTooltipBackgroundStatusbar()\n\n				    local class, _, _, _, _, r, g, b = _detalhes:GetClass(target [1])\n				    if (class and class ~= \"UNKNOW\") then\n					local texture, l, r, t, b = _detalhes:GetClassIcon(class)\n					GameCooltip:AddIcon (\"Interface\\\\AddOns\\\\Details\\\\images\\\\classes_small_alpha\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height, l, r, t, b)\n				    else\n					GameCooltip:AddIcon (\"Interface\\\\GossipFrame\\\\IncompleteQuestIcon\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    end\n				    --\n				end\n			",
			["target"] = false,
			["script"] = "				local combat, instance_container, instance = ...\n				local total, top, amount = 0, 0, 0\n\n				local misc_actors = combat:GetActorList (DETAILS_ATTRIBUTE_MISC)\n\n				for index, character in ipairs(misc_actors) do\n					if (character.cc_done and character:IsPlayer()) then\n						local cc_done = floor(character.cc_done)\n						instance_container:AddValue (character, cc_done)\n						total = total + cc_done\n						if (cc_done > top) then\n							top = cc_done\n						end\n						amount = amount + 1\n					end\n				end\n\n				return total, top, amount\n			",
			["attribute"] = false,
			["script_version"] = 11,
		}, -- [5]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Show the amount of crowd control received for each player.",
			["total_script"] = "				local value, top, total, combat, instance = ...\n				return floor(value)\n			",
			["icon"] = "Interface\\ICONS\\Spell_Frost_ChainsOfIce",
			["spellid"] = false,
			["name"] = "Crowd Control Received",
			["tooltip"] = "				local actor, combat, instance = ...\n				local name = actor:name()\n				local spells, from = {}, {}\n				local misc_actors = combat:GetActorList (DETAILS_ATTRIBUTE_MISC)\n\n				for index, character in ipairs(misc_actors) do\n				    if (character.cc_done and character:IsPlayer()) then\n					local on_actor = character.cc_done_targets [name]\n					if (on_actor) then\n					    tinsert(from, {character:name(), on_actor})\n\n					    for spellid, spell in pairs(character.cc_done_spells._ActorTable) do\n\n						local spell_on_actor = spell.targets [name]\n						if (spell_on_actor) then\n						    local has_spell\n						    for index, spell_table in ipairs(spells) do\n							if (spell_table [1] == spellid) then\n							    spell_table [2] = spell_table [2] + spell_on_actor\n							    has_spell = true\n							end\n						    end\n						    if (not has_spell) then\n							tinsert(spells, {spellid, spell_on_actor})\n						    end\n						end\n\n					    end\n					end\n				    end\n				end\n\n				table.sort (from, _detalhes.Sort2)\n				table.sort (spells, _detalhes.Sort2)\n\n				for index, spell in ipairs(spells) do\n				    local name, _, icon = GetSpellInfo(spell [1])\n				    GameCooltip:AddLine(name, spell [2])\n				    _detalhes:AddTooltipBackgroundStatusbar()\n				    GameCooltip:AddIcon (icon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				end\n\n				_detalhes:AddTooltipSpellHeaderText (\"From\", \"yellow\", #from)\n				_detalhes:AddTooltipHeaderStatusbar (1, 1, 1, 0.6)\n\n				for index, t in ipairs(from) do\n				    GameCooltip:AddLine(t[1], t[2])\n				    _detalhes:AddTooltipBackgroundStatusbar()\n\n				    local class, _, _, _, _, r, g, b = _detalhes:GetClass(t [1])\n				    if (class and class ~= \"UNKNOW\") then\n					local texture, l, r, t, b = _detalhes:GetClassIcon(class)\n					GameCooltip:AddIcon (\"Interface\\\\AddOns\\\\Details\\\\images\\\\classes_small_alpha\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height, l, r, t, b)\n				    else\n					GameCooltip:AddIcon (\"Interface\\\\GossipFrame\\\\IncompleteQuestIcon\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    end\n\n				end\n			",
			["target"] = false,
			["script"] = "				local combat, instance_container, instance = ...\n				local total, top, amt = 0, 0, 0\n\n				local misc_actors = combat:GetActorList (DETAILS_ATTRIBUTE_MISC)\n				DETAILS_CUSTOM_CC_RECEIVED_CACHE = DETAILS_CUSTOM_CC_RECEIVED_CACHE or {}\n				wipe (DETAILS_CUSTOM_CC_RECEIVED_CACHE)\n\n				for index, character in ipairs(misc_actors) do\n				    if (character.cc_done and character:IsPlayer()) then\n\n					for player_name, amount in pairs(character.cc_done_targets) do\n					    local target = combat (1, player_name) or combat (2, player_name)\n					    if (target and target:IsPlayer()) then\n						instance_container:AddValue (target, amount)\n						total = total + amount\n						if (amount > top) then\n						    top = amount\n						end\n						if (not DETAILS_CUSTOM_CC_RECEIVED_CACHE [player_name]) then\n						    DETAILS_CUSTOM_CC_RECEIVED_CACHE [player_name] = true\n						    amt = amt + 1\n						end\n					    end\n					end\n\n				    end\n				end\n\n				return total, top, amt\n			",
			["attribute"] = false,
			["script_version"] = 3,
		}, -- [6]
		{
			["source"] = false,
			["author"] = "Details!",
			["percent_script"] = "				local value, top, total, combat, instance = ...\n				local dps = _detalhes:ToK (floor(value) / combat:GetCombatTime())\n				local percent = string.format(\"%.1f\", value/total*100)\n				return dps .. \", \" .. percent\n			",
			["desc"] = "Show your spells in the window.",
			["tooltip"] = "			--config:\n			--Background RBG and Alpha:\n			local R, G, B, A = 0, 0, 0, 0.75\n			local R, G, B, A = 0.1960, 0.1960, 0.1960, 0.8697\n\n			--get the parameters passed\n			local spell, combat, instance = ...\n\n			--get the cooltip object (we dont use the convencional GameTooltip here)\n			local GC = GameCooltip\n			GC:SetOption(\"YSpacingMod\", 0)\n\n			local role = DetailsFramework.UnitGroupRolesAssigned(\"player\")\n\n			if (spell.n_total) then\n\n			    local spellschool, schooltext = spell.spellschool, \"\"\n			    if (spellschool) then\n				local t = Details.spells_school [spellschool]\n				if (t and t.name) then\n				    schooltext = t.formated\n				end\n			    end\n\n			    local total_hits = spell.counter\n			    local combat_time = instance.showing:GetCombatTime()\n\n			    local debuff_uptime_total, cast_string = \"\", \"\"\n			    local misc_actor = instance.showing (4, Details.playername)\n			    if (misc_actor) then\n				local debuff_uptime = misc_actor.debuff_uptime_spells and misc_actor.debuff_uptime_spells._ActorTable [spell.id] and misc_actor.debuff_uptime_spells._ActorTable [spell.id].uptime\n				if (debuff_uptime) then\n				    debuff_uptime_total = floor(debuff_uptime / instance.showing:GetCombatTime() * 100)\n				end\n\n				local spellName = GetSpellInfo(spell.id)\n				local amountOfCasts = combat:GetSpellCastAmount(Details.playername, spellName)\n\n				if (amountOfCasts == 0) then\n				    amountOfCasts = \"(|cFFFFFF00?|r)\"\n				end\n				cast_string = cast_string .. amountOfCasts\n			    end\n\n			    --Cooltip code\n			    GC:AddLine(\"Casts:\", cast_string or \"?\")\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    if (debuff_uptime_total ~= \"\") then\n				GC:AddLine(\"Uptime:\", (debuff_uptime_total or \"?\") .. \"%\")\n				GC:AddStatusBar (100, 1, R, G, B, A)\n			    end\n\n			    GC:AddLine(\"Hits:\", spell.counter)\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    local average = spell.total / total_hits\n			    GC:AddLine(\"Average:\", _detalhes:ToK (average))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    GC:AddLine(\"E-Dps:\", _detalhes:ToK (spell.total / combat_time))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    GC:AddLine(\"School:\", schooltext)\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    --GC:AddLine(\" \")\n\n			    GC:AddLine(\"Normal Hits: \", spell.n_amt .. \" (\" ..floor( spell.n_amt/total_hits*100) .. \"%)\")\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    local n_average = spell.n_total / spell.n_amt\n			    local T = (combat_time*spell.n_total)/spell.total\n			    local P = average/n_average*100\n			    T = P*T/100\n\n			    GC:AddLine(\"Average / E-Dps: \",  _detalhes:ToK (n_average) .. \" / \" .. format(\"%.1f\",spell.n_total / T ))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    --GC:AddLine(\" \")\n\n			    GC:AddLine(\"Critical Hits: \", spell.c_amt .. \" (\" ..floor( spell.c_amt/total_hits*100) .. \"%)\")\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    if (spell.c_amt > 0) then\n				local c_average = spell.c_total/spell.c_amt\n				local T = (combat_time*spell.c_total)/spell.total\n				local P = average/c_average*100\n				T = P*T/100\n				local crit_dps = spell.c_total / T\n\n				GC:AddLine(\"Average / E-Dps: \",  _detalhes:ToK (c_average) .. \" / \" .. _detalhes:comma_value (crit_dps))\n			    else\n				GC:AddLine(\"Average / E-Dps: \",  \"0 / 0\")\n			    end\n\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n\n			elseif (spell.n_total) then\n\n			    local spellschool, schooltext = spell.spellschool, \"\"\n			    if (spellschool) then\n				local t = _detalhes.spells_school [spellschool]\n				if (t and t.name) then\n				    schooltext = t.formated\n				end\n			    end\n\n			    local total_hits = spell.counter\n			    local combat_time = instance.showing:GetCombatTime()\n\n			    --Cooltip code\n			    GC:AddLine(\"Hits:\", spell.counter)\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    local average = spell.total / total_hits\n			    GC:AddLine(\"Average:\", _detalhes:ToK (average))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    GC:AddLine(\"E-Hps:\", _detalhes:ToK (spell.total / combat_time))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    GC:AddLine(\"School:\", schooltext)\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    --GC:AddLine(\" \")\n\n			    GC:AddLine(\"Normal Hits: \", spell.n_amt .. \" (\" ..floor( spell.n_amt/total_hits*100) .. \"%)\")\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    local n_average = spell.n_total / spell.n_amt\n			    local T = (combat_time*spell.n_total)/spell.total\n			    local P = average/n_average*100\n			    T = P*T/100\n\n			    GC:AddLine(\"Average / E-Dps: \",  _detalhes:ToK (n_average) .. \" / \" .. format(\"%.1f\",spell.n_total / T ))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    --GC:AddLine(\" \")\n\n			    GC:AddLine(\"Critical Hits: \", spell.c_amt .. \" (\" ..floor( spell.c_amt/total_hits*100) .. \"%)\")\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    if (spell.c_amt > 0) then\n				local c_average = spell.c_total/spell.c_amt\n				local T = (combat_time*spell.c_total)/spell.total\n				local P = average/c_average*100\n				T = P*T/100\n				local crit_dps = spell.c_total / T\n\n				GC:AddLine(\"Average / E-Hps: \",  _detalhes:ToK (c_average) .. \" / \" .. _detalhes:comma_value (crit_dps))\n			    else\n				GC:AddLine(\"Average / E-Hps: \",  \"0 / 0\")\n			    end\n\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			end\n			",
			["icon"] = "Interface\\CHATFRAME\\UI-ChatIcon-Battlenet",
			["name"] = "My Spells",
			["spellid"] = false,
			["target"] = false,
			["script"] = "				--get the parameters passed\n				local combat, instance_container, instance = ...\n				--declade the values to return\n				local total, top, amount = 0, 0, 0\n\n				local player\n				local pet_attribute\n\n				local role = DetailsFramework.UnitGroupRolesAssigned(\"player\")\n				local spec = DetailsFramework.GetSpecialization()\n				role = spec and DetailsFramework.GetSpecializationRole (spec) or role\n\n				if (role == \"DAMAGER\") then\n					player = combat (DETAILS_ATTRIBUTE_DAMAGE, _detalhes.playername)\n					pet_attribute = DETAILS_ATTRIBUTE_DAMAGE\n				elseif (role == \"HEALER\") then\n					player = combat (DETAILS_ATTRIBUTE_HEAL, _detalhes.playername)\n					pet_attribute = DETAILS_ATTRIBUTE_HEAL\n				else\n					player = combat (DETAILS_ATTRIBUTE_DAMAGE, _detalhes.playername)\n					pet_attribute = DETAILS_ATTRIBUTE_DAMAGE\n				end\n\n				--do the loop\n\n				if (player) then\n					local spells = player:GetSpellList()\n					for spellid, spell in pairs(spells) do\n						instance_container:AddValue (spell, spell.total)\n						total = total + spell.total\n						if (top < spell.total) then\n							top = spell.total\n						end\n						amount = amount + 1\n					end\n\n					for _, PetName in ipairs(player.pets) do\n						local pet = combat (pet_attribute, PetName)\n						if (pet) then\n							for spellid, spell in pairs(pet:GetSpellList()) do\n								instance_container:AddValue (spell, spell.total, nil, \" (\" .. PetName:gsub((\" <.*\"), \"\") .. \")\")\n								total = total + spell.total\n								if (top < spell.total) then\n									top = spell.total\n								end\n								amount = amount + 1\n							end\n						end\n					end\n				end\n\n				--return the values\n				return total, top, amount\n			",
			["attribute"] = false,
			["script_version"] = 10,
		}, -- [7]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Show the amount of damage applied on targets marked with skull.",
			["tooltip"] = "				--get the parameters passed\n				local actor, combat, instance = ...\n\n				--get the cooltip object (we dont use the convencional GameTooltip here)\n				local GameCooltip = GameCooltip\n\n				--Cooltip code\n				local format_func = Details:GetCurrentToKFunction()\n\n				--Cooltip code\n				local RaidTargets = actor.raid_targets\n\n				local DamageOnStar = RaidTargets [128]\n				if (DamageOnStar) then\n				    --RAID_TARGET_8 is the built-in localized word for 'Skull'.\n				    GameCooltip:AddLine(RAID_TARGET_8 .. \":\", format_func (_, DamageOnStar))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_8\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n			",
			["icon"] = "Interface\\TARGETINGFRAME\\UI-RaidTargetingIcon_8",
			["name"] = "Damage On Skull Marked Targets",
			["spellid"] = false,
			["target"] = false,
			["script"] = "				--get the parameters passed\n				local Combat, CustomContainer, Instance = ...\n				--declade the values to return\n				local total, top, amount = 0, 0, 0\n\n				--raid target flags:\n				-- 128: skull\n				-- 64: cross\n				-- 32: square\n				-- 16: moon\n				-- 8: triangle\n				-- 4: diamond\n				-- 2: circle\n				-- 1: star\n\n				--do the loop\n				for _, actor in ipairs(Combat:GetActorList (DETAILS_ATTRIBUTE_DAMAGE)) do\n				    if (actor:IsPlayer()) then\n					if (actor.raid_targets [128]) then\n					    CustomContainer:AddValue (actor, actor.raid_targets [128])\n					end\n				    end\n				end\n\n				--if not managed inside the loop, get the values of total, top and amount\n				total, top = CustomContainer:GetTotalAndHighestValue()\n				amount = CustomContainer:GetNumActors()\n\n				--return the values\n				return total, top, amount\n			",
			["attribute"] = false,
			["script_version"] = 3,
		}, -- [8]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Show the amount of damage applied on targets marked with any other mark.",
			["tooltip"] = "				--get the parameters passed\n				local actor, combat, instance = ...\n\n				--get the cooltip object\n				local GameCooltip = GameCooltip\n\n				local format_func = Details:GetCurrentToKFunction()\n\n				--Cooltip code\n				local RaidTargets = actor.raid_targets\n\n				local DamageOnStar = RaidTargets [1]\n				if (DamageOnStar) then\n				    GameCooltip:AddLine(RAID_TARGET_1 .. \":\", format_func (_, DamageOnStar))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_1\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnCircle = RaidTargets [2]\n				if (DamageOnCircle) then\n				    GameCooltip:AddLine(RAID_TARGET_2 .. \":\", format_func (_, DamageOnCircle))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_2\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnDiamond = RaidTargets [4]\n				if (DamageOnDiamond) then\n				    GameCooltip:AddLine(RAID_TARGET_3 .. \":\", format_func (_, DamageOnDiamond))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_3\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnTriangle = RaidTargets [8]\n				if (DamageOnTriangle) then\n				    GameCooltip:AddLine(RAID_TARGET_4 .. \":\", format_func (_, DamageOnTriangle))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_4\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnMoon = RaidTargets [16]\n				if (DamageOnMoon) then\n				    GameCooltip:AddLine(RAID_TARGET_5 .. \":\", format_func (_, DamageOnMoon))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_5\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnSquare = RaidTargets [32]\n				if (DamageOnSquare) then\n				    GameCooltip:AddLine(RAID_TARGET_6 .. \":\", format_func (_, DamageOnSquare))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_6\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnCross = RaidTargets [64]\n				if (DamageOnCross) then\n				    GameCooltip:AddLine(RAID_TARGET_7 .. \":\", format_func (_, DamageOnCross))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_7\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n			",
			["icon"] = "Interface\\TARGETINGFRAME\\UI-RaidTargetingIcon_5",
			["name"] = "Damage On Other Marked Targets",
			["spellid"] = false,
			["target"] = false,
			["script"] = "				--get the parameters passed\n				local Combat, CustomContainer, Instance = ...\n				--declade the values to return\n				local total, top, amount = 0, 0, 0\n\n				--do the loop\n				for _, actor in ipairs(Combat:GetActorList (DETAILS_ATTRIBUTE_DAMAGE)) do\n				    if (actor:IsPlayer()) then\n					local total = (actor.raid_targets [1] or 0) --star\n					total = total + (actor.raid_targets [2] or 0) --circle\n					total = total + (actor.raid_targets [4] or 0) --diamond\n					total = total + (actor.raid_targets [8] or 0) --tiangle\n					total = total + (actor.raid_targets [16] or 0) --moon\n					total = total + (actor.raid_targets [32] or 0) --square\n					total = total + (actor.raid_targets [64] or 0) --cross\n\n					if (total > 0) then\n					    CustomContainer:AddValue (actor, total)\n					end\n				    end\n				end\n\n				--if not managed inside the loop, get the values of total, top and amount\n				total, top = CustomContainer:GetTotalAndHighestValue()\n				amount = CustomContainer:GetNumActors()\n\n				--return the values\n				return total, top, amount\n			",
			["attribute"] = false,
			["script_version"] = 3,
		}, -- [9]
		{
			["source"] = false,
			["author"] = "Details!",
			["icon"] = "Interface\\Buttons\\Spell-Reset",
			["tooltip"] = "				--get the parameters passed\n				local actor, combat, instance = ...\n\n				--get the cooltip object (we dont use the convencional GameTooltip here)\n				local GameCooltip = GameCooltip2\n\n				--Cooltip code\n				--get the overall combat\n				local OverallCombat = Details:GetCombat(-1)\n				--get the current combat\n				local CurrentCombat = Details:GetCombat(0)\n\n				local AllSpells = {}\n\n				local playerTotal = 0\n\n				--overall\n				local player = OverallCombat [1]:GetActor(actor.nome)\n				if (player) then\n					playerTotal = playerTotal + player.total\n					local playerSpells = player:GetSpellList()\n					for spellID, spellTable in pairs(playerSpells) do\n						AllSpells [spellID] = spellTable.total\n					end\n				end\n				--current\n				if (Details.in_combat) then\n					local player = CurrentCombat [1]:GetActor(actor.nome)\n					if (player) then\n						playerTotal = playerTotal + player.total\n						local playerSpells = player:GetSpellList()\n						for spellID, spellTable in pairs(playerSpells) do\n							AllSpells [spellID] = (AllSpells [spellID] or 0) + (spellTable.total or 0)\n						end\n					end\n				end\n\n				local sortedList = {}\n				for spellID, total in pairs(AllSpells) do\n					tinsert(sortedList, {spellID, total})\n				end\n				table.sort (sortedList, Details.Sort2)\n\n				local format_func = Details:GetCurrentToKFunction()\n\n				--build the tooltip\n\n				local topSpellTotal = sortedList and sortedList[1] and sortedList[1][2] or 0\n\n				for i, t in ipairs(sortedList) do\n					local spellID, total = unpack(t)\n					if (total > 1) then\n						local spellName, _, spellIcon = Details.GetSpellInfo(spellID)\n\n						local spellPercent = total / playerTotal * 100\n						local formatedSpellPercent = format(\"%.1f\", spellPercent)\n\n						if (string.len(formatedSpellPercent) < 4) then\n							formatedSpellPercent = formatedSpellPercent  .. \"0\"\n						end\n\n						GameCooltip:AddLine(spellName, format_func (_, total) .. \"    \" .. formatedSpellPercent  .. \"%\")\n\n						Details:AddTooltipBackgroundStatusbar(false, total / topSpellTotal * 100)\n						GameCooltip:AddIcon (spellIcon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height, 0.078125, 0.921875, 0.078125, 0.921875)\n\n					end\n				end\n			",
			["percent_script"] = "				local value, top, total, combat, instance = ...\n\n				--get the time of overall combat\n				local OverallCombatTime = Details:GetCombat(-1):GetCombatTime()\n\n				--get the time of current combat if the player is in combat\n				if (Details.in_combat) then\n					local CurrentCombatTime = Details:GetCombat(0):GetCombatTime()\n					OverallCombatTime = OverallCombatTime + CurrentCombatTime\n				end\n\n				--calculate the DPS and return it as percent\n				local totalValue = value\n\n				--build the string\n				local ToK = Details:GetCurrentToKFunction()\n				local s = ToK (_, value / OverallCombatTime)\n\n				return s\n			",
			["total_script"] = "				local value, top, total, combat, instance = ...\n				return value\n			",
			["spellid"] = false,
			["displayName"] = "Damage Done",
			["name"] = "Dynamic Overall Damage",
			["desc"] = "Show overall damage done on the fly.",
			["target"] = false,
			["script"] = "				--init:\n				local combat, instance_container, instance = ...\n				local total, top, amount = 0, 0, 0\n\n				--get the overall combat\n				local OverallCombat = Details:GetCombat(-1)\n				--get the current combat\n				local CurrentCombat = Details:GetCombat(0)\n\n				if (not OverallCombat.GetActorList or not CurrentCombat.GetActorList) then\n					return 0, 0, 0\n				end\n\n				--get the damage actor container for overall\n				local damage_container_overall = OverallCombat:GetActorList ( DETAILS_ATTRIBUTE_DAMAGE )\n				--get the damage actor container for current\n				local damage_container_current = CurrentCombat:GetActorList ( DETAILS_ATTRIBUTE_DAMAGE )\n\n				--do the loop:\n				for _, player in ipairs( damage_container_overall ) do\n					--only player in group\n					if (player:IsGroupPlayer()) then\n						instance_container:AddValue (player, player.total)\n					end\n				end\n\n				if (Details.in_combat) then\n					for _, player in ipairs( damage_container_current ) do\n						--only player in group\n						if (player:IsGroupPlayer()) then\n							instance_container:AddValue (player, player.total)\n						end\n					end\n				end\n\n				total, top =  instance_container:GetTotalAndHighestValue()\n				amount =  instance_container:GetNumActors()\n\n				--return:\n				return total, top, amount\n			",
			["attribute"] = false,
			["script_version"] = 8,
		}, -- [10]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Damage done to shields",
			["tooltip"] = "				--get the parameters passed\n				local actor, Combat, instance = ...\n\n				--get the cooltip object (we dont use the convencional GameTooltip here)\n				local GameCooltip = GameCooltip\n\n				--Cooltip code\n				--get the actor total damage absorbed\n				local totalAbsorb = actor.totalabsorbed\n				local format_func = Details:GetCurrentToKFunction()\n\n				--get the damage absorbed by all the actor pets\n				for petIndex, petName in ipairs(actor.pets) do\n				    local pet = Combat :GetActor(1, petName)\n				    if (pet) then\n					totalAbsorb = totalAbsorb + pet.totalabsorbed\n				    end\n				end\n\n				GameCooltip:AddLine(actor:Name(), format_func (_, actor.totalabsorbed))\n				Details:AddTooltipBackgroundStatusbar()\n\n				for petIndex, petName in ipairs(actor.pets) do\n				    local pet = Combat :GetActor(1, petName)\n				    if (pet) then\n					totalAbsorb = totalAbsorb + pet.totalabsorbed\n\n					GameCooltip:AddLine(petName, format_func (_, pet.totalabsorbed))\n					Details:AddTooltipBackgroundStatusbar()\n\n				    end\n				end\n			",
			["icon"] = "Interface\\ICONS\\Spell_Holy_PowerWordShield",
			["name"] = "Damage on Shields",
			["spellid"] = false,
			["target"] = false,
			["script"] = "				--get the parameters passed\n				local Combat, CustomContainer, Instance = ...\n				--declade the values to return\n				local total, top, amount = 0, 0, 0\n\n				--do the loop\n				for index, actor in ipairs(Combat:GetActorList(1)) do\n				    if (actor:IsPlayer()) then\n\n					--get the actor total damage absorbed\n					local totalAbsorb = actor.totalabsorbed\n\n					--get the damage absorbed by all the actor pets\n					for petIndex, petName in ipairs(actor.pets) do\n					    local pet = Combat :GetActor(1, petName)\n					    if (pet) then\n						totalAbsorb = totalAbsorb + pet.totalabsorbed\n					    end\n					end\n\n					--add the value to the actor on the custom container\n					CustomContainer:AddValue (actor, totalAbsorb)\n\n				    end\n				end\n				--loop end\n\n				--if not managed inside the loop, get the values of total, top and amount\n				total, top = CustomContainer:GetTotalAndHighestValue()\n				amount = CustomContainer:GetNumActors()\n\n				--return the values\n				return total, top, amount\n			",
			["attribute"] = false,
			["script_version"] = 1,
		}, -- [11]
	},
	["played_class_time"] = true,
	["latest_news_saw"] = "10.1.7 11914",
	["class_time_played"] = {
		[9] = {
			["HUNTER"] = 50.00300000000425,
			["SHAMAN"] = 27292.81600000002,
			["ROGUE"] = 26619.45000000002,
			["MAGE"] = 84.02799999999843,
			["DRUID"] = 100.1130000000048,
			["DEATHKNIGHT"] = 18209.37100000001,
			["DEMONHUNTER"] = 16104.804,
		},
	},
	["parser_options"] = {
		["energy_overflow"] = false,
		["shield_overheal"] = false,
	},
	["slash_me_used"] = false,
	["show_warning_id1"] = true,
	["details_auras"] = {
	},
	["spell_category_latest_save"] = 0,
	["run_code"] = {
		["on_groupchange"] = "\n-- this code runs when the player enter or leave a group",
		["on_zonechanged"] = "\n-- when the player changes zone, this code will run",
		["on_init"] = "\n-- code to run when Details! initializes, put here code which only will run once\n-- this also will run then the profile is changed\n\n--size of the death log tooltip in the Deaths display (default 350)\nDetails.death_tooltip_width = 350;\n\n--when in arena or battleground, details! silently switch to activity time (goes back to the old setting on leaving, default true)\nDetails.force_activity_time_pvp = true;\n\n--speed of the bar animations (default 33)\nDetails.animation_speed = 33;\n\n--threshold to trigger slow or fast speed (default 0.45)\nDetails.animation_speed_mintravel = 0.45;\n\n--call to update animations\nDetails:RefreshAnimationFunctions();\n\n--max window size, does require a /reload to work (default 480 x 450)\nDetails.max_window_size.width = 480;\nDetails.max_window_size.height = 450;\n\n--use the arena team color as the class color (default true)\nDetails.color_by_arena_team = true;\n\n--how much time the update warning is shown (default 10)\nDetails.update_warning_timeout = 10;",
		["on_specchanged"] = "\n-- run when the player changes its spec",
		["on_leavecombat"] = "\n-- this code runs when the player leave combat",
		["on_entercombat"] = "\n-- this code runs when the player enters in combat",
	},
	["exit_errors"] = {
	},
	["latest_npcid_pool_access"] = 1695698514,
	["realm_sync"] = true,
	["spellid_ignored"] = {
	},
	["createauraframe"] = {
	},
	["data_wipes_exp"] = {
		["9"] = false,
		["14"] = false,
		["13"] = false,
		["12"] = false,
		["11"] = false,
		["10"] = true,
	},
	["spell_category_latest_query"] = 0,
	["tutorial"] = {
		["unlock_button"] = 1,
		["main_help_button"] = 40,
		["WINDOW_GROUP_MAKING1"] = true,
		["alert_frames"] = {
			false, -- [1]
			false, -- [2]
			false, -- [3]
			false, -- [4]
			false, -- [5]
			false, -- [6]
		},
		["OVERALLDATA_WARNING1"] = 1,
		["logons"] = 40,
		["version_announce"] = 0,
		["ctrl_click_close_tutorial"] = false,
		["MIN_COMBAT_TIME"] = true,
		["bookmark_tutorial"] = false,
	},
	["switchSaved"] = {
		["slots"] = 4,
		["table"] = {
			{
				["atributo"] = 1,
				["sub_atributo"] = 1,
			}, -- [1]
			{
				["atributo"] = 2,
				["sub_atributo"] = 1,
			}, -- [2]
			{
				["atributo"] = 1,
				["sub_atributo"] = 6,
			}, -- [3]
			{
				["atributo"] = 4,
				["sub_atributo"] = 5,
			}, -- [4]
		},
	},
	["show_totalhitdamage_on_overkill"] = false,
	["aura_tracker_frame"] = {
		["scaletable"] = {
			["scale"] = 1,
		},
		["position"] = {
		},
	},
	["report_where"] = "SAY",
	["item_level_pool"] = {
		["Player-61-0CBE5A4C"] = {
			["name"] = "Gromkahr-Zul'jin",
			["time"] = 1695938569,
			["ilvl"] = 417.125,
		},
		["Player-96-0E248C23"] = {
			["name"] = "Whø-Velen",
			["time"] = 1695938569,
			["ilvl"] = 441.875,
		},
		["Player-3684-0E3D4403"] = {
			["time"] = 1696016795,
			["name"] = "Stormart",
			["ilvl"] = 446.25,
		},
		["Player-11-0E2588E1"] = {
			["time"] = 1696024599,
			["name"] = "Näotaka-Tichondrius",
			["ilvl"] = 409.0625,
		},
		["Player-3684-0706172C"] = {
			["time"] = 1696024869,
			["name"] = "Skelay",
			["ilvl"] = 422.625,
		},
		["Player-55-06A2E3B1"] = {
			["time"] = 1696016795,
			["name"] = "Umbric-Dentarg",
			["ilvl"] = 411.3125,
		},
		["Player-3684-0E13083A"] = {
			["time"] = 1696016795,
			["name"] = "Doddly",
			["ilvl"] = 445.875,
		},
		["Player-3684-0DD9E451"] = {
			["name"] = "Flirts",
			["time"] = 1696019142,
			["ilvl"] = 320.5,
		},
		["Player-1136-09195D52"] = {
			["name"] = "Kalabarr-Bonechewer",
			["time"] = 1695935983,
			["ilvl"] = 411.5,
		},
		["Player-157-0776B870"] = {
			["name"] = "Kinzydoodle-DemonSoul",
			["time"] = 1696019131,
			["ilvl"] = 338.5625,
		},
		["Player-1425-0E3FA505"] = {
			["name"] = "Onkhar-Drakkari",
			["time"] = 1695935981,
			["ilvl"] = 394.625,
		},
		["Player-3725-0C269C56"] = {
			["name"] = "Newtworare-Frostmourne",
			["time"] = 1695938591,
			["ilvl"] = 265.6875,
		},
		["Player-84-089E8911"] = {
			["time"] = 1696016784,
			["name"] = "Drac-Dragonmaw",
			["ilvl"] = 441.1875,
		},
		["Player-76-0B8E771B"] = {
			["time"] = 1696016784,
			["name"] = "Kalythra-Sargeras",
			["ilvl"] = 446.5,
		},
		["Player-3684-0E014D1A"] = {
			["name"] = "Sultarion",
			["time"] = 1696019142,
			["ilvl"] = 442.375,
		},
		["Player-11-0E51BD8F"] = {
			["time"] = 1696024599,
			["name"] = "Wågyußeef-Tichondrius",
			["ilvl"] = 401.625,
		},
		["Player-1427-0E1BF09D"] = {
			["time"] = 1696024600,
			["name"] = "Syren-Ragnaros",
			["ilvl"] = 416.3125,
		},
		["Player-67-0F019A46"] = {
			["name"] = "Sannyøk-Auchindoun",
			["time"] = 1695938569,
			["ilvl"] = 402.1875,
		},
		["Player-3684-0CFF7479"] = {
			["name"] = "Gelosia",
			["time"] = 1695938569,
			["ilvl"] = 409.125,
		},
		["Player-162-0B4E4881"] = {
			["name"] = "Oladson-EmeraldDream",
			["time"] = 1695935996,
			["ilvl"] = 393.125,
		},
		["Player-3676-09F465EF"] = {
			["name"] = "Endofnothing-Area52",
			["time"] = 1695935920,
			["ilvl"] = 410.9375,
		},
	},
	["savedStyles"] = {
	},
	["always_use_profile_exception"] = {
	},
	["merge_player_abilities"] = false,
	["mythic_plus"] = {
		["make_overall_boss_only"] = false,
		["mythicrun_chart_frame_ready"] = {
			["y"] = 6.103515625e-05,
			["x"] = -9.1552734375e-05,
			["point"] = "CENTER",
			["scale"] = 1,
		},
		["merge_boss_trash"] = true,
		["delay_to_show_graphic"] = 5,
		["reverse_death_log"] = false,
		["make_overall_when_done"] = true,
		["show_damage_graphic"] = true,
		["mythicrun_chart_frame"] = {
			["y"] = -37.19627380371094,
			["x"] = 187.0771484375,
			["point"] = "CENTER",
			["scale"] = 1,
		},
		["boss_dedicated_segment"] = true,
		["mythicrun_chart_frame_minimized"] = {
			["y"] = 0.0001220703125,
			["x"] = 3.0517578125e-05,
			["point"] = "CENTER",
			["scale"] = 1,
		},
		["last_mythicrun_chart"] = {
		},
	},
	["savedTimeCaptures"] = {
	},
	["spell_category_savedtable"] = {
	},
	["damage_scroll_position"] = {
		["scale"] = 1,
	},
	["performance_profiles"] = {
		["Dungeon"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["RaidFinder"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Battleground15"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Battleground40"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Mythic"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Arena"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Raid30"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Raid15"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
	},
	["exit_log"] = {
		"1 - Closing Breakdown Window.", -- [1]
		"2 - Clearing user placed position from instance windows.", -- [2]
		"  - 1 has baseFrame: yes.", -- [3]
		"4 - Reversing switches.", -- [4]
		"6 - Saving Config.", -- [5]
		"7 - Saving Profiles.", -- [6]
		"8 - Saving nicktag cache.", -- [7]
		"9 - Saving Auto Run Code.", -- [8]
	},
	["installed_skins_cache"] = {
	},
	["update_warning_timeout"] = 10,
	["deathlog_line_height"] = 16,
}
__details_backup = {
	["_instance_backup"] = {
	},
	["_general_logs"] = {
		"2023-09-29 12:56:25 | actor removed Withering Contagion (disposable)", -- [1]
		"2023-09-29 12:56:25 | actor removed Bloody Bite (disposable)", -- [2]
		"2023-09-29 12:56:25 | actor removed Scented Meat (disposable)", -- [3]
		"2023-09-29 12:56:25 | actor removed Bone Bolt (disposable)", -- [4]
		"2023-09-29 12:56:25 | actor removed Withering Poison (disposable)", -- [5]
		"2023-09-29 12:56:25 | actor removed Disoriented (disposable)", -- [6]
		"2023-09-29 12:56:25 | actor removed Bertinuat (disposable)", -- [7]
		"2023-09-29 12:56:25 | actor removed Infuse Corruption (disposable)", -- [8]
		"2023-09-29 12:56:25 | actor removed Withering (disposable)", -- [9]
		"2023-09-29 12:56:25 | actor removed Decaying Roots (disposable)", -- [10]
		"2023-09-29 12:56:25 | actor removed Gushing Ooze (disposable)", -- [11]
		"2023-09-29 12:56:25 | actor removed Crushing Smash (disposable)", -- [12]
		"2023-09-29 12:56:25 | actor removed Vicious Clawmangle (disposable)", -- [13]
		"2023-09-29 12:56:25 | actor removed Toxic Trap (disposable)", -- [14]
		"2023-09-29 12:56:25 | actor removed Rotchanting Totem (disposable)", -- [15]
		"2023-09-29 12:56:25 | actor removed Capacitor Totem <Stormart> (disposable)", -- [16]
		"2023-09-29 12:56:25 | actor removed Viscid Bile (disposable)", -- [17]
		"2023-09-29 12:56:25 | actor removed Rancid Ooze (disposable)", -- [18]
		"2023-09-29 12:56:25 | actor removed Piercing Shards (disposable)", -- [19]
		"2023-09-29 12:56:25 | actor removed Bone Chomp <Stoneclaw Hunter> (disposable)", -- [20]
		"2023-09-29 12:56:25 | actor removed Earthbind Totem <Stormart> (disposable)", -- [21]
		"2023-09-29 12:56:25 | actor removed Acid Splatter (disposable)", -- [22]
		"2023-09-29 12:56:25 | actor removed Rotting Surge (disposable)", -- [23]
		"2023-09-29 12:56:25 | actor removed Decay Claws (disposable)", -- [24]
		"2023-09-29 12:56:25 | actor removed Bleeding (disposable)", -- [25]
		"2023-09-29 12:56:25 | actor removed Necrotic Breath (disposable)", -- [26]
		"2023-09-29 12:56:25 | actor removed Bleeding <Wilted Oak> (disposable)", -- [27]
		"2023-09-29 12:56:25 | actor removed Bleeding <Brackenhide Shaper> (disposable)", -- [28]
		"2023-09-29 12:56:25 | actor removed Infected Bite (disposable)", -- [29]
	},
	["_exit_error"] = {
	},
}
