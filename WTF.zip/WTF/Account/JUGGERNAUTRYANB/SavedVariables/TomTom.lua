
TomTomDB = {
	["profileKeys"] = {
		["Janwa - Mal'Ganis"] = "Default",
		["Gelosia - Mal'Ganis"] = "Default",
		["Ryanmage - Mal'Ganis"] = "Default",
		["Allaeda - Mal'Ganis"] = "Default",
		["Stormart - Mal'Ganis"] = "Default",
		["Skelay - Mal'Ganis"] = "Default",
		["Elyyine - Mal'Ganis"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["arrow"] = {
				["position"] = {
					"CENTER", -- [1]
					nil, -- [2]
					"CENTER", -- [3]
					102.8376617431641, -- [4]
					147.6923065185547, -- [5]
				},
			},
			["block"] = {
				["position"] = {
					"BOTTOMRIGHT", -- [1]
					nil, -- [2]
					"BOTTOMRIGHT", -- [3]
					0, -- [4]
					285.5387573242188, -- [5]
				},
			},
		},
	},
}
TomTomWaypoints = nil
TomTomWaypointsM = {
	["profileKeys"] = {
		["Janwa - Mal'Ganis"] = "Janwa - Mal'Ganis",
		["Gelosia - Mal'Ganis"] = "Gelosia - Mal'Ganis",
		["Ryanmage - Mal'Ganis"] = "Ryanmage - Mal'Ganis",
		["Allaeda - Mal'Ganis"] = "Allaeda - Mal'Ganis",
		["Stormart - Mal'Ganis"] = "Stormart - Mal'Ganis",
		["Skelay - Mal'Ganis"] = "Skelay - Mal'Ganis",
		["Elyyine - Mal'Ganis"] = "Elyyine - Mal'Ganis",
	},
	["profiles"] = {
		["Janwa - Mal'Ganis"] = {
		},
		["Gelosia - Mal'Ganis"] = {
		},
		["Ryanmage - Mal'Ganis"] = {
		},
		["Allaeda - Mal'Ganis"] = {
		},
		["Stormart - Mal'Ganis"] = {
		},
		["Skelay - Mal'Ganis"] = {
		},
		["Elyyine - Mal'Ganis"] = {
		},
	},
}
