
GoldSave = {
	["Skelay_Mal'Ganis::Horde"] = {
		["show"] = true,
		["name"] = "Skelay",
		["gold"] = 525862842,
		["faction"] = "Horde",
		["realm"] = "Mal'Ganis",
	},
	["Allaeda_Mal'Ganis::Horde"] = {
		["show"] = true,
		["name"] = "Allaeda",
		["gold"] = 297326591,
		["faction"] = "Horde",
		["realm"] = "Mal'Ganis",
	},
	["Gelosia_Mal'Ganis::Horde"] = {
		["show"] = true,
		["name"] = "Gelosia",
		["gold"] = 550471487,
		["faction"] = "Horde",
		["realm"] = "Mal'Ganis",
	},
	["Stormart_Mal'Ganis::Alliance"] = {
		["show"] = true,
		["name"] = "Stormart",
		["gold"] = 10349858409,
		["faction"] = "Alliance",
		["realm"] = "Mal'Ganis",
	},
}
