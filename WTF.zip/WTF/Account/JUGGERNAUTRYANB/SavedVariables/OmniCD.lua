
OmniCDDB = {
	["profileKeys"] = {
		["Janwa - Mal'Ganis"] = "Default",
		["Gelosia - Mal'Ganis"] = "Default",
		["Ryanmage - Mal'Ganis"] = "Default",
		["Allaeda - Mal'Ganis"] = "Default",
		["Stormart - Mal'Ganis"] = "Default",
		["Skelay - Mal'Ganis"] = "Default",
		["Elyyine - Mal'Ganis"] = "Default",
	},
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["cooldowns"] = {
	},
	["version"] = 3,
	["profiles"] = {
		["Default"] = {
			["Party"] = {
				["party"] = {
					["extraBars"] = {
						["raidBar0"] = {
							["manualPos"] = {
								["raidBar0"] = {
									["y"] = 299.7026943902711,
									["x"] = 498.8749817013741,
								},
							},
						},
					},
					["position"] = {
						["displayInactive"] = false,
					},
				},
			},
		},
	},
}
