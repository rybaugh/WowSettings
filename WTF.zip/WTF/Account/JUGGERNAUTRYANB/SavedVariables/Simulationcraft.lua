
SimulationCraftDB = {
	["profileKeys"] = {
		["Stormart - Mal'Ganis"] = "Stormart - Mal'Ganis",
		["Allaeda - Mal'Ganis"] = "Allaeda - Mal'Ganis",
		["Skelay - Mal'Ganis"] = "Skelay - Mal'Ganis",
		["Gelosia - Mal'Ganis"] = "Gelosia - Mal'Ganis",
	},
	["profiles"] = {
		["Stormart - Mal'Ganis"] = {
		},
		["Allaeda - Mal'Ganis"] = {
		},
		["Skelay - Mal'Ganis"] = {
			["minimap"] = {
				["minimapPos"] = 88.13407721763961,
			},
		},
		["Gelosia - Mal'Ganis"] = {
		},
	},
}
