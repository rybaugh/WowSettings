
LeaPlusDB = {
	["WidgetTopR"] = "TOP",
	["MuteBattleShouts"] = "Off",
	["MuteCustomList"] = "",
	["MusicContinent"] = "Zones",
	["ClassColPlayer"] = "On",
	["MuteRazorwings"] = "Off",
	["DressupTransmogAnim"] = "Off",
	["ShowMinimapIcon"] = "On",
	["TipCursorY"] = 0,
	["ChatTemp5"] = {
		"|cff00aa00|cff979797|Hpratcopy|h[09:08:05]|h|r |cffa5a5a5Ugahboogah|r-Thrall receives loot: |cff0070dd|Hitem:201300::::::::70:263:::::::::|h[Iridescent Ore Fragments]|h|r.", -- [1]
		"|cff00aa00|cff979797|Hpratcopy|h[09:08:13]|h|r |cffa5a5a5Ugahboogah|r-Thrall receives loot: |cff0070dd|Hitem:190315::::::::70:263:::::::::|h[Rousing Earth]|h|rx4.", -- [2]
		"|cff00aa00|cff979797|Hpratcopy|h[09:08:13]|h|r |cffa5a5a5Ugahboogah|r-Thrall receives loot: |cff1eff00|Hitem:188658::::::::70:263::::1:38:2:::::|h[Draconium Ore |A:Professions-ChatIcon-Quality-Tier2:17:23::1|a]|h|rx3.", -- [3]
		"|cffffff00|cff979797|Hpratcopy|h[09:08:30]|h|r |cffa5a5a5Beefquin|r-Barthilas leaves the party.", -- [4]
		"|cffffff00|cff979797|Hpratcopy|h[09:08:35]|h|r |WLuddyxdxd-Kel'Thuzad (Horde)|w joins the party.", -- [5]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:08:41]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Luddyxdxd-Kel'Thuzad:389:PARTY|h|cffd8bc3f70|r:|cff33937fLuddyxdxd|r-|cff33d7feKel|r|h|cffd8d8d8]|r: yo", -- [6]
		"|cff00aa00|cff979797|Hpratcopy|h[09:09:03]|h|r |cffa5a5a5Ugahboogah|r-Thrall receives loot: |cffffffff|Hitem:190396::::::::70:263::::1:38:2:::::|h[Serevite Ore |A:Professions-ChatIcon-Quality-Tier2:17:23::1|a]|h|rx14.", -- [7]
		"|cff00aa00|cff979797|Hpratcopy|h[09:09:03]|h|r |cffa5a5a5Ugahboogah|r-Thrall receives loot: |cffffffff|Hitem:197754::::::::70:263:::::::::|h[Salt Deposit]|h|rx2.", -- [8]
		"|cff00aa00|cff979797|Hpratcopy|h[09:09:03]|h|r |cffa5a5a5Ugahboogah|r-Thrall receives loot: |cff0070dd|Hitem:190312::::::::70:263::::1:38:1:::::|h[Khaz'gorite Ore |A:Professions-ChatIcon-Quality-Tier1:17:15::1|a]|h|r.", -- [9]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:09:20]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Luddyxdxd-Kel'Thuzad:394:PARTY|h|cffd8bc3f70|r:|cff33937fLuddyxdxd|r-|cff33d7feKel|r|h|cffd8d8d8]|r: wa", -- [10]
		"|cff00aa00|cff979797|Hpratcopy|h[09:09:27]|h|r |cffa5a5a5Ugahboogah|r-Thrall receives loot: |cffffffff|Hitem:190396::::::::70:263::::1:38:2:::::|h[Serevite Ore |A:Professions-ChatIcon-Quality-Tier2:17:23::1|a]|h|rx4.", -- [11]
		"|cff00aa00|cff979797|Hpratcopy|h[09:10:00]|h|r |cffa5a5a5Ugahboogah|r-Thrall receives loot: |cff1eff00|Hitem:188658::::::::70:263::::1:38:2:::::|h[Draconium Ore |A:Professions-ChatIcon-Quality-Tier2:17:23::1|a]|h|rx3.", -- [12]
		"|cff00aa00|cff979797|Hpratcopy|h[09:10:18]|h|r |cffa5a5a5Ugahboogah|r-Thrall receives item: |cff0070dd|Hitem:190324::::::::70:263:::::::::|h[Awakened Order]|h|r.", -- [13]
		"|cff00aa00|cff979797|Hpratcopy|h[09:10:23]|h|r |cffa5a5a5Ugahboogah|r-Thrall receives loot: |cffffffff|Hitem:190396::::::::70:263::::1:38:2:::::|h[Serevite Ore |A:Professions-ChatIcon-Quality-Tier2:17:23::1|a]|h|rx3.", -- [14]
		"|cff00aa00|cff979797|Hpratcopy|h[09:10:23]|h|r |cffa5a5a5Ugahboogah|r-Thrall receives loot: |cff0070dd|Hitem:190322::::::::70:263:::::::::|h[Rousing Order]|h|rx4.", -- [15]
		"|cff00aa00|cff979797|Hpratcopy|h[09:10:34]|h|r |cffa5a5a5Ugahboogah|r-Thrall receives loot: |cffffffff|Hitem:190396::::::::70:263::::1:38:2:::::|h[Serevite Ore |A:Professions-ChatIcon-Quality-Tier2:17:23::1|a]|h|rx3.", -- [16]
		"|cff00aa00|cff979797|Hpratcopy|h[09:10:34]|h|r |cffa5a5a5Ugahboogah|r-Thrall receives loot: |cffffffff|Hitem:197754::::::::70:263:::::::::|h[Salt Deposit]|h|r.", -- [17]
		"|cff00aa00|cff979797|Hpratcopy|h[09:10:34]|h|r |cffa5a5a5Ugahboogah|r-Thrall receives loot: |cff0070dd|Hitem:190315::::::::70:263:::::::::|h[Rousing Earth]|h|rx6.", -- [18]
		"|cffffff00|cff979797|Hpratcopy|h[09:10:39]|h|r Mistmedaddy-Frostmourne joins the party.", -- [19]
		"|cffffff00|cff979797|Hpratcopy|h[09:10:48]|h|r |cffa5a5a5Mistmedaddy|r-Frostmourne leaves the party.", -- [20]
		"|cff00aa00|cff979797|Hpratcopy|h[09:11:08]|h|r |cffa5a5a5Ugahboogah|r-Thrall receives loot: |cff9d9d9d|Hitem:188735::::::::70:263:::1:7966:2:9:70:28:2437:::::|h[Timeworn Chain Clasp]|h|r.", -- [21]
		"|cff00aa00|cff979797|Hpratcopy|h[09:11:43]|h|r |cffa5a5a5Ugahboogah|r-Thrall receives loot: |cffffffff|Hitem:194966::::::::70:263:::::::::|h[Thousandbite Piranha]|h|r.", -- [22]
		"|cff00aa00|cff979797|Hpratcopy|h[09:12:00]|h|r |cffa5a5a5Ugahboogah|r-Thrall receives loot: |cffffffff|Hitem:194966::::::::70:263:::::::::|h[Thousandbite Piranha]|h|r.", -- [23]
		"|cffffff00|cff979797|Hpratcopy|h[09:12:09]|h|r |WHuulia-Zul'jin (Horde)|w joins the party.", -- [24]
		"|cff00aa00|cff979797|Hpratcopy|h[09:12:11]|h|r |cffa5a5a5Ugahboogah|r-Thrall receives loot: |cffffffff|Hitem:194966::::::::70:263:::::::::|h[Thousandbite Piranha]|h|r.", -- [25]
		"|cff76c8ff|cff979797|Hpratcopy|h[09:12:14]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Stormart-Mal'Ganis:410:PARTY|h|cffd8bc3f70|r:|cff0070ddStormart|r|h|cffd8d8d8]|r: at stone", -- [26]
		"|cff00aa00|cff979797|Hpratcopy|h[09:12:39]|h|r |cffa5a5a5Paull|r-Azralon receives loot: |cffffffff|Hitem:193050::::::::70:263:::::::::|h[Tattered Wildercloth]|h|r.", -- [27]
		"|cff00aa00|cff979797|Hpratcopy|h[09:12:40]|h|r |cffa5a5a5Paull|r-Azralon receives loot: |cffffffff|Hitem:193201::::::::70:263:::::::::|h[Key Framing]|h|r.", -- [28]
		"|cff00aa00|cff979797|Hpratcopy|h[09:12:40]|h|r |cffa5a5a5Paull|r-Azralon receives loot: |cffffffff|Hitem:191251::::::::70:263:::::::::|h[Key Fragments]|h|rx3.", -- [29]
		"|cffffff00|cff979797|Hpratcopy|h[09:13:19]|h|r Your instance lock for Neltharus will expire in 1 |4hour:hours;.", -- [30]
		"|cffffff00|cff979797|Hpratcopy|h[09:13:24]|h|r |cffa5a5a5Ugahboogah|r-Thrall is now the group leader.", -- [31]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:13:28]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Stormart-Mal'Ganis:418:PARTY|h|cffd8bc3f70|r:|cff0070ddStormart|r|h|cffd8d8d8]|r: ugah you got lead", -- [32]
		"|cffffff00|cff979797|Hpratcopy|h[09:13:37]|h|r |cffa5a5a5Ugahboogah|r-Thrall has initiated a ready check.", -- [33]
		"|cffffff00|cff979797|Hpratcopy|h[09:15:17]|h|r |cfff48cbaCorbán|r has gone offline.", -- [34]
		"|cffffff00|cff979797|Hpratcopy|h[09:15:33]|h|r |cffd8d8d8[|r|Hplayer:Corbaño:423|h|cffd8bc3f70|r:|cffffffffCorbaño|r|h|cffd8d8d8]|r has come online.", -- [35]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:16:16]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Luddyxdxd-Kel'Thuzad:424:PARTY|h|cffd8bc3f70|r:|cff33937fLuddyxdxd|r-|cff33d7feKel|r|h|cffd8d8d8]|r: wahju dahjuw", -- [36]
		"|cffffff00|cff979797|Hpratcopy|h[09:17:06]|h|r |cffffffffCorbaño|r has gone offline.", -- [37]
		"|cffffff00|cff979797|Hpratcopy|h[09:17:21]|h|r |cffd8d8d8[|r|Hplayer:Diom:426|h|cffd8bc3f68|r:|cffa330c9Diom|r|h|cffd8d8d8]|r has come online.", -- [38]
		"|cffffff00|cff979797|Hpratcopy|h[09:19:09]|h|r |cffa5a5a5Huulia|r has died.", -- [39]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:19:22]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Huulia-Zul'jin:430:PARTY|h|cffd8bc3f70|r:|cff0070ddHuulia|r-|cffad92d1Zul|r|h|cffd8d8d8]|r: zoned out lol", -- [40]
		"|cffffff00|cff979797|Hpratcopy|h[09:21:34]|h|r |cff71d5ff|Hdeath:7|h[You died.]|h", -- [41]
		"|cffffff00|cff979797|Hpratcopy|h[09:21:55]|h|r |cffa330c9Diom|r has gone offline.", -- [42]
		"|cffffff00|cff979797|Hpratcopy|h[09:22:10]|h|r |cffd8d8d8[|r|Hplayer:Corb:438|h|cff8b8b8b64|r:|cff00ff98Corb|r|h|cffd8d8d8]|r has come online.", -- [43]
		"|cffffff00|cff979797|Hpratcopy|h[09:24:53]|h|r |cff00ff98Corb|r has gone offline.", -- [44]
		"|cffffff00|cff979797|Hpratcopy|h[09:25:38]|h|r |cffd8d8d8[|r|Hplayer:Vaness:452|h|cffd8bc3f70|r:|cff0070ddVaness|r|h|cffd8d8d8]|r has come online.", -- [45]
		"|cffffff00|cff979797|Hpratcopy|h[09:26:44]|h|r |cffa5a5a5Paull|r has died.", -- [46]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:27:28]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Paull-Azralon:454:PARTY|h|cffd8bc3f70|r:|cfff48cbaPaull|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: ty", -- [47]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:28:43]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Paull-Azralon:455:PARTY|h|cffd8bc3f70|r:|cfff48cbaPaull|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: Interrompeu Sinalizador de Lava's |cff71d5ff|Hspell:372538:0|h[Derreter]|h|r!", -- [48]
		"|cffffff00|cff979797|Hpratcopy|h[09:28:51]|h|r |cffa5a5a5Paull|r has died.", -- [49]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:28:55]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Paull-Azralon:457:PARTY|h|cffd8bc3f70|r:|cfff48cbaPaull|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: agro plz", -- [50]
		"|cffffff00|cff979797|Hpratcopy|h[09:29:34]|h|r |cff0070ddVaness|r has gone offline.", -- [51]
		"|cffffff00|cff979797|Hpratcopy|h[09:29:50]|h|r |cffd8d8d8[|r|Hplayer:Caj:459|h|cffd8bc3f70|r:|cfffff468Caj|r|h|cffd8d8d8]|r has come online.", -- [52]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:30:06]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Paull-Azralon:460:PARTY|h|cffd8bc3f70|r:|cfff48cbaPaull|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: ty again", -- [53]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:30:12]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Luddyxdxd-Kel'Thuzad:461:PARTY|h|cffd8bc3f70|r:|cff33937fLuddyxdxd|r-|cff33d7feKel|r|h|cffd8d8d8]|r: i just swapped t o plater", -- [54]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:30:15]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Luddyxdxd-Kel'Thuzad:462:PARTY|h|cffd8bc3f70|r:|cff33937fLuddyxdxd|r-|cff33d7feKel|r|h|cffd8d8d8]|r: and i thought i had it", -- [55]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:30:18]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Luddyxdxd-Kel'Thuzad:463:PARTY|h|cffd8bc3f70|r:|cff33937fLuddyxdxd|r-|cff33d7feKel|r|h|cffd8d8d8]|r: but im fucking lost", -- [56]
		"|cffffff00|cff979797|Hpratcopy|h[09:33:08]|h|r |cfffff468Caj|r has gone offline.", -- [57]
		"|cffffff00|cff979797|Hpratcopy|h[09:33:23]|h|r |cffd8d8d8[|r|Hplayer:Yle:492|h|cff8b8b8b62|r:|cff3fc7ebYle|r|h|cffd8d8d8]|r has come online.", -- [58]
		"|cffffff00|cff979797|Hpratcopy|h[09:33:47]|h|r |cffa5a5a5Huulia|r has died.", -- [59]
		"|cffffff00|cff979797|Hpratcopy|h[09:34:40]|h|r |cff71d5ff|Hdeath:8|h[You died.]|h", -- [60]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:34:43]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Stormart-Mal'Ganis:496:PARTY|h|cffd8bc3f70|r:|cff0070ddStormart|r|h|cffd8d8d8]|r: come on", -- [61]
		"|cffffff00|cff979797|Hpratcopy|h[09:37:17]|h|r |cff3fc7ebYle|r has gone offline.", -- [62]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:37:21]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Paull-Azralon:499:PARTY|h|cffd8bc3f70|r:|cfff48cbaPaull|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: Interrompeu Lavamante Qalashi's |cff71d5ff|Hspell:383231:0|h[Seta de Lava]|h|r!", -- [63]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:37:39]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Paull-Azralon:500:PARTY|h|cffd8bc3f70|r:|cfff48cbaPaull|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: Interrompeu Lavamante Qalashi's |cff71d5ff|Hspell:383231:0|h[Seta de Lava]|h|r!", -- [64]
		"|cffffff00|cff979797|Hpratcopy|h[09:38:13]|h|r |cffd8d8d8[|r|Hplayer:Corbán:502|h|cffd8bc3f70|r:|cfff48cbaCorbán|r|h|cffd8d8d8]|r has come online.", -- [65]
		"|cff00aa00|cff979797|Hpratcopy|h[09:40:06]|h|r You receive item: |cff0070dd|Hitem:204078::::::::70:263:::::::::|h[Aspect's Shadowflame Crest Fragment]|h|rx12", -- [66]
		"|cff00aa00|cff979797|Hpratcopy|h[09:40:08]|h|r You receive loot: |cffa335ee|Hitem:193785::::::::70:263::33:5:9330:6652:9147:1650:8767:1:28:1279:::::|h[Forgestorm]|h|r", -- [67]
		"|cff00aa00|cff979797|Hpratcopy|h[09:40:11]|h|r |cffa5a5a5Paull|r-Azralon receives loot: |cffa335ee|Hitem:193789::::::::70:263::16:7:9330:6652:9223:9221:9144:1650:8767:1:28:1279:::::|h[Fural's Blazing Faulds]|h|r.", -- [68]
		"|cffffff00|cff979797|Hpratcopy|h[09:40:15]|h|r You have requested to trade with |cffa5a5a5Huulia|r-Zul'jin.", -- [69]
		"|cff00aa00|cff979797|Hpratcopy|h[09:40:16]|h|r |cffa5a5a5Huulia|r-Zul'jin receives loot: |cffa335ee|Hitem:180653::::::::70:263::::5:17:406:18:17:19:10:20:3:21:123:::::|h[Mythic Keystone]|h|r.", -- [70]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:40:29]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Huulia-Zul'jin:524:PARTY|h|cffd8bc3f70|r:|cff0070ddHuulia|r-|cffad92d1Zul|r|h|cffd8d8d8]|r: ggs!", -- [71]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:40:40]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Luddyxdxd-Kel'Thuzad:525:PARTY|h|cffd8bc3f70|r:|cff33937fLuddyxdxd|r-|cff33d7feKel|r|h|cffd8d8d8]|r: gg", -- [72]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:40:40]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Paull-Azralon:526:PARTY|h|cffd8bc3f70|r:|cfff48cbaPaull|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: |cffa335ee|Hitem:193789::::::::70:70::16:7:9330:6652:9223:9221:9144:1650:8767:1:28:1279:::::|h[Escarcelas Fulgurantes de Fural]|h|r", -- [73]
		"|cffffff00|cff979797|Hpratcopy|h[09:40:41]|h|r |cffa5a5a5Luddyxdxd|r-Kel'Thuzad leaves the party.", -- [74]
		"|cff76c8ff|cff979797|Hpratcopy|h[09:40:43]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Ugahboogah-Thrall:538:PARTY|h|cffd8bc3f70|r:|cffc41e3aUgahboogah|r-|cff1dfd54Thr|r|h|cffd8d8d8]|r: leegs?", -- [75]
		"|cffffff00|cff979797|Hpratcopy|h[09:40:44]|h|r Neondrake has fled from Gatzar in a duel", -- [76]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:40:47]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Paull-Azralon:546:PARTY|h|cffd8bc3f70|r:|cfff48cbaPaull|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: y", -- [77]
		"|cffffff00|cff979797|Hpratcopy|h[09:40:53]|h|r |cfff48cbaCorbán|r has gone offline.", -- [78]
		"|cffffff00|cff979797|Hpratcopy|h[09:41:07]|h|r |cffd8d8d8[|r|Hplayer:Diom:572|h|cffd8bc3f68|r:|cffa330c9Diom|r|h|cffd8d8d8]|r has come online.", -- [79]
		"|cffffff00|cff979797|Hpratcopy|h[09:42:12]|h|r |cffa330c9Diom|r has gone offline.", -- [80]
		"|cffffff00|cff979797|Hpratcopy|h[09:42:14]|h|r You leave the group.", -- [81]
		"|cff00aa00|cff979797|Hpratcopy|h[11:07:21]|h|r You receive item: |cffa335ee|Hitem:180653::::::::70:263::::5:17:206:18:21:19:9:20:124:21:6:::::|h[Mythic Keystone]|h|r", -- [82]
		"|cff00aa00|cff979797|Hpratcopy|h[11:07:21]|h|r You receive item: |cffa335ee|Hitem:205225::::::::70:263:::::::::|h[Aspects' Token of Merit]|h|rx6", -- [83]
		"|cffffff00|cff979797|Hpratcopy|h[11:09:05]|h|r |cffff7c0aNabrocan|r has gone offline.", -- [84]
		"|cffffff00|cff979797|Hpratcopy|h[11:09:20]|h|r |cffd8d8d8[|r|Hplayer:Corßan:174|h|cffd8bc3f70|r:|cff33937fCorßan|r|h|cffd8d8d8]|r has come online.", -- [85]
		"|cffffff00|cff979797|Hpratcopy|h[11:10:26]|h|r |cffd8d8d8[|r|Hplayer:Jimsdk-Mal'Ganis:175:ACHIEVEMENT|h|cffc41e3aJimsdk|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18977:Player-3684-0891AEB7:1:9:26:23:4294967295:4294967295:4294967295:4294967295|h[Draconically Epic]|h|r |cffffffff(|rCompleted 8/23/23|cffffffff)|r!", -- [86]
		"|cff00aa00|cff979797|Hpratcopy|h[11:10:43]|h|r You receive item: |cffa335ee|Hitem:204717::::::::70:263:::::::::|h[Splintered Spark of Shadowflame]|h|rx2", -- [87]
		"|cffffff00|cff979797|Hpratcopy|h[11:11:05]|h|r |cffc69b6dBrich|r has gone offline.", -- [88]
		"|cffffff00|cff979797|Hpratcopy|h[11:11:14]|h|r |cffd8d8d8[|r|Hplayer:Hivaids:178|h|cffd8bc3f70|r:|cffaad372Hivaids|r|h|cffd8d8d8]|r has come online.", -- [89]
		"|cffffff00|cff979797|Hpratcopy|h[11:11:50]|h|r |cffaad372Hivaids|r has gone offline.", -- [90]
		"|cffffff00|cff979797|Hpratcopy|h[11:12:00]|h|r |cffd8d8d8[|r|Hplayer:Brich:180|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r has come online.", -- [91]
		"|cffff80ff|cff979797|Hpratcopy|h[11:14:00]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:181:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: stop logging in and acting like you're checking vault. we all know you dont play anymore", -- [92]
		"|cffff80ff|cff979797|Hpratcopy|h[11:14:13]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:182:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: i get vault every tuesday", -- [93]
		"|cffff80ff|cff979797|Hpratcopy|h[11:14:13]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:183:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: also promote me", -- [94]
		"|cffff80ff|cff979797|Hpratcopy|h[11:14:29]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:184:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: if you played and logged in you would know you've been promoted already", -- [95]
		"|cffff80ff|cff979797|Hpratcopy|h[11:15:52]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:186:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: no", -- [96]
		"|cffff80ff|cff979797|Hpratcopy|h[11:15:53]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:187:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: brady", -- [97]
		"|cffff80ff|cff979797|Hpratcopy|h[11:15:58]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:188:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: promote. me. now.", -- [98]
		"|cffff80ff|cff979797|Hpratcopy|h[11:16:08]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:189:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: to my correct rank", -- [99]
		"|cffffff00|cff979797|Hpratcopy|h[11:17:30]|h|r |cffc69b6dBrich|r has promoted |cff00ff00Stormart|r to GuiId Master.", -- [100]
		"|cff00aa00|cff979797|Hpratcopy|h[11:17:51]|h|r You receive item: |cffa335ee|Hitem:204440::::::::70:263:::::::::|h[Spark of Shadowflame]|h|r", -- [101]
		"|cffff80ff|cff979797|Hpratcopy|h[11:18:02]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:193:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: there", -- [102]
		"|cffff80ff|cff979797|Hpratcopy|h[11:20:13]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:198:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: i hate you", -- [103]
		"|cffff80ff|cff979797|Hpratcopy|h[11:20:33]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:204:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: lol", -- [104]
		"|cffff80ff|cff979797|Hpratcopy|h[11:20:58]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:205:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: have you seen the new bad message system in game?", -- [105]
		"|cffff80ff|cff979797|Hpratcopy|h[11:21:13]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:206:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: ill send you what you just sent me and see how it comes through to you in whispers", -- [106]
		"|cffff80ff|cff979797|Hpratcopy|h[11:21:15]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:207:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: i hate you", -- [107]
		"|cffff80ff|cff979797|Hpratcopy|h[11:21:38]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:209:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: nothing happened", -- [108]
		"|cffff80ff|cff979797|Hpratcopy|h[11:22:08]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:210:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: oh really? i got a thing that was like |cff00ff00stormart|r send you an inappropriorate message. then had [View Message] for me to click to actually make it appear", -- [109]
		"|cffff80ff|cff979797|Hpratcopy|h[11:22:18]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:211:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: wtf", -- [110]
		"|cffff80ff|cff979797|Hpratcopy|h[11:22:21]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:212:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: disable that shit", -- [111]
		"|cffff80ff|cff979797|Hpratcopy|h[11:22:25]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:213:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: now i have a yellow [Report] button next to your \"i hate you message\"", -- [112]
		"|cffff80ff|cff979797|Hpratcopy|h[11:23:23]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:220:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: weird, it was set to censor everyone but friends", -- [113]
		"|cffff80ff|cff979797|Hpratcopy|h[11:23:38]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:228:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: but i guess since you're direct whispering me it doesnt count as a friend", -- [114]
		"|cffff80ff|cff979797|Hpratcopy|h[11:24:25]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:251:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: yeah idk", -- [115]
		"|cffff80ff|cff979797|Hpratcopy|h[11:24:25]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:252:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: and have you tried the ping system yet?", -- [116]
		"|cffffff00|cff979797|Hpratcopy|h[11:24:47]|h|r |cffd8d8d8[|r|Hplayer:Brich:268|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r has invited you to join a group.", -- [117]
		"|cffffff00|cff979797|Hpratcopy|h[11:25:14]|h|r Dungeon Difficulty set to Heroic.", -- [118]
		"|cffffff00|cff979797|Hpratcopy|h[11:25:14]|h|r This is now a cross-faction instance group. You can do these activities together: dungeons and raids (non-queued), Torghast, Rated PvP", -- [119]
		"|cffff80ff|cff979797|Hpratcopy|h[11:25:19]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:293:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: yeah i have", -- [120]
		"|cffff80ff|cff979797|Hpratcopy|h[11:25:29]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:298:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: pretty sick", -- [121]
		"|cffff80ff|cff979797|Hpratcopy|h[11:25:31]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:299:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: 100% they implemented this for solo q rbgs", -- [122]
		"|cffff80ff|cff979797|Hpratcopy|h[11:25:55]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:302:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: oh yeah, helps a lot with yolo rbgs for sure", -- [123]
		"|cffff80ff|cff979797|Hpratcopy|h[11:25:55]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:303:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: which would be fucking sick", -- [124]
		"|cffff80ff|cff979797|Hpratcopy|h[11:26:23]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:312:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: once i get used to it ill be using it in raids lol", -- [125]
		"|cffffff00|cff979797|Hpratcopy|h[11:27:44]|h|r Your group has been disbanded.", -- [126]
		"0 |4day:days;, 0 |4hour:hours;, 4 |4minute:minutes;, 39 |4second:seconds;", -- [127]
		"========== End of Scrollback ==========", -- [128]
	},
	["MuteMountSounds"] = "Off",
	["SetWeatherDensity"] = "On",
	["MuteArena"] = "Off",
	["MinimapR"] = "TOPRIGHT",
	["InvKey"] = "inv",
	["minimapPos"] = 77.08284522959488,
	["HideMiniAddonMenu"] = "On",
	["TipCursorX"] = 0,
	["ChatHistoryTime"] = 1695933082,
	["AutoReleaseDelay"] = 0,
	["MainPanelR"] = "CENTER",
	["LeaStartPage"] = 0,
	["AutoQuestWeekly"] = "On",
	["DressupItemButtons"] = "On",
	["InviteFriendsOnly"] = "Off",
	["HideErrorMessages"] = "On",
	["MuteBalls"] = "Off",
	["HideMacroText"] = "Off",
	["HideBossBanner"] = "Off",
	["MuteZeppelins"] = "Off",
	["AutoReleasePvP"] = "Off",
	["TransHallowed"] = "Off",
	["NoPetAutomation"] = "Off",
	["WowheadLinkComments"] = "Off",
	["AutoResNoCombat"] = "On",
	["ChatTemp6"] = {
		"|cff76c8ff|cff979797|Hpratcopy|h[09:12:14]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Stormart-Mal'Ganis:410:PARTY|h|cffd8bc3f70|r:|cff0070ddStormart|r|h|cffd8d8d8]|r: at stone", -- [1]
		"|cff00aa00|cff979797|Hpratcopy|h[09:12:39]|h|r |cffa5a5a5Paull|r-Azralon receives loot: |cffffffff|Hitem:193050::::::::70:263:::::::::|h[Tattered Wildercloth]|h|r.", -- [2]
		"|cff00aa00|cff979797|Hpratcopy|h[09:12:40]|h|r |cffa5a5a5Paull|r-Azralon receives loot: |cffffffff|Hitem:193201::::::::70:263:::::::::|h[Key Framing]|h|r.", -- [3]
		"|cff00aa00|cff979797|Hpratcopy|h[09:12:40]|h|r |cffa5a5a5Paull|r-Azralon receives loot: |cffffffff|Hitem:191251::::::::70:263:::::::::|h[Key Fragments]|h|rx3.", -- [4]
		"|cffffff00|cff979797|Hpratcopy|h[09:13:19]|h|r Your instance lock for Neltharus will expire in 1 |4hour:hours;.", -- [5]
		"|cffffff00|cff979797|Hpratcopy|h[09:13:24]|h|r |cffa5a5a5Ugahboogah|r-Thrall is now the group leader.", -- [6]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:13:28]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Stormart-Mal'Ganis:418:PARTY|h|cffd8bc3f70|r:|cff0070ddStormart|r|h|cffd8d8d8]|r: ugah you got lead", -- [7]
		"|cffffff00|cff979797|Hpratcopy|h[09:13:37]|h|r |cffa5a5a5Ugahboogah|r-Thrall has initiated a ready check.", -- [8]
		"|cffffffff|cff979797|Hpratcopy|h[09:13:37]|h|r [S] |cffd8d8d8[|r|Hplayer:Huulia-Zul'jin:421:SAY|h|cffd8bc3f70|r:|cff0070ddHuulia|r-|cffad92d1Zul|r|h|cffd8d8d8]|r: Reminder to check Talents :)", -- [9]
		"|cffffff00|cff979797|Hpratcopy|h[09:15:17]|h|r |cfff48cbaCorbán|r has gone offline.", -- [10]
		"|cffffff00|cff979797|Hpratcopy|h[09:15:33]|h|r |cffd8d8d8[|r|Hplayer:Corbaño:423|h|cffd8bc3f70|r:|cffffffffCorbaño|r|h|cffd8d8d8]|r has come online.", -- [11]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:16:16]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Luddyxdxd-Kel'Thuzad:424:PARTY|h|cffd8bc3f70|r:|cff33937fLuddyxdxd|r-|cff33d7feKel|r|h|cffd8d8d8]|r: wahju dahjuw", -- [12]
		"|cffffff00|cff979797|Hpratcopy|h[09:17:06]|h|r |cffffffffCorbaño|r has gone offline.", -- [13]
		"|cffffff00|cff979797|Hpratcopy|h[09:17:21]|h|r |cffd8d8d8[|r|Hplayer:Diom:426|h|cffd8bc3f68|r:|cffa330c9Diom|r|h|cffd8d8d8]|r has come online.", -- [14]
		"|cffffffff|cff979797|Hpratcopy|h[09:18:05]|h|r [S] |cffd8d8d8[|r|Hplayer:Ugahboogah-Thrall:428:SAY|h|cffd8bc3f70|r:|cffc41e3aUgahboogah|r-|cff1dfd54Thr|r|h|cffd8d8d8]|r: Lava Spray on |cffa5a5a5Ugahboogah|r", -- [15]
		"|cffffff00|cff979797|Hpratcopy|h[09:19:09]|h|r |cffa5a5a5Huulia|r has died.", -- [16]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:19:22]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Huulia-Zul'jin:430:PARTY|h|cffd8bc3f70|r:|cff0070ddHuulia|r-|cffad92d1Zul|r|h|cffd8d8d8]|r: zoned out lol", -- [17]
		"|cffff8040|cff979797|Hpratcopy|h[09:19:49]|h|r |Hplayer:Paull:431:TEXT_EMOTE:|h|cfff48cbaPaull|r|h-Azralon dances with Magmatusk.", -- [18]
		"|cffffff00|cff979797|Hpratcopy|h[09:21:34]|h|r |cff71d5ff|Hdeath:7|h[You died.]|h", -- [19]
		"|cffffff00|cff979797|Hpratcopy|h[09:21:55]|h|r |cffa330c9Diom|r has gone offline.", -- [20]
		"|cffffff00|cff979797|Hpratcopy|h[09:22:10]|h|r |cffd8d8d8[|r|Hplayer:Corb:438|h|cff8b8b8b64|r:|cff00ff98Corb|r|h|cffd8d8d8]|r has come online.", -- [21]
		"|cffffff00|cff979797|Hpratcopy|h[09:24:53]|h|r |cff00ff98Corb|r has gone offline.", -- [22]
		"|cffffff00|cff979797|Hpratcopy|h[09:25:38]|h|r |cffd8d8d8[|r|Hplayer:Vaness:452|h|cffd8bc3f70|r:|cff0070ddVaness|r|h|cffd8d8d8]|r has come online.", -- [23]
		"|cffffff00|cff979797|Hpratcopy|h[09:26:44]|h|r |cffa5a5a5Paull|r has died.", -- [24]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:27:28]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Paull-Azralon:454:PARTY|h|cffd8bc3f70|r:|cfff48cbaPaull|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: ty", -- [25]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:28:43]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Paull-Azralon:455:PARTY|h|cffd8bc3f70|r:|cfff48cbaPaull|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: Interrompeu Sinalizador de Lava's |cff71d5ff|Hspell:372538:0|h[Derreter]|h|r!", -- [26]
		"|cffffff00|cff979797|Hpratcopy|h[09:28:51]|h|r |cffa5a5a5Paull|r has died.", -- [27]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:28:55]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Paull-Azralon:457:PARTY|h|cffd8bc3f70|r:|cfff48cbaPaull|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: agro plz", -- [28]
		"|cffffff00|cff979797|Hpratcopy|h[09:29:34]|h|r |cff0070ddVaness|r has gone offline.", -- [29]
		"|cffffff00|cff979797|Hpratcopy|h[09:29:50]|h|r |cffd8d8d8[|r|Hplayer:Caj:459|h|cffd8bc3f70|r:|cfffff468Caj|r|h|cffd8d8d8]|r has come online.", -- [30]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:30:06]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Paull-Azralon:460:PARTY|h|cffd8bc3f70|r:|cfff48cbaPaull|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: ty again", -- [31]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:30:12]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Luddyxdxd-Kel'Thuzad:461:PARTY|h|cffd8bc3f70|r:|cff33937fLuddyxdxd|r-|cff33d7feKel|r|h|cffd8d8d8]|r: i just swapped t o plater", -- [32]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:30:15]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Luddyxdxd-Kel'Thuzad:462:PARTY|h|cffd8bc3f70|r:|cff33937fLuddyxdxd|r-|cff33d7feKel|r|h|cffd8d8d8]|r: and i thought i had it", -- [33]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:30:18]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Luddyxdxd-Kel'Thuzad:463:PARTY|h|cffd8bc3f70|r:|cff33937fLuddyxdxd|r-|cff33d7feKel|r|h|cffd8d8d8]|r: but im fucking lost", -- [34]
		"|cffffffff|cff979797|Hpratcopy|h[09:31:51]|h|r [S] |cffd8d8d8[|r|Hplayer:Huulia-Zul'jin:466:SAY|h|cffd8bc3f70|r:|cff0070ddHuulia|r-|cffad92d1Zul|r|h|cffd8d8d8]|r: Blazing Aegis on |cffa5a5a5Huulia|r", -- [35]
		"|cffffffff|cff979797|Hpratcopy|h[09:31:52]|h|r [S] |cffd8d8d8[|r|Hplayer:Huulia-Zul'jin:467:SAY|h|cffd8bc3f70|r:|cff0070ddHuulia|r-|cffad92d1Zul|r|h|cffd8d8d8]|r: 3", -- [36]
		"|cffffffff|cff979797|Hpratcopy|h[09:31:53]|h|r [S] |cffd8d8d8[|r|Hplayer:Huulia-Zul'jin:468:SAY|h|cffd8bc3f70|r:|cff0070ddHuulia|r-|cffad92d1Zul|r|h|cffd8d8d8]|r: 2", -- [37]
		"|cffffffff|cff979797|Hpratcopy|h[09:31:54]|h|r [S] |cffd8d8d8[|r|Hplayer:Huulia-Zul'jin:469:SAY|h|cffd8bc3f70|r:|cff0070ddHuulia|r-|cffad92d1Zul|r|h|cffd8d8d8]|r: 1", -- [38]
		"|cffffffff|cff979797|Hpratcopy|h[09:32:00]|h|r [S] |cffd8d8d8[|r|Hplayer:Ugahboogah-Thrall:471:SAY|h|cffd8bc3f70|r:|cffc41e3aUgahboogah|r-|cff1dfd54Thr|r|h|cffd8d8d8]|r: Heated Swings on |cffa5a5a5Ugahboogah|r", -- [39]
		"|cffffffff|cff979797|Hpratcopy|h[09:32:02]|h|r [S] |cffd8d8d8[|r|Hplayer:Ugahboogah-Thrall:472:SAY|h|cffd8bc3f70|r:|cffc41e3aUgahboogah|r-|cff1dfd54Thr|r|h|cffd8d8d8]|r: 3", -- [40]
		"|cffffffff|cff979797|Hpratcopy|h[09:32:03]|h|r [S] |cffd8d8d8[|r|Hplayer:Ugahboogah-Thrall:473:SAY|h|cffd8bc3f70|r:|cffc41e3aUgahboogah|r-|cff1dfd54Thr|r|h|cffd8d8d8]|r: 2", -- [41]
		"|cffffffff|cff979797|Hpratcopy|h[09:32:04]|h|r [S] |cffd8d8d8[|r|Hplayer:Ugahboogah-Thrall:474:SAY|h|cffd8bc3f70|r:|cffc41e3aUgahboogah|r-|cff1dfd54Thr|r|h|cffd8d8d8]|r: 1", -- [42]
		"|cffffffff|cff979797|Hpratcopy|h[09:32:30]|h|r [S] |cffd8d8d8[|r|Hplayer:Ugahboogah-Thrall:478:SAY|h|cffd8bc3f70|r:|cffc41e3aUgahboogah|r-|cff1dfd54Thr|r|h|cffd8d8d8]|r: Heated Swings on |cffa5a5a5Ugahboogah|r", -- [43]
		"|cffffffff|cff979797|Hpratcopy|h[09:32:32]|h|r [S] |cffd8d8d8[|r|Hplayer:Ugahboogah-Thrall:479:SAY|h|cffd8bc3f70|r:|cffc41e3aUgahboogah|r-|cff1dfd54Thr|r|h|cffd8d8d8]|r: 3", -- [44]
		"|cffffffff|cff979797|Hpratcopy|h[09:32:33]|h|r [S] |cffd8d8d8[|r|Hplayer:Ugahboogah-Thrall:480:SAY|h|cffd8bc3f70|r:|cffc41e3aUgahboogah|r-|cff1dfd54Thr|r|h|cffd8d8d8]|r: 2", -- [45]
		"|cffffffff|cff979797|Hpratcopy|h[09:32:34]|h|r [S] |cffd8d8d8[|r|Hplayer:Ugahboogah-Thrall:481:SAY|h|cffd8bc3f70|r:|cffc41e3aUgahboogah|r-|cff1dfd54Thr|r|h|cffd8d8d8]|r: 1", -- [46]
		"|cffffffff|cff979797|Hpratcopy|h[09:32:52]|h|r [S] |cffd8d8d8[|r|Hplayer:Huulia-Zul'jin:484:SAY|h|cffd8bc3f70|r:|cff0070ddHuulia|r-|cffad92d1Zul|r|h|cffd8d8d8]|r: Blazing Aegis on |cffa5a5a5Huulia|r", -- [47]
		"|cffffffff|cff979797|Hpratcopy|h[09:32:52]|h|r [S] |cffd8d8d8[|r|Hplayer:Huulia-Zul'jin:485:SAY|h|cffd8bc3f70|r:|cff0070ddHuulia|r-|cffad92d1Zul|r|h|cffd8d8d8]|r: 3", -- [48]
		"|cffffffff|cff979797|Hpratcopy|h[09:32:53]|h|r [S] |cffd8d8d8[|r|Hplayer:Huulia-Zul'jin:486:SAY|h|cffd8bc3f70|r:|cff0070ddHuulia|r-|cffad92d1Zul|r|h|cffd8d8d8]|r: 2", -- [49]
		"|cffffffff|cff979797|Hpratcopy|h[09:32:54]|h|r [S] |cffd8d8d8[|r|Hplayer:Huulia-Zul'jin:487:SAY|h|cffd8bc3f70|r:|cff0070ddHuulia|r-|cffad92d1Zul|r|h|cffd8d8d8]|r: 1", -- [50]
		"|cffffffff|cff979797|Hpratcopy|h[09:33:01]|h|r [S] |cffd8d8d8[|r|Hplayer:Ugahboogah-Thrall:489:SAY|h|cffd8bc3f70|r:|cffc41e3aUgahboogah|r-|cff1dfd54Thr|r|h|cffd8d8d8]|r: Heated Swings on |cffa5a5a5Ugahboogah|r", -- [51]
		"|cffffff00|cff979797|Hpratcopy|h[09:33:08]|h|r |cfffff468Caj|r has gone offline.", -- [52]
		"|cffffff00|cff979797|Hpratcopy|h[09:33:23]|h|r |cffd8d8d8[|r|Hplayer:Yle:492|h|cff8b8b8b62|r:|cff3fc7ebYle|r|h|cffd8d8d8]|r has come online.", -- [53]
		"|cffffff00|cff979797|Hpratcopy|h[09:33:47]|h|r |cffa5a5a5Huulia|r has died.", -- [54]
		"|cffffff00|cff979797|Hpratcopy|h[09:34:40]|h|r |cff71d5ff|Hdeath:8|h[You died.]|h", -- [55]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:34:43]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Stormart-Mal'Ganis:496:PARTY|h|cffd8bc3f70|r:|cff0070ddStormart|r|h|cffd8d8d8]|r: come on", -- [56]
		"|cffffff00|cff979797|Hpratcopy|h[09:37:17]|h|r |cff3fc7ebYle|r has gone offline.", -- [57]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:37:21]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Paull-Azralon:499:PARTY|h|cffd8bc3f70|r:|cfff48cbaPaull|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: Interrompeu Lavamante Qalashi's |cff71d5ff|Hspell:383231:0|h[Seta de Lava]|h|r!", -- [58]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:37:39]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Paull-Azralon:500:PARTY|h|cffd8bc3f70|r:|cfff48cbaPaull|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: Interrompeu Lavamante Qalashi's |cff71d5ff|Hspell:383231:0|h[Seta de Lava]|h|r!", -- [59]
		"|cffffff00|cff979797|Hpratcopy|h[09:38:13]|h|r |cffd8d8d8[|r|Hplayer:Corbán:502|h|cffd8bc3f70|r:|cfff48cbaCorbán|r|h|cffd8d8d8]|r has come online.", -- [60]
		"|cff00aa00|cff979797|Hpratcopy|h[09:40:06]|h|r You receive currency: |cff0070dd|Hcurrency:2245:0|h[Flightstones]|h|rx59", -- [61]
		"|cff00aa00|cff979797|Hpratcopy|h[09:40:06]|h|r You receive currency: |cff0070dd|Hcurrency:2408:0|h[Bonus Flightstones]|h|rx25", -- [62]
		"|cff00aa00|cff979797|Hpratcopy|h[09:40:06]|h|r You receive item: |cff0070dd|Hitem:204078::::::::70:263:::::::::|h[Aspect's Shadowflame Crest Fragment]|h|rx12", -- [63]
		"|cff00aa00|cff979797|Hpratcopy|h[09:40:08]|h|r You receive loot: |cffa335ee|Hitem:193785::::::::70:263::33:5:9330:6652:9147:1650:8767:1:28:1279:::::|h[Forgestorm]|h|r", -- [64]
		"|cffffff00|cff979797|Hpratcopy|h[09:40:09]|h|r You loot 52 Gold, 83 Silver, 48 Copper", -- [65]
		"|cff00aa00|cff979797|Hpratcopy|h[09:40:11]|h|r |cffa5a5a5Paull|r-Azralon receives loot: |cffa335ee|Hitem:193789::::::::70:263::16:7:9330:6652:9223:9221:9144:1650:8767:1:28:1279:::::|h[Fural's Blazing Faulds]|h|r.", -- [66]
		"|cffffff00|cff979797|Hpratcopy|h[09:40:15]|h|r You have requested to trade with |cffa5a5a5Huulia|r-Zul'jin.", -- [67]
		"|cff00aa00|cff979797|Hpratcopy|h[09:40:16]|h|r |cffa5a5a5Huulia|r-Zul'jin receives loot: |cffa335ee|Hitem:180653::::::::70:263::::5:17:406:18:17:19:10:20:3:21:123:::::|h[Mythic Keystone]|h|r.", -- [68]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:40:29]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Huulia-Zul'jin:524:PARTY|h|cffd8bc3f70|r:|cff0070ddHuulia|r-|cffad92d1Zul|r|h|cffd8d8d8]|r: ggs!", -- [69]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:40:40]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Luddyxdxd-Kel'Thuzad:525:PARTY|h|cffd8bc3f70|r:|cff33937fLuddyxdxd|r-|cff33d7feKel|r|h|cffd8d8d8]|r: gg", -- [70]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:40:40]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Paull-Azralon:526:PARTY|h|cffd8bc3f70|r:|cfff48cbaPaull|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: |cffa335ee|Hitem:193789::::::::70:70::16:7:9330:6652:9223:9221:9144:1650:8767:1:28:1279:::::|h[Escarcelas Fulgurantes de Fural]|h|r", -- [71]
		"|cffffff00|cff979797|Hpratcopy|h[09:40:41]|h|r |cffa5a5a5Luddyxdxd|r-Kel'Thuzad leaves the party.", -- [72]
		"|cff76c8ff|cff979797|Hpratcopy|h[09:40:43]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Ugahboogah-Thrall:538:PARTY|h|cffd8bc3f70|r:|cffc41e3aUgahboogah|r-|cff1dfd54Thr|r|h|cffd8d8d8]|r: leegs?", -- [73]
		"|cffffff00|cff979797|Hpratcopy|h[09:40:44]|h|r Neondrake has fled from Gatzar in a duel", -- [74]
		"|cffaaaaff|cff979797|Hpratcopy|h[09:40:47]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Paull-Azralon:546:PARTY|h|cffd8bc3f70|r:|cfff48cbaPaull|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: y", -- [75]
		"|cffffff00|cff979797|Hpratcopy|h[09:40:53]|h|r |cfff48cbaCorbán|r has gone offline.", -- [76]
		"|cffffff00|cff979797|Hpratcopy|h[09:41:07]|h|r |cffd8d8d8[|r|Hplayer:Diom:572|h|cffd8bc3f68|r:|cffa330c9Diom|r|h|cffd8d8d8]|r has come online.", -- [77]
		"|cffffff00|cff979797|Hpratcopy|h[09:42:12]|h|r |cffa330c9Diom|r has gone offline.", -- [78]
		"|cffffff00|cff979797|Hpratcopy|h[09:42:14]|h|r You leave the group.", -- [79]
		"|cff00aa00|cff979797|Hpratcopy|h[11:07:21]|h|r You receive item: |cffa335ee|Hitem:180653::::::::70:263::::5:17:206:18:21:19:9:20:124:21:6:::::|h[Mythic Keystone]|h|r", -- [80]
		"|cff00aa00|cff979797|Hpratcopy|h[11:07:21]|h|r You receive item: |cffa335ee|Hitem:205225::::::::70:263:::::::::|h[Aspects' Token of Merit]|h|rx6", -- [81]
		"|cffffff00|cff979797|Hpratcopy|h[11:09:05]|h|r |cffff7c0aNabrocan|r has gone offline.", -- [82]
		"|cffffff00|cff979797|Hpratcopy|h[11:09:20]|h|r |cffd8d8d8[|r|Hplayer:Corßan:174|h|cffd8bc3f70|r:|cff33937fCorßan|r|h|cffd8d8d8]|r has come online.", -- [83]
		"|cffffff00|cff979797|Hpratcopy|h[11:10:26]|h|r |cffd8d8d8[|r|Hplayer:Jimsdk-Mal'Ganis:175:ACHIEVEMENT|h|cffc41e3aJimsdk|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18977:Player-3684-0891AEB7:1:9:26:23:4294967295:4294967295:4294967295:4294967295|h[Draconically Epic]|h|r |cffffffff(|rCompleted 8/23/23|cffffffff)|r!", -- [84]
		"|cff00aa00|cff979797|Hpratcopy|h[11:10:43]|h|r You receive item: |cffa335ee|Hitem:204717::::::::70:263:::::::::|h[Splintered Spark of Shadowflame]|h|rx2", -- [85]
		"|cffffff00|cff979797|Hpratcopy|h[11:11:05]|h|r |cffc69b6dBrich|r has gone offline.", -- [86]
		"|cffffff00|cff979797|Hpratcopy|h[11:11:14]|h|r |cffd8d8d8[|r|Hplayer:Hivaids:178|h|cffd8bc3f70|r:|cffaad372Hivaids|r|h|cffd8d8d8]|r has come online.", -- [87]
		"|cffffff00|cff979797|Hpratcopy|h[11:11:50]|h|r |cffaad372Hivaids|r has gone offline.", -- [88]
		"|cffffff00|cff979797|Hpratcopy|h[11:12:00]|h|r |cffd8d8d8[|r|Hplayer:Brich:180|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r has come online.", -- [89]
		"|cffff80ff|cff979797|Hpratcopy|h[11:14:00]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:181:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: stop logging in and acting like you're checking vault. we all know you dont play anymore", -- [90]
		"|cffff80ff|cff979797|Hpratcopy|h[11:14:13]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:182:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: i get vault every tuesday", -- [91]
		"|cffff80ff|cff979797|Hpratcopy|h[11:14:13]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:183:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: also promote me", -- [92]
		"|cffff80ff|cff979797|Hpratcopy|h[11:14:29]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:184:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: if you played and logged in you would know you've been promoted already", -- [93]
		"|cffff80ff|cff979797|Hpratcopy|h[11:15:52]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:186:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: no", -- [94]
		"|cffff80ff|cff979797|Hpratcopy|h[11:15:53]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:187:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: brady", -- [95]
		"|cffff80ff|cff979797|Hpratcopy|h[11:15:58]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:188:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: promote. me. now.", -- [96]
		"|cffff80ff|cff979797|Hpratcopy|h[11:16:08]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:189:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: to my correct rank", -- [97]
		"|cffffff00|cff979797|Hpratcopy|h[11:17:30]|h|r |cffc69b6dBrich|r has promoted |cff00ff00Stormart|r to GuiId Master.", -- [98]
		"|cff00aa00|cff979797|Hpratcopy|h[11:17:51]|h|r You receive item: |cffa335ee|Hitem:204440::::::::70:263:::::::::|h[Spark of Shadowflame]|h|r", -- [99]
		"|cffff80ff|cff979797|Hpratcopy|h[11:18:02]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:193:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: there", -- [100]
		"|cffff80ff|cff979797|Hpratcopy|h[11:20:13]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:198:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: i hate you", -- [101]
		"|cffff80ff|cff979797|Hpratcopy|h[11:20:33]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:204:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: lol", -- [102]
		"|cffff80ff|cff979797|Hpratcopy|h[11:20:58]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:205:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: have you seen the new bad message system in game?", -- [103]
		"|cffff80ff|cff979797|Hpratcopy|h[11:21:13]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:206:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: ill send you what you just sent me and see how it comes through to you in whispers", -- [104]
		"|cffff80ff|cff979797|Hpratcopy|h[11:21:15]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:207:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: i hate you", -- [105]
		"|cffff80ff|cff979797|Hpratcopy|h[11:21:38]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:209:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: nothing happened", -- [106]
		"|cffff80ff|cff979797|Hpratcopy|h[11:22:08]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:210:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: oh really? i got a thing that was like |cff00ff00stormart|r send you an inappropriorate message. then had [View Message] for me to click to actually make it appear", -- [107]
		"|cffff80ff|cff979797|Hpratcopy|h[11:22:18]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:211:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: wtf", -- [108]
		"|cffff80ff|cff979797|Hpratcopy|h[11:22:21]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:212:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: disable that shit", -- [109]
		"|cffff80ff|cff979797|Hpratcopy|h[11:22:25]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:213:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: now i have a yellow [Report] button next to your \"i hate you message\"", -- [110]
		"|cffff80ff|cff979797|Hpratcopy|h[11:23:23]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:220:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: weird, it was set to censor everyone but friends", -- [111]
		"|cffff80ff|cff979797|Hpratcopy|h[11:23:38]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:228:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: but i guess since you're direct whispering me it doesnt count as a friend", -- [112]
		"|cffff80ff|cff979797|Hpratcopy|h[11:24:25]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:251:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: yeah idk", -- [113]
		"|cffff80ff|cff979797|Hpratcopy|h[11:24:25]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:252:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: and have you tried the ping system yet?", -- [114]
		"|cffffff00|cff979797|Hpratcopy|h[11:24:47]|h|r |cffd8d8d8[|r|Hplayer:Brich:268|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r has invited you to join a group.", -- [115]
		"|cffff4040|cff979797|Hpratcopy|h[11:24:59]|h|r [Y] |cffd8d8d8[|r|Hplayer:Kilmarnock-Mal'Ganis:274:YELL|h|cffa330c9Kilmarnock|r|h|cffd8d8d8]|r: [Orcish] l zug nuk nakazz makogg goth'a", -- [116]
		"|cffffff00|cff979797|Hpratcopy|h[11:25:14]|h|r Dungeon Difficulty set to Heroic.", -- [117]
		"|cffffff00|cff979797|Hpratcopy|h[11:25:14]|h|r This is now a cross-faction instance group. You can do these activities together: dungeons and raids (non-queued), Torghast, Rated PvP", -- [118]
		"|cffff80ff|cff979797|Hpratcopy|h[11:25:19]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:293:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: yeah i have", -- [119]
		"|cffff80ff|cff979797|Hpratcopy|h[11:25:29]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:298:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: pretty sick", -- [120]
		"|cffff80ff|cff979797|Hpratcopy|h[11:25:31]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:299:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: 100% they implemented this for solo q rbgs", -- [121]
		"|cffff80ff|cff979797|Hpratcopy|h[11:25:55]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:302:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: oh yeah, helps a lot with yolo rbgs for sure", -- [122]
		"|cffff80ff|cff979797|Hpratcopy|h[11:25:55]|h|r [W To] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:303:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: which would be fucking sick", -- [123]
		"|cffff80ff|cff979797|Hpratcopy|h[11:26:23]|h|r [W From] |cffd8d8d8[|r|Hplayer:Brich-Mal'Ganis:312:WHISPER:BRICH-MAL'GANIS|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r: once i get used to it ill be using it in raids lol", -- [124]
		"|cffffff00|cff979797|Hpratcopy|h[11:27:44]|h|r Your group has been disbanded.", -- [125]
		"|cffffff00|cff979797|Hpratcopy|h[11:29:24]|h|r You repaired your armor for 165|TInterface\\MoneyFrame\\UI-GoldIcon:0:0:2:0|t 66|TInterface\\MoneyFrame\\UI-SilverIcon:0:0:2:0|t 68|TInterface\\MoneyFrame\\UI-CopperIcon:0:0:2:0|t", -- [126]
		"0 |4day:days;, 0 |4hour:hours;, 2 |4minute:minutes;, 59 |4second:seconds;", -- [127]
		"========== End of Scrollback ==========", -- [128]
	},
	["AutoSellExcludeMyChar"] = "On",
	["MuteGyrocopters"] = "Off",
	["UseArrowKeysInChat"] = "On",
	["TipHideInCombat"] = "Off",
	["AcceptPartyFriends"] = "Off",
	["TipShowOtherRank"] = "Off",
	["MuteHarp"] = "Off",
	["NoSharedQuests"] = "Off",
	["ShowTrainAllButton"] = "Off",
	["RestoreChatMessages"] = "On",
	["FirstRunMessageSeen"] = true,
	["ChatTemp4"] = {
		"|cffffff00|cff979797|Hpratcopy|h[10:44:40]|h|r |cffd8d8d8[|r|Hplayer:Pandaloca-Thunderhorn:3560:ACHIEVEMENT|h|cffd8bc3f70|r:|cff00ff98Pandaloca|r-|cff18fb03Thu|r:4|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18160:Player-1129-0AF8E3A1:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff(|rCompleted 5/27/23|cffffffff)|r!", -- [1]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:40]|h|r |cffd8d8d8[|r|Hplayer:Pandaloca-Thunderhorn:3561:ACHIEVEMENT|h|cffd8bc3f70|r:|cff00ff98Pandaloca|r-|cff18fb03Thu|r:4|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18164:Player-1129-0AF8E3A1:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Fury of Giants]|h|r |cffffffff(|rCompleted 9/22/23|cffffffff)|r!", -- [2]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:40]|h|r |cffd8d8d8[|r|Hplayer:Dorah-Malygos:3562:ACHIEVEMENT|h|cffd8bc3f70|r:|cff0070ddDorah|r-|cffb1afb8Mal|r:5|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18164:Player-104-0D8124FE:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Fury of Giants]|h|r |cffffffff(|rCompleted 9/22/23|cffffffff)|r!", -- [3]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:40]|h|r |cffd8d8d8[|r|Hplayer:Zaradrelina-Jubei'Thos:3563:ACHIEVEMENT|h|cffd8bc3f70|r:|cffc69b6dZaradrelina|r-|cffd0d34cJub|r:2|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18164:Player-3725-0C271B58:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Fury of Giants]|h|r |cffffffff(|rCompleted 9/22/23|cffffffff)|r!", -- [4]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:40]|h|r |cffd8d8d8[|r|Hplayer:Tigbits-Ner'zhul:3564:ACHIEVEMENT|h|cffd8bc3f70|r:|cfff48cbaTigbits|r-|cff61ad68Ner|r:3|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18164:Player-1168-09F30E32:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Fury of Giants]|h|r |cffffffff(|rCompleted 9/22/23|cffffffff)|r!", -- [5]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:40]|h|r |cffd8d8d8[|r|Hplayer:Borthmar-Thrall:3565:ACHIEVEMENT|h|cffd8bc3f70|r:|cff0070ddBorthmar|r-|cff1dfd54Thr|r:5|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18164:Player-3678-0D67C8CC:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Fury of Giants]|h|r |cffffffff(|rCompleted 9/22/23|cffffffff)|r!", -- [6]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:40]|h|r |cffd8d8d8[|r|Hplayer:Shortymcstab-Arthas:3566:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Shortymcstab|r-|cff9aab5eArt|r:5|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18164:Player-69-0BA642A6:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Fury of Giants]|h|r |cffffffff(|rCompleted 9/22/23|cffffffff)|r!", -- [7]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:40]|h|r |cffd8d8d8[|r|Hplayer:Lilshock-Eredar:3567:ACHIEVEMENT|h|cffd8bc3f70|r:|cff0070ddLilshock|r-|cff2a8ba4Ere|r:1|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18160:Player-53-0C57FE06:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff(|rCompleted 5/27/23|cffffffff)|r!", -- [8]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:40]|h|r |cffd8d8d8[|r|Hplayer:Lilshock-Eredar:3568:ACHIEVEMENT|h|cffd8bc3f70|r:|cff0070ddLilshock|r-|cff2a8ba4Ere|r:1|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18164:Player-53-0C57FE06:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Fury of Giants]|h|r |cffffffff(|rCompleted 9/22/23|cffffffff)|r!", -- [9]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:40]|h|r Received 280 Gold, 90 Silver.", -- [10]
		"|cffff7f00|cff979797|Hpratcopy|h[10:44:40]|h|r |Hchannel:INSTANCE_CHAT|h[I] |h|cffd8d8d8[|r|Hplayer:Tayro-Area52:3570:INSTANCE_CHAT|h|cffd8bc3f70|r:|cffc41e3aTayro|r-|cff64968eAre|r:3|h|cffd8d8d8]|r: Jumping Leaderboard:", -- [11]
		"|cffff7f00|cff979797|Hpratcopy|h[10:44:40]|h|r |Hchannel:INSTANCE_CHAT|h[I] |h|cffd8d8d8[|r|Hplayer:Tayro-Area52:3571:INSTANCE_CHAT|h|cffd8bc3f70|r:|cffc41e3aTayro|r-|cff64968eAre|r:3|h|cffd8d8d8]|r: |cffa5a5a5Tayro|r: 7", -- [12]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:41]|h|r |HlootHistory:2689|h[Loot]|h: |cffa335ee|Hitem:202639::::::::70:261::4:4:9411:9231:1459:8767::::::|h[Zenith Ventilation Fluid]|h|r", -- [13]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:41]|h|r |HlootHistory:2689|h[Loot]|h: |cffa335ee|Hitem:202632::::::::70:261::4:4:9411:9231:1459:8767::::::|h[Mystic Ventilation Fluid]|h|r", -- [14]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:41]|h|r |HlootHistory:2689|h[Loot]|h: |cffa335ee|Hitem:204393::::::::70:261::4:8:6652:9415:9225:9220:9411:9315:1459:8767::::::|h[Clasps of the Diligent Steward]|h|r", -- [15]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:41]|h|r |HlootHistory:2689|h[Loot]|h: |cffa335ee|Hitem:204393::::::::70:261::4:8:6652:9414:9225:9220:9411:9315:1459:8767::::::|h[Clasps of the Diligent Steward]|h|r", -- [16]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:41]|h|r |HlootHistory:2689|h[Loot]|h: |cffa335ee|Hitem:204322::::::::70:261::4:5:40:9411:9315:1459:8767::::::|h[Failure Disposal Cannon]|h|r", -- [17]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:41]|h|r You receive currency: |cff0070dd|Hcurrency:2245:0|h[Flightstones]|h|rx35", -- [18]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:41]|h|r You receive loot: |cff0070dd|Hitem:204075::::::::70:261:::::::::|h[Whelpling's Shadowflame Crest Fragment]|h|rx10", -- [19]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:41]|h|r |cffd8d8d8[|r|Hplayer:Shortymcstab-Arthas:3579:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Shortymcstab|r-|cff9aab5eArt|r:5|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:1180:Player-69-0BA642A6:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Got My Mind On My Money]|h|r |cffffffff(|rCompleted 5/12/12|cffffffff)|r!", -- [20]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:42]|h|r You loot 125 Gold, 57 Silver, 69 Copper", -- [21]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:42]|h|r |cffa5a5a5Issapanda|r-Tichondrius receives loot: |cffa335ee|Hitem:204717::::::::70:261:::::::::|h[Splintered Spark of Shadowflame]|h|r.", -- [22]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:42]|h|r |cffa5a5a5Tayro|r-Area52 receives loot: |cffa335ee|Hitem:204717::::::::70:261:::::::::|h[Splintered Spark of Shadowflame]|h|r.", -- [23]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:43]|h|r |HlootHistory:2689|h[Loot]|h: You have selected Greed for: |cffa335ee|Hitem:204393::::::::70:261::4:8:6652:9415:9225:9220:9411:9315:1459:8767::::::|h[Clasps of the Diligent Steward]|h|r |HlootHistory:2689|h|cnLOOT_LINK_COLOR:[View Loot Rolls]|r|h", -- [24]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:44]|h|r |HlootHistory:2689|h[Loot]|h: You have selected Greed for: |cffa335ee|Hitem:204393::::::::70:261::4:8:6652:9414:9225:9220:9411:9315:1459:8767::::::|h[Clasps of the Diligent Steward]|h|r |HlootHistory:2689|h|cnLOOT_LINK_COLOR:[View Loot Rolls]|r|h", -- [25]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:45]|h|r |cffa5a5a5Lilshock|r-Eredar receives loot: |cffa335ee|Hitem:191784::::::::70:261:::::::::|h[Dragon Shard of Knowledge]|h|r.", -- [26]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:45]|h|r |cffa5a5a5Valdiscantha|r-Dath'Remar receives loot: |cffa335ee|Hitem:204717::::::::70:261:::::::::|h[Splintered Spark of Shadowflame]|h|r.", -- [27]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:46]|h|r |HlootHistory:2689|h[Loot]|h: You have selected Greed for: |cffa335ee|Hitem:202632::::::::70:261::4:4:9411:9231:1459:8767::::::|h[Mystic Ventilation Fluid]|h|r |HlootHistory:2689|h|cnLOOT_LINK_COLOR:[View Loot Rolls]|r|h", -- [28]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:47]|h|r |HlootHistory:2689|h[Loot]|h: You have selected Need for: |cffa335ee|Hitem:202639::::::::70:261::4:4:9411:9231:1459:8767::::::|h[Zenith Ventilation Fluid]|h|r |HlootHistory:2689|h|cnLOOT_LINK_COLOR:[View Loot Rolls]|r|h", -- [29]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:49]|h|r |cffa5a5a5Issapanda|r-Tichondrius has left the instance group.", -- [30]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:54]|h|r |cffa5a5a5Pyronite|r-Gilneas has left the instance group.", -- [31]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:55]|h|r |cffa5a5a5Valdiscantha|r-Dath'Remar has left the instance group.", -- [32]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:56]|h|r |cffa5a5a5Duntul|r-Skywall has left the instance group.", -- [33]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:57]|h|r |cffa5a5a5Yvnnet|r-AlteracMountains has left the instance group.", -- [34]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:58]|h|r |cffa5a5a5Borthmar|r-Thrall receives loot: |cffa335ee|Hitem:191784::::::::70:261:::::::::|h[Dragon Shard of Knowledge]|h|r.", -- [35]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:59]|h|r |cffa5a5a5Lilshock|r-Eredar has left the instance group.", -- [36]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:59]|h|r |cfff48cbaBoondocs|r receives loot: |cffa335ee|Hitem:204717::::::::70:261:::::::::|h[Splintered Spark of Shadowflame]|h|r.", -- [37]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:59]|h|r |cffa5a5a5Theoverseer|r-BleedingHollow has left the instance group.", -- [38]
		"|cff00aa00|cff979797|Hpratcopy|h[10:45:00]|h|r |cffa5a5a5Ragtar|r-Cho'gall receives loot: |cffa335ee|Hitem:191784::::::::70:261:::::::::|h[Dragon Shard of Knowledge]|h|r.", -- [39]
		"|cffffff00|cff979797|Hpratcopy|h[10:45:02]|h|r |cffa5a5a5Zaradrelina|r-Jubei'Thos has left the instance group.", -- [40]
		"|cffffff00|cff979797|Hpratcopy|h[10:45:03]|h|r |cffa5a5a5Toebeansuwu|r-WyrmrestAccord has left the instance group.", -- [41]
		"|cffffff00|cff979797|Hpratcopy|h[10:45:04]|h|r You leave the group.", -- [42]
		"|cff00aa00|cff979797|Hpratcopy|h[10:45:20]|h|r |HlootHistory:2689|h[Loot]|h: Shortymcstab (Need - 98, Main-Spec) Won: |cffa335ee|Hitem:202639::::::::70:261::4:4:9411:9231:1459:8767::::::|h[Zenith Ventilation Fluid]|h|r", -- [43]
		"|cff00aa00|cff979797|Hpratcopy|h[10:45:20]|h|r |HlootHistory:2689|h[Loot]|h: Panacaea (Need - 85, Main-Spec) Won: |cffa335ee|Hitem:204393::::::::70:261::4:8:6652:9414:9225:9220:9411:9315:1459:8767::::::|h[Clasps of the Diligent Steward]|h|r", -- [44]
		"|cff00aa00|cff979797|Hpratcopy|h[10:45:20]|h|r |HlootHistory:2689|h[Loot]|h: Dizzavow (Need - 74, Main-Spec) Won: |cffa335ee|Hitem:204393::::::::70:261::4:8:6652:9415:9225:9220:9411:9315:1459:8767::::::|h[Clasps of the Diligent Steward]|h|r", -- [45]
		"|cff00aa00|cff979797|Hpratcopy|h[10:45:20]|h|r |HlootHistory:2689|h[Loot]|h: Tayro (Greed - 90) Won: |cffa335ee|Hitem:202632::::::::70:261::4:4:9411:9231:1459:8767::::::|h[Mystic Ventilation Fluid]|h|r", -- [46]
		"|cffffff00|cff979797|Hpratcopy|h[10:45:35]|h|r You are now queued in the Raid Finder.", -- [47]
		"|cffffff9f|cff979797|Hpratcopy|h[10:45:53]|h|r Sabellian says: See, Wrathion? They have been marshaling a defense while we tarried.", -- [48]
		"|cffffff9f|cff979797|Hpratcopy|h[10:45:57]|h|r Sabellian says: There are quite a number of them. Let me know when you are ready to discuss a plan, Gelosia.", -- [49]
		"|cffffff9f|cff979797|Hpratcopy|h[10:45:58]|h|r Sabellian says: Keep low. We have not been spotted--", -- [50]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:00]|h|r Wrathion says: I usually prefer the stealthy approach as well, but now is the time to let dragons be dragons! Remind these weaklings who they are dealing with!", -- [51]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:04]|h|r Stonebreath Summoner says: Prepare for the earth's embrace!", -- [52]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:05]|h|r Stonebreath Landslider says: Prepare for the earth's embrace!", -- [53]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:05]|h|r Stonebreath Landslider says: May the rubble rain down!", -- [54]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:05]|h|r Summitshaper Lorac says: Ha ha! I knew you order-addled fools would come!", -- [55]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:06]|h|r Stonebreath Landslider says: May the rubble rain down!", -- [56]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:11]|h|r Summitshaper Lorac says: Remember the name Lorac! I ensure these caverns... will be your tomb!", -- [57]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:11]|h|r Sabellian says: Wrathion no! You are just going to--", -- [58]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:12]|h|r Stonebreath Landslider says: I am now but another grain of dirt...", -- [59]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:12]|h|r Stonebreath Landslider says: I am now but another grain of dirt...", -- [60]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:13]|h|r Stonebreath Landslider says: I've failed you, Summitshaper...", -- [61]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:13]|h|r Stonebreath Landslider says: I've failed you, Summitshaper...", -- [62]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:13]|h|r Wrathion says: Going to terrify them? Make them re-evaluate their life choices? Agreed!", -- [63]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:14]|h|r Stonebreath Landslider says: I've failed you, Summitshaper...", -- [64]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:14]|h|r Stonebreath Landslider says: I am now but another grain of dirt...", -- [65]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:16]|h|r Stonebreath Landslider says: Crush them!", -- [66]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:16]|h|r Stonebreath Landslider says: Return to the dirt, worm!", -- [67]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:18]|h|r Stonebreath Landslider says: May the rubble rain down!", -- [68]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:19]|h|r Wrathion says: You think dragons fall so easily?!", -- [69]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:23]|h|r Stonebreath Landslider says: The earth... welcomes me...", -- [70]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:23]|h|r Stonebreath Landslider says: I am now but another grain of dirt...", -- [71]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:24]|h|r Sabellian says: Stop! He is baiting us, Wrathion!", -- [72]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:25]|h|r Stonebreath Landslider says: I am now but another grain of dirt...", -- [73]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:25]|h|r Stonebreath Landslider says: I am now but another grain of dirt...", -- [74]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:25]|h|r Stonebreath Landslider says: The earth... welcomes me...", -- [75]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:25]|h|r Stonebreath Landslider says: The earth... welcomes me...", -- [76]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:26]|h|r Sabellian says: That blasted-- We have lost the element of surprise. Gelosia, take on the ground forces and I will support you from the air!", -- [77]
		"|cff00aa00|cff979797|Hpratcopy|h[10:46:32]|h|r You receive loot: |cff9d9d9d|Hitem:188728::::::::70:261::9:1:7966:2:9:70:28:2650:::::|h[Timeworn Chain Armguards]|h|r", -- [78]
		"|cff00aa00|cff979797|Hpratcopy|h[10:46:32]|h|r You receive loot: |cff9d9d9d|Hitem:192625::::::::70:261:::::::::|h[Motionless Stone]|h|rx2", -- [79]
		"|cff00aa00|cff979797|Hpratcopy|h[10:46:32]|h|r You receive loot: |cffffffff|Hitem:193050::::::::70:261:::::::::|h[Tattered Wildercloth]|h|r", -- [80]
		"|cffffff00|cff979797|Hpratcopy|h[10:46:33]|h|r You loot 5 Gold, 95 Silver, 90 Copper", -- [81]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:38]|h|r Sabellian says: Whelp! Stop your showboating! Fall in line and listen to my strategy!", -- [82]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:46]|h|r Wrathion says: Your endless whining about a strategy will not win you the throne!", -- [83]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:49]|h|r Cliffkeeper Bouldani says: I was taught by Lorac, himself! You'll never pass his greatest acolyte - ME!", -- [84]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:54]|h|r Wrathion says: Let us take this lackey out together, Gelosia!", -- [85]
		"|cffffff9f|cff979797|Hpratcopy|h[10:47:38]|h|r Cliffkeeper Bouldani says: Master will... kill me for this...", -- [86]
		"|cffffff9f|cff979797|Hpratcopy|h[10:47:39]|h|r Wrathion says: Stay back, old man. Allow me to clear the way for you.", -- [87]
		"|cff00aa00|cff979797|Hpratcopy|h[10:47:39]|h|r You receive loot: |cff9d9d9d|Hitem:192625::::::::70:261:::::::::|h[Motionless Stone]|h|rx2", -- [88]
		"|cffffff00|cff979797|Hpratcopy|h[10:47:40]|h|r You loot 85 Silver, 42 Copper", -- [89]
		"|cffffff9f|cff979797|Hpratcopy|h[10:47:45]|h|r Cinderstep Igniter says: Lord Fyrakk! Save us...", -- [90]
		"|cffffff9f|cff979797|Hpratcopy|h[10:47:45]|h|r Cinderstep Weaver says: Lord Fyrakk! Save us...", -- [91]
		"|cffffff9f|cff979797|Hpratcopy|h[10:47:45]|h|r Cinderstep Igniter says: Lord Fyrakk! Save us...", -- [92]
		"|cffffff9f|cff979797|Hpratcopy|h[10:47:45]|h|r Cinderstep Weaver says: Lord Fyrakk! Save us...", -- [93]
		"|cffffff9f|cff979797|Hpratcopy|h[10:47:46]|h|r Sabellian says: Insufferable...", -- [94]
		"|cffffff9f|cff979797|Hpratcopy|h[10:48:04]|h|r Cinderstep Igniter says: Lord Fyrakk! Save us...", -- [95]
		"|cffffff9f|cff979797|Hpratcopy|h[10:48:09]|h|r Cinderstep Melter says: My flame... is out...", -- [96]
		"|cff00aa00|cff979797|Hpratcopy|h[10:48:24]|h|r You receive loot: |cff9d9d9d|Hitem:188707::::::::70:261::9:1:7966:2:9:70:28:2650:::::|h[Rotten Leather Guise]|h|r", -- [97]
		"|cff00aa00|cff979797|Hpratcopy|h[10:48:24]|h|r You receive loot: |cff9d9d9d|Hitem:192635::::::::70:261:::::::::|h[Warped Metal]|h|rx4", -- [98]
		"|cffffff00|cff979797|Hpratcopy|h[10:48:25]|h|r You loot 3 Gold, 17 Silver, 87 Copper", -- [99]
		"|cffffff9f|cff979797|Hpratcopy|h[10:48:31]|h|r Cinderstep Igniter says: Lord Fyrakk! Save us...", -- [100]
		"|cffffff9f|cff979797|Hpratcopy|h[10:48:31]|h|r Cinderstep Igniter says: Lord Fyrakk! Save us...", -- [101]
		"|cffffff9f|cff979797|Hpratcopy|h[10:48:33]|h|r Cinderstep Igniter says: You will become cinders!", -- [102]
		"|cffffff9f|cff979797|Hpratcopy|h[10:48:53]|h|r Wrathion says: Now they try to best the black dragonflight with fire? How cute.", -- [103]
		"|cffffff9f|cff979797|Hpratcopy|h[10:48:56]|h|r Portalkeeper Cimbra says: I trained in the Firelands. You cannot defeat me.", -- [104]
		"|cffffff9f|cff979797|Hpratcopy|h[10:49:04]|h|r Sabellian says: Indeed. Their grasp of effective stratagem is only surpassed by yours, Wrathion.", -- [105]
		"|cffffff9f|cff979797|Hpratcopy|h[10:49:17]|h|r Portalkeeper Cimbra says: The Firelands was... not this hot...", -- [106]
		"|cffffff9f|cff979797|Hpratcopy|h[10:49:18]|h|r Wrathion says: Now, shall we kick the braggart off his walking mountain of mud?", -- [107]
		"|cffffff9f|cff979797|Hpratcopy|h[10:49:24]|h|r Sabellian says: This filthy fool seems to be the only one left standing against us. Should we not have some fun?", -- [108]
		"|cffffff9f|cff979797|Hpratcopy|h[10:49:37]|h|r Summitshaper Lorac says: Lord Fyrakk was unconcerned, but I knew you'd follow. I am a planner! I am prepared!", -- [109]
		"|cffffff9f|cff979797|Hpratcopy|h[10:49:54]|h|r Summitshaper Lorac says: This is the part where you die! Attack them, my mud minion!", -- [110]
		"|cffffff9f|cff979797|Hpratcopy|h[10:50:03]|h|r Summitshaper Lorac says: Why won't you die? Killing you should have been easy.", -- [111]
		"|cffffff9f|cff979797|Hpratcopy|h[10:50:21]|h|r Summitshaper Lorac says: I didn't... plan for this-", -- [112]
		"|cffffff00|cff979797|Hpratcopy|h[10:50:23]|h|r You loot 67 Silver, 13 Copper", -- [113]
		"|cffffff9f|cff979797|Hpratcopy|h[10:50:27]|h|r Wrathion says: Ugh! I've got muck in my boots. Disgusting!", -- [114]
		"|cff00aa00|cff979797|Hpratcopy|h[10:50:31]|h|r You receive item: |cffffffff|Hitem:203013::::::::70:261:::::::::|h[Niffen Incense]|h|r", -- [115]
		"|cffffff9f|cff979797|Hpratcopy|h[10:50:31]|h|r Tuberros says: Reekroot is one of the most sublime smellies out there! Our snifferscouts left scent trails where they planted them. Use this incense to follow the smells to the roots.", -- [116]
		"|cffffff9f|cff979797|Hpratcopy|h[10:50:35]|h|r Elder Honeypelt says: You're an uplander aren't ya? You've gotten yourself into quite the bind. Would you like some help?", -- [117]
		"|cffffff00|cff979797|Hpratcopy|h[10:51:13]|h|r Total time played: 1 |4day:days;, 21 |4hour:hours;, 38 |4minute:minutes;, 36 |4second:seconds;", -- [118]
		"|cffffff00|cff979797|Hpratcopy|h[10:51:13]|h|r Time played this level: 0 |4day:days;, 6 |4hour:hours;, 20 |4minute:minutes;, 58 |4second:seconds;", -- [119]
		"|cff00aa00|cff979797|Hpratcopy|h[10:51:15]|h|r You receive currency: |cff0070dd|Hcurrency:2245:0|h[Flightstones]|h|rx15", -- [120]
		"|cffffff00|cff979797|Hpratcopy|h[10:51:15]|h|r The Patience of Princes completed.", -- [121]
		"|cffffff00|cff979797|Hpratcopy|h[10:51:15]|h|r Received 84 Gold, 27 Silver.", -- [122]
		"|cffffff00|cff979797|Hpratcopy|h[10:51:17]|h|r Quest accepted: It Was Not Enough", -- [123]
		"|cffffff00|cff979797|Hpratcopy|h[10:51:18]|h|r Quest accepted: Culling the Deep", -- [124]
		"|cffffff9f|cff979797|Hpratcopy|h[10:51:19]|h|r Elder Honeypelt says: Don't worry, I've got excellent control of my claws. It's my eyesight that's never been good.", -- [125]
		"|cffffff9f|cff979797|Hpratcopy|h[10:51:21]|h|r Elder Honeypelt says: There you go, uplander. What say we go find those friends I smell on you?", -- [126]
		"0 |4day:days;, 0 |4hour:hours;, 0 |4minute:minutes;, 15 |4second:seconds;", -- [127]
		"========== End of Scrollback ==========", -- [128]
	},
	["AutoSellNoGreyGear"] = "Off",
	["NoCooldownDuration"] = "On",
	["SquareMinimap"] = "On",
	["MinimapModder"] = "On",
	["WidgetTopY"] = -15,
	["NoChatFade"] = "Off",
	["RecentChatSize"] = 170,
	["MuteBanLu"] = "Off",
	["NoRestedEmotes"] = "Off",
	["NoPartyInvites"] = "Off",
	["CombatPlates"] = "Off",
	["AutoQuestRegular"] = "On",
	["HideEventToasts"] = "Off",
	["ChatHistory4Count"] = 128,
	["HideZoneText"] = "Off",
	["ControlR"] = "CENTER",
	["ControlScale"] = 1,
	["FriendlyCommunities"] = "On",
	["EnhanceDressup"] = "On",
	["CustomAddonButtons"] = {
		["WIM3MinimapButton"] = {
			["minimapPos"] = 187.1301525177606,
			["hide"] = false,
		},
	},
	["ControlX"] = 0,
	["MinimapX"] = -17,
	["AutoQuestShift"] = "Off",
	["ControlY"] = 0,
	["ShowWhoPinged"] = "On",
	["ChatHistory5Count"] = 128,
	["TipShowTarget"] = "On",
	["UseEasyChatResizing"] = "Off",
	["BlockDuelSpam"] = "Off",
	["AutomateQuests"] = "Off",
	["ShowChatMenuButton"] = "Off",
	["AutoReleaseNoWintergsp"] = "Off",
	["Cooldowns"] = {
		["DEATHKNIGHT"] = {
			["S2R2Pet"] = false,
			["S2R4Pet"] = false,
			["S2R1Pet"] = false,
			["S2R1Idn"] = "",
			["S2R4Idn"] = "",
			["S2R3Idn"] = "",
			["S2R2Idn"] = "",
			["S2R3Pet"] = false,
			["S2R5Idn"] = "",
			["S2R5Pet"] = false,
		},
		["WARRIOR"] = {
		},
		["ROGUE"] = {
			["S3R2Pet"] = false,
			["S3R2Idn"] = "",
			["S3R1Pet"] = false,
			["S3R4Idn"] = "",
			["S3R5Idn"] = "",
			["S3R3Idn"] = "",
			["S3R3Pet"] = false,
			["S3R1Idn"] = "",
			["S3R5Pet"] = false,
			["S3R4Pet"] = false,
		},
		["MAGE"] = {
			["S2R2Pet"] = false,
			["S2R4Pet"] = false,
			["S2R1Pet"] = false,
			["S2R1Idn"] = "",
			["S2R4Idn"] = "",
			["S2R3Idn"] = "",
			["S2R2Idn"] = "",
			["S2R3Pet"] = false,
			["S2R5Idn"] = "",
			["S2R5Pet"] = false,
		},
		["PRIEST"] = {
		},
		["HUNTER"] = {
			["S3R2Pet"] = false,
			["S3R2Idn"] = "",
			["S3R1Pet"] = false,
			["S3R4Idn"] = "",
			["S3R5Idn"] = "",
			["S3R3Idn"] = "",
			["S3R3Pet"] = false,
			["S3R1Idn"] = "",
			["S3R4Pet"] = false,
			["S3R5Pet"] = false,
		},
		["EVOKER"] = {
		},
		["WARLOCK"] = {
		},
		["DEMONHUNTER"] = {
			["S2R2Pet"] = false,
			["S2R4Pet"] = false,
			["S2R1Pet"] = false,
			["S2R1Idn"] = "",
			["S2R4Idn"] = "",
			["S2R3Idn"] = "",
			["S2R2Idn"] = "",
			["S2R3Pet"] = false,
			["S2R5Pet"] = false,
			["S2R5Idn"] = "",
		},
		["SHAMAN"] = {
			["S2R2Pet"] = false,
			["S2R4Pet"] = false,
			["S2R1Pet"] = false,
			["S2R1Idn"] = "375986",
			["S2R4Idn"] = "",
			["S2R3Idn"] = "",
			["S2R2Idn"] = "333957",
			["S2R3Pet"] = false,
			["S2R5Pet"] = false,
			["S2R5Idn"] = "108271",
		},
		["DRUID"] = {
			["S4R2Idn"] = "",
			["S4R4Pet"] = false,
			["S4R5Pet"] = false,
			["S4R3Idn"] = "",
			["S4R2Pet"] = false,
			["S4R4Idn"] = "",
			["S4R3Pet"] = false,
			["S4R1Idn"] = "",
			["S4R1Pet"] = false,
			["S4R5Idn"] = "",
		},
		["MONK"] = {
		},
		["PALADIN"] = {
		},
	},
	["FilterChatMessages"] = "Off",
	["LeaPlusQuestFontSize"] = 12,
	["ManageWidgetTop"] = "Off",
	["CharAddonList"] = "Off",
	["NoAlerts"] = "Off",
	["MainPanelX"] = 275.6918640136719,
	["HideMiniAddonButtons"] = "On",
	["NoDuelRequests"] = "On",
	["AutoAcceptRes"] = "On",
	["CooldownsOnPlayer"] = "Off",
	["ControlA"] = "CENTER",
	["DressupMoreZoomOut"] = "Off",
	["QuestFontChange"] = "Off",
	["NoRaidRestrictions"] = "Off",
	["MuteAirships"] = "Off",
	["FasterLooting"] = "On",
	["MuteDucks"] = "Off",
	["MuteSoulEaters"] = "Off",
	["AutoRepairGear"] = "On",
	["HideCleanupBtns"] = "Off",
	["MuteGameSounds"] = "Off",
	["DressupWiderPreview"] = "On",
	["MuteSunflower"] = "Off",
	["ChatHistory4"] = {
		"|cffffff00|cff979797|Hpratcopy|h[12:51:15]|h|r |cffd8d8d8[|r|Hplayer:Brich:213|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r has come online.", -- [1]
		"|cff00aa00|cff979797|Hpratcopy|h[12:51:44]|h|r You receive item: |cff0070dd|Hitem:193218::::::::70:261:::::::::|h[Dense Hide |A:Professions-ChatIcon-Quality-Tier3:17:18::1|a]|h|rx5", -- [2]
		"|cff00aa00|cff979797|Hpratcopy|h[12:51:44]|h|r You receive item: |cffffffff|Hitem:198200::::::::70:261:::::::::|h[Reinforced Machine Chassis |A:Professions-ChatIcon-Quality-Tier3:17:18::1|a]|h|r", -- [3]
		"|cff00aa00|cff979797|Hpratcopy|h[12:51:45]|h|r You receive item: |cffffffff|Hitem:198194::::::::70:261:::::::::|h[Greased-Up Gears |A:Professions-ChatIcon-Quality-Tier3:17:18::1|a]|h|rx3", -- [4]
		"|cff00aa00|cff979797|Hpratcopy|h[12:51:46]|h|r You receive item: |cffffffff|Hitem:198197::::::::70:261:::::::::|h[Arclight Capacitor |A:Professions-ChatIcon-Quality-Tier3:17:18::1|a]|h|rx3", -- [5]
		"|cff00aa00|cff979797|Hpratcopy|h[12:51:46]|h|r You receive item: |cff1eff00|Hitem:198309::::::::70:261:::::::::|h[One-Size-Fits-All Gear |A:Professions-ChatIcon-Quality-Tier3:17:18::1|a]|h|r", -- [6]
		"|cffffff00|cff979797|Hpratcopy|h[12:52:39]|h|r Faür-Stormrage has fled from Tunnado-Stormrage in a duel", -- [7]
		"|cff00aa00|cff979797|Hpratcopy|h[12:53:12]|h|r You receive item: |cff1eff00|Hitem:198255::::::::70:261:::::::::|h[Calibrated Safety Switch |A:Professions-ChatIcon-Quality-Tier3:17:18::1|a]|h|r", -- [8]
		"|cffffff00|cff979797|Hpratcopy|h[12:53:36]|h|r Crafting order placed.", -- [9]
		"|cffff80ff|cff979797|Hpratcopy|h[12:54:24]|h|r [W From] |cffd8d8d8[|r|Hplayer:Bapaladin-Mal'Ganis:497:WHISPER:BAPALADIN-MAL'GANIS|h|cfff48cbaBapaladin|r|h|cffd8d8d8]|r: 424 or 447?", -- [10]
		"|cffff80ff|cff979797|Hpratcopy|h[12:54:30]|h|r [W To] |cffd8d8d8[|r|Hplayer:Bapaladin-Mal'Ganis:515:WHISPER:BAPALADIN-MAL'GANIS|h|cfff48cbaBapaladin|r|h|cffd8d8d8]|r: 424", -- [11]
		"|cffffff9f|cff979797|Hpratcopy|h[12:54:46]|h|r Journeyman Envial says: Gems so bright you'll want to shine your scales! Come browse the work of the finest jewelcrafters in the Dragon Isles.", -- [12]
		"|cffffff00|cff979797|Hpratcopy|h[12:55:37]|h|r A crafter has fulfilled your order with Slimy Expulsion Boots |A:Professions-ChatIcon-Quality-Tier5:17:17::1|a.", -- [13]
		"|cffffff00|cff979797|Hpratcopy|h[12:55:45]|h|r A crafter has fulfilled your order with Needlessly Complex Wristguards |A:Professions-ChatIcon-Quality-Tier4:17:17::1|a.", -- [14]
		"|cffff80ff|cff979797|Hpratcopy|h[12:55:47]|h|r [W From] |cffd8d8d8[|r|Hplayer:Bapaladin-Mal'Ganis:673:WHISPER:BAPALADIN-MAL'GANIS|h|cfff48cbaBapaladin|r|h|cffd8d8d8]|r: ok for you", -- [15]
		"|cffffff00|cff979797|Hpratcopy|h[12:55:49]|h|r |cffc69b6dBrich|r has gone offline.", -- [16]
		"|cffff80ff|cff979797|Hpratcopy|h[12:55:49]|h|r [W From] |cffd8d8d8[|r|Hplayer:Bapaladin-Mal'Ganis:678:WHISPER:BAPALADIN-MAL'GANIS|h|cfff48cbaBapaladin|r|h|cffd8d8d8]|r: send to Basempr", -- [17]
		"|cff00aa00|cff979797|Hpratcopy|h[12:55:50]|h|r You receive item: |cffa335ee|Hitem:193451::::::::70:261::13:6:8836:8840:8902:8960:9405:9366:4:28:2164:38:8:40:376:48:204440:::::|h[Slimy Expulsion Boots |A:Professions-ChatIcon-Quality-Tier5:17:17::1|a]|h|r", -- [18]
		"|cff00aa00|cff979797|Hpratcopy|h[12:55:50]|h|r You receive item: |cffa335ee|Hitem:198327::::::::70:261::13:8:8836:8840:8902:9404:8951:8863:9366:9415:8:28:2164:29:32:38:7:40:559:48:198309:50:198255:52:204440:54:206041:::::|h[Needlessly Complex Wristguards |A:Professions-ChatIcon-Quality-Tier4:17:17::1|a]|h|r", -- [19]
		"|cff82c5ff|cff979797|Hpratcopy|h[12:56:58]|h|r |TInterface\\FriendsFrame\\UI-Toast-ToastIcons.tga:16:16:0:0:128:64:2:29:34:61|t|HBNplayer:|Kq38|k:20:757:BN_INLINE_TOAST_ALERT:0|h[|Kq38|k] (|T-2:10:10:0:0:32:32:0:32:0:32|t SMoLzz)|h has come online.", -- [20]
		"|cffffff00|cff979797|Hpratcopy|h[12:57:13]|h|r |cffd8d8d8[|r|Hplayer:Coruptid:772|h|cffd8bc3f70|r:|cffaad372Coruptid|r|h|cffd8d8d8]|r has come online.", -- [21]
		"|cff00aa00|cff979797|Hpratcopy|h[12:57:16]|h|r You receive item: |cff0070dd|Hitem:201409::::::::70:261:::::::::|h[Tinker: Arclight Vital Correctors |A:Professions-ChatIcon-Quality-Tier3:17:18::1|a]|h|r", -- [22]
		"|cffffff00|cff979797|Hpratcopy|h[12:58:56]|h|r Patrickros-Stormrage has defeated Tunnado-Stormrage in a duel", -- [23]
		"|cffffff00|cff979797|Hpratcopy|h[12:59:59]|h|r |cffd8d8d8[|r|Hplayer:Wargrimz:966|h|cffd8bc3f70|r:|cffaad372Wargrimz|r|h|cffd8d8d8]|r has come online.", -- [24]
		"|cff00aa00|cff979797|Hpratcopy|h[13:02:05]|h|r You receive item: |cffffffff|Hitem:192836::::::::70:261:::::::::|h[Shimmering Clasp |A:Professions-ChatIcon-Quality-Tier3:17:18::1|a]|h|rx2", -- [25]
		"|cff00aa00|cff979797|Hpratcopy|h[13:02:05]|h|r You receive item: |cff0070dd|Hitem:193379::::::::70:261:::::::::|h[Elemental Harmony |A:Professions-ChatIcon-Quality-Tier3:17:18::1|a]|h|r", -- [26]
		"|cff00aa00|cff979797|Hpratcopy|h[13:02:06]|h|r You receive item: |cff0070dd|Hitem:192861::::::::70:261:::::::::|h[Ysemerald |A:Professions-ChatIcon-Quality-Tier3:17:18::1|a]|h|r", -- [27]
		"|cff00aa00|cff979797|Hpratcopy|h[13:02:06]|h|r You receive item: |cff1eff00|Hitem:194578::::::::70:261:::::::::|h[Draconic Missive of the Peerless |A:Professions-ChatIcon-Quality-Tier3:17:18::1|a]|h|r", -- [28]
		"|cffffff00|cff979797|Hpratcopy|h[13:02:43]|h|r Crafting order placed.", -- [29]
		"|cffff80ff|cff979797|Hpratcopy|h[13:03:02]|h|r [W From] |cffd8d8d8[|r|Hplayer:Bapaladin-Mal'Ganis:1163:WHISPER:BAPALADIN-MAL'GANIS|h|cfff48cbaBapaladin|r|h|cffd8d8d8]|r: i can do it", -- [30]
		"|cffff80ff|cff979797|Hpratcopy|h[13:03:08]|h|r [W From] |cffd8d8d8[|r|Hplayer:Bapaladin-Mal'Ganis:1170:WHISPER:BAPALADIN-MAL'GANIS|h|cfff48cbaBapaladin|r|h|cffd8d8d8]|r: send to Basemp", -- [31]
		"|cffffff00|cff979797|Hpratcopy|h[13:03:08]|h|r A crafter has fulfilled your order with Signet of Titanic Insight |A:Professions-ChatIcon-Quality-Tier5:17:17::1|a.", -- [32]
		"|cffffff00|cff979797|Hpratcopy|h[13:03:28]|h|r Tunnado-Stormrage has defeated Faür-Stormrage in a duel", -- [33]
		"|cff00aa00|cff979797|Hpratcopy|h[13:04:24]|h|r You receive item: |cffa335ee|Hitem:192999::::::::70:261::13:7:8836:8840:8902:8780:9405:8791:9366:7:28:2164:29:40:30:32:38:8:40:258:48:194578:51:204440:::::|h[Signet of Titanic Insight |A:Professions-ChatIcon-Quality-Tier5:17:17::1|a]|h|r", -- [34]
		"|cffffff00|cff979797|Hpratcopy|h[13:04:48]|h|r Faür-Stormrage has defeated Tunnado-Stormrage in a duel", -- [35]
		"|cffffff00|cff979797|Hpratcopy|h[13:05:34]|h|r You sold your junk for 1|TInterface\\MoneyFrame\\UI-GoldIcon:0:0:2:0|t 75|TInterface\\MoneyFrame\\UI-SilverIcon:0:0:2:0|t 37|TInterface\\MoneyFrame\\UI-CopperIcon:0:0:2:0|t", -- [36]
		"|cffffff00|cff979797|Hpratcopy|h[13:05:34]|h|r You repaired your armor for 140|TInterface\\MoneyFrame\\UI-GoldIcon:0:0:2:0|t 90|TInterface\\MoneyFrame\\UI-SilverIcon:0:0:2:0|t 9|TInterface\\MoneyFrame\\UI-CopperIcon:0:0:2:0|t", -- [37]
		"|cffffff00|cff979797|Hpratcopy|h[13:06:04]|h|r |cffaad372Wargrimz|r has gone offline.", -- [38]
		"|cffffff00|cff979797|Hpratcopy|h[13:06:31]|h|r |cffd8d8d8[|r|Hplayer:Ripnrots:1420|h|cffd8bc3f70|r:|cffc41e3aRipnrots|r|h|cffd8d8d8]|r has come online.", -- [39]
		"|cff00fff6|cff979797|Hpratcopy|h[13:06:43]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq78|k:36:1435:BN_WHISPER:|Kq78|k:Budsmokr#1645|h|A:UI-ChatIcon-WoW:0:0:0:0|a|cffaad372|Kq78|k|r|h|cffd8d8d8]|r: cam on a meeting next to me, cant talk", -- [40]
		"|cffffff00|cff979797|Hpratcopy|h[13:06:59]|h|r |cffc41e3aRipnrots|r has gone offline.", -- [41]
		"|cffffff00|cff979797|Hpratcopy|h[13:07:14]|h|r |cffd8d8d8[|r|Hplayer:Hoznboats:1469|h|cffd8bc3f70|r:|cfff48cbaHoznboats|r|h|cffd8d8d8]|r has come online.", -- [42]
		"|cffffff00|cff979797|Hpratcopy|h[13:07:55]|h|r Faür-Stormrage has defeated Patrickros-Stormrage in a duel", -- [43]
		"|cffffff00|cff979797|Hpratcopy|h[13:09:08]|h|r This is now a cross-faction instance group. You can do these activities together: dungeons and raids (non-queued), Torghast, Rated PvP", -- [44]
		"|cffffff00|cff979797|Hpratcopy|h[13:09:08]|h|r Dungeon Difficulty set to Normal.", -- [45]
		"|cffffff00|cff979797|Hpratcopy|h[13:09:16]|h|r Nethull-EmeraldDream has defeated Delasangre-EmeraldDream in a duel", -- [46]
		"|cffff8040|cff979797|Hpratcopy|h[13:09:35]|h|r Aeoreon sighs.", -- [47]
		"|cffff8040|cff979797|Hpratcopy|h[13:09:35]|h|r Numernormi chuckles.", -- [48]
		"|cffffff9f|cff979797|Hpratcopy|h[13:09:36]|h|r Aeoreon says: That is not what they mean, Vekkalis.", -- [49]
		"|cff00aa00|cff979797|Hpratcopy|h[13:09:57]|h|r You receive item: |cffa335ee|Hitem:204193::::::::70:261:::::::::|h[Whelpling's Shadowflame Crest]|h|r", -- [50]
		"|cffffff00|cff979797|Hpratcopy|h[13:10:38]|h|r Dungeon Difficulty set to Mythic.", -- [51]
		"|cffaaaaff|cff979797|Hpratcopy|h[13:10:54]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Îllest-EmeraldDream:1700:PARTY|h|cffd8bc3f70|r:|cff8788eeÎllest|r-|cff30c774Eme|r|h|cffd8d8d8]|r: ty for summon", -- [52]
		"|cffaaaaff|cff979797|Hpratcopy|h[13:11:12]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Apoplectic-Alexstrasza:1701:PARTY|h|cffd8bc3f70|r:|cff8788eeApoplectic|r-|cffd25865Ale|r|h|cffd8d8d8]|r: My pleasure", -- [53]
		"|cffffff00|cff979797|Hpratcopy|h[13:11:33]|h|r |cfff48cbaHoznboats|r has gone offline.", -- [54]
		"|cffaaaaff|cff979797|Hpratcopy|h[13:11:46]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Chelyberrana-Stormrage:1703:PARTY|h|cffd8bc3f70|r:|cffff7c0aChelyberrana|r-|cffc4955eSto|r|h|cffd8d8d8]|r: YES TY FOR SUMMON MUCH APPRECIATED", -- [55]
		"|cff76c8ff|cff979797|Hpratcopy|h[13:11:54]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Fjörgynn-Azralon:1704:PARTY|h|cffd8bc3f70|r:|cff0070ddFjörgynn|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: Illest go out and get inside again", -- [56]
		"|cffaaaaff|cff979797|Hpratcopy|h[13:11:57]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Apoplectic-Alexstrasza:1705:PARTY|h|cffd8bc3f70|r:|cff8788eeApoplectic|r-|cffd25865Ale|r|h|cffd8d8d8]|r: IT WAS MY PLEASURE TO ASSIST", -- [57]
		"|cffffff00|cff979797|Hpratcopy|h[13:12:01]|h|r |cffd8d8d8[|r|Hplayer:Wargrimz:1706|h|cffd8bc3f70|r:|cffaad372Wargrimz|r|h|cffd8d8d8]|r has come online.", -- [58]
		"|cffaaaaff|cff979797|Hpratcopy|h[13:12:18]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Îllest-EmeraldDream:1707:PARTY|h|cffd8bc3f70|r:|cff8788eeÎllest|r-|cff30c774Eme|r|h|cffd8d8d8]|r: there we go lol", -- [59]
		"|cffffff00|cff979797|Hpratcopy|h[13:12:33]|h|r |cffa5a5a5Fjörgynn|r-Azralon has initiated a ready check.", -- [60]
		"|cffffff00|cff979797|Hpratcopy|h[13:15:09]|h|r |cffaad372Wargrimz|r has gone offline.", -- [61]
		"|cffffff00|cff979797|Hpratcopy|h[13:15:21]|h|r |cffd8d8d8[|r|Hplayer:Macewindfury:1710|h|cffd8bc3f70|r:|cff0070ddMacewindfury|r|h|cffd8d8d8]|r has come online.", -- [62]
		"|cffff4040|cff979797|Hpratcopy|h[13:16:05]|h|r Watcher Irideus yells: More trespassers? I will not allow you through!", -- [63]
		"|cffffff00|cff979797|Hpratcopy|h[13:16:19]|h|r |cff0070ddMacewindfury|r has gone offline.", -- [64]
		"|cffff4040|cff979797|Hpratcopy|h[13:16:30]|h|r Watcher Irideus yells: Order will overwhelm you.", -- [65]
		"|cffffdd00|cff979797|Hpratcopy|h[13:16:30]|h|r |TInterface\\ICONS\\Ability_ThunderKing_LightningWhip.blp:20|t Watcher Irideus begins casting |cFFFF0000|Hspell:389179|h[Power Overload]|h|r!", -- [66]
		"|cffff4040|cff979797|Hpratcopy|h[13:16:38]|h|r Watcher Irideus yells: I will not let you through!", -- [67]
		"|cffffdd00|cff979797|Hpratcopy|h[13:16:41]|h|r |TInterface\\ICONS\\Spell_Nature_LightningShield.blp:20|t Watcher Irideus erects an |cFFFF0000|Hspell:383840|h[Ablative Barrier]|h|r!", -- [68]
		"|cffff4040|cff979797|Hpratcopy|h[13:16:42]|h|r Watcher Irideus yells: My sacrifice will keep these halls safe!", -- [69]
		"|cffff4040|cff979797|Hpratcopy|h[13:17:01]|h|r Watcher Irideus yells: A small victory, I will eliminate you!", -- [70]
		"|cffffff00|cff979797|Hpratcopy|h[13:17:19]|h|r |cffd8d8d8[|r|Hplayer:Wargrimz:1719|h|cffd8bc3f70|r:|cffaad372Wargrimz|r|h|cffd8d8d8]|r has come online.", -- [71]
		"|cffff4040|cff979797|Hpratcopy|h[13:17:29]|h|r Watcher Irideus yells: Order will overwhelm you.", -- [72]
		"|cffffdd00|cff979797|Hpratcopy|h[13:17:29]|h|r |TInterface\\ICONS\\Ability_ThunderKing_LightningWhip.blp:20|t Watcher Irideus begins casting |cFFFF0000|Hspell:389179|h[Power Overload]|h|r!", -- [73]
		"|cffffffff|cff979797|Hpratcopy|h[13:17:29]|h|r [S] |cffd8d8d8[|r|Hplayer:Fjörgynn-Azralon:1722:SAY|h|cffd8bc3f70|r:|cff0070ddFjörgynn|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: Sobrecarga de Energia em |cffa5a5a5Fjörgynn|r!", -- [74]
		"|cffffffff|cff979797|Hpratcopy|h[13:17:32]|h|r [S] |cffd8d8d8[|r|Hplayer:Fjörgynn-Azralon:1723:SAY|h|cffd8bc3f70|r:|cff0070ddFjörgynn|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: 3", -- [75]
		"|cffffffff|cff979797|Hpratcopy|h[13:17:33]|h|r [S] |cffd8d8d8[|r|Hplayer:Fjörgynn-Azralon:1724:SAY|h|cffd8bc3f70|r:|cff0070ddFjörgynn|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: 2", -- [76]
		"|cffff4040|cff979797|Hpratcopy|h[13:17:37]|h|r Watcher Irideus yells: Tyr... Forgive me... I could not... stop... them...", -- [77]
		"|cffffff9f|cff979797|Hpratcopy|h[13:20:17]|h|r Squallbringer Cyraz says: The winds are always in my favor!", -- [78]
		"|cffffdd00|cff979797|Hpratcopy|h[13:21:19]|h|r |TInterface\\ICONS\\Ability_Druid_FerociousBite.blp:20|t The Gulping Goliath begins to cast |cFFFF0000|Hspell:385551|h[Gulp]|h|r!", -- [79]
		"|cffffffff|cff979797|Hpratcopy|h[13:21:40]|h|r [S] |cffd8d8d8[|r|Hplayer:Fjörgynn-Azralon:1728:SAY|h|cffd8bc3f70|r:|cff0070ddFjörgynn|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: Batida de Barriga em |cffa5a5a5Fjörgynn|r!", -- [80]
		"|cffffdd00|cff979797|Hpratcopy|h[13:22:06]|h|r |TInterface\\ICONS\\Ability_Druid_FerociousBite.blp:20|t The Gulping Goliath begins to cast |cFFFF0000|Hspell:385551|h[Gulp]|h|r!", -- [81]
		"|cffff4040|cff979797|Hpratcopy|h[13:24:23]|h|r Khajin the Unyielding yells: We'll build a new world free from their corruption!", -- [82]
		"|cffff4040|cff979797|Hpratcopy|h[13:24:33]|h|r Khajin the Unyielding yells: Let me show ya the power of the elements!", -- [83]
		"|cffffdd00|cff979797|Hpratcopy|h[13:24:43]|h|r |TInterface\\ICONS\\Spell_Frost_Ice Shards.blp:20|tKhajin the Unyielding begins to cast |cFFFF0000|Hspell:386757|h[Hailstorm]|h|r!", -- [84]
		"|cffff4040|cff979797|Hpratcopy|h[13:24:55]|h|r Khajin the Unyielding yells: Ya gonna catch ya death!", -- [85]
		"|cffff4040|cff979797|Hpratcopy|h[13:25:08]|h|r Khajin the Unyielding yells: Let me show ya the power of the elements!", -- [86]
		"|cffffdd00|cff979797|Hpratcopy|h[13:25:13]|h|r |TInterface\\ICONS\\Spell_Frost_Ice Shards.blp:20|tKhajin the Unyielding begins to cast |cFFFF0000|Hspell:386757|h[Hailstorm]|h|r!", -- [87]
		"|cffff4040|cff979797|Hpratcopy|h[13:25:25]|h|r Khajin the Unyielding yells: Ya gonna catch ya death!", -- [88]
		"|cffff4040|cff979797|Hpratcopy|h[13:25:39]|h|r Khajin the Unyielding yells: Nothing... can stop... us...", -- [89]
		"|cffff4040|cff979797|Hpratcopy|h[13:27:28]|h|r Infuser Sariya yells: Fools! Do you not see what that wretch Tyr has done?", -- [90]
		"|cffff4040|cff979797|Hpratcopy|h[13:27:56]|h|r Infuser Sariya yells: The elemental... will cleanse... the waters...", -- [91]
		"|cffffdd00|cff979797|Hpratcopy|h[13:29:04]|h|r |TInterface\\ICONS\\Creatureportrait_Bubble.blp:20|t The Primal Tsunami begins to |cFFFF0000|Hspell:388420|h[Cast Away]|h|r its enemies!", -- [92]
		"|cff40ff40|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1741:GUILD|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16261:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Heroic: Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!", -- [93]
		"|cff40ff40|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1742:GUILD|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16262:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Mythic: Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!", -- [94]
		"|cff40ff40|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1743:GUILD|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16260:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!", -- [95]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1744:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16261:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Heroic: Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!", -- [96]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1745:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16262:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Mythic: Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!", -- [97]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1746:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16260:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!", -- [98]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Apoplectic-Alexstrasza:1747:ACHIEVEMENT|h|cffd8bc3f70|r:|cff8788eeApoplectic|r-|cffd25865Ale|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16262:Player-1070-0D8ADEBB:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Mythic: Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!", -- [99]
		"|cff40ff40|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1748:GUILD|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:11183:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Keystone Initiate]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!", -- [100]
		"|cff40ff40|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1749:GUILD|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:11184:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Keystone Challenger]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!", -- [101]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1750:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:11183:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Keystone Initiate]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!", -- [102]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1751:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:11184:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Keystone Challenger]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!", -- [103]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Chelyberrana-Stormrage:1752:ACHIEVEMENT|h|cffd8bc3f70|r:|cffff7c0aChelyberrana|r-|cffc4955eSto|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:17842:Player-60-0F2BFCA2:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Dragonflight Keystone Explorer: Season Two]|h|r |cffffffff(|rCompleted 5/10/23|cffffffff)|r!", -- [104]
		"|cff00aa00|cff979797|Hpratcopy|h[13:30:01]|h|r You receive currency: |cff0070dd|Hcurrency:2245:0|h[Flightstones]|h|rx42", -- [105]
		"|cff00aa00|cff979797|Hpratcopy|h[13:30:01]|h|r You receive currency: |cff0070dd|Hcurrency:2408:0|h[Bonus Flightstones]|h|rx25", -- [106]
		"|cff00aa00|cff979797|Hpratcopy|h[13:30:01]|h|r You receive item: |cff0070dd|Hitem:204075::::::::70:261:::::::::|h[Whelpling's Shadowflame Crest Fragment]|h|rx12", -- [107]
		"|cffaaaaff|cff979797|Hpratcopy|h[13:30:09]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Apoplectic-Alexstrasza:1756:PARTY|h|cffd8bc3f70|r:|cff8788eeApoplectic|r-|cffd25865Ale|r|h|cffd8d8d8]|r: Gee Gee Wee Pee", -- [108]
		"|cff00aa00|cff979797|Hpratcopy|h[13:30:09]|h|r |cffa5a5a5Fjörgynn|r-Azralon receives loot: |cffa335ee|Hitem:193736::::::::70:261::33:5:9315:6652:9144:1630:8767:1:28:1279:::::|h[Water's Beating Heart]|h|r.", -- [109]
		"|cff00aa00|cff979797|Hpratcopy|h[13:30:10]|h|r |cffa5a5a5Îllest|r-EmeraldDream receives loot: |cffa335ee|Hitem:204717::::::::70:261:::::::::|h[Splintered Spark of Shadowflame]|h|r.", -- [110]
		"|cff00aa00|cff979797|Hpratcopy|h[13:30:10]|h|r |cffa5a5a5Îllest|r-EmeraldDream receives loot: |cffa335ee|Hitem:180653::::::::70:261::::4:17:405:18:11:19:9:20:124:::::|h[Mythic Keystone]|h|r.", -- [111]
		"|cff00aa00|cff979797|Hpratcopy|h[13:30:11]|h|r You receive loot: |cffa335ee|Hitem:193743::::::::70:261::16:5:9315:6652:9144:1630:8767:1:28:1279:::::|h[Irideus Fragment]|h|r", -- [112]
		"|cff00aa00|cff979797|Hpratcopy|h[13:30:11]|h|r You receive loot: |cffa335ee|Hitem:180653::::::::70:261::::3:17:438:18:4:19:9:::::|h[Mythic Keystone]|h|r", -- [113]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:12]|h|r You loot 55 Gold, 34 Silver, 86 Copper", -- [114]
		"|cff40ff40|cff979797|Hpratcopy|h[13:30:12]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Wargrimz-Mal'Ganis:1763:GUILD|h|cffd8bc3f70|r:|cffaad372Wargrimz|r|h|cffd8d8d8]|r: gratz", -- [115]
		"|cffaaaaff|cff979797|Hpratcopy|h[13:30:14]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Chelyberrana-Stormrage:1764:PARTY|h|cffd8bc3f70|r:|cffff7c0aChelyberrana|r-|cffc4955eSto|r|h|cffd8d8d8]|r: WEE PEE?", -- [116]
		"|cff00aa00|cff979797|Hpratcopy|h[13:30:18]|h|r |cffa5a5a5Apoplectic|r-Alexstrasza receives loot: |cffffffff|Hitem:198038::::::::70:261:::::::::|h[Ancient Titansteel Ingot]|h|rx10.", -- [117]
		"|cff00aa00|cff979797|Hpratcopy|h[13:30:18]|h|r |cffa5a5a5Apoplectic|r-Alexstrasza receives loot: |cffa335ee|Hitem:204717::::::::70:261:::::::::|h[Splintered Spark of Shadowflame]|h|r.", -- [118]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:26]|h|r |cffa5a5a5Îllest|r-EmeraldDream leaves the party.", -- [119]
		"|cffaaaaff|cff979797|Hpratcopy|h[13:30:27]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Apoplectic-Alexstrasza:1768:PARTY|h|cffd8bc3f70|r:|cff8788eeApoplectic|r-|cffd25865Ale|r|h|cffd8d8d8]|r: Isn't that what we just killed?", -- [120]
		"|cff76c8ff|cff979797|Hpratcopy|h[13:30:28]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Fjörgynn-Azralon:1769:PARTY|h|cffd8bc3f70|r:|cff0070ddFjörgynn|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: ty all", -- [121]
		"|cffaaaaff|cff979797|Hpratcopy|h[13:30:29]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1770:PARTY|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r: ty all", -- [122]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:32]|h|r |cffa5a5a5Fjörgynn|r-Azralon leaves the party.", -- [123]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:32]|h|r |cffa5a5a5Apoplectic|r-Alexstrasza is now the group leader.", -- [124]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:37]|h|r |cffa5a5a5Apoplectic|r-Alexstrasza leaves the party.", -- [125]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:37]|h|r |cffa5a5a5Chelyberrana|r-Stormrage is now the group leader.", -- [126]
		"|cffffff9f|cff979797|Hpratcopy|h[13:31:21]|h|r Brigita says: Welcome to the Roasted Ram! Seating is open.", -- [127]
		"|cffffff00|cff979797|Hpratcopy|h[13:31:29]|h|r Gooeyzugzug has defeated Minivoker in a duel", -- [128]
	},
	["BordersTop"] = 0,
	["AutoSellExcludeMyAlts"] = "On",
	["MiniClusterScale"] = 1,
	["DressupAnimControl"] = "On",
	["NoClassBar"] = "Off",
	["TipNoHealthBar"] = "Off",
	["SetChatFontSize"] = "Off",
	["MaxCameraZoom"] = "On",
	["AutoSellJunk"] = "On",
	["ShowRaidToggle"] = "Off",
	["TooltipAnchorMenu"] = 1,
	["NoScreenEffects"] = "Off",
	["MinimapNoScale"] = "Off",
	["MuteTravelers"] = "Off",
	["HideBodyguard"] = "Off",
	["InviteFromWhisper"] = "Off",
	["AutoSellExcludeList"] = "",
	["ShowVoiceButtons"] = "Off",
	["TransSpraybots"] = "Off",
	["TipHideShiftOverride"] = "On",
	["AutoRepairGuildFunds"] = "On",
	["TransBlight"] = "Off",
	["AutoConfirmRole"] = "Off",
	["LockoutSharing"] = "Off",
	["BordersRight"] = 0,
	["MuteCustomSounds"] = "Off",
	["MuteVaults"] = "Off",
	["AutoSellNoKeeperTahult"] = "On",
	["AutoReleaseNoAshran"] = "Off",
	["ManageControl"] = "Off",
	["TransTurkey"] = "Off",
	["DressupFasterZoom"] = 3,
	["MuteMechsuits"] = "Off",
	["NoRestedSleep"] = "Off",
	["ClassColTarget"] = "On",
	["LeaPlusChatFontSize"] = 20,
	["SyncFromFriends"] = "Off",
	["MuteUnicorns"] = "Off",
	["MuteOttuks"] = "Off",
	["NoCommandBar"] = "Off",
	["BlockDrunkenSpam"] = "Off",
	["AutoQuestCompleted"] = "On",
	["ClassColFrames"] = "Off",
	["NoConfirmLoot"] = "Off",
	["CombineAddonButtons"] = "Off",
	["WeatherLevel"] = 1,
	["NoStickyChat"] = "Off",
	["LeaPlusMailFontSize"] = 15,
	["MuteTrains"] = "Off",
	["BordersAlpha"] = 0,
	["MuteAnima"] = "Off",
	["UnclampChat"] = "Off",
	["NoFriendRequests"] = "Off",
	["AutoRepairShowSummary"] = "On",
	["AutoReleaseNoTolBarad"] = "Off",
	["ShowVolumeInFrame"] = "Off",
	["TipShowRank"] = "On",
	["DurabilityStatus"] = "Off",
	["NoChatButtons"] = "Off",
	["MuteMechSteps"] = "Off",
	["MuteLogin"] = "Off",
	["WidgetTopScale"] = 1,
	["NoSocialButton"] = "Off",
	["ChatTemp1"] = {
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:41]|h|r You receive currency: |cff0070dd|Hcurrency:2245:0|h[Flightstones]|h|rx35", -- [1]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:41]|h|r You receive loot: |cff0070dd|Hitem:204075::::::::70:261:::::::::|h[Whelpling's Shadowflame Crest Fragment]|h|rx10", -- [2]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:41]|h|r |cffd8d8d8[|r|Hplayer:Shortymcstab-Arthas:3579:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Shortymcstab|r-|cff9aab5eArt|r:5|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:1180:Player-69-0BA642A6:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Got My Mind On My Money]|h|r |cffffffff(|rCompleted 5/12/12|cffffffff)|r!", -- [3]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:42]|h|r You loot 125 Gold, 57 Silver, 69 Copper", -- [4]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:42]|h|r |cffa5a5a5Issapanda|r-Tichondrius receives loot: |cffa335ee|Hitem:204717::::::::70:261:::::::::|h[Splintered Spark of Shadowflame]|h|r.", -- [5]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:42]|h|r |cffa5a5a5Tayro|r-Area52 receives loot: |cffa335ee|Hitem:204717::::::::70:261:::::::::|h[Splintered Spark of Shadowflame]|h|r.", -- [6]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:43]|h|r |HlootHistory:2689|h[Loot]|h: You have selected Greed for: |cffa335ee|Hitem:204393::::::::70:261::4:8:6652:9415:9225:9220:9411:9315:1459:8767::::::|h[Clasps of the Diligent Steward]|h|r |HlootHistory:2689|h|cnLOOT_LINK_COLOR:[View Loot Rolls]|r|h", -- [7]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:44]|h|r |HlootHistory:2689|h[Loot]|h: You have selected Greed for: |cffa335ee|Hitem:204393::::::::70:261::4:8:6652:9414:9225:9220:9411:9315:1459:8767::::::|h[Clasps of the Diligent Steward]|h|r |HlootHistory:2689|h|cnLOOT_LINK_COLOR:[View Loot Rolls]|r|h", -- [8]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:45]|h|r |cffa5a5a5Lilshock|r-Eredar receives loot: |cffa335ee|Hitem:191784::::::::70:261:::::::::|h[Dragon Shard of Knowledge]|h|r.", -- [9]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:45]|h|r |cffa5a5a5Valdiscantha|r-Dath'Remar receives loot: |cffa335ee|Hitem:204717::::::::70:261:::::::::|h[Splintered Spark of Shadowflame]|h|r.", -- [10]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:46]|h|r |HlootHistory:2689|h[Loot]|h: You have selected Greed for: |cffa335ee|Hitem:202632::::::::70:261::4:4:9411:9231:1459:8767::::::|h[Mystic Ventilation Fluid]|h|r |HlootHistory:2689|h|cnLOOT_LINK_COLOR:[View Loot Rolls]|r|h", -- [11]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:47]|h|r |HlootHistory:2689|h[Loot]|h: You have selected Need for: |cffa335ee|Hitem:202639::::::::70:261::4:4:9411:9231:1459:8767::::::|h[Zenith Ventilation Fluid]|h|r |HlootHistory:2689|h|cnLOOT_LINK_COLOR:[View Loot Rolls]|r|h", -- [12]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:49]|h|r |cffa5a5a5Issapanda|r-Tichondrius has left the instance group.", -- [13]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:54]|h|r |cffa5a5a5Pyronite|r-Gilneas has left the instance group.", -- [14]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:55]|h|r |cffa5a5a5Valdiscantha|r-Dath'Remar has left the instance group.", -- [15]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:56]|h|r |cffa5a5a5Duntul|r-Skywall has left the instance group.", -- [16]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:57]|h|r |cffa5a5a5Yvnnet|r-AlteracMountains has left the instance group.", -- [17]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:58]|h|r |cffa5a5a5Borthmar|r-Thrall receives loot: |cffa335ee|Hitem:191784::::::::70:261:::::::::|h[Dragon Shard of Knowledge]|h|r.", -- [18]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:59]|h|r |cffa5a5a5Lilshock|r-Eredar has left the instance group.", -- [19]
		"|cff00aa00|cff979797|Hpratcopy|h[10:44:59]|h|r |cfff48cbaBoondocs|r receives loot: |cffa335ee|Hitem:204717::::::::70:261:::::::::|h[Splintered Spark of Shadowflame]|h|r.", -- [20]
		"|cffffff00|cff979797|Hpratcopy|h[10:44:59]|h|r |cffa5a5a5Theoverseer|r-BleedingHollow has left the instance group.", -- [21]
		"|cff00aa00|cff979797|Hpratcopy|h[10:45:00]|h|r |cffa5a5a5Ragtar|r-Cho'gall receives loot: |cffa335ee|Hitem:191784::::::::70:261:::::::::|h[Dragon Shard of Knowledge]|h|r.", -- [22]
		"|cffffff00|cff979797|Hpratcopy|h[10:45:02]|h|r |cffa5a5a5Zaradrelina|r-Jubei'Thos has left the instance group.", -- [23]
		"|cffffff00|cff979797|Hpratcopy|h[10:45:03]|h|r |cffa5a5a5Toebeansuwu|r-WyrmrestAccord has left the instance group.", -- [24]
		"|cffffff00|cff979797|Hpratcopy|h[10:45:04]|h|r You leave the group.", -- [25]
		"|cff00aa00|cff979797|Hpratcopy|h[10:45:20]|h|r |HlootHistory:2689|h[Loot]|h: Shortymcstab (Need - 98, Main-Spec) Won: |cffa335ee|Hitem:202639::::::::70:261::4:4:9411:9231:1459:8767::::::|h[Zenith Ventilation Fluid]|h|r", -- [26]
		"|cff00aa00|cff979797|Hpratcopy|h[10:45:20]|h|r |HlootHistory:2689|h[Loot]|h: Panacaea (Need - 85, Main-Spec) Won: |cffa335ee|Hitem:204393::::::::70:261::4:8:6652:9414:9225:9220:9411:9315:1459:8767::::::|h[Clasps of the Diligent Steward]|h|r", -- [27]
		"|cff00aa00|cff979797|Hpratcopy|h[10:45:20]|h|r |HlootHistory:2689|h[Loot]|h: Dizzavow (Need - 74, Main-Spec) Won: |cffa335ee|Hitem:204393::::::::70:261::4:8:6652:9415:9225:9220:9411:9315:1459:8767::::::|h[Clasps of the Diligent Steward]|h|r", -- [28]
		"|cff00aa00|cff979797|Hpratcopy|h[10:45:20]|h|r |HlootHistory:2689|h[Loot]|h: Tayro (Greed - 90) Won: |cffa335ee|Hitem:202632::::::::70:261::4:4:9411:9231:1459:8767::::::|h[Mystic Ventilation Fluid]|h|r", -- [29]
		"|cffffff00|cff979797|Hpratcopy|h[10:45:20]|h|r Loot Specialization set to: Assassination", -- [30]
		"|cffc3e6e8|cff979797|Hpratcopy|h[10:45:20]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Ohn'ahran Plains]|h", -- [31]
		"|cffe8e479|cff979797|Hpratcopy|h[10:45:20]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Ohn'ahran Plains]|h", -- [32]
		"|cffffff00|cff979797|Hpratcopy|h[10:45:35]|h|r You are now queued in the Raid Finder.", -- [33]
		"|cffe8e479|cff979797|Hpratcopy|h[10:45:50]|h|r |Hchannel:channel:3|h[3] |h Left Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Ohn'ahran Plains]|h", -- [34]
		"|cffffff00|cff979797|Hpratcopy|h[10:45:50]|h|r Loot Specialization set to: Assassination", -- [35]
		"|cffc3e6e8|cff979797|Hpratcopy|h[10:45:50]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - The Throughway]|h", -- [36]
		"|cffffff9f|cff979797|Hpratcopy|h[10:45:53]|h|r Sabellian says: See, Wrathion? They have been marshaling a defense while we tarried.", -- [37]
		"|cffffff9f|cff979797|Hpratcopy|h[10:45:57]|h|r Sabellian says: There are quite a number of them. Let me know when you are ready to discuss a plan, Gelosia.", -- [38]
		"|cffffff9f|cff979797|Hpratcopy|h[10:45:58]|h|r Sabellian says: Keep low. We have not been spotted--", -- [39]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:00]|h|r Wrathion says: I usually prefer the stealthy approach as well, but now is the time to let dragons be dragons! Remind these weaklings who they are dealing with!", -- [40]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:04]|h|r Stonebreath Summoner says: Prepare for the earth's embrace!", -- [41]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:05]|h|r Stonebreath Landslider says: Prepare for the earth's embrace!", -- [42]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:05]|h|r Stonebreath Landslider says: May the rubble rain down!", -- [43]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:05]|h|r Summitshaper Lorac says: Ha ha! I knew you order-addled fools would come!", -- [44]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:06]|h|r Stonebreath Landslider says: May the rubble rain down!", -- [45]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:11]|h|r Summitshaper Lorac says: Remember the name Lorac! I ensure these caverns... will be your tomb!", -- [46]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:11]|h|r Sabellian says: Wrathion no! You are just going to--", -- [47]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:12]|h|r Stonebreath Landslider says: I am now but another grain of dirt...", -- [48]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:12]|h|r Stonebreath Landslider says: I am now but another grain of dirt...", -- [49]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:13]|h|r Stonebreath Landslider says: I've failed you, Summitshaper...", -- [50]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:13]|h|r Stonebreath Landslider says: I've failed you, Summitshaper...", -- [51]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:13]|h|r Wrathion says: Going to terrify them? Make them re-evaluate their life choices? Agreed!", -- [52]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:14]|h|r Stonebreath Landslider says: I've failed you, Summitshaper...", -- [53]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:14]|h|r Stonebreath Landslider says: I am now but another grain of dirt...", -- [54]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:16]|h|r Stonebreath Landslider says: Crush them!", -- [55]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:16]|h|r Stonebreath Landslider says: Return to the dirt, worm!", -- [56]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:18]|h|r Stonebreath Landslider says: May the rubble rain down!", -- [57]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:19]|h|r Wrathion says: You think dragons fall so easily?!", -- [58]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:23]|h|r Stonebreath Landslider says: The earth... welcomes me...", -- [59]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:23]|h|r Stonebreath Landslider says: I am now but another grain of dirt...", -- [60]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:24]|h|r Sabellian says: Stop! He is baiting us, Wrathion!", -- [61]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:25]|h|r Stonebreath Landslider says: I am now but another grain of dirt...", -- [62]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:25]|h|r Stonebreath Landslider says: I am now but another grain of dirt...", -- [63]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:25]|h|r Stonebreath Landslider says: The earth... welcomes me...", -- [64]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:25]|h|r Stonebreath Landslider says: The earth... welcomes me...", -- [65]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:26]|h|r Sabellian says: That blasted-- We have lost the element of surprise. Gelosia, take on the ground forces and I will support you from the air!", -- [66]
		"|cff00aa00|cff979797|Hpratcopy|h[10:46:32]|h|r You receive loot: |cff9d9d9d|Hitem:188728::::::::70:261::9:1:7966:2:9:70:28:2650:::::|h[Timeworn Chain Armguards]|h|r", -- [67]
		"|cff00aa00|cff979797|Hpratcopy|h[10:46:32]|h|r You receive loot: |cff9d9d9d|Hitem:192625::::::::70:261:::::::::|h[Motionless Stone]|h|rx2", -- [68]
		"|cff00aa00|cff979797|Hpratcopy|h[10:46:32]|h|r You receive loot: |cffffffff|Hitem:193050::::::::70:261:::::::::|h[Tattered Wildercloth]|h|r", -- [69]
		"|cffffff00|cff979797|Hpratcopy|h[10:46:33]|h|r You loot 5 Gold, 95 Silver, 90 Copper", -- [70]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:38]|h|r Sabellian says: Whelp! Stop your showboating! Fall in line and listen to my strategy!", -- [71]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:46]|h|r Wrathion says: Your endless whining about a strategy will not win you the throne!", -- [72]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:49]|h|r Cliffkeeper Bouldani says: I was taught by Lorac, himself! You'll never pass his greatest acolyte - ME!", -- [73]
		"|cffffff9f|cff979797|Hpratcopy|h[10:46:54]|h|r Wrathion says: Let us take this lackey out together, Gelosia!", -- [74]
		"|cffffff9f|cff979797|Hpratcopy|h[10:47:38]|h|r Cliffkeeper Bouldani says: Master will... kill me for this...", -- [75]
		"|cffffff9f|cff979797|Hpratcopy|h[10:47:39]|h|r Wrathion says: Stay back, old man. Allow me to clear the way for you.", -- [76]
		"|cff00aa00|cff979797|Hpratcopy|h[10:47:39]|h|r You receive loot: |cff9d9d9d|Hitem:192625::::::::70:261:::::::::|h[Motionless Stone]|h|rx2", -- [77]
		"|cffffff00|cff979797|Hpratcopy|h[10:47:40]|h|r You loot 85 Silver, 42 Copper", -- [78]
		"|cffffff9f|cff979797|Hpratcopy|h[10:47:45]|h|r Cinderstep Igniter says: Lord Fyrakk! Save us...", -- [79]
		"|cffffff9f|cff979797|Hpratcopy|h[10:47:45]|h|r Cinderstep Weaver says: Lord Fyrakk! Save us...", -- [80]
		"|cffffff9f|cff979797|Hpratcopy|h[10:47:45]|h|r Cinderstep Igniter says: Lord Fyrakk! Save us...", -- [81]
		"|cffffff9f|cff979797|Hpratcopy|h[10:47:45]|h|r Cinderstep Weaver says: Lord Fyrakk! Save us...", -- [82]
		"|cffffff9f|cff979797|Hpratcopy|h[10:47:46]|h|r Sabellian says: Insufferable...", -- [83]
		"|cffffff9f|cff979797|Hpratcopy|h[10:48:04]|h|r Cinderstep Igniter says: Lord Fyrakk! Save us...", -- [84]
		"|cffffff9f|cff979797|Hpratcopy|h[10:48:09]|h|r Cinderstep Melter says: My flame... is out...", -- [85]
		"|cff00aa00|cff979797|Hpratcopy|h[10:48:24]|h|r You receive loot: |cff9d9d9d|Hitem:188707::::::::70:261::9:1:7966:2:9:70:28:2650:::::|h[Rotten Leather Guise]|h|r", -- [86]
		"|cff00aa00|cff979797|Hpratcopy|h[10:48:24]|h|r You receive loot: |cff9d9d9d|Hitem:192635::::::::70:261:::::::::|h[Warped Metal]|h|rx4", -- [87]
		"|cffffff00|cff979797|Hpratcopy|h[10:48:25]|h|r You loot 3 Gold, 17 Silver, 87 Copper", -- [88]
		"|cffffff9f|cff979797|Hpratcopy|h[10:48:31]|h|r Cinderstep Igniter says: Lord Fyrakk! Save us...", -- [89]
		"|cffffff9f|cff979797|Hpratcopy|h[10:48:31]|h|r Cinderstep Igniter says: Lord Fyrakk! Save us...", -- [90]
		"|cffffff9f|cff979797|Hpratcopy|h[10:48:33]|h|r Cinderstep Igniter says: You will become cinders!", -- [91]
		"|cffffff9f|cff979797|Hpratcopy|h[10:48:53]|h|r Wrathion says: Now they try to best the black dragonflight with fire? How cute.", -- [92]
		"|cffffff9f|cff979797|Hpratcopy|h[10:48:56]|h|r Portalkeeper Cimbra says: I trained in the Firelands. You cannot defeat me.", -- [93]
		"|cffffff9f|cff979797|Hpratcopy|h[10:49:04]|h|r Sabellian says: Indeed. Their grasp of effective stratagem is only surpassed by yours, Wrathion.", -- [94]
		"|cffffff9f|cff979797|Hpratcopy|h[10:49:17]|h|r Portalkeeper Cimbra says: The Firelands was... not this hot...", -- [95]
		"|cffffff9f|cff979797|Hpratcopy|h[10:49:18]|h|r Wrathion says: Now, shall we kick the braggart off his walking mountain of mud?", -- [96]
		"|cffffff9f|cff979797|Hpratcopy|h[10:49:24]|h|r Sabellian says: This filthy fool seems to be the only one left standing against us. Should we not have some fun?", -- [97]
		"|cffffff9f|cff979797|Hpratcopy|h[10:49:37]|h|r Summitshaper Lorac says: Lord Fyrakk was unconcerned, but I knew you'd follow. I am a planner! I am prepared!", -- [98]
		"|cffffff9f|cff979797|Hpratcopy|h[10:49:54]|h|r Summitshaper Lorac says: This is the part where you die! Attack them, my mud minion!", -- [99]
		"|cffffff9f|cff979797|Hpratcopy|h[10:50:03]|h|r Summitshaper Lorac says: Why won't you die? Killing you should have been easy.", -- [100]
		"|cffffff9f|cff979797|Hpratcopy|h[10:50:21]|h|r Summitshaper Lorac says: I didn't... plan for this-", -- [101]
		"|cffffff00|cff979797|Hpratcopy|h[10:50:23]|h|r You loot 67 Silver, 13 Copper", -- [102]
		"|cffffff9f|cff979797|Hpratcopy|h[10:50:27]|h|r Wrathion says: Ugh! I've got muck in my boots. Disgusting!", -- [103]
		"|cffffff00|cff979797|Hpratcopy|h[10:50:30]|h|r Loot Specialization set to: Assassination", -- [104]
		"|cffc3e6e8|cff979797|Hpratcopy|h[10:50:30]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Zaralek Cavern]|h", -- [105]
		"|cffe8e479|cff979797|Hpratcopy|h[10:50:30]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Zaralek Cavern]|h", -- [106]
		"|cff00aa00|cff979797|Hpratcopy|h[10:50:31]|h|r You receive item: |cffffffff|Hitem:203013::::::::70:261:::::::::|h[Niffen Incense]|h|r", -- [107]
		"|cffffff9f|cff979797|Hpratcopy|h[10:50:31]|h|r Tuberros says: Reekroot is one of the most sublime smellies out there! Our snifferscouts left scent trails where they planted them. Use this incense to follow the smells to the roots.", -- [108]
		"|cffffff9f|cff979797|Hpratcopy|h[10:50:35]|h|r Elder Honeypelt says: You're an uplander aren't ya? You've gotten yourself into quite the bind. Would you like some help?", -- [109]
		"|cffffff00|cff979797|Hpratcopy|h[10:51:12]|h|r Loot Specialization set to: Assassination", -- [110]
		"|cffffff00|cff979797|Hpratcopy|h[10:51:13]|h|r Total time played: 1 |4day:days;, 21 |4hour:hours;, 38 |4minute:minutes;, 36 |4second:seconds;", -- [111]
		"|cffffff00|cff979797|Hpratcopy|h[10:51:13]|h|r Time played this level: 0 |4day:days;, 6 |4hour:hours;, 20 |4minute:minutes;, 58 |4second:seconds;", -- [112]
		"|cff00aa00|cff979797|Hpratcopy|h[10:51:15]|h|r You receive currency: |cff0070dd|Hcurrency:2245:0|h[Flightstones]|h|rx15", -- [113]
		"|cff8080ff|cff979797|Hpratcopy|h[10:51:15]|h|r Reputation with Valdrakken Accord increased by 600.", -- [114]
		"|cffffff00|cff979797|Hpratcopy|h[10:51:15]|h|r The Patience of Princes completed.", -- [115]
		"|cffffff00|cff979797|Hpratcopy|h[10:51:15]|h|r Received 84 Gold, 27 Silver.", -- [116]
		"|cffffff00|cff979797|Hpratcopy|h[10:51:17]|h|r Quest accepted: It Was Not Enough", -- [117]
		"|cffffff00|cff979797|Hpratcopy|h[10:51:18]|h|r Quest accepted: Culling the Deep", -- [118]
		"|cffffff9f|cff979797|Hpratcopy|h[10:51:19]|h|r Elder Honeypelt says: Don't worry, I've got excellent control of my claws. It's my eyesight that's never been good.", -- [119]
		"|cffffff9f|cff979797|Hpratcopy|h[10:51:21]|h|r Elder Honeypelt says: There you go, uplander. What say we go find those friends I smell on you?", -- [120]
		"0 |4day:days;, 0 |4hour:hours;, 0 |4minute:minutes;, 15 |4second:seconds;", -- [121]
		"========== End of Scrollback ==========", -- [122]
		"|cff979797|Hpratcopy|h[10:51:35]|h|r |cff33ff99Decursive|r: Decursive 2.7.10 by John Wellesz", -- [123]
		"|cff979797|Hpratcopy|h[10:51:35]|h|r |cff33ff99Decursive|r: |cff4c7fff |cff4c7fff Decursive is now initialized, remember to check the options (/decursive) |r", -- [124]
	},
	["PlusPanelAlpha"] = 0,
	["MuteSniffing"] = "Off",
	["MoveChatEditBoxToTop"] = "Off",
	["PlayerChainMenu"] = 1,
	["PlusPanelScale"] = 1,
	["MuteInterface"] = "Off",
	["ShowVolume"] = "On",
	["MinimapY"] = -22,
	["MiniExcludeList"] = "",
	["MuteRockets"] = "Off",
	["TransProfessions"] = "Off",
	["NoScreenGlow"] = "Off",
	["NoCombatLogTab"] = "On",
	["ShowWowheadLinks"] = "Off",
	["MuteStriders"] = "Off",
	["AutoAcceptSummon"] = "On",
	["MutePierre"] = "Off",
	["AutoSellShowSummary"] = "On",
	["ShowPetSaveBtn"] = "Off",
	["MuteBrooms"] = "Off",
	["MuteChimes"] = "Off",
	["TransWitch"] = "Off",
	["ShowCooldowns"] = "On",
	["MaxChatHstory"] = "Off",
	["MailFontChange"] = "Off",
	["FasterMovieSkip"] = "Off",
	["ShowBorders"] = "Off",
	["MainPanelA"] = "CENTER",
	["AutoQuestDaily"] = "On",
	["BordersLeft"] = 0,
	["ChatHistory1"] = {
		"|cffffff00|cff979797|Hpratcopy|h[13:15:09]|h|r |cffaad372Wargrimz|r has gone offline.", -- [1]
		"|cffffff00|cff979797|Hpratcopy|h[13:15:21]|h|r |cffd8d8d8[|r|Hplayer:Macewindfury:1710|h|cffd8bc3f70|r:|cff0070ddMacewindfury|r|h|cffd8d8d8]|r has come online.", -- [2]
		"|cff979797|Hpratcopy|h[13:16:04]|h|r debug: |cFFFFFF00First Hit|r: Moonfire (DoT) from Chelyberrana-Stormrage", -- [3]
		"|cff979797|Hpratcopy|h[13:16:04]|h|r |cffffaeaeDetails!:|r |cFFFFFF00First Hit|r: Moonfire (DoT) from Chelyberrana-Stormrage |cFFFFBB00Boss First Target|r: Chelyberrana    ", -- [4]
		"|cffff4040|cff979797|Hpratcopy|h[13:16:05]|h|r Watcher Irideus yells: More trespassers? I will not allow you through!", -- [5]
		"|cffffff00|cff979797|Hpratcopy|h[13:16:19]|h|r |cff0070ddMacewindfury|r has gone offline.", -- [6]
		"|cffff4040|cff979797|Hpratcopy|h[13:16:30]|h|r Watcher Irideus yells: Order will overwhelm you.", -- [7]
		"|cffffdd00|cff979797|Hpratcopy|h[13:16:30]|h|r |TInterface\\ICONS\\Ability_ThunderKing_LightningWhip.blp:20|t Watcher Irideus begins casting |cFFFF0000|Hspell:389179|h[Power Overload]|h|r!", -- [8]
		"|cffff4040|cff979797|Hpratcopy|h[13:16:38]|h|r Watcher Irideus yells: I will not let you through!", -- [9]
		"|cffffdd00|cff979797|Hpratcopy|h[13:16:41]|h|r |TInterface\\ICONS\\Spell_Nature_LightningShield.blp:20|t Watcher Irideus erects an |cFFFF0000|Hspell:383840|h[Ablative Barrier]|h|r!", -- [10]
		"|cffff4040|cff979797|Hpratcopy|h[13:16:42]|h|r Watcher Irideus yells: My sacrifice will keep these halls safe!", -- [11]
		"|cffff4040|cff979797|Hpratcopy|h[13:17:01]|h|r Watcher Irideus yells: A small victory, I will eliminate you!", -- [12]
		"|cffffff00|cff979797|Hpratcopy|h[13:17:19]|h|r |cffd8d8d8[|r|Hplayer:Wargrimz:1719|h|cffd8bc3f70|r:|cffaad372Wargrimz|r|h|cffd8d8d8]|r has come online.", -- [13]
		"|cffff4040|cff979797|Hpratcopy|h[13:17:29]|h|r Watcher Irideus yells: Order will overwhelm you.", -- [14]
		"|cffffdd00|cff979797|Hpratcopy|h[13:17:29]|h|r |TInterface\\ICONS\\Ability_ThunderKing_LightningWhip.blp:20|t Watcher Irideus begins casting |cFFFF0000|Hspell:389179|h[Power Overload]|h|r!", -- [15]
		"|cffffffff|cff979797|Hpratcopy|h[13:17:29]|h|r [S] |cffd8d8d8[|r|Hplayer:Fjörgynn-Azralon:1722:SAY|h|cffd8bc3f70|r:|cff0070ddFjörgynn|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: Sobrecarga de Energia em |cffa5a5a5Fjörgynn|r!", -- [16]
		"|cffffffff|cff979797|Hpratcopy|h[13:17:32]|h|r [S] |cffd8d8d8[|r|Hplayer:Fjörgynn-Azralon:1723:SAY|h|cffd8bc3f70|r:|cff0070ddFjörgynn|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: 3", -- [17]
		"|cffffffff|cff979797|Hpratcopy|h[13:17:33]|h|r [S] |cffd8d8d8[|r|Hplayer:Fjörgynn-Azralon:1724:SAY|h|cffd8bc3f70|r:|cff0070ddFjörgynn|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: 2", -- [18]
		"|cffff4040|cff979797|Hpratcopy|h[13:17:37]|h|r Watcher Irideus yells: Tyr... Forgive me... I could not... stop... them...", -- [19]
		"|cffffff9f|cff979797|Hpratcopy|h[13:20:17]|h|r Squallbringer Cyraz says: The winds are always in my favor!", -- [20]
		"|cff979797|Hpratcopy|h[13:21:01]|h|r debug: |cFFFFFF00First Hit|r: Roiling Shadowflame from Îllest-EmeraldDream", -- [21]
		"|cff979797|Hpratcopy|h[13:21:01]|h|r |cffffaeaeDetails!:|r |cFFFFFF00First Hit|r: Roiling Shadowflame from Îllest-EmeraldDream |cFFFFBB00Boss First Target|r: Chelyberrana    ", -- [22]
		"|cffffdd00|cff979797|Hpratcopy|h[13:21:19]|h|r |TInterface\\ICONS\\Ability_Druid_FerociousBite.blp:20|t The Gulping Goliath begins to cast |cFFFF0000|Hspell:385551|h[Gulp]|h|r!", -- [23]
		"|cffffffff|cff979797|Hpratcopy|h[13:21:40]|h|r [S] |cffd8d8d8[|r|Hplayer:Fjörgynn-Azralon:1728:SAY|h|cffd8bc3f70|r:|cff0070ddFjörgynn|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: Batida de Barriga em |cffa5a5a5Fjörgynn|r!", -- [24]
		"|cffffdd00|cff979797|Hpratcopy|h[13:22:06]|h|r |TInterface\\ICONS\\Ability_Druid_FerociousBite.blp:20|t The Gulping Goliath begins to cast |cFFFF0000|Hspell:385551|h[Gulp]|h|r!", -- [25]
		"|cff979797|Hpratcopy|h[13:24:23]|h|r debug: |cFFFFFF00First Hit|r: Moonfire (DoT) from Chelyberrana-Stormrage", -- [26]
		"|cff979797|Hpratcopy|h[13:24:23]|h|r |cffffaeaeDetails!:|r |cFFFFFF00First Hit|r: Moonfire (DoT) from Chelyberrana-Stormrage |cFFFFBB00Boss First Target|r: Chelyberrana    ", -- [27]
		"|cffff4040|cff979797|Hpratcopy|h[13:24:23]|h|r Khajin the Unyielding yells: We'll build a new world free from their corruption!", -- [28]
		"|cffff4040|cff979797|Hpratcopy|h[13:24:33]|h|r Khajin the Unyielding yells: Let me show ya the power of the elements!", -- [29]
		"|cffffdd00|cff979797|Hpratcopy|h[13:24:43]|h|r |TInterface\\ICONS\\Spell_Frost_Ice Shards.blp:20|tKhajin the Unyielding begins to cast |cFFFF0000|Hspell:386757|h[Hailstorm]|h|r!", -- [30]
		"|cffff4040|cff979797|Hpratcopy|h[13:24:55]|h|r Khajin the Unyielding yells: Ya gonna catch ya death!", -- [31]
		"|cffff4040|cff979797|Hpratcopy|h[13:25:08]|h|r Khajin the Unyielding yells: Let me show ya the power of the elements!", -- [32]
		"|cffffdd00|cff979797|Hpratcopy|h[13:25:13]|h|r |TInterface\\ICONS\\Spell_Frost_Ice Shards.blp:20|tKhajin the Unyielding begins to cast |cFFFF0000|Hspell:386757|h[Hailstorm]|h|r!", -- [33]
		"|cffff4040|cff979797|Hpratcopy|h[13:25:25]|h|r Khajin the Unyielding yells: Ya gonna catch ya death!", -- [34]
		"|cffff4040|cff979797|Hpratcopy|h[13:25:39]|h|r Khajin the Unyielding yells: Nothing... can stop... us...", -- [35]
		"|cffff4040|cff979797|Hpratcopy|h[13:27:28]|h|r Infuser Sariya yells: Fools! Do you not see what that wretch Tyr has done?", -- [36]
		"|cffff4040|cff979797|Hpratcopy|h[13:27:56]|h|r Infuser Sariya yells: The elemental... will cleanse... the waters...", -- [37]
		"|cff979797|Hpratcopy|h[13:28:13]|h|r |cffffaeaeDetails!:|r |cFFFFBB00First Hit|r: *?* |cFFFFBB00Boss First Target|r: Chelyberrana    ", -- [38]
		"|cff979797|Hpratcopy|h[13:28:15]|h|r debug: |cFFFFFF00First Hit|r: Moonfire (DoT) from Chelyberrana-Stormrage", -- [39]
		"|cffffdd00|cff979797|Hpratcopy|h[13:29:04]|h|r |TInterface\\ICONS\\Creatureportrait_Bubble.blp:20|t The Primal Tsunami begins to |cFFFF0000|Hspell:388420|h[Cast Away]|h|r its enemies!", -- [40]
		"|cff979797|Hpratcopy|h[13:30:00]|h|r |cff33ff99<AngryKeystones>|r |cffffd700Beat the timer for +3 Halls of Infusion in 16:55.570. You were 4:04.430 ahead of the +3 timer.|r", -- [41]
		"|cff40ff40|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1741:GUILD|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16261:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Heroic: Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!", -- [42]
		"|cff40ff40|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1742:GUILD|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16262:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Mythic: Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!", -- [43]
		"|cff40ff40|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1743:GUILD|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16260:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!", -- [44]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1744:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16261:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Heroic: Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!", -- [45]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1745:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16262:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Mythic: Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!", -- [46]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1746:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16260:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!", -- [47]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Apoplectic-Alexstrasza:1747:ACHIEVEMENT|h|cffd8bc3f70|r:|cff8788eeApoplectic|r-|cffd25865Ale|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16262:Player-1070-0D8ADEBB:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Mythic: Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!", -- [48]
		"|cff40ff40|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1748:GUILD|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:11183:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Keystone Initiate]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!", -- [49]
		"|cff40ff40|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1749:GUILD|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:11184:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Keystone Challenger]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!", -- [50]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1750:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:11183:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Keystone Initiate]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!", -- [51]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1751:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:11184:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Keystone Challenger]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!", -- [52]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Chelyberrana-Stormrage:1752:ACHIEVEMENT|h|cffd8bc3f70|r:|cffff7c0aChelyberrana|r-|cffc4955eSto|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:17842:Player-60-0F2BFCA2:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Dragonflight Keystone Explorer: Season Two]|h|r |cffffffff(|rCompleted 5/10/23|cffffffff)|r!", -- [53]
		"|cff00aa00|cff979797|Hpratcopy|h[13:30:01]|h|r You receive currency: |cff0070dd|Hcurrency:2245:0|h[Flightstones]|h|rx42", -- [54]
		"|cff00aa00|cff979797|Hpratcopy|h[13:30:01]|h|r You receive currency: |cff0070dd|Hcurrency:2408:0|h[Bonus Flightstones]|h|rx25", -- [55]
		"|cff00aa00|cff979797|Hpratcopy|h[13:30:01]|h|r You receive item: |cff0070dd|Hitem:204075::::::::70:261:::::::::|h[Whelpling's Shadowflame Crest Fragment]|h|rx12", -- [56]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:04]|h|r Halls of Infusion (Level 5) completed in 16:55 (18 |4min:min; 5 |4sec:sec; left). This is a new Tyrannical record!", -- [57]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:04]|h|r Rating increased for |cffffd200Apoplectic|r, |cffffd200Fjörgynn|r, |cffffd200Chelyberrana|r, |cffffd200Gelosia|r, |cffffd200Îllest|r!", -- [58]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:04]|h|r Your Mythic+ Rating increased to |cffffffff90|r (+90). Keystone upgraded +3.", -- [59]
		"|cffaaaaff|cff979797|Hpratcopy|h[13:30:09]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Apoplectic-Alexstrasza:1756:PARTY|h|cffd8bc3f70|r:|cff8788eeApoplectic|r-|cffd25865Ale|r|h|cffd8d8d8]|r: Gee Gee Wee Pee", -- [60]
		"|cff00aa00|cff979797|Hpratcopy|h[13:30:09]|h|r |cffa5a5a5Fjörgynn|r-Azralon receives loot: |cffa335ee|Hitem:193736::::::::70:261::33:5:9315:6652:9144:1630:8767:1:28:1279:::::|h[Water's Beating Heart]|h|r.", -- [61]
		"|cff00aa00|cff979797|Hpratcopy|h[13:30:10]|h|r |cffa5a5a5Îllest|r-EmeraldDream receives loot: |cffa335ee|Hitem:204717::::::::70:261:::::::::|h[Splintered Spark of Shadowflame]|h|r.", -- [62]
		"|cff00aa00|cff979797|Hpratcopy|h[13:30:10]|h|r |cffa5a5a5Îllest|r-EmeraldDream receives loot: |cffa335ee|Hitem:180653::::::::70:261::::4:17:405:18:11:19:9:20:124:::::|h[Mythic Keystone]|h|r.", -- [63]
		"|cff00aa00|cff979797|Hpratcopy|h[13:30:11]|h|r You receive loot: |cffa335ee|Hitem:193743::::::::70:261::16:5:9315:6652:9144:1630:8767:1:28:1279:::::|h[Irideus Fragment]|h|r", -- [64]
		"|cff00aa00|cff979797|Hpratcopy|h[13:30:11]|h|r You receive loot: |cffa335ee|Hitem:180653::::::::70:261::::3:17:438:18:4:19:9:::::|h[Mythic Keystone]|h|r", -- [65]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:12]|h|r You loot 55 Gold, 34 Silver, 86 Copper", -- [66]
		"|cff40ff40|cff979797|Hpratcopy|h[13:30:12]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Wargrimz-Mal'Ganis:1763:GUILD|h|cffd8bc3f70|r:|cffaad372Wargrimz|r|h|cffd8d8d8]|r: gratz", -- [67]
		"|cffaaaaff|cff979797|Hpratcopy|h[13:30:14]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Chelyberrana-Stormrage:1764:PARTY|h|cffd8bc3f70|r:|cffff7c0aChelyberrana|r-|cffc4955eSto|r|h|cffd8d8d8]|r: WEE PEE?", -- [68]
		"|cff00aa00|cff979797|Hpratcopy|h[13:30:18]|h|r |cffa5a5a5Apoplectic|r-Alexstrasza receives loot: |cffffffff|Hitem:198038::::::::70:261:::::::::|h[Ancient Titansteel Ingot]|h|rx10.", -- [69]
		"|cff00aa00|cff979797|Hpratcopy|h[13:30:18]|h|r |cffa5a5a5Apoplectic|r-Alexstrasza receives loot: |cffa335ee|Hitem:204717::::::::70:261:::::::::|h[Splintered Spark of Shadowflame]|h|r.", -- [70]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:26]|h|r |cffa5a5a5Îllest|r-EmeraldDream leaves the party.", -- [71]
		"|cffaaaaff|cff979797|Hpratcopy|h[13:30:27]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Apoplectic-Alexstrasza:1768:PARTY|h|cffd8bc3f70|r:|cff8788eeApoplectic|r-|cffd25865Ale|r|h|cffd8d8d8]|r: Isn't that what we just killed?", -- [72]
		"|cff76c8ff|cff979797|Hpratcopy|h[13:30:28]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Fjörgynn-Azralon:1769:PARTY|h|cffd8bc3f70|r:|cff0070ddFjörgynn|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: ty all", -- [73]
		"|cffaaaaff|cff979797|Hpratcopy|h[13:30:29]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1770:PARTY|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r: ty all", -- [74]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:32]|h|r |cffa5a5a5Fjörgynn|r-Azralon leaves the party.", -- [75]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:32]|h|r |cffa5a5a5Apoplectic|r-Alexstrasza is now the group leader.", -- [76]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:37]|h|r |cffa5a5a5Apoplectic|r-Alexstrasza leaves the party.", -- [77]
		"|cffffff00|cff979797|Hpratcopy|h[13:30:37]|h|r |cffa5a5a5Chelyberrana|r-Stormrage is now the group leader.", -- [78]
		"|cffffff00|cff979797|Hpratcopy|h[13:31:09]|h|r Loot Specialization set to: Assassination", -- [79]
		"|cffc3e6e8|cff979797|Hpratcopy|h[13:31:10]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Valdrakken]|h", -- [80]
		"|cffe89e79|cff979797|Hpratcopy|h[13:31:10]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h", -- [81]
		"|cffe8e479|cff979797|Hpratcopy|h[13:31:10]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Valdrakken]|h", -- [82]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:10]|h|r |Hchannel:channel:5|h[5] |h Changed Channel: |Hchannel:CHANNEL:5|h[5. Trade (Services) - City]|h", -- [83]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:11]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Blanchiness-Mal'Ganis:1779:CHANNEL:5|h|cffc41e3aBlanchiness|r|h|cffd8d8d8]|r: [ZakRaider™] WTS FULL HEROIC |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  or ONLY Last Boss |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r || AotC || Trade gold in Raid || Free group loot", -- [84]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:12]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Yzexyponaly-Mal'Ganis:1780:CHANNEL:5|h|cffc69b6dYzexyponaly|r|h|cffd8d8d8]|r: [WТS] Mythic +10–20 & Dawn of the Infinite Megadungeon Сarry tonight! Get 415-447 ilvl gear, Immortal run, Armor Stack & Achieves hassle-free. EXPRESS Start in 30 minutes. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.", -- [85]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:13]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Safarooniee-Mal'Ganis:1781:CHANNEL:5|h|cffc41e3aSafarooniee|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00CHEAPEST IN MARKET|r|cffffffff>|r OFFERING 9/9 Heroic Full Clear NOW! |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff<|r|cff00ff00MAX DROPS|r|cffffffff>|r |cffffffff<|r|cff00ff00BEST GEARING OPTION|r|cffffffff>|r |cffffffff<|r|cff00ff00VIP Run Available|r|cffffffff>|r |cffffffff<|r|cff00ff00Cheapest|r|cffffffff>|r || |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r [PAYMENTS IN RAID FOR SAFETY] /w me for reserve your spot!", -- [86]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:13]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Gylfaginning-Mal'Ganis:1782:CHANNEL:5|h|cffff7c0aGylfaginning|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS [Aberrus, the Shadowed Crucible]   Heroic |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20 (Armor Stack, Specific Key for free, Discount Multiple Keys) ANY Key MEGA DUNGEON Armor Stack available All loot tradeable GOLD ONLY", -- [87]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:13]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Yarita-Mal'Ganis:1783:CHANNEL:5|h|cffc41e3aYarita|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:15|h[Aberrus, the Shadowed Crucible]|h|rHeroic |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key Mega Dungeon armor Stack available All loot tradeable", -- [88]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:17]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Kashisoo-Mal'Ganis:1784:CHANNEL:5|h|cffc41e3aKashisoo|r|h|cffd8d8d8]|r: WTS POWER LEVEL FAST AND CHEAP|||| FULL AFK CAN SUMMON 10-70,10-60,60-70 PST FOR INFO|| GOLD ONLY", -- [89]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:17]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Aksurip-Mal'Ganis:1785:CHANNEL:5|h|cffc41e3aAksurip|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  Heroic Full Run |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key MEGA DUNGEON armor Stack available All loot tradeable", -- [90]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:17]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Vraubankk-Mal'Ganis:1786:CHANNEL:5|h|cfffff468Vraubankk|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Bakers|r|cffffffff>|r are offering  |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280K|r|cffffffff>|r // Last Boss HC |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00110k|r|cffffffff>|r // Unsaved and Funnel // Payment Inside in the raid group for safety!! We price match everyone!!  /w to book!", -- [91]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:18]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Aromyvepi-Mal'Ganis:1787:CHANNEL:5|h|cffc69b6dAromyvepi|r|h|cffd8d8d8]|r: [WТS] Arena 3v3 & Solo Shuffle Carry! Get up to 2400 Arena Rating, 450 ilvl gear, Elite PvP Tmog, Gladiator & Legend titles hassle-free. EXPRESS boost: start tonight. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.", -- [92]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:18]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Edidiqurazy-Mal'Ganis:1788:CHANNEL:5|h|cffc69b6dEdidiqurazy|r|h|cffd8d8d8]|r: [WТS] Aberrus Heroic & Mythic Carry! Get 428–450 ilvl upgradable gear & AotC achieve. EXPRESS boost: runs start every hour. Saved, Unsaved & VIP Lootruns available. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.", -- [93]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:18]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Kashisoo-Mal'Ganis:1789:CHANNEL:5|h|cffc41e3aKashisoo|r|h|cffd8d8d8]|r: WTS POWER LEVEL FAST AND CHEAP|||| FULL AFK CAN SUMMON 10-70,10-60,60-70 PST FOR INFO|| GOLD ONLY", -- [94]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:20]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Crystalragé-Mal'Ganis:1791:CHANNEL:5|h|cffc41e3aCrystalragé|r|h|cffd8d8d8]|r: [Guildies] OFFERING HEROIC FULL CLEAR NOW! |cffffff00|Hachievement:18160:Player-3684-0E3848E2:0:0:0:-1:0:0:0:0|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r [9/9 Heroic Full Run] [LOWEST PRICE] [MAX DROPS] [BEST FOR GEARING] [VIP RUN AVAILABLE] & HC |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r [Price Match] [Payment Inside Raid] /w me for booking!", -- [95]
		"|cffffff9f|cff979797|Hpratcopy|h[13:31:21]|h|r Brigita says: Welcome to the Roasted Ram! Seating is open.", -- [96]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:21]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Yukinahara-Mal'Ganis:1794:CHANNEL:5|h|cfffff468Yukinahara|r|h|cffd8d8d8]|r: [ZakRaider™] |cffffffff<|r|cff00ff00WTS|r|cffffffff>|r FULL HEROIC RUN |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r // Last Boss only|cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r // AOTC // Group loot // Trade Gold inside Raid", -- [97]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:23]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Naysun-Mal'Ganis:1795:CHANNEL:5|h|cffc41e3aNaysun|r|h|cffd8d8d8]|r: >>WTS<< [+10]-[+24] - SpecificKeys - Portals (20 timed) - KSM/KSH - NewMega Dungeon - Get your weekly vault max level (447) - Special offers for multiples runs (x4/x8) - Free 2 Armor Stack for 4 or more Runs - DM For check prices <3", -- [98]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:25]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Annycatpaw-Mal'Ganis:1796:CHANNEL:5|h|cff00ff98Annycatpaw|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00WTS|r|cffffffff>|r LAST SPOT ~~HEROIC FULL RUN~~  |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r // Trade gold inside Raid", -- [99]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:25]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Rockingex-Mal'Ganis:1797:CHANNEL:5|h|cffaad372Rockingex|r|h|cffd8d8d8]|r: ////______WTS______\\\\\\\\  Mythic Dungeon 10-23 ____ Timed / KSM / KSH ___Armor stack_____|cff66bbff|Hjournal:0:1209:8|h[Dawn of the Infinite]|h|r   ____Leveling 1-70 ///  GOLD ONLY _______<3", -- [100]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:27]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Hoovies-Mal'Ganis:1798:CHANNEL:5|h|cffff7c0aHoovies|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r >WTS |cffffff00|Hachievement:18160:Player-3684-0E3848E2:0:0:0:-1:0:0:0:0|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r 9/9 HEROIC |cffffffff<|r|cff00ff00280k|r|cffffffff>|r & Heroic |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r - Trade INSIDE raid for safety, also offering **UNSAVED** runs /w now for more info!", -- [101]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:28]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Safarooniee-Mal'Ganis:1799:CHANNEL:5|h|cffc41e3aSafarooniee|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00CHEAPEST IN MARKET|r|cffffffff>|r OFFERING 9/9 Heroic Full Clear NOW! |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff<|r|cff00ff00MAX DROPS|r|cffffffff>|r |cffffffff<|r|cff00ff00BEST GEARING OPTION|r|cffffffff>|r |cffffffff<|r|cff00ff00VIP Run Available|r|cffffffff>|r |cffffffff<|r|cff00ff00Cheapest|r|cffffffff>|r || |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r [PAYMENTS IN RAID FOR SAFETY] /w me for reserve your spot!", -- [102]
		"|cffffff00|cff979797|Hpratcopy|h[13:31:29]|h|r Gooeyzugzug has defeated Minivoker in a duel", -- [103]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:29]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Prinsa-Mal'Ganis:1801:CHANNEL:5|h|cffc41e3aPrinsa|r|h|cffd8d8d8]|r: OFFERING |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280K|r|cffffffff>|r // |cffffffff<|r|cff00ff00NORMAL 100K|r|cffffffff>|r |cffffffff<|r|cff00ff00HC&NORM 340K|r|cffffffff>|r, ECHO |cffffffff<|r|cff00ff0060K|r|cffffffff>|r HC  Sarkareth |cffffffff<|r|cff00ff00110K|r|cffffffff>|r BOTH |cffffffff<|r|cff00ff00150K|r|cffffffff>|r// Payment Inside in the raid group for safety!! /w to book!", -- [104]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:29]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Yzexyponaly-Mal'Ganis:1802:CHANNEL:5|h|cffc69b6dYzexyponaly|r|h|cffd8d8d8]|r: [WТS] Arena 3v3 & Solo Shuffle Carry! Get up to 2400 Arena Rating, 450 ilvl gear, Elite PvP Tmog, Gladiator & Legend titles hassle-free. EXPRESS boost: start tonight. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.", -- [105]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:30]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Yarita-Mal'Ganis:1803:CHANNEL:5|h|cffc41e3aYarita|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:15|h[Aberrus, the Shadowed Crucible]|h|rHeroic |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key Mega Dungeon armor Stack available All loot tradeable", -- [106]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:32]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Gylfaginning-Mal'Ganis:1804:CHANNEL:5|h|cffff7c0aGylfaginning|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS [Aberrus, the Shadowed Crucible]   Heroic |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20 (Armor Stack, Specific Key for free, Discount Multiple Keys) ANY Key MEGA DUNGEON Armor Stack available All loot tradeable GOLD ONLY", -- [107]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:34]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Aksurip-Mal'Ganis:1807:CHANNEL:5|h|cffc41e3aAksurip|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  Heroic Full Run |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key MEGA DUNGEON armor Stack available All loot tradeable", -- [108]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:34]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Vraubankk-Mal'Ganis:1808:CHANNEL:5|h|cfffff468Vraubankk|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Bakers|r|cffffffff>|r are offering  |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280K|r|cffffffff>|r // Last Boss HC |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00110k|r|cffffffff>|r // Unsaved and Funnel // Payment Inside in the raid group for safety!! We price match everyone!!  /w to book!", -- [109]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:35]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Nemna-Mal'Ganis:1809:CHANNEL:5|h|cffc69b6dNemna|r|h|cffd8d8d8]|r: --WTS--  Mythic +16 +20 +22 +24 +25 Anylvl  //  Armor stack  //  Specific key  //  Items Tradeables And Specific  // THE BEST PRICES AND OFFERS // New Dungeon And Mythic Raid.- Full Run 9/9M /PvP bost Whisp Me For More info.", -- [110]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:35]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Aromyvepi-Mal'Ganis:1810:CHANNEL:5|h|cffc69b6dAromyvepi|r|h|cffd8d8d8]|r: [WТS] Powerleveling Services! 10-70 Selfplayed Leveling, Mage Tower, Dragon Glyphs, Flightstones & Shadowflame Crests hassle-free. EXPRESS boost: start in 1 hour. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.", -- [111]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:35]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Crystalragé-Mal'Ganis:1811:CHANNEL:5|h|cffc41e3aCrystalragé|r|h|cffd8d8d8]|r: [Guildies] OFFERING HEROIC FULL CLEAR NOW! |cffffff00|Hachievement:18160:Player-3684-0E3848E2:0:0:0:-1:0:0:0:0|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r [9/9 Heroic Full Run] [LOWEST PRICE] [MAX DROPS] [BEST FOR GEARING] [VIP RUN AVAILABLE] & HC |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r [Price Match] [Payment Inside Raid] /w me for booking!", -- [112]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:36]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Edidiqurazy-Mal'Ganis:1812:CHANNEL:5|h|cffc69b6dEdidiqurazy|r|h|cffd8d8d8]|r: [WТS] Mythic +10–20 & Dawn of the Infinite Megadungeon Сarry tonight! Get 415-447 ilvl gear, Immortal run, Armor Stack & Achieves hassle-free. EXPRESS Start in 30 minutes. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.", -- [113]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:37]|h|r |Hchannel:channel:5|h[5] |h<Busy>|cffd8d8d8[|r|Hplayer:Cogalvanya-Mal'Ganis:1813:CHANNEL:5|h|cffc69b6dCogalvanya|r|h|cffd8d8d8]|r: >>>SELL CHEAPEST|cffffffff<|r|cff00ff00<< We have a [Price Match]and !!!-20%!!! from any competitor ABERRUS|cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r]9/9 [HEROIC VIP LOOT] |r|cffffffff>|r>>MAX DROP<<<, EXPRESS Last BOSS, raids every 1 HOUR, Whisper me for!!!", -- [114]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:43]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Safarooniee-Mal'Ganis:1814:CHANNEL:5|h|cffc41e3aSafarooniee|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00CHEAPEST IN MARKET|r|cffffffff>|r OFFERING 9/9 Heroic Full Clear NOW! |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff<|r|cff00ff00MAX DROPS|r|cffffffff>|r |cffffffff<|r|cff00ff00BEST GEARING OPTION|r|cffffffff>|r |cffffffff<|r|cff00ff00VIP Run Available|r|cffffffff>|r |cffffffff<|r|cff00ff00Cheapest|r|cffffffff>|r || |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r [PAYMENTS IN RAID FOR SAFETY] /w me for reserve your spot!", -- [115]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:45]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Blanchiness-Mal'Ganis:1815:CHANNEL:5|h|cffc41e3aBlanchiness|r|h|cffd8d8d8]|r: [ZakRaider™] WTS FULL HEROIC |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  or ONLY Last Boss |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r || AotC || Trade gold in Raid || Free group loot", -- [116]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:47]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Yzexyponaly-Mal'Ganis:1816:CHANNEL:5|h|cffc69b6dYzexyponaly|r|h|cffd8d8d8]|r: [WТS] Powerleveling Services! 10-70 Selfplayed Leveling, Mage Tower, Dragon Glyphs, Flightstones & Shadowflame Crests hassle-free. EXPRESS boost: start in 1 hour. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.", -- [117]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:48]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Gylfaginning-Mal'Ganis:1817:CHANNEL:5|h|cffff7c0aGylfaginning|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS [Aberrus, the Shadowed Crucible]   Heroic |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20 (Armor Stack, Specific Key for free, Discount Multiple Keys) ANY Key MEGA DUNGEON Armor Stack available All loot tradeable GOLD ONLY", -- [118]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:49]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Prinsa-Mal'Ganis:1818:CHANNEL:5|h|cffc41e3aPrinsa|r|h|cffd8d8d8]|r: OFFERING |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280K|r|cffffffff>|r // |cffffffff<|r|cff00ff00NORMAL 100K|r|cffffffff>|r |cffffffff<|r|cff00ff00HC&NORM 340K|r|cffffffff>|r, ECHO |cffffffff<|r|cff00ff0060K|r|cffffffff>|r HC  Sarkareth |cffffffff<|r|cff00ff00110K|r|cffffffff>|r BOTH |cffffffff<|r|cff00ff00150K|r|cffffffff>|r// Payment Inside in the raid group for safety!! /w to book!", -- [119]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:49]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Yarita-Mal'Ganis:1819:CHANNEL:5|h|cffc41e3aYarita|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:15|h[Aberrus, the Shadowed Crucible]|h|rHeroic |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key Mega Dungeon armor Stack available All loot tradeable", -- [120]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:50]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Aksurip-Mal'Ganis:1820:CHANNEL:5|h|cffc41e3aAksurip|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  Heroic Full Run |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key MEGA DUNGEON armor Stack available All loot tradeable", -- [121]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:50]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Yukinahara-Mal'Ganis:1821:CHANNEL:5|h|cfffff468Yukinahara|r|h|cffd8d8d8]|r: [ZakRaider™] |cffffffff<|r|cff00ff00WTS|r|cffffffff>|r FULL HEROIC RUN |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r // Last Boss only|cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r // AOTC // Group loot // Trade Gold inside Raid", -- [122]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:50]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Crystalragé-Mal'Ganis:1822:CHANNEL:5|h|cffc41e3aCrystalragé|r|h|cffd8d8d8]|r: [Guildies] OFFERING HEROIC FULL CLEAR NOW! |cffffff00|Hachievement:18160:Player-3684-0E3848E2:0:0:0:-1:0:0:0:0|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r [9/9 Heroic Full Run] [LOWEST PRICE] [MAX DROPS] [BEST FOR GEARING] [VIP RUN AVAILABLE] & HC |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r [Price Match] [Payment Inside Raid] /w me for booking!", -- [123]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:51]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Vraubankk-Mal'Ganis:1823:CHANNEL:5|h|cfffff468Vraubankk|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Bakers|r|cffffffff>|r are offering  |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280K|r|cffffffff>|r // Last Boss HC |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00110k|r|cffffffff>|r // Unsaved and Funnel // Payment Inside in the raid group for safety!! We price match everyone!!  /w to book!", -- [124]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:52]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Aromyvepi-Mal'Ganis:1824:CHANNEL:5|h|cffc69b6dAromyvepi|r|h|cffd8d8d8]|r: [WТS] Aberrus Heroic & Mythic Carry! Get 428–450 ilvl upgradable gear & AotC achieve. EXPRESS boost: runs start every hour. Saved, Unsaved & VIP Lootruns available. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.", -- [125]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:53]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Edidiqurazy-Mal'Ganis:1825:CHANNEL:5|h|cffc69b6dEdidiqurazy|r|h|cffd8d8d8]|r: [WТS] Arena 3v3 & Solo Shuffle Carry! Get up to 2400 Arena Rating, 450 ilvl gear, Elite PvP Tmog, Gladiator & Legend titles hassle-free. EXPRESS boost: start tonight. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.", -- [126]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:53]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Annycatpaw-Mal'Ganis:1826:CHANNEL:5|h|cff00ff98Annycatpaw|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00WTS|r|cffffffff>|r LAST SPOT ~~HEROIC FULL RUN~~  |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r // Trade gold inside Raid", -- [127]
		"|cffffc0c0|cff979797|Hpratcopy|h[13:31:56]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Hoovies-Mal'Ganis:1827:CHANNEL:5|h|cffff7c0aHoovies|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r >WTS |cffffff00|Hachievement:18160:Player-3684-0E3848E2:0:0:0:-1:0:0:0:0|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r 9/9 HEROIC |cffffffff<|r|cff00ff00280k|r|cffffffff>|r & Heroic |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r - Trade INSIDE raid for safety, also offering **UNSAVED** runs /w now for more info!", -- [128]
	},
	["MuteLunarwing"] = "Off",
	["TipModEnable"] = "On",
	["NoPetDuels"] = "On",
	["MuteEvents"] = "Off",
	["ShowPlayerChain"] = "Off",
	["MuteVigor"] = "Off",
	["TransAqir"] = "Off",
	["MuteReady"] = "Off",
	["MuteDragonriding"] = "Off",
	["ChatHistoryName"] = "Gelosia-Mal'Ganis",
	["UnclampMinimap"] = "Off",
	["ChatHistory6Count"] = 128,
	["MuteFurlines"] = "Off",
	["TransAtomic"] = "Off",
	["HideTalkingFrame"] = "Off",
	["ShowReadyTimer"] = "On",
	["AutomateGossip"] = "Off",
	["UnivGroupColor"] = "Off",
	["TipBackSimple"] = "Off",
	["MinimapA"] = "TOPRIGHT",
	["WidgetTopX"] = 0,
	["AutoQuestKeyMenu"] = 1,
	["LeaPlusTipSize"] = 1,
	["WidgetTopA"] = "TOP",
	["BlockSpellLinks"] = "Off",
	["ChatHistory1Count"] = 128,
	["RecentChatWindow"] = "Off",
	["hide"] = false,
	["HideKeybindText"] = "Off",
	["NoTransforms"] = "Off",
	["MainPanelY"] = 49.23074340820313,
	["AutoReleaseNoAlterac"] = "Off",
	["ShowCooldownID"] = "On",
	["NoHitIndicators"] = "Off",
	["MuteAerials"] = "Off",
	["EasyItemDestroy"] = "On",
	["MuteSoulseekers"] = "Off",
	["MuteFizzle"] = "Off",
	["FriendlyGuild"] = "On",
	["BordersBottom"] = 0,
	["MuteBikes"] = "Off",
	["TransLantern"] = "Off",
	["LeaPlusFasterLootDelay"] = 0.3,
	["MuteHovercraft"] = "Off",
}
