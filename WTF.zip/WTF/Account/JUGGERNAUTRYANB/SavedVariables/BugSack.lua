
BugSackDB = {
	["soundMedia"] = "BugSack: Fatality",
	["altwipe"] = false,
	["useMaster"] = false,
	["fontSize"] = "GameFontHighlight",
	["mute"] = true,
	["auto"] = false,
	["chatframe"] = false,
}
BugSackLDBIconDB = {
	["minimapPos"] = 106.5482745756032,
}
