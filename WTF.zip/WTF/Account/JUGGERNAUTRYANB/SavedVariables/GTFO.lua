
GTFOData = {
	["Active"] = true,
	["IgnoreSpellList"] = {
	},
	["TrivialDamagePercent"] = 2,
	["SoundChannel"] = "Master",
	["Sounds"] = {
		true, -- [1]
		true, -- [2]
		true, -- [3]
		true, -- [4]
	},
	["DataCode"] = "4",
	["Volume"] = 3,
	["IgnoreOptions"] = {
		["EyeOfCorruption2"] = true,
	},
	["SoundOverrides"] = {
		"", -- [1]
		"", -- [2]
		"", -- [3]
		"", -- [4]
	},
}
