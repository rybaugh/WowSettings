
Postal3DB = {
	["profileKeys"] = {
		["Janwa - Mal'Ganis"] = "Janwa - Mal'Ganis",
		["Gelosia - Mal'Ganis"] = "Gelosia - Mal'Ganis",
		["Ryanmage - Mal'Ganis"] = "Ryanmage - Mal'Ganis",
		["Allaeda - Mal'Ganis"] = "Allaeda - Mal'Ganis",
		["Stormart - Mal'Ganis"] = "Stormart - Mal'Ganis",
		["Skelay - Mal'Ganis"] = "Skelay - Mal'Ganis",
		["Elyyine - Mal'Ganis"] = "Elyyine - Mal'Ganis",
	},
	["global"] = {
		["BlackBook"] = {
			["alts"] = {
				"Allaeda|Mal'Ganis|Horde|70|DEMONHUNTER", -- [1]
				"Elyyine|Mal'Ganis|Alliance|70|DRUID", -- [2]
				"Gelosia|Mal'Ganis|Horde|70|ROGUE", -- [3]
				"Janwa|Mal'Ganis|Horde|70|HUNTER", -- [4]
				"Ryanmage|Mal'Ganis|Horde|70|MAGE", -- [5]
				"Skelay|Mal'Ganis|Horde|70|DEATHKNIGHT", -- [6]
				"Stormart|Mal'Ganis|Alliance|70|SHAMAN", -- [7]
			},
		},
	},
	["profiles"] = {
		["Janwa - Mal'Ganis"] = {
		},
		["Gelosia - Mal'Ganis"] = {
		},
		["Ryanmage - Mal'Ganis"] = {
		},
		["Allaeda - Mal'Ganis"] = {
		},
		["Stormart - Mal'Ganis"] = {
		},
		["Skelay - Mal'Ganis"] = {
			["BlackBook"] = {
				["recent"] = {
					"Allaeda|Mal'Ganis|Horde", -- [1]
				},
			},
		},
		["Elyyine - Mal'Ganis"] = {
		},
	},
}
