
Bagnon_Sets = {
	["tackleColor"] = {
	},
	["fridgeColor"] = {
	},
	["engineerColor"] = {
	},
	["herbColor"] = {
	},
	["inscribeColor"] = {
	},
	["soulColor"] = {
	},
	["quiverColor"] = {
	},
	["reagentColor"] = {
	},
	["gemColor"] = {
	},
	["enchantColor"] = {
	},
	["keyColor"] = {
	},
	["normalColor"] = {
	},
	["profiles"] = {
	},
	["mineColor"] = {
	},
	["version"] = "10.1.12",
	["display"] = {
	},
	["global"] = {
		["inventory"] = {
			["y"] = 100,
			["rules"] = {
				"all", -- [1]
				"all/normal", -- [2]
				"all/trade", -- [3]
				"all/reagent", -- [4]
				"all/keys", -- [5]
				"all/quiver", -- [6]
				"equip", -- [7]
				"equip/armor", -- [8]
				"equip/weapon", -- [9]
				"equip/trinket", -- [10]
				"use", -- [11]
				"use/consume", -- [12]
				"use/enhance", -- [13]
				"trade", -- [14]
				"trade/goods", -- [15]
				"trade/gem", -- [16]
				"trade/glyph", -- [17]
				"trade/recipe", -- [18]
				"quest", -- [19]
				"misc", -- [20]
			},
			["point"] = "BOTTOMRIGHT",
			["hiddenBags"] = {
			},
			["color"] = {
			},
			["x"] = -50.000244140625,
			["hiddenRules"] = {
			},
			["borderColor"] = {
			},
		},
		["vault"] = {
			["rules"] = {
				"all", -- [1]
				"all/normal", -- [2]
				"all/trade", -- [3]
				"all/reagent", -- [4]
				"all/keys", -- [5]
				"all/quiver", -- [6]
				"equip", -- [7]
				"equip/armor", -- [8]
				"equip/weapon", -- [9]
				"equip/trinket", -- [10]
				"use", -- [11]
				"use/consume", -- [12]
				"use/enhance", -- [13]
				"trade", -- [14]
				"trade/goods", -- [15]
				"trade/gem", -- [16]
				"trade/glyph", -- [17]
				"trade/recipe", -- [18]
				"quest", -- [19]
				"misc", -- [20]
			},
			["hiddenBags"] = {
			},
			["color"] = {
			},
			["hiddenRules"] = {
			},
			["borderColor"] = {
			},
		},
		["guild"] = {
			["rules"] = {
				"all", -- [1]
				"all/normal", -- [2]
				"all/trade", -- [3]
				"all/reagent", -- [4]
				"all/keys", -- [5]
				"all/quiver", -- [6]
				"equip", -- [7]
				"equip/armor", -- [8]
				"equip/weapon", -- [9]
				"equip/trinket", -- [10]
				"use", -- [11]
				"use/consume", -- [12]
				"use/enhance", -- [13]
				"trade", -- [14]
				"trade/goods", -- [15]
				"trade/gem", -- [16]
				"trade/glyph", -- [17]
				"trade/recipe", -- [18]
				"quest", -- [19]
				"misc", -- [20]
			},
			["borderColor"] = {
			},
			["color"] = {
			},
			["hiddenRules"] = {
			},
			["hiddenBags"] = {
			},
		},
		["bank"] = {
			["rules"] = {
				"all", -- [1]
				"all/normal", -- [2]
				"all/trade", -- [3]
				"all/reagent", -- [4]
				"all/keys", -- [5]
				"all/quiver", -- [6]
				"equip", -- [7]
				"equip/armor", -- [8]
				"equip/weapon", -- [9]
				"equip/trinket", -- [10]
				"use", -- [11]
				"use/consume", -- [12]
				"use/enhance", -- [13]
				"trade", -- [14]
				"trade/goods", -- [15]
				"trade/gem", -- [16]
				"trade/glyph", -- [17]
				"trade/recipe", -- [18]
				"quest", -- [19]
				"misc", -- [20]
			},
			["point"] = "BOTTOMLEFT",
			["hiddenBags"] = {
			},
			["color"] = {
			},
			["hiddenRules"] = {
			},
			["y"] = 113.7691497802734,
			["x"] = 95.00001525878906,
			["borderColor"] = {
			},
			["showBags"] = true,
		},
	},
	["leatherColor"] = {
	},
}
