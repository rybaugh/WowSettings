
Prat3CharDB = {
	["history"] = {
		["cmdhistory"] = {
			["ChatFrame10EditBox"] = {
			},
			["ChatFrame7EditBox"] = {
			},
			["ChatFrame5EditBox"] = {
			},
			["ChatFrame8EditBox"] = {
			},
			["ChatFrame4EditBox"] = {
			},
			["ChatFrame6EditBox"] = {
			},
			["ChatFrame9EditBox"] = {
			},
			["ChatFrame2EditBox"] = {
			},
			["ChatFrame3EditBox"] = {
			},
			["ChatFrame1EditBox"] = {
			},
		},
	},
}
Prat3HighCPUPerCharDB = {
	["scrollback"] = {
		["ChatFrame5"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 6,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[08:19:45]|h|r Total time played: 117 |4day:days;, 18 |4hour:hours;, 23 |4minute:minutes;, 9 |4second:seconds;",
					["serverTime"] = 1695914349,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 126668.9,
					["g"] = 1,
					["b"] = 0,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:19:45]|h|r Time played this level: 22 |4day:days;, 10 |4hour:hours;, 36 |4minute:minutes;, 50 |4second:seconds;",
					["serverTime"] = 1695914349,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 126668.9,
					["g"] = 1,
					["b"] = 0,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:20:15]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq25|k:36:1233:BN_WHISPER:|Kq25|k:Budsmokr#1645|h|A:UI-ChatIcon-WoW:0:0:0:0|a|cff0070dd|Kq25|k|r|h|cffd8d8d8]|r: get that made?",
					["serverTime"] = 1695914379,
					["r"] = 0,
					["extraData"] = {
						53, -- [1]
						false, -- [2]
						3, -- [3]
						4, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 126699.22,
					["g"] = 1,
					["b"] = 0.9647059440612793,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:20:25]|h|r [W From] |cffd8d8d8[|r|HBNplayer:|Kq25|k:36:1234:BN_WHISPER:|Kq25|k:Budsmokr#1645|h|A:UI-ChatIcon-WoW:0:0:0:0|a|cff0070dd|Kq25|k|r|h|cffd8d8d8]|r: yeah",
					["serverTime"] = 1695914389,
					["r"] = 0,
					["extraData"] = {
						52, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 126709.247,
					["g"] = 1,
					["b"] = 0.9647059440612793,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:25:38]|h|r You are now Away: AFK",
					["serverTime"] = 1695914702,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 127021.973,
					["g"] = 1,
					["b"] = 0,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:45:28]|h|r You are no longer Away.",
					["serverTime"] = 1695915892,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 128212.488,
					["g"] = 1,
					["b"] = 0,
				}, -- [6]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame4"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 6,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[08:19:45]|h|r Total time played: 117 |4day:days;, 18 |4hour:hours;, 23 |4minute:minutes;, 9 |4second:seconds;",
					["serverTime"] = 1695914349,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 126668.9,
					["g"] = 1,
					["b"] = 0,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:19:45]|h|r Time played this level: 22 |4day:days;, 10 |4hour:hours;, 36 |4minute:minutes;, 50 |4second:seconds;",
					["serverTime"] = 1695914349,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 126668.9,
					["g"] = 1,
					["b"] = 0,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:20:15]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq25|k:36:1233:BN_WHISPER:|Kq25|k:Budsmokr#1645|h|A:UI-ChatIcon-WoW:0:0:0:0|a|cff0070dd|Kq25|k|r|h|cffd8d8d8]|r: get that made?",
					["serverTime"] = 1695914379,
					["r"] = 0,
					["extraData"] = {
						53, -- [1]
						false, -- [2]
						3, -- [3]
						4, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 126699.22,
					["g"] = 1,
					["b"] = 0.9647059440612793,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:20:25]|h|r [W From] |cffd8d8d8[|r|HBNplayer:|Kq25|k:36:1234:BN_WHISPER:|Kq25|k:Budsmokr#1645|h|A:UI-ChatIcon-WoW:0:0:0:0|a|cff0070dd|Kq25|k|r|h|cffd8d8d8]|r: yeah",
					["serverTime"] = 1695914389,
					["r"] = 0,
					["extraData"] = {
						52, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 126709.247,
					["g"] = 1,
					["b"] = 0.9647059440612793,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:25:38]|h|r You are now Away: AFK",
					["serverTime"] = 1695914702,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 127021.973,
					["g"] = 1,
					["b"] = 0,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:45:28]|h|r You are no longer Away.",
					["serverTime"] = 1695915892,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 128212.488,
					["g"] = 1,
					["b"] = 0,
				}, -- [6]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame3"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 4,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["serverTime"] = 1695914343,
					["r"] = 1,
					["b"] = 0,
					["timestamp"] = 126662.327,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [1]
				{
					["message"] = "0 |4day:days;, 0 |4hour:hours;, 0 |4minute:minutes;, 0 |4second:seconds;",
					["timestamp"] = 126662.327,
				}, -- [2]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 126662.327,
				}, -- [3]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 126637.73,
					["g"] = 1,
					["b"] = 0,
				}, -- [4]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame7"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame6"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 6,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[08:19:45]|h|r Total time played: 117 |4day:days;, 18 |4hour:hours;, 23 |4minute:minutes;, 9 |4second:seconds;",
					["serverTime"] = 1695914349,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 126668.9,
					["g"] = 1,
					["b"] = 0,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:19:45]|h|r Time played this level: 22 |4day:days;, 10 |4hour:hours;, 36 |4minute:minutes;, 50 |4second:seconds;",
					["serverTime"] = 1695914349,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 126668.9,
					["g"] = 1,
					["b"] = 0,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:20:15]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq25|k:36:1233:BN_WHISPER:|Kq25|k:Budsmokr#1645|h|A:UI-ChatIcon-WoW:0:0:0:0|a|cff0070dd|Kq25|k|r|h|cffd8d8d8]|r: get that made?",
					["serverTime"] = 1695914379,
					["r"] = 0,
					["extraData"] = {
						53, -- [1]
						false, -- [2]
						3, -- [3]
						4, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 126699.22,
					["g"] = 1,
					["b"] = 0.9647059440612793,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:20:25]|h|r [W From] |cffd8d8d8[|r|HBNplayer:|Kq25|k:36:1234:BN_WHISPER:|Kq25|k:Budsmokr#1645|h|A:UI-ChatIcon-WoW:0:0:0:0|a|cff0070dd|Kq25|k|r|h|cffd8d8d8]|r: yeah",
					["serverTime"] = 1695914389,
					["r"] = 0,
					["extraData"] = {
						52, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 126709.247,
					["g"] = 1,
					["b"] = 0.9647059440612793,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:25:38]|h|r You are now Away: AFK",
					["serverTime"] = 1695914702,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 127021.973,
					["g"] = 1,
					["b"] = 0,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:45:28]|h|r You are no longer Away.",
					["serverTime"] = 1695915892,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 128212.488,
					["g"] = 1,
					["b"] = 0,
				}, -- [6]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame8"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame10"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame9"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame1"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 33,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[08:19:39]|h|r |cff33ff99Decursive|r: Decursive 2.7.10 by John Wellesz",
					["timestamp"] = 126662.327,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:19:39]|h|r |cff33ff99Decursive|r: |cff4c7fff |cff4c7fff Decursive is now initialized, remember to check the options (/decursive) |r",
					["timestamp"] = 126662.327,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:19:39]|h|r |cffFFFFFFRaiderIO|r is using expired data. Please update now to see the most accurate data: |cffFFFFFFhttps://rio.gg/addon|r",
					["r"] = 1,
					["serverTime"] = 1695914343,
					["timestamp"] = 126662.327,
					["g"] = 1,
					["b"] = 0,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:19:43]|h|r Loot Specialization set to: Enhancement",
					["serverTime"] = 1695914347,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 126662.327,
					["g"] = 1,
					["b"] = 0,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:19:43]|h|r |cffffd700Titan Panel|r|cff19ff19 7.01.03.100107|r|cffffd700|cffffd700 by the |cffff8c00Titan Panel Development Team|r|cff19ff19|r",
					["timestamp"] = 126662.327,
					["serverTime"] = 1695914347,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:19:43]|h|r |cffffd700Titan: |r|cFFFFFF00Warning: |r|cff19ff19 Feature : Opening Bag Disabled Until taint is fixed or work around found.|r",
					["timestamp"] = 126662.327,
					["serverTime"] = 1695914347,
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:19:45]|h|r Total time played: 117 |4day:days;, 18 |4hour:hours;, 23 |4minute:minutes;, 9 |4second:seconds;",
					["serverTime"] = 1695914349,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 126668.9,
					["g"] = 1,
					["b"] = 0,
				}, -- [7]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:19:45]|h|r Time played this level: 22 |4day:days;, 10 |4hour:hours;, 36 |4minute:minutes;, 50 |4second:seconds;",
					["serverTime"] = 1695914349,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 126668.9,
					["g"] = 1,
					["b"] = 0,
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:19:46]|h|r |cffffff00Time played this class (Dragonflight): 0 days 6 hours 29 minutes (/details playedclass)",
					["timestamp"] = 126670.337,
					["serverTime"] = 1695914350,
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:19:46]|h|r |cffffff00Time played this class (Dragonflight): 0 days 6 hours 29 minutes (/details playedclass)",
					["timestamp"] = 126670.337,
					["serverTime"] = 1695914350,
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:19:46]|h|r |cffffff00Time played this class (Dragonflight): 0 days 6 hours 29 minutes (/details playedclass)",
					["timestamp"] = 126670.337,
					["serverTime"] = 1695914350,
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:19:46]|h|r |cffffff00Time played this class (Dragonflight): 0 days 6 hours 29 minutes (/details playedclass)",
					["timestamp"] = 126670.337,
					["serverTime"] = 1695914350,
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:19:52]|h|r Cousin Slowhands says: Maybe you could roll a barrel.",
					["serverTime"] = 1695914356,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 126675.895,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:19:53]|h|r Mystic Birdhat says: It is not my intention to initiate legislation against you.",
					["serverTime"] = 1695914357,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 126677.211,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:19:58]|h|r Trading Post Barker says: Hey friend! Come check out our new items in the Trading Post. We just got a new shipment!",
					["serverTime"] = 1695914362,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 126681.978,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:20:15]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq25|k:36:1233:BN_WHISPER:|Kq25|k:Budsmokr#1645|h|A:UI-ChatIcon-WoW:0:0:0:0|a|cff0070dd|Kq25|k|r|h|cffd8d8d8]|r: get that made?",
					["serverTime"] = 1695914379,
					["r"] = 0,
					["extraData"] = {
						53, -- [1]
						false, -- [2]
						3, -- [3]
						4, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 126699.22,
					["g"] = 1,
					["b"] = 0.9647059440612793,
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:20:25]|h|r [W From] |cffd8d8d8[|r|HBNplayer:|Kq25|k:36:1234:BN_WHISPER:|Kq25|k:Budsmokr#1645|h|A:UI-ChatIcon-WoW:0:0:0:0|a|cff0070dd|Kq25|k|r|h|cffd8d8d8]|r: yeah",
					["serverTime"] = 1695914389,
					["r"] = 0,
					["extraData"] = {
						52, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 126709.247,
					["g"] = 1,
					["b"] = 0.9647059440612793,
				}, -- [17]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:25:38]|h|r You are now Away: AFK",
					["serverTime"] = 1695914702,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 127021.973,
					["g"] = 1,
					["b"] = 0,
				}, -- [18]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:26:01]|h|r |TInterface\\FriendsFrame\\UI-Toast-ToastIcons.tga:16:16:0:0:128:64:2:29:34:61|t|HBNplayer:|Kq65|k:7:1288:BN_INLINE_TOAST_ALERT:0|h[|Kq65|k] (|T-2:10:10:0:0:32:32:0:32:0:32|t Xprt)|h has come online.",
					["serverTime"] = 1695914725,
					["r"] = 0.5098039507865906,
					["extraData"] = {
						54, -- [1]
						false, -- [2]
						8, -- [3]
						9, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 127044.977,
					["g"] = 0.7725490927696228,
					["b"] = 1,
				}, -- [19]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:27:47]|h|r Apprentice Caretaker Zefren says: Hello, I was wondering if I would be able to get some building materials sent to a tower in the Waking Shores?",
					["serverTime"] = 1695914831,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 127151.442,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [20]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:27:54]|h|r Apprentice Caretaker Zefren says: Oh and it needs to be very high grade!",
					["serverTime"] = 1695914838,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 127157.617,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [21]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:28:00]|h|r Apprentice Caretaker Zefren says: My goodness, I forgot my gold, I am so sorry! I'll be back later!",
					["serverTime"] = 1695914844,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 127164.504,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [22]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:28:28]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Lovemydruid-Mal'Ganis:1293:CHANNEL:2|h|cffff7c0aLovemydruid|r|h|cffd8d8d8]|r: LF |cffa335ee|Hitem:193452:6607:::::::70:103::13:6:8836:8840:8902:8960:9405:9366:4:28:2164:38:8:40:383:48:204440::::Player-3684-0DFE529E:|h[Toxic Thorn Footwraps |A:Professions-ChatIcon-Quality-Tier5:17:17::1|a]|h|r recraft",
					["serverTime"] = 1695914872,
					["r"] = 0.9098039865493774,
					["extraData"] = {
						70, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 127192.327,
					["g"] = 0.6196078658103943,
					["b"] = 0.4745098352432251,
				}, -- [23]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:29:45]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Devildriver-Mal'Ganis:1296:CHANNEL:5|h|cffc69b6dDevildriver|r|h|cffd8d8d8]|r: |cffffd000|Htrade:Player-3684-0E059325:195097:164|h[Blacksmithing]|h|r LFW All Rank 5 weapons/shields/boots/belts and Icebane naxx set",
					["serverTime"] = 1695914949,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						13, -- [3]
						14, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 127269.157,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [24]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:29:45]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Devildriver-Mal'Ganis:1297:CHANNEL:5|h|cffc69b6dDevildriver|r|h|cffd8d8d8]|r: |cffffd000|Htrade:Player-3684-0E059325:7411:333|h[Enchanting]|h|r LFW Aspects/wyrm's",
					["serverTime"] = 1695914949,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						13, -- [3]
						14, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 127269.39,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [25]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:30:07]|h|r Journeyman Envial says: Add some shine to your hoard! Gems from across the seas, faceted on demand!",
					["serverTime"] = 1695914971,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 127290.994,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [26]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:31:14]|h|r A triumphant roar echoes from atop the Seat of the Aspects as Nasz'uro, the Unbound Legacy is formed.",
					["serverTime"] = 1695915038,
					["r"] = 1,
					["extraData"] = {
						37, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 127358.191,
					["g"] = 0.4705882668495178,
					["b"] = 0.03921568766236305,
				}, -- [27]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:33:38]|h|r Adventurer Rugan says: Hello, I'd like to buy some health potions please.",
					["serverTime"] = 1695915182,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 127502.509,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [28]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:33:42]|h|r Gohfyrr says: Sorry, we don't sell healing potions. I can sell you vials if you want to make your own healing potions?",
					["serverTime"] = 1695915186,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 127505.748,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [29]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:33:52]|h|r Adventurer Rugan says: No... No. Thank you though. Have a good day.",
					["serverTime"] = 1695915196,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 127515.933,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [30]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:33:58]|h|r Visiting Mage says: Brings back memories. Not great ones, but memories.",
					["serverTime"] = 1695915202,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 127521.574,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [31]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:34:09]|h|r Adventurer Rugan says: Diani is going to give me so much hassle over this.",
					["serverTime"] = 1695915213,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 127533.145,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [32]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:45:28]|h|r You are no longer Away.",
					["serverTime"] = 1695915892,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 128212.488,
					["g"] = 1,
					["b"] = 0,
				}, -- [33]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
	},
}
