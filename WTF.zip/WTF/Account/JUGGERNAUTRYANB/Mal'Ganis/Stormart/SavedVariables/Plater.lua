
PlaterDBChr = {
	["spellRangeCheckRangeFriendly"] = {
		[263] = 40,
		[264] = 40,
		[262] = 40,
	},
	["buffsBanned"] = {
	},
	["first_run3"] = {
		["Player-3684-0E3D4403"] = true,
	},
	["minimap"] = {
		["minimapPos"] = 129.3469853346396,
	},
	["resources_on_target"] = false,
	["debuffsBanned"] = {
	},
	["spellRangeCheckRangeEnemy"] = {
		[263] = 40,
		[264] = 40,
		[262] = 40,
	},
}
