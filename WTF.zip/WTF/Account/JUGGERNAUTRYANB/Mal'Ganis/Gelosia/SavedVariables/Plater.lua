
PlaterDBChr = {
	["spellRangeCheckRangeFriendly"] = {
		[260] = 20,
		[261] = 30,
		[259] = 30,
	},
	["buffsBanned"] = {
	},
	["first_run3"] = {
		["Player-3684-0CFF7479"] = true,
	},
	["spellRangeCheckRangeEnemy"] = {
		[260] = 20,
		[261] = 30,
		[259] = 30,
	},
	["resources_on_target"] = false,
	["debuffsBanned"] = {
	},
	["minimap"] = {
	},
}
