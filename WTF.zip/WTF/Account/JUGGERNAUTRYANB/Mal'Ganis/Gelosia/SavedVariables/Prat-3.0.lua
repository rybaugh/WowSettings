
Prat3CharDB = {
	["history"] = {
		["cmdhistory"] = {
			["ChatFrame10EditBox"] = {
			},
			["ChatFrame7EditBox"] = {
			},
			["ChatFrame5EditBox"] = {
			},
			["ChatFrame8EditBox"] = {
			},
			["ChatFrame4EditBox"] = {
			},
			["ChatFrame6EditBox"] = {
			},
			["ChatFrame9EditBox"] = {
			},
			["ChatFrame2EditBox"] = {
			},
			["ChatFrame3EditBox"] = {
			},
			["ChatFrame1EditBox"] = {
			},
		},
	},
}
Prat3HighCPUPerCharDB = {
	["scrollback"] = {
		["ChatFrame5"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame4"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 2,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:21]|h|r Brigita says: Welcome to the Roasted Ram! Seating is open.",
					["serverTime"] = 1695933046,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						82, -- [3]
						83, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2731.384,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:29]|h|r Gooeyzugzug has defeated Minivoker in a duel",
					["serverTime"] = 1695933054,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2739.602,
					["g"] = 1,
					["b"] = 0,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:51:15]|h|r |cffd8d8d8[|r|Hplayer:Brich:213|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1695930640,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 325.594,
					["g"] = 1,
					["b"] = 0,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:51:44]|h|r You receive item: |cff0070dd|Hitem:193218::::::::70:261:::::::::|h[Dense Hide |A:Professions-ChatIcon-Quality-Tier3:17:18::1|a]|h|rx5",
					["serverTime"] = 1695930669,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 354.712,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:51:44]|h|r You receive item: |cffffffff|Hitem:198200::::::::70:261:::::::::|h[Reinforced Machine Chassis |A:Professions-ChatIcon-Quality-Tier3:17:18::1|a]|h|r",
					["serverTime"] = 1695930669,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 354.916,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:51:45]|h|r You receive item: |cffffffff|Hitem:198194::::::::70:261:::::::::|h[Greased-Up Gears |A:Professions-ChatIcon-Quality-Tier3:17:18::1|a]|h|rx3",
					["serverTime"] = 1695930670,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 355.684,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:51:46]|h|r You receive item: |cffffffff|Hitem:198197::::::::70:261:::::::::|h[Arclight Capacitor |A:Professions-ChatIcon-Quality-Tier3:17:18::1|a]|h|rx3",
					["serverTime"] = 1695930671,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 355.994,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [7]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:51:46]|h|r You receive item: |cff1eff00|Hitem:198309::::::::70:261:::::::::|h[One-Size-Fits-All Gear |A:Professions-ChatIcon-Quality-Tier3:17:18::1|a]|h|r",
					["serverTime"] = 1695930671,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 356.51,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:52:39]|h|r Faür-Stormrage has fled from Tunnado-Stormrage in a duel",
					["serverTime"] = 1695930724,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 409.733,
					["g"] = 1,
					["b"] = 0,
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:53:12]|h|r You receive item: |cff1eff00|Hitem:198255::::::::70:261:::::::::|h[Calibrated Safety Switch |A:Professions-ChatIcon-Quality-Tier3:17:18::1|a]|h|r",
					["serverTime"] = 1695930757,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 442.075,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:53:36]|h|r Crafting order placed.",
					["serverTime"] = 1695930781,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 466.19,
					["g"] = 1,
					["b"] = 0,
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:54:24]|h|r [W From] |cffd8d8d8[|r|Hplayer:Bapaladin-Mal'Ganis:497:WHISPER:BAPALADIN-MAL'GANIS|h|cfff48cbaBapaladin|r|h|cffd8d8d8]|r: 424 or 447?",
					["serverTime"] = 1695930829,
					["r"] = 1,
					["extraData"] = {
						8, -- [1]
						false, -- [2]
						79, -- [3]
						80, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 514.721,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:54:30]|h|r [W To] |cffd8d8d8[|r|Hplayer:Bapaladin-Mal'Ganis:515:WHISPER:BAPALADIN-MAL'GANIS|h|cfff48cbaBapaladin|r|h|cffd8d8d8]|r: 424",
					["serverTime"] = 1695930835,
					["r"] = 1,
					["extraData"] = {
						10, -- [1]
						false, -- [2]
						79, -- [3]
						81, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 520.914,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:54:46]|h|r Journeyman Envial says: Gems so bright you'll want to shine your scales! Come browse the work of the finest jewelcrafters in the Dragon Isles.",
					["serverTime"] = 1695930851,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						82, -- [3]
						83, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 536.458,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:55:37]|h|r A crafter has fulfilled your order with Slimy Expulsion Boots |A:Professions-ChatIcon-Quality-Tier5:17:17::1|a.",
					["serverTime"] = 1695930902,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 587.198,
					["g"] = 1,
					["b"] = 0,
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:55:45]|h|r A crafter has fulfilled your order with Needlessly Complex Wristguards |A:Professions-ChatIcon-Quality-Tier4:17:17::1|a.",
					["serverTime"] = 1695930910,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 595.193,
					["g"] = 1,
					["b"] = 0,
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:55:47]|h|r [W From] |cffd8d8d8[|r|Hplayer:Bapaladin-Mal'Ganis:673:WHISPER:BAPALADIN-MAL'GANIS|h|cfff48cbaBapaladin|r|h|cffd8d8d8]|r: ok for you",
					["serverTime"] = 1695930912,
					["r"] = 1,
					["extraData"] = {
						8, -- [1]
						false, -- [2]
						79, -- [3]
						80, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 597.192,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [17]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:55:49]|h|r |cffc69b6dBrich|r has gone offline.",
					["serverTime"] = 1695930914,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 599.442,
					["g"] = 1,
					["b"] = 0,
				}, -- [18]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:55:49]|h|r [W From] |cffd8d8d8[|r|Hplayer:Bapaladin-Mal'Ganis:678:WHISPER:BAPALADIN-MAL'GANIS|h|cfff48cbaBapaladin|r|h|cffd8d8d8]|r: send to Basempr",
					["serverTime"] = 1695930914,
					["r"] = 1,
					["extraData"] = {
						8, -- [1]
						false, -- [2]
						79, -- [3]
						80, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 599.505,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [19]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:55:50]|h|r You receive item: |cffa335ee|Hitem:193451::::::::70:261::13:6:8836:8840:8902:8960:9405:9366:4:28:2164:38:8:40:376:48:204440:::::|h[Slimy Expulsion Boots |A:Professions-ChatIcon-Quality-Tier5:17:17::1|a]|h|r",
					["serverTime"] = 1695930915,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 599.9540000000001,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [20]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:55:50]|h|r You receive item: |cffa335ee|Hitem:198327::::::::70:261::13:8:8836:8840:8902:9404:8951:8863:9366:9415:8:28:2164:29:32:38:7:40:559:48:198309:50:198255:52:204440:54:206041:::::|h[Needlessly Complex Wristguards |A:Professions-ChatIcon-Quality-Tier4:17:17::1|a]|h|r",
					["serverTime"] = 1695930915,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 600.451,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [21]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:56:58]|h|r |TInterface\\FriendsFrame\\UI-Toast-ToastIcons.tga:16:16:0:0:128:64:2:29:34:61|t|HBNplayer:|Kq38|k:20:757:BN_INLINE_TOAST_ALERT:0|h[|Kq38|k] (|T-2:10:10:0:0:32:32:0:32:0:32|t SMoLzz)|h has come online.",
					["serverTime"] = 1695930983,
					["r"] = 0.5098039507865906,
					["extraData"] = {
						54, -- [1]
						false, -- [2]
						90, -- [3]
						91, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 668.1,
					["g"] = 0.7725490927696228,
					["b"] = 1,
				}, -- [22]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:13]|h|r |cffd8d8d8[|r|Hplayer:Coruptid:772|h|cffd8bc3f70|r:|cffaad372Coruptid|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1695930998,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 683.564,
					["g"] = 1,
					["b"] = 0,
				}, -- [23]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:16]|h|r You receive item: |cff0070dd|Hitem:201409::::::::70:261:::::::::|h[Tinker: Arclight Vital Correctors |A:Professions-ChatIcon-Quality-Tier3:17:18::1|a]|h|r",
					["serverTime"] = 1695931001,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 686.71,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [24]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:56]|h|r Patrickros-Stormrage has defeated Tunnado-Stormrage in a duel",
					["serverTime"] = 1695931101,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 786.056,
					["g"] = 1,
					["b"] = 0,
				}, -- [25]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:59]|h|r |cffd8d8d8[|r|Hplayer:Wargrimz:966|h|cffd8bc3f70|r:|cffaad372Wargrimz|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1695931164,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 849.58,
					["g"] = 1,
					["b"] = 0,
				}, -- [26]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:02:05]|h|r You receive item: |cffffffff|Hitem:192836::::::::70:261:::::::::|h[Shimmering Clasp |A:Professions-ChatIcon-Quality-Tier3:17:18::1|a]|h|rx2",
					["serverTime"] = 1695931290,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 975.116,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [27]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:02:05]|h|r You receive item: |cff0070dd|Hitem:193379::::::::70:261:::::::::|h[Elemental Harmony |A:Professions-ChatIcon-Quality-Tier3:17:18::1|a]|h|r",
					["serverTime"] = 1695931290,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 975.535,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [28]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:02:06]|h|r You receive item: |cff0070dd|Hitem:192861::::::::70:261:::::::::|h[Ysemerald |A:Professions-ChatIcon-Quality-Tier3:17:18::1|a]|h|r",
					["serverTime"] = 1695931291,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 976.139,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [29]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:02:06]|h|r You receive item: |cff1eff00|Hitem:194578::::::::70:261:::::::::|h[Draconic Missive of the Peerless |A:Professions-ChatIcon-Quality-Tier3:17:18::1|a]|h|r",
					["serverTime"] = 1695931291,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 976.514,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [30]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:02:43]|h|r Crafting order placed.",
					["serverTime"] = 1695931328,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1013.515,
					["g"] = 1,
					["b"] = 0,
				}, -- [31]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:03:02]|h|r [W From] |cffd8d8d8[|r|Hplayer:Bapaladin-Mal'Ganis:1163:WHISPER:BAPALADIN-MAL'GANIS|h|cfff48cbaBapaladin|r|h|cffd8d8d8]|r: i can do it",
					["serverTime"] = 1695931347,
					["r"] = 1,
					["extraData"] = {
						8, -- [1]
						false, -- [2]
						79, -- [3]
						80, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1031.982,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [32]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:03:08]|h|r [W From] |cffd8d8d8[|r|Hplayer:Bapaladin-Mal'Ganis:1170:WHISPER:BAPALADIN-MAL'GANIS|h|cfff48cbaBapaladin|r|h|cffd8d8d8]|r: send to Basemp",
					["serverTime"] = 1695931353,
					["r"] = 1,
					["extraData"] = {
						8, -- [1]
						false, -- [2]
						79, -- [3]
						80, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1038.507,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [33]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:03:08]|h|r A crafter has fulfilled your order with Signet of Titanic Insight |A:Professions-ChatIcon-Quality-Tier5:17:17::1|a.",
					["serverTime"] = 1695931353,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1038.882,
					["g"] = 1,
					["b"] = 0,
				}, -- [34]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:03:28]|h|r Tunnado-Stormrage has defeated Faür-Stormrage in a duel",
					["serverTime"] = 1695931373,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1058.247,
					["g"] = 1,
					["b"] = 0,
				}, -- [35]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:04:24]|h|r You receive item: |cffa335ee|Hitem:192999::::::::70:261::13:7:8836:8840:8902:8780:9405:8791:9366:7:28:2164:29:40:30:32:38:8:40:258:48:194578:51:204440:::::|h[Signet of Titanic Insight |A:Professions-ChatIcon-Quality-Tier5:17:17::1|a]|h|r",
					["serverTime"] = 1695931429,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1114.885,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [36]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:04:48]|h|r Faür-Stormrage has defeated Tunnado-Stormrage in a duel",
					["serverTime"] = 1695931453,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1137.951,
					["g"] = 1,
					["b"] = 0,
				}, -- [37]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:05:34]|h|r You sold your junk for 1|TInterface\\MoneyFrame\\UI-GoldIcon:0:0:2:0|t 75|TInterface\\MoneyFrame\\UI-SilverIcon:0:0:2:0|t 37|TInterface\\MoneyFrame\\UI-CopperIcon:0:0:2:0|t",
					["serverTime"] = 1695931499,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						false, -- [2]
						104, -- [3]
						104, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1184.295,
					["g"] = 1,
					["b"] = 0,
				}, -- [38]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:05:34]|h|r You repaired your armor for 140|TInterface\\MoneyFrame\\UI-GoldIcon:0:0:2:0|t 90|TInterface\\MoneyFrame\\UI-SilverIcon:0:0:2:0|t 9|TInterface\\MoneyFrame\\UI-CopperIcon:0:0:2:0|t",
					["serverTime"] = 1695931499,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						false, -- [2]
						104, -- [3]
						104, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1184.295,
					["g"] = 1,
					["b"] = 0,
				}, -- [39]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:06:04]|h|r |cffaad372Wargrimz|r has gone offline.",
					["serverTime"] = 1695931529,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1214.61,
					["g"] = 1,
					["b"] = 0,
				}, -- [40]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:06:31]|h|r |cffd8d8d8[|r|Hplayer:Ripnrots:1420|h|cffd8bc3f70|r:|cffc41e3aRipnrots|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1695931556,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1241.086,
					["g"] = 1,
					["b"] = 0,
				}, -- [41]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:06:43]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq78|k:36:1435:BN_WHISPER:|Kq78|k:Budsmokr#1645|h|A:UI-ChatIcon-WoW:0:0:0:0|a|cffaad372|Kq78|k|r|h|cffd8d8d8]|r: cam on a meeting next to me, cant talk",
					["serverTime"] = 1695931568,
					["r"] = 0,
					["extraData"] = {
						53, -- [1]
						false, -- [2]
						113, -- [3]
						114, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1253.909,
					["g"] = 1,
					["b"] = 0.9647059440612793,
				}, -- [42]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:06:59]|h|r |cffc41e3aRipnrots|r has gone offline.",
					["serverTime"] = 1695931584,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1269.65,
					["g"] = 1,
					["b"] = 0,
				}, -- [43]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:07:14]|h|r |cffd8d8d8[|r|Hplayer:Hoznboats:1469|h|cffd8bc3f70|r:|cfff48cbaHoznboats|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1695931599,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1284.265,
					["g"] = 1,
					["b"] = 0,
				}, -- [44]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:07:55]|h|r Faür-Stormrage has defeated Patrickros-Stormrage in a duel",
					["serverTime"] = 1695931640,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1325.38,
					["g"] = 1,
					["b"] = 0,
				}, -- [45]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:09:08]|h|r This is now a cross-faction instance group. You can do these activities together: dungeons and raids (non-queued), Torghast, Rated PvP",
					["serverTime"] = 1695931713,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1398.14,
					["g"] = 1,
					["b"] = 0,
				}, -- [46]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:09:08]|h|r Dungeon Difficulty set to Normal.",
					["serverTime"] = 1695931713,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1398.14,
					["g"] = 1,
					["b"] = 0,
				}, -- [47]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:09:16]|h|r Nethull-EmeraldDream has defeated Delasangre-EmeraldDream in a duel",
					["serverTime"] = 1695931721,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1406.825,
					["g"] = 1,
					["b"] = 0,
				}, -- [48]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:09:35]|h|r Aeoreon sighs.",
					["serverTime"] = 1695931740,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						false, -- [2]
						115, -- [3]
						116, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1425.232,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [49]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:09:35]|h|r Numernormi chuckles.",
					["serverTime"] = 1695931740,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						false, -- [2]
						115, -- [3]
						116, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1425.923,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [50]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:09:36]|h|r Aeoreon says: That is not what they mean, Vekkalis.",
					["serverTime"] = 1695931741,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						82, -- [3]
						83, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1426.9,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [51]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:09:57]|h|r You receive item: |cffa335ee|Hitem:204193::::::::70:261:::::::::|h[Whelpling's Shadowflame Crest]|h|r",
					["serverTime"] = 1695931762,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1447.334,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [52]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:10:38]|h|r Dungeon Difficulty set to Mythic.",
					["serverTime"] = 1695931803,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1488.56,
					["g"] = 1,
					["b"] = 0,
				}, -- [53]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:10:54]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Îllest-EmeraldDream:1700:PARTY|h|cffd8bc3f70|r:|cff8788eeÎllest|r-|cff30c774Eme|r|h|cffd8d8d8]|r: ty for summon",
					["serverTime"] = 1695931819,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						127, -- [3]
						128, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1504.498,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [54]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:11:12]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Apoplectic-Alexstrasza:1701:PARTY|h|cffd8bc3f70|r:|cff8788eeApoplectic|r-|cffd25865Ale|r|h|cffd8d8d8]|r: My pleasure",
					["serverTime"] = 1695931837,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						127, -- [3]
						129, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1522.747,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [55]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:11:33]|h|r |cfff48cbaHoznboats|r has gone offline.",
					["serverTime"] = 1695931858,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1543.204,
					["g"] = 1,
					["b"] = 0,
				}, -- [56]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:11:46]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Chelyberrana-Stormrage:1703:PARTY|h|cffd8bc3f70|r:|cffff7c0aChelyberrana|r-|cffc4955eSto|r|h|cffd8d8d8]|r: YES TY FOR SUMMON MUCH APPRECIATED",
					["serverTime"] = 1695931871,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						127, -- [3]
						130, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1556.642,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [57]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:11:54]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Fjörgynn-Azralon:1704:PARTY|h|cffd8bc3f70|r:|cff0070ddFjörgynn|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: Illest go out and get inside again",
					["serverTime"] = 1695931879,
					["r"] = 0.4627451300621033,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						127, -- [3]
						131, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1564.297,
					["g"] = 0.7843137979507446,
					["b"] = 1,
				}, -- [58]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:11:57]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Apoplectic-Alexstrasza:1705:PARTY|h|cffd8bc3f70|r:|cff8788eeApoplectic|r-|cffd25865Ale|r|h|cffd8d8d8]|r: IT WAS MY PLEASURE TO ASSIST",
					["serverTime"] = 1695931882,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						127, -- [3]
						129, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1567.098,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [59]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:12:01]|h|r |cffd8d8d8[|r|Hplayer:Wargrimz:1706|h|cffd8bc3f70|r:|cffaad372Wargrimz|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1695931886,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1571.306,
					["g"] = 1,
					["b"] = 0,
				}, -- [60]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:12:18]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Îllest-EmeraldDream:1707:PARTY|h|cffd8bc3f70|r:|cff8788eeÎllest|r-|cff30c774Eme|r|h|cffd8d8d8]|r: there we go lol",
					["serverTime"] = 1695931903,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						127, -- [3]
						128, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1588.639,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [61]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:12:33]|h|r |cffa5a5a5Fjörgynn|r-Azralon has initiated a ready check.",
					["serverTime"] = 1695931918,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1603.139,
					["g"] = 1,
					["b"] = 0,
				}, -- [62]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:15:09]|h|r |cffaad372Wargrimz|r has gone offline.",
					["serverTime"] = 1695932074,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1759.486,
					["g"] = 1,
					["b"] = 0,
				}, -- [63]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:15:21]|h|r |cffd8d8d8[|r|Hplayer:Macewindfury:1710|h|cffd8bc3f70|r:|cff0070ddMacewindfury|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1695932086,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1771.833,
					["g"] = 1,
					["b"] = 0,
				}, -- [64]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:16:05]|h|r Watcher Irideus yells: More trespassers? I will not allow you through!",
					["serverTime"] = 1695932130,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1815.034,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [65]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:16:19]|h|r |cff0070ddMacewindfury|r has gone offline.",
					["serverTime"] = 1695932144,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1828.946,
					["g"] = 1,
					["b"] = 0,
				}, -- [66]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:16:30]|h|r Watcher Irideus yells: Order will overwhelm you.",
					["serverTime"] = 1695932155,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1840.52,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [67]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:16:30]|h|r |TInterface\\ICONS\\Ability_ThunderKing_LightningWhip.blp:20|t Watcher Irideus begins casting |cFFFF0000|Hspell:389179|h[Power Overload]|h|r!",
					["serverTime"] = 1695932155,
					["r"] = 1,
					["extraData"] = {
						42, -- [1]
						false, -- [2]
						134, -- [3]
						135, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1840.52,
					["g"] = 0.8666667342185974,
					["b"] = 0,
				}, -- [68]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:16:38]|h|r Watcher Irideus yells: I will not let you through!",
					["serverTime"] = 1695932163,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1848.748,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [69]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:16:41]|h|r |TInterface\\ICONS\\Spell_Nature_LightningShield.blp:20|t Watcher Irideus erects an |cFFFF0000|Hspell:383840|h[Ablative Barrier]|h|r!",
					["serverTime"] = 1695932166,
					["r"] = 1,
					["extraData"] = {
						42, -- [1]
						false, -- [2]
						134, -- [3]
						135, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1851.155,
					["g"] = 0.8666667342185974,
					["b"] = 0,
				}, -- [70]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:16:42]|h|r Watcher Irideus yells: My sacrifice will keep these halls safe!",
					["serverTime"] = 1695932167,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1852.232,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [71]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:17:01]|h|r Watcher Irideus yells: A small victory, I will eliminate you!",
					["serverTime"] = 1695932186,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1871.712,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [72]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:17:19]|h|r |cffd8d8d8[|r|Hplayer:Wargrimz:1719|h|cffd8bc3f70|r:|cffaad372Wargrimz|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1695932204,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1889.176,
					["g"] = 1,
					["b"] = 0,
				}, -- [73]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:17:29]|h|r Watcher Irideus yells: Order will overwhelm you.",
					["serverTime"] = 1695932214,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1899.017,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [74]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:17:29]|h|r |TInterface\\ICONS\\Ability_ThunderKing_LightningWhip.blp:20|t Watcher Irideus begins casting |cFFFF0000|Hspell:389179|h[Power Overload]|h|r!",
					["serverTime"] = 1695932214,
					["r"] = 1,
					["extraData"] = {
						42, -- [1]
						false, -- [2]
						134, -- [3]
						135, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1899.017,
					["g"] = 0.8666667342185974,
					["b"] = 0,
				}, -- [75]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:17:29]|h|r [S] |cffd8d8d8[|r|Hplayer:Fjörgynn-Azralon:1722:SAY|h|cffd8bc3f70|r:|cff0070ddFjörgynn|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: Sobrecarga de Energia em |cffa5a5a5Fjörgynn|r!",
					["serverTime"] = 1695932214,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						136, -- [3]
						137, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1899.017,
					["g"] = 1,
					["b"] = 1,
				}, -- [76]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:17:32]|h|r [S] |cffd8d8d8[|r|Hplayer:Fjörgynn-Azralon:1723:SAY|h|cffd8bc3f70|r:|cff0070ddFjörgynn|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: 3",
					["serverTime"] = 1695932217,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						136, -- [3]
						137, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1902.201,
					["g"] = 1,
					["b"] = 1,
				}, -- [77]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:17:33]|h|r [S] |cffd8d8d8[|r|Hplayer:Fjörgynn-Azralon:1724:SAY|h|cffd8bc3f70|r:|cff0070ddFjörgynn|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: 2",
					["serverTime"] = 1695932218,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						136, -- [3]
						137, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1903.203,
					["g"] = 1,
					["b"] = 1,
				}, -- [78]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:17:37]|h|r Watcher Irideus yells: Tyr... Forgive me... I could not... stop... them...",
					["serverTime"] = 1695932222,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1907.466,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [79]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:20:17]|h|r Squallbringer Cyraz says: The winds are always in my favor!",
					["serverTime"] = 1695932382,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						82, -- [3]
						83, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2067.874,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [80]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:21:19]|h|r |TInterface\\ICONS\\Ability_Druid_FerociousBite.blp:20|t The Gulping Goliath begins to cast |cFFFF0000|Hspell:385551|h[Gulp]|h|r!",
					["serverTime"] = 1695932444,
					["r"] = 1,
					["extraData"] = {
						42, -- [1]
						false, -- [2]
						134, -- [3]
						135, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2129.311,
					["g"] = 0.8666667342185974,
					["b"] = 0,
				}, -- [81]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:21:40]|h|r [S] |cffd8d8d8[|r|Hplayer:Fjörgynn-Azralon:1728:SAY|h|cffd8bc3f70|r:|cff0070ddFjörgynn|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: Batida de Barriga em |cffa5a5a5Fjörgynn|r!",
					["serverTime"] = 1695932465,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						136, -- [3]
						137, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2150.203,
					["g"] = 1,
					["b"] = 1,
				}, -- [82]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:22:06]|h|r |TInterface\\ICONS\\Ability_Druid_FerociousBite.blp:20|t The Gulping Goliath begins to cast |cFFFF0000|Hspell:385551|h[Gulp]|h|r!",
					["serverTime"] = 1695932491,
					["r"] = 1,
					["extraData"] = {
						42, -- [1]
						false, -- [2]
						134, -- [3]
						135, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2176.614,
					["g"] = 0.8666667342185974,
					["b"] = 0,
				}, -- [83]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:24:23]|h|r Khajin the Unyielding yells: We'll build a new world free from their corruption!",
					["serverTime"] = 1695932628,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2313.451,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [84]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:24:33]|h|r Khajin the Unyielding yells: Let me show ya the power of the elements!",
					["serverTime"] = 1695932638,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2323.439,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [85]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:24:43]|h|r |TInterface\\ICONS\\Spell_Frost_Ice Shards.blp:20|tKhajin the Unyielding begins to cast |cFFFF0000|Hspell:386757|h[Hailstorm]|h|r!",
					["serverTime"] = 1695932648,
					["r"] = 1,
					["extraData"] = {
						42, -- [1]
						false, -- [2]
						134, -- [3]
						135, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2333.433,
					["g"] = 0.8666667342185974,
					["b"] = 0,
				}, -- [86]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:24:55]|h|r Khajin the Unyielding yells: Ya gonna catch ya death!",
					["serverTime"] = 1695932660,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2345.441,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [87]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:25:08]|h|r Khajin the Unyielding yells: Let me show ya the power of the elements!",
					["serverTime"] = 1695932673,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2358.415,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [88]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:25:13]|h|r |TInterface\\ICONS\\Spell_Frost_Ice Shards.blp:20|tKhajin the Unyielding begins to cast |cFFFF0000|Hspell:386757|h[Hailstorm]|h|r!",
					["serverTime"] = 1695932678,
					["r"] = 1,
					["extraData"] = {
						42, -- [1]
						false, -- [2]
						134, -- [3]
						135, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2363.446,
					["g"] = 0.8666667342185974,
					["b"] = 0,
				}, -- [89]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:25:25]|h|r Khajin the Unyielding yells: Ya gonna catch ya death!",
					["serverTime"] = 1695932690,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2375.448,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [90]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:25:39]|h|r Khajin the Unyielding yells: Nothing... can stop... us...",
					["serverTime"] = 1695932704,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2388.961,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [91]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:27:28]|h|r Infuser Sariya yells: Fools! Do you not see what that wretch Tyr has done?",
					["serverTime"] = 1695932813,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2498.798,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [92]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:27:56]|h|r Infuser Sariya yells: The elemental... will cleanse... the waters...",
					["serverTime"] = 1695932841,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2526.127,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [93]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:29:04]|h|r |TInterface\\ICONS\\Creatureportrait_Bubble.blp:20|t The Primal Tsunami begins to |cFFFF0000|Hspell:388420|h[Cast Away]|h|r its enemies!",
					["serverTime"] = 1695932909,
					["r"] = 1,
					["extraData"] = {
						42, -- [1]
						false, -- [2]
						134, -- [3]
						135, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2593.963,
					["g"] = 0.8666667342185974,
					["b"] = 0,
				}, -- [94]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1741:GUILD|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16261:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Heroic: Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 0.250980406999588,
					["extraData"] = {
						48, -- [1]
						false, -- [2]
						138, -- [3]
						139, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [95]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1742:GUILD|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16262:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Mythic: Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 0.250980406999588,
					["extraData"] = {
						48, -- [1]
						false, -- [2]
						138, -- [3]
						139, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [96]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1743:GUILD|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16260:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 0.250980406999588,
					["extraData"] = {
						48, -- [1]
						false, -- [2]
						138, -- [3]
						139, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [97]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1744:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16261:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Heroic: Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						140, -- [3]
						141, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0,
				}, -- [98]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1745:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16262:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Mythic: Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						140, -- [3]
						141, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0,
				}, -- [99]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1746:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16260:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						140, -- [3]
						141, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0,
				}, -- [100]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Apoplectic-Alexstrasza:1747:ACHIEVEMENT|h|cffd8bc3f70|r:|cff8788eeApoplectic|r-|cffd25865Ale|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16262:Player-1070-0D8ADEBB:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Mythic: Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						140, -- [3]
						142, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0,
				}, -- [101]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1748:GUILD|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:11183:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Keystone Initiate]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 0.250980406999588,
					["extraData"] = {
						48, -- [1]
						false, -- [2]
						138, -- [3]
						139, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [102]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1749:GUILD|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:11184:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Keystone Challenger]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 0.250980406999588,
					["extraData"] = {
						48, -- [1]
						false, -- [2]
						138, -- [3]
						139, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [103]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1750:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:11183:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Keystone Initiate]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						140, -- [3]
						141, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0,
				}, -- [104]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1751:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:11184:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Keystone Challenger]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						140, -- [3]
						141, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0,
				}, -- [105]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Chelyberrana-Stormrage:1752:ACHIEVEMENT|h|cffd8bc3f70|r:|cffff7c0aChelyberrana|r-|cffc4955eSto|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:17842:Player-60-0F2BFCA2:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Dragonflight Keystone Explorer: Season Two]|h|r |cffffffff(|rCompleted 5/10/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						140, -- [3]
						143, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0,
				}, -- [106]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:01]|h|r You receive currency: |cff0070dd|Hcurrency:2245:0|h[Flightstones]|h|rx42",
					["serverTime"] = 1695932966,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						144, -- [3]
						145, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2651.256,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [107]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:01]|h|r You receive currency: |cff0070dd|Hcurrency:2408:0|h[Bonus Flightstones]|h|rx25",
					["serverTime"] = 1695932966,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						144, -- [3]
						145, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2651.256,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [108]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:01]|h|r You receive item: |cff0070dd|Hitem:204075::::::::70:261:::::::::|h[Whelpling's Shadowflame Crest Fragment]|h|rx12",
					["serverTime"] = 1695932966,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2651.311,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [109]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:09]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Apoplectic-Alexstrasza:1756:PARTY|h|cffd8bc3f70|r:|cff8788eeApoplectic|r-|cffd25865Ale|r|h|cffd8d8d8]|r: Gee Gee Wee Pee",
					["serverTime"] = 1695932974,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						127, -- [3]
						129, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2658.934,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [110]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:09]|h|r |cffa5a5a5Fjörgynn|r-Azralon receives loot: |cffa335ee|Hitem:193736::::::::70:261::33:5:9315:6652:9144:1630:8767:1:28:1279:::::|h[Water's Beating Heart]|h|r.",
					["serverTime"] = 1695932974,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						146, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2659.67,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [111]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:10]|h|r |cffa5a5a5Îllest|r-EmeraldDream receives loot: |cffa335ee|Hitem:204717::::::::70:261:::::::::|h[Splintered Spark of Shadowflame]|h|r.",
					["serverTime"] = 1695932975,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						147, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2660.508,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [112]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:10]|h|r |cffa5a5a5Îllest|r-EmeraldDream receives loot: |cffa335ee|Hitem:180653::::::::70:261::::4:17:405:18:11:19:9:20:124:::::|h[Mythic Keystone]|h|r.",
					["serverTime"] = 1695932975,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						147, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2660.674,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [113]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:11]|h|r You receive loot: |cffa335ee|Hitem:193743::::::::70:261::16:5:9315:6652:9144:1630:8767:1:28:1279:::::|h[Irideus Fragment]|h|r",
					["serverTime"] = 1695932976,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2661.243,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [114]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:11]|h|r You receive loot: |cffa335ee|Hitem:180653::::::::70:261::::3:17:438:18:4:19:9:::::|h[Mythic Keystone]|h|r",
					["serverTime"] = 1695932976,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2661.243,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [115]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:12]|h|r You loot 55 Gold, 34 Silver, 86 Copper",
					["serverTime"] = 1695932977,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						false, -- [2]
						104, -- [3]
						148, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2662.263,
					["g"] = 1,
					["b"] = 0,
				}, -- [116]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:12]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Wargrimz-Mal'Ganis:1763:GUILD|h|cffd8bc3f70|r:|cffaad372Wargrimz|r|h|cffd8d8d8]|r: gratz",
					["serverTime"] = 1695932977,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						false, -- [2]
						138, -- [3]
						149, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2662.618,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [117]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:14]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Chelyberrana-Stormrage:1764:PARTY|h|cffd8bc3f70|r:|cffff7c0aChelyberrana|r-|cffc4955eSto|r|h|cffd8d8d8]|r: WEE PEE?",
					["serverTime"] = 1695932979,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						127, -- [3]
						130, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2664.8,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [118]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:18]|h|r |cffa5a5a5Apoplectic|r-Alexstrasza receives loot: |cffffffff|Hitem:198038::::::::70:261:::::::::|h[Ancient Titansteel Ingot]|h|rx10.",
					["serverTime"] = 1695932983,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						150, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2668.518,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [119]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:18]|h|r |cffa5a5a5Apoplectic|r-Alexstrasza receives loot: |cffa335ee|Hitem:204717::::::::70:261:::::::::|h[Splintered Spark of Shadowflame]|h|r.",
					["serverTime"] = 1695932983,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						150, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2668.824,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [120]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:26]|h|r |cffa5a5a5Îllest|r-EmeraldDream leaves the party.",
					["serverTime"] = 1695932991,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2676.821,
					["g"] = 1,
					["b"] = 0,
				}, -- [121]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:27]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Apoplectic-Alexstrasza:1768:PARTY|h|cffd8bc3f70|r:|cff8788eeApoplectic|r-|cffd25865Ale|r|h|cffd8d8d8]|r: Isn't that what we just killed?",
					["serverTime"] = 1695932992,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						127, -- [3]
						129, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2677.565,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [122]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:28]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Fjörgynn-Azralon:1769:PARTY|h|cffd8bc3f70|r:|cff0070ddFjörgynn|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: ty all",
					["serverTime"] = 1695932993,
					["r"] = 0.4627451300621033,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						127, -- [3]
						131, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2678.689,
					["g"] = 0.7843137979507446,
					["b"] = 1,
				}, -- [123]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:29]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1770:PARTY|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r: ty all",
					["serverTime"] = 1695932994,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						127, -- [3]
						151, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2679.88,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [124]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:32]|h|r |cffa5a5a5Fjörgynn|r-Azralon leaves the party.",
					["serverTime"] = 1695932997,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2682.393,
					["g"] = 1,
					["b"] = 0,
				}, -- [125]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:32]|h|r |cffa5a5a5Apoplectic|r-Alexstrasza is now the group leader.",
					["serverTime"] = 1695932997,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2682.501,
					["g"] = 1,
					["b"] = 0,
				}, -- [126]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:37]|h|r |cffa5a5a5Apoplectic|r-Alexstrasza leaves the party.",
					["serverTime"] = 1695933002,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2687.236,
					["g"] = 1,
					["b"] = 0,
				}, -- [127]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:37]|h|r |cffa5a5a5Chelyberrana|r-Stormrage is now the group leader.",
					["serverTime"] = 1695933002,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2687.415,
					["g"] = 1,
					["b"] = 0,
				}, -- [128]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame3"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 8,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["r"] = 1,
					["b"] = 0,
					["serverTime"] = 1695910962,
					["timestamp"] = 122.936,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [1]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 122.936,
					["serverTime"] = 1695915922,
					["r"] = 1,
				}, -- [2]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["b"] = 0,
					["r"] = 1,
					["serverTime"] = 1695923430,
					["timestamp"] = 122.936,
					["g"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
				}, -- [3]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["g"] = 1,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 122.936,
					["serverTime"] = 1695923459,
					["b"] = 0,
				}, -- [4]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["serverTime"] = 1695930438,
					["r"] = 1,
					["b"] = 0,
					["timestamp"] = 122.936,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [5]
				{
					["message"] = "0 |4day:days;, 0 |4hour:hours;, 0 |4minute:minutes;, 0 |4second:seconds;",
					["timestamp"] = 122.936,
				}, -- [6]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 122.936,
				}, -- [7]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 69.531,
					["g"] = 1,
					["b"] = 0,
				}, -- [8]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame7"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame6"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame8"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame10"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame9"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame1"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 4,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:52]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Aromyvepi-Mal'Ganis:1824:CHANNEL:5|h|cffc69b6dAromyvepi|r|h|cffd8d8d8]|r: [WТS] Aberrus Heroic & Mythic Carry! Get 428–450 ilvl upgradable gear & AotC achieve. EXPRESS boost: runs start every hour. Saved, Unsaved & VIP Lootruns available. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["serverTime"] = 1695933077,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						4, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2762.585,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:53]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Edidiqurazy-Mal'Ganis:1825:CHANNEL:5|h|cffc69b6dEdidiqurazy|r|h|cffd8d8d8]|r: [WТS] Arena 3v3 & Solo Shuffle Carry! Get up to 2400 Arena Rating, 450 ilvl gear, Elite PvP Tmog, Gladiator & Legend titles hassle-free. EXPRESS boost: start tonight. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["serverTime"] = 1695933078,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						18, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2763.161,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:53]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Annycatpaw-Mal'Ganis:1826:CHANNEL:5|h|cff00ff98Annycatpaw|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00WTS|r|cffffffff>|r LAST SPOT ~~HEROIC FULL RUN~~  |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r // Trade gold inside Raid",
					["serverTime"] = 1695933078,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						38, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2763.657,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:56]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Hoovies-Mal'Ganis:1827:CHANNEL:5|h|cffff7c0aHoovies|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r >WTS |cffffff00|Hachievement:18160:Player-3684-0E3848E2:0:0:0:-1:0:0:0:0|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r 9/9 HEROIC |cffffffff<|r|cff00ff00280k|r|cffffffff>|r & Heroic |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r - Trade INSIDE raid for safety, also offering **UNSAVED** runs /w now for more info!",
					["serverTime"] = 1695933081,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						42, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2765.935,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:15:09]|h|r |cffaad372Wargrimz|r has gone offline.",
					["serverTime"] = 1695932074,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1759.486,
					["g"] = 1,
					["b"] = 0,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:15:21]|h|r |cffd8d8d8[|r|Hplayer:Macewindfury:1710|h|cffd8bc3f70|r:|cff0070ddMacewindfury|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1695932086,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1771.833,
					["g"] = 1,
					["b"] = 0,
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:16:04]|h|r debug: |cFFFFFF00First Hit|r: Moonfire (DoT) from Chelyberrana-Stormrage",
					["timestamp"] = 1814.817,
					["serverTime"] = 1695932129,
				}, -- [7]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:16:04]|h|r |cffffaeaeDetails!:|r |cFFFFFF00First Hit|r: Moonfire (DoT) from Chelyberrana-Stormrage |cFFFFBB00Boss First Target|r: Chelyberrana    ",
					["timestamp"] = 1814.92,
					["serverTime"] = 1695932129,
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:16:05]|h|r Watcher Irideus yells: More trespassers? I will not allow you through!",
					["serverTime"] = 1695932130,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1815.034,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:16:19]|h|r |cff0070ddMacewindfury|r has gone offline.",
					["serverTime"] = 1695932144,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1828.946,
					["g"] = 1,
					["b"] = 0,
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:16:30]|h|r Watcher Irideus yells: Order will overwhelm you.",
					["serverTime"] = 1695932155,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1840.52,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:16:30]|h|r |TInterface\\ICONS\\Ability_ThunderKing_LightningWhip.blp:20|t Watcher Irideus begins casting |cFFFF0000|Hspell:389179|h[Power Overload]|h|r!",
					["serverTime"] = 1695932155,
					["r"] = 1,
					["extraData"] = {
						42, -- [1]
						false, -- [2]
						134, -- [3]
						135, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1840.52,
					["g"] = 0.8666667342185974,
					["b"] = 0,
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:16:38]|h|r Watcher Irideus yells: I will not let you through!",
					["serverTime"] = 1695932163,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1848.748,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:16:41]|h|r |TInterface\\ICONS\\Spell_Nature_LightningShield.blp:20|t Watcher Irideus erects an |cFFFF0000|Hspell:383840|h[Ablative Barrier]|h|r!",
					["serverTime"] = 1695932166,
					["r"] = 1,
					["extraData"] = {
						42, -- [1]
						false, -- [2]
						134, -- [3]
						135, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1851.155,
					["g"] = 0.8666667342185974,
					["b"] = 0,
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:16:42]|h|r Watcher Irideus yells: My sacrifice will keep these halls safe!",
					["serverTime"] = 1695932167,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1852.232,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:17:01]|h|r Watcher Irideus yells: A small victory, I will eliminate you!",
					["serverTime"] = 1695932186,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1871.712,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:17:19]|h|r |cffd8d8d8[|r|Hplayer:Wargrimz:1719|h|cffd8bc3f70|r:|cffaad372Wargrimz|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1695932204,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1889.176,
					["g"] = 1,
					["b"] = 0,
				}, -- [17]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:17:29]|h|r Watcher Irideus yells: Order will overwhelm you.",
					["serverTime"] = 1695932214,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1899.017,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [18]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:17:29]|h|r |TInterface\\ICONS\\Ability_ThunderKing_LightningWhip.blp:20|t Watcher Irideus begins casting |cFFFF0000|Hspell:389179|h[Power Overload]|h|r!",
					["serverTime"] = 1695932214,
					["r"] = 1,
					["extraData"] = {
						42, -- [1]
						false, -- [2]
						134, -- [3]
						135, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1899.017,
					["g"] = 0.8666667342185974,
					["b"] = 0,
				}, -- [19]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:17:29]|h|r [S] |cffd8d8d8[|r|Hplayer:Fjörgynn-Azralon:1722:SAY|h|cffd8bc3f70|r:|cff0070ddFjörgynn|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: Sobrecarga de Energia em |cffa5a5a5Fjörgynn|r!",
					["serverTime"] = 1695932214,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						136, -- [3]
						137, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1899.017,
					["g"] = 1,
					["b"] = 1,
				}, -- [20]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:17:32]|h|r [S] |cffd8d8d8[|r|Hplayer:Fjörgynn-Azralon:1723:SAY|h|cffd8bc3f70|r:|cff0070ddFjörgynn|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: 3",
					["serverTime"] = 1695932217,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						136, -- [3]
						137, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1902.201,
					["g"] = 1,
					["b"] = 1,
				}, -- [21]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:17:33]|h|r [S] |cffd8d8d8[|r|Hplayer:Fjörgynn-Azralon:1724:SAY|h|cffd8bc3f70|r:|cff0070ddFjörgynn|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: 2",
					["serverTime"] = 1695932218,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						136, -- [3]
						137, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1903.203,
					["g"] = 1,
					["b"] = 1,
				}, -- [22]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:17:37]|h|r Watcher Irideus yells: Tyr... Forgive me... I could not... stop... them...",
					["serverTime"] = 1695932222,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1907.466,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [23]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:20:17]|h|r Squallbringer Cyraz says: The winds are always in my favor!",
					["serverTime"] = 1695932382,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						82, -- [3]
						83, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2067.874,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [24]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:21:01]|h|r debug: |cFFFFFF00First Hit|r: Roiling Shadowflame from Îllest-EmeraldDream",
					["timestamp"] = 2111.086,
					["serverTime"] = 1695932426,
				}, -- [25]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:21:01]|h|r |cffffaeaeDetails!:|r |cFFFFFF00First Hit|r: Roiling Shadowflame from Îllest-EmeraldDream |cFFFFBB00Boss First Target|r: Chelyberrana    ",
					["timestamp"] = 2111.191,
					["serverTime"] = 1695932426,
				}, -- [26]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:21:19]|h|r |TInterface\\ICONS\\Ability_Druid_FerociousBite.blp:20|t The Gulping Goliath begins to cast |cFFFF0000|Hspell:385551|h[Gulp]|h|r!",
					["serverTime"] = 1695932444,
					["r"] = 1,
					["extraData"] = {
						42, -- [1]
						false, -- [2]
						134, -- [3]
						135, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2129.311,
					["g"] = 0.8666667342185974,
					["b"] = 0,
				}, -- [27]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:21:40]|h|r [S] |cffd8d8d8[|r|Hplayer:Fjörgynn-Azralon:1728:SAY|h|cffd8bc3f70|r:|cff0070ddFjörgynn|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: Batida de Barriga em |cffa5a5a5Fjörgynn|r!",
					["serverTime"] = 1695932465,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						136, -- [3]
						137, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2150.203,
					["g"] = 1,
					["b"] = 1,
				}, -- [28]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:22:06]|h|r |TInterface\\ICONS\\Ability_Druid_FerociousBite.blp:20|t The Gulping Goliath begins to cast |cFFFF0000|Hspell:385551|h[Gulp]|h|r!",
					["serverTime"] = 1695932491,
					["r"] = 1,
					["extraData"] = {
						42, -- [1]
						false, -- [2]
						134, -- [3]
						135, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2176.614,
					["g"] = 0.8666667342185974,
					["b"] = 0,
				}, -- [29]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:24:23]|h|r debug: |cFFFFFF00First Hit|r: Moonfire (DoT) from Chelyberrana-Stormrage",
					["timestamp"] = 2313.22,
					["serverTime"] = 1695932628,
				}, -- [30]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:24:23]|h|r |cffffaeaeDetails!:|r |cFFFFFF00First Hit|r: Moonfire (DoT) from Chelyberrana-Stormrage |cFFFFBB00Boss First Target|r: Chelyberrana    ",
					["timestamp"] = 2313.324,
					["serverTime"] = 1695932628,
				}, -- [31]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:24:23]|h|r Khajin the Unyielding yells: We'll build a new world free from their corruption!",
					["serverTime"] = 1695932628,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2313.451,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [32]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:24:33]|h|r Khajin the Unyielding yells: Let me show ya the power of the elements!",
					["serverTime"] = 1695932638,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2323.439,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [33]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:24:43]|h|r |TInterface\\ICONS\\Spell_Frost_Ice Shards.blp:20|tKhajin the Unyielding begins to cast |cFFFF0000|Hspell:386757|h[Hailstorm]|h|r!",
					["serverTime"] = 1695932648,
					["r"] = 1,
					["extraData"] = {
						42, -- [1]
						false, -- [2]
						134, -- [3]
						135, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2333.433,
					["g"] = 0.8666667342185974,
					["b"] = 0,
				}, -- [34]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:24:55]|h|r Khajin the Unyielding yells: Ya gonna catch ya death!",
					["serverTime"] = 1695932660,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2345.441,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [35]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:25:08]|h|r Khajin the Unyielding yells: Let me show ya the power of the elements!",
					["serverTime"] = 1695932673,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2358.415,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [36]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:25:13]|h|r |TInterface\\ICONS\\Spell_Frost_Ice Shards.blp:20|tKhajin the Unyielding begins to cast |cFFFF0000|Hspell:386757|h[Hailstorm]|h|r!",
					["serverTime"] = 1695932678,
					["r"] = 1,
					["extraData"] = {
						42, -- [1]
						false, -- [2]
						134, -- [3]
						135, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2363.446,
					["g"] = 0.8666667342185974,
					["b"] = 0,
				}, -- [37]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:25:25]|h|r Khajin the Unyielding yells: Ya gonna catch ya death!",
					["serverTime"] = 1695932690,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2375.448,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [38]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:25:39]|h|r Khajin the Unyielding yells: Nothing... can stop... us...",
					["serverTime"] = 1695932704,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2388.961,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [39]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:27:28]|h|r Infuser Sariya yells: Fools! Do you not see what that wretch Tyr has done?",
					["serverTime"] = 1695932813,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2498.798,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [40]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:27:56]|h|r Infuser Sariya yells: The elemental... will cleanse... the waters...",
					["serverTime"] = 1695932841,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						132, -- [3]
						133, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2526.127,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [41]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:28:13]|h|r |cffffaeaeDetails!:|r |cFFFFBB00First Hit|r: *?* |cFFFFBB00Boss First Target|r: Chelyberrana    ",
					["timestamp"] = 2543.847,
					["serverTime"] = 1695932858,
				}, -- [42]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:28:15]|h|r debug: |cFFFFFF00First Hit|r: Moonfire (DoT) from Chelyberrana-Stormrage",
					["timestamp"] = 2545.01,
					["serverTime"] = 1695932860,
				}, -- [43]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:29:04]|h|r |TInterface\\ICONS\\Creatureportrait_Bubble.blp:20|t The Primal Tsunami begins to |cFFFF0000|Hspell:388420|h[Cast Away]|h|r its enemies!",
					["serverTime"] = 1695932909,
					["r"] = 1,
					["extraData"] = {
						42, -- [1]
						false, -- [2]
						134, -- [3]
						135, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2593.963,
					["g"] = 0.8666667342185974,
					["b"] = 0,
				}, -- [44]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cff33ff99<AngryKeystones>|r |cffffd700Beat the timer for +3 Halls of Infusion in 16:55.570. You were 4:04.430 ahead of the +3 timer.|r",
					["timestamp"] = 2650.446,
					["serverTime"] = 1695932965,
				}, -- [45]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1741:GUILD|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16261:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Heroic: Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 0.250980406999588,
					["extraData"] = {
						48, -- [1]
						false, -- [2]
						138, -- [3]
						139, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [46]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1742:GUILD|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16262:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Mythic: Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 0.250980406999588,
					["extraData"] = {
						48, -- [1]
						false, -- [2]
						138, -- [3]
						139, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [47]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1743:GUILD|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16260:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 0.250980406999588,
					["extraData"] = {
						48, -- [1]
						false, -- [2]
						138, -- [3]
						139, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [48]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1744:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16261:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Heroic: Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						140, -- [3]
						141, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0,
				}, -- [49]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1745:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16262:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Mythic: Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						140, -- [3]
						141, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0,
				}, -- [50]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1746:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16260:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						140, -- [3]
						141, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0,
				}, -- [51]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Apoplectic-Alexstrasza:1747:ACHIEVEMENT|h|cffd8bc3f70|r:|cff8788eeApoplectic|r-|cffd25865Ale|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:16262:Player-1070-0D8ADEBB:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Mythic: Halls of Infusion]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						140, -- [3]
						142, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0,
				}, -- [52]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1748:GUILD|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:11183:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Keystone Initiate]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 0.250980406999588,
					["extraData"] = {
						48, -- [1]
						false, -- [2]
						138, -- [3]
						139, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [53]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1749:GUILD|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:11184:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Keystone Challenger]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 0.250980406999588,
					["extraData"] = {
						48, -- [1]
						false, -- [2]
						138, -- [3]
						139, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [54]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1750:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:11183:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Keystone Initiate]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						140, -- [3]
						141, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0,
				}, -- [55]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1751:ACHIEVEMENT|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:11184:Player-3684-0CFF7479:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Keystone Challenger]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						140, -- [3]
						141, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0,
				}, -- [56]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:00]|h|r |cffd8d8d8[|r|Hplayer:Chelyberrana-Stormrage:1752:ACHIEVEMENT|h|cffd8bc3f70|r:|cffff7c0aChelyberrana|r-|cffc4955eSto|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:17842:Player-60-0F2BFCA2:1:9:28:23:4294967295:4294967295:4294967295:4294967295|h[Dragonflight Keystone Explorer: Season Two]|h|r |cffffffff(|rCompleted 5/10/23|cffffffff)|r!",
					["serverTime"] = 1695932965,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						140, -- [3]
						143, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2650.626,
					["g"] = 1,
					["b"] = 0,
				}, -- [57]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:01]|h|r You receive currency: |cff0070dd|Hcurrency:2245:0|h[Flightstones]|h|rx42",
					["serverTime"] = 1695932966,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						144, -- [3]
						145, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2651.256,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [58]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:01]|h|r You receive currency: |cff0070dd|Hcurrency:2408:0|h[Bonus Flightstones]|h|rx25",
					["serverTime"] = 1695932966,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						144, -- [3]
						145, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2651.256,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [59]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:01]|h|r You receive item: |cff0070dd|Hitem:204075::::::::70:261:::::::::|h[Whelpling's Shadowflame Crest Fragment]|h|rx12",
					["serverTime"] = 1695932966,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2651.311,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [60]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:04]|h|r Halls of Infusion (Level 5) completed in 16:55 (18 |4min:min; 5 |4sec:sec; left). This is a new Tyrannical record!",
					["serverTime"] = 1695932969,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 2654.778,
					["g"] = 1,
					["b"] = 0,
				}, -- [61]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:04]|h|r Rating increased for |cffffd200Apoplectic|r, |cffffd200Fjörgynn|r, |cffffd200Chelyberrana|r, |cffffd200Gelosia|r, |cffffd200Îllest|r!",
					["serverTime"] = 1695932969,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 2654.778,
					["g"] = 1,
					["b"] = 0,
				}, -- [62]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:04]|h|r Your Mythic+ Rating increased to |cffffffff90|r (+90). Keystone upgraded +3.",
					["serverTime"] = 1695932969,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 2654.778,
					["g"] = 1,
					["b"] = 0,
				}, -- [63]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:09]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Apoplectic-Alexstrasza:1756:PARTY|h|cffd8bc3f70|r:|cff8788eeApoplectic|r-|cffd25865Ale|r|h|cffd8d8d8]|r: Gee Gee Wee Pee",
					["serverTime"] = 1695932974,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						127, -- [3]
						129, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2658.934,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [64]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:09]|h|r |cffa5a5a5Fjörgynn|r-Azralon receives loot: |cffa335ee|Hitem:193736::::::::70:261::33:5:9315:6652:9144:1630:8767:1:28:1279:::::|h[Water's Beating Heart]|h|r.",
					["serverTime"] = 1695932974,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						146, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2659.67,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [65]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:10]|h|r |cffa5a5a5Îllest|r-EmeraldDream receives loot: |cffa335ee|Hitem:204717::::::::70:261:::::::::|h[Splintered Spark of Shadowflame]|h|r.",
					["serverTime"] = 1695932975,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						147, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2660.508,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [66]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:10]|h|r |cffa5a5a5Îllest|r-EmeraldDream receives loot: |cffa335ee|Hitem:180653::::::::70:261::::4:17:405:18:11:19:9:20:124:::::|h[Mythic Keystone]|h|r.",
					["serverTime"] = 1695932975,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						147, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2660.674,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [67]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:11]|h|r You receive loot: |cffa335ee|Hitem:193743::::::::70:261::16:5:9315:6652:9144:1630:8767:1:28:1279:::::|h[Irideus Fragment]|h|r",
					["serverTime"] = 1695932976,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2661.243,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [68]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:11]|h|r You receive loot: |cffa335ee|Hitem:180653::::::::70:261::::3:17:438:18:4:19:9:::::|h[Mythic Keystone]|h|r",
					["serverTime"] = 1695932976,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2661.243,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [69]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:12]|h|r You loot 55 Gold, 34 Silver, 86 Copper",
					["serverTime"] = 1695932977,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						false, -- [2]
						104, -- [3]
						148, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2662.263,
					["g"] = 1,
					["b"] = 0,
				}, -- [70]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:12]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Wargrimz-Mal'Ganis:1763:GUILD|h|cffd8bc3f70|r:|cffaad372Wargrimz|r|h|cffd8d8d8]|r: gratz",
					["serverTime"] = 1695932977,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						false, -- [2]
						138, -- [3]
						149, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2662.618,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [71]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:14]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Chelyberrana-Stormrage:1764:PARTY|h|cffd8bc3f70|r:|cffff7c0aChelyberrana|r-|cffc4955eSto|r|h|cffd8d8d8]|r: WEE PEE?",
					["serverTime"] = 1695932979,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						127, -- [3]
						130, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2664.8,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [72]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:18]|h|r |cffa5a5a5Apoplectic|r-Alexstrasza receives loot: |cffffffff|Hitem:198038::::::::70:261:::::::::|h[Ancient Titansteel Ingot]|h|rx10.",
					["serverTime"] = 1695932983,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						150, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2668.518,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [73]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:18]|h|r |cffa5a5a5Apoplectic|r-Alexstrasza receives loot: |cffa335ee|Hitem:204717::::::::70:261:::::::::|h[Splintered Spark of Shadowflame]|h|r.",
					["serverTime"] = 1695932983,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						69, -- [3]
						150, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2668.824,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [74]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:26]|h|r |cffa5a5a5Îllest|r-EmeraldDream leaves the party.",
					["serverTime"] = 1695932991,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2676.821,
					["g"] = 1,
					["b"] = 0,
				}, -- [75]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:27]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Apoplectic-Alexstrasza:1768:PARTY|h|cffd8bc3f70|r:|cff8788eeApoplectic|r-|cffd25865Ale|r|h|cffd8d8d8]|r: Isn't that what we just killed?",
					["serverTime"] = 1695932992,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						127, -- [3]
						129, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2677.565,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [76]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:28]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Fjörgynn-Azralon:1769:PARTY|h|cffd8bc3f70|r:|cff0070ddFjörgynn|r-|cffd174a9Azr|r|h|cffd8d8d8]|r: ty all",
					["serverTime"] = 1695932993,
					["r"] = 0.4627451300621033,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						127, -- [3]
						131, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2678.689,
					["g"] = 0.7843137979507446,
					["b"] = 1,
				}, -- [77]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:29]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Gelosia-Mal'Ganis:1770:PARTY|h|cffd8bc3f70|r:|cfffff468Gelosia|r|h|cffd8d8d8]|r: ty all",
					["serverTime"] = 1695932994,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						127, -- [3]
						151, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2679.88,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [78]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:32]|h|r |cffa5a5a5Fjörgynn|r-Azralon leaves the party.",
					["serverTime"] = 1695932997,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2682.393,
					["g"] = 1,
					["b"] = 0,
				}, -- [79]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:32]|h|r |cffa5a5a5Apoplectic|r-Alexstrasza is now the group leader.",
					["serverTime"] = 1695932997,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2682.501,
					["g"] = 1,
					["b"] = 0,
				}, -- [80]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:37]|h|r |cffa5a5a5Apoplectic|r-Alexstrasza leaves the party.",
					["serverTime"] = 1695933002,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2687.236,
					["g"] = 1,
					["b"] = 0,
				}, -- [81]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:30:37]|h|r |cffa5a5a5Chelyberrana|r-Stormrage is now the group leader.",
					["serverTime"] = 1695933002,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2687.415,
					["g"] = 1,
					["b"] = 0,
				}, -- [82]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:09]|h|r Loot Specialization set to: Assassination",
					["serverTime"] = 1695933034,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 2719.134,
					["g"] = 1,
					["b"] = 0,
				}, -- [83]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:10]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Valdrakken]|h",
					["serverTime"] = 1695933035,
					["r"] = 0.7647059559822083,
					["extraData"] = {
						69, -- [1]
						false, -- [2]
						117, -- [3]
						118, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2720.229,
					["g"] = 0.9019608497619629,
					["b"] = 0.9098039865493774,
				}, -- [84]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:10]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h",
					["serverTime"] = 1695933035,
					["r"] = 0.9098039865493774,
					["extraData"] = {
						70, -- [1]
						false, -- [2]
						52, -- [3]
						120, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2720.229,
					["g"] = 0.6196078658103943,
					["b"] = 0.4745098352432251,
				}, -- [85]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:10]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Valdrakken]|h",
					["serverTime"] = 1695933035,
					["r"] = 0.9098039865493774,
					["extraData"] = {
						71, -- [1]
						false, -- [2]
						122, -- [3]
						123, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2720.229,
					["g"] = 0.8941177129745483,
					["b"] = 0.4745098352432251,
				}, -- [86]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:10]|h|r |Hchannel:channel:5|h[5] |h Changed Channel: |Hchannel:CHANNEL:5|h[5. Trade (Services) - City]|h",
					["serverTime"] = 1695933035,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						125, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2720.229,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [87]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:11]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Blanchiness-Mal'Ganis:1779:CHANNEL:5|h|cffc41e3aBlanchiness|r|h|cffd8d8d8]|r: [ZakRaider™] WTS FULL HEROIC |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  or ONLY Last Boss |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r || AotC || Trade gold in Raid || Free group loot",
					["serverTime"] = 1695933036,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						8, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2721.552,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [88]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:12]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Yzexyponaly-Mal'Ganis:1780:CHANNEL:5|h|cffc69b6dYzexyponaly|r|h|cffd8d8d8]|r: [WТS] Mythic +10–20 & Dawn of the Infinite Megadungeon Сarry tonight! Get 415-447 ilvl gear, Immortal run, Armor Stack & Achieves hassle-free. EXPRESS Start in 30 minutes. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["serverTime"] = 1695933037,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						26, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2722.621,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [89]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:13]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Safarooniee-Mal'Ganis:1781:CHANNEL:5|h|cffc41e3aSafarooniee|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00CHEAPEST IN MARKET|r|cffffffff>|r OFFERING 9/9 Heroic Full Clear NOW! |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff<|r|cff00ff00MAX DROPS|r|cffffffff>|r |cffffffff<|r|cff00ff00BEST GEARING OPTION|r|cffffffff>|r |cffffffff<|r|cff00ff00VIP Run Available|r|cffffffff>|r |cffffffff<|r|cff00ff00Cheapest|r|cffffffff>|r || |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r [PAYMENTS IN RAID FOR SAFETY] /w me for reserve your spot!",
					["serverTime"] = 1695933038,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						24, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2723.576,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [90]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:13]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Gylfaginning-Mal'Ganis:1782:CHANNEL:5|h|cffff7c0aGylfaginning|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS [Aberrus, the Shadowed Crucible]   Heroic |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20 (Armor Stack, Specific Key for free, Discount Multiple Keys) ANY Key MEGA DUNGEON Armor Stack available All loot tradeable GOLD ONLY",
					["serverTime"] = 1695933038,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						30, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2723.576,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [91]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:13]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Yarita-Mal'Ganis:1783:CHANNEL:5|h|cffc41e3aYarita|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:15|h[Aberrus, the Shadowed Crucible]|h|rHeroic |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key Mega Dungeon armor Stack available All loot tradeable",
					["serverTime"] = 1695933038,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						22, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2723.576,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [92]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:17]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Kashisoo-Mal'Ganis:1784:CHANNEL:5|h|cffc41e3aKashisoo|r|h|cffd8d8d8]|r: WTS POWER LEVEL FAST AND CHEAP|||| FULL AFK CAN SUMMON 10-70,10-60,60-70 PST FOR INFO|| GOLD ONLY",
					["serverTime"] = 1695933042,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2726.968,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [93]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:17]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Aksurip-Mal'Ganis:1785:CHANNEL:5|h|cffc41e3aAksurip|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  Heroic Full Run |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key MEGA DUNGEON armor Stack available All loot tradeable",
					["serverTime"] = 1695933042,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						16, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2726.968,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [94]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:17]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Vraubankk-Mal'Ganis:1786:CHANNEL:5|h|cfffff468Vraubankk|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Bakers|r|cffffffff>|r are offering  |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280K|r|cffffffff>|r // Last Boss HC |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00110k|r|cffffffff>|r // Unsaved and Funnel // Payment Inside in the raid group for safety!! We price match everyone!!  /w to book!",
					["serverTime"] = 1695933042,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						46, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2727.447,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [95]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:18]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Aromyvepi-Mal'Ganis:1787:CHANNEL:5|h|cffc69b6dAromyvepi|r|h|cffd8d8d8]|r: [WТS] Arena 3v3 & Solo Shuffle Carry! Get up to 2400 Arena Rating, 450 ilvl gear, Elite PvP Tmog, Gladiator & Legend titles hassle-free. EXPRESS boost: start tonight. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["serverTime"] = 1695933043,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						4, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2727.968,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [96]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:18]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Edidiqurazy-Mal'Ganis:1788:CHANNEL:5|h|cffc69b6dEdidiqurazy|r|h|cffd8d8d8]|r: [WТS] Aberrus Heroic & Mythic Carry! Get 428–450 ilvl upgradable gear & AotC achieve. EXPRESS boost: runs start every hour. Saved, Unsaved & VIP Lootruns available. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["serverTime"] = 1695933043,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						18, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2728.532,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [97]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:18]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Kashisoo-Mal'Ganis:1789:CHANNEL:5|h|cffc41e3aKashisoo|r|h|cffd8d8d8]|r: WTS POWER LEVEL FAST AND CHEAP|||| FULL AFK CAN SUMMON 10-70,10-60,60-70 PST FOR INFO|| GOLD ONLY",
					["serverTime"] = 1695933043,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2728.532,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [98]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:20]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Crystalragé-Mal'Ganis:1791:CHANNEL:5|h|cffc41e3aCrystalragé|r|h|cffd8d8d8]|r: [Guildies] OFFERING HEROIC FULL CLEAR NOW! |cffffff00|Hachievement:18160:Player-3684-0E3848E2:0:0:0:-1:0:0:0:0|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r [9/9 Heroic Full Run] [LOWEST PRICE] [MAX DROPS] [BEST FOR GEARING] [VIP RUN AVAILABLE] & HC |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r [Price Match] [Payment Inside Raid] /w me for booking!",
					["serverTime"] = 1695933045,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						10, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2730.224,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [99]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:21]|h|r Brigita says: Welcome to the Roasted Ram! Seating is open.",
					["serverTime"] = 1695933046,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						82, -- [3]
						83, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2731.384,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [100]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:21]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Yukinahara-Mal'Ganis:1794:CHANNEL:5|h|cfffff468Yukinahara|r|h|cffd8d8d8]|r: [ZakRaider™] |cffffffff<|r|cff00ff00WTS|r|cffffffff>|r FULL HEROIC RUN |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r // Last Boss only|cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r // AOTC // Group loot // Trade Gold inside Raid",
					["serverTime"] = 1695933046,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						28, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2731.539,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [101]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:23]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Naysun-Mal'Ganis:1795:CHANNEL:5|h|cffc41e3aNaysun|r|h|cffd8d8d8]|r: >>WTS<< [+10]-[+24] - SpecificKeys - Portals (20 timed) - KSM/KSH - NewMega Dungeon - Get your weekly vault max level (447) - Special offers for multiples runs (x4/x8) - Free 2 Armor Stack for 4 or more Runs - DM For check prices <3",
					["serverTime"] = 1695933048,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						44, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2733.445,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [102]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:25]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Annycatpaw-Mal'Ganis:1796:CHANNEL:5|h|cff00ff98Annycatpaw|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00WTS|r|cffffffff>|r LAST SPOT ~~HEROIC FULL RUN~~  |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r // Trade gold inside Raid",
					["serverTime"] = 1695933050,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						38, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2735.644,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [103]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:25]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Rockingex-Mal'Ganis:1797:CHANNEL:5|h|cffaad372Rockingex|r|h|cffd8d8d8]|r: ////______WTS______\\\\\\\\  Mythic Dungeon 10-23 ____ Timed / KSM / KSH ___Armor stack_____|cff66bbff|Hjournal:0:1209:8|h[Dawn of the Infinite]|h|r   ____Leveling 1-70 ///  GOLD ONLY _______<3",
					["serverTime"] = 1695933050,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						36, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2735.644,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [104]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:27]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Hoovies-Mal'Ganis:1798:CHANNEL:5|h|cffff7c0aHoovies|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r >WTS |cffffff00|Hachievement:18160:Player-3684-0E3848E2:0:0:0:-1:0:0:0:0|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r 9/9 HEROIC |cffffffff<|r|cff00ff00280k|r|cffffffff>|r & Heroic |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r - Trade INSIDE raid for safety, also offering **UNSAVED** runs /w now for more info!",
					["serverTime"] = 1695933052,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						42, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2737.878,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [105]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:28]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Safarooniee-Mal'Ganis:1799:CHANNEL:5|h|cffc41e3aSafarooniee|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00CHEAPEST IN MARKET|r|cffffffff>|r OFFERING 9/9 Heroic Full Clear NOW! |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff<|r|cff00ff00MAX DROPS|r|cffffffff>|r |cffffffff<|r|cff00ff00BEST GEARING OPTION|r|cffffffff>|r |cffffffff<|r|cff00ff00VIP Run Available|r|cffffffff>|r |cffffffff<|r|cff00ff00Cheapest|r|cffffffff>|r || |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r [PAYMENTS IN RAID FOR SAFETY] /w me for reserve your spot!",
					["serverTime"] = 1695933053,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						24, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2738.704,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [106]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:29]|h|r Gooeyzugzug has defeated Minivoker in a duel",
					["serverTime"] = 1695933054,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2739.602,
					["g"] = 1,
					["b"] = 0,
				}, -- [107]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:29]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Prinsa-Mal'Ganis:1801:CHANNEL:5|h|cffc41e3aPrinsa|r|h|cffd8d8d8]|r: OFFERING |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280K|r|cffffffff>|r // |cffffffff<|r|cff00ff00NORMAL 100K|r|cffffffff>|r |cffffffff<|r|cff00ff00HC&NORM 340K|r|cffffffff>|r, ECHO |cffffffff<|r|cff00ff0060K|r|cffffffff>|r HC  Sarkareth |cffffffff<|r|cff00ff00110K|r|cffffffff>|r BOTH |cffffffff<|r|cff00ff00150K|r|cffffffff>|r// Payment Inside in the raid group for safety!! /w to book!",
					["serverTime"] = 1695933054,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						34, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2739.872,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [108]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:29]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Yzexyponaly-Mal'Ganis:1802:CHANNEL:5|h|cffc69b6dYzexyponaly|r|h|cffd8d8d8]|r: [WТS] Arena 3v3 & Solo Shuffle Carry! Get up to 2400 Arena Rating, 450 ilvl gear, Elite PvP Tmog, Gladiator & Legend titles hassle-free. EXPRESS boost: start tonight. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["serverTime"] = 1695933054,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						26, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2739.872,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [109]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:30]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Yarita-Mal'Ganis:1803:CHANNEL:5|h|cffc41e3aYarita|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:15|h[Aberrus, the Shadowed Crucible]|h|rHeroic |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key Mega Dungeon armor Stack available All loot tradeable",
					["serverTime"] = 1695933055,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						22, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2740.74,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [110]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:32]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Gylfaginning-Mal'Ganis:1804:CHANNEL:5|h|cffff7c0aGylfaginning|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS [Aberrus, the Shadowed Crucible]   Heroic |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20 (Armor Stack, Specific Key for free, Discount Multiple Keys) ANY Key MEGA DUNGEON Armor Stack available All loot tradeable GOLD ONLY",
					["serverTime"] = 1695933057,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						30, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2742.414,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [111]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:34]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Aksurip-Mal'Ganis:1807:CHANNEL:5|h|cffc41e3aAksurip|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  Heroic Full Run |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key MEGA DUNGEON armor Stack available All loot tradeable",
					["serverTime"] = 1695933059,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						16, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2744.565,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [112]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:34]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Vraubankk-Mal'Ganis:1808:CHANNEL:5|h|cfffff468Vraubankk|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Bakers|r|cffffffff>|r are offering  |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280K|r|cffffffff>|r // Last Boss HC |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00110k|r|cffffffff>|r // Unsaved and Funnel // Payment Inside in the raid group for safety!! We price match everyone!!  /w to book!",
					["serverTime"] = 1695933059,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						46, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2744.565,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [113]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:35]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Nemna-Mal'Ganis:1809:CHANNEL:5|h|cffc69b6dNemna|r|h|cffd8d8d8]|r: --WTS--  Mythic +16 +20 +22 +24 +25 Anylvl  //  Armor stack  //  Specific key  //  Items Tradeables And Specific  // THE BEST PRICES AND OFFERS // New Dungeon And Mythic Raid.- Full Run 9/9M /PvP bost Whisp Me For More info.",
					["serverTime"] = 1695933060,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						14, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2744.98,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [114]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:35]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Aromyvepi-Mal'Ganis:1810:CHANNEL:5|h|cffc69b6dAromyvepi|r|h|cffd8d8d8]|r: [WТS] Powerleveling Services! 10-70 Selfplayed Leveling, Mage Tower, Dragon Glyphs, Flightstones & Shadowflame Crests hassle-free. EXPRESS boost: start in 1 hour. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["serverTime"] = 1695933060,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						4, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2745.353,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [115]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:35]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Crystalragé-Mal'Ganis:1811:CHANNEL:5|h|cffc41e3aCrystalragé|r|h|cffd8d8d8]|r: [Guildies] OFFERING HEROIC FULL CLEAR NOW! |cffffff00|Hachievement:18160:Player-3684-0E3848E2:0:0:0:-1:0:0:0:0|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r [9/9 Heroic Full Run] [LOWEST PRICE] [MAX DROPS] [BEST FOR GEARING] [VIP RUN AVAILABLE] & HC |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r [Price Match] [Payment Inside Raid] /w me for booking!",
					["serverTime"] = 1695933060,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						10, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2745.353,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [116]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:36]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Edidiqurazy-Mal'Ganis:1812:CHANNEL:5|h|cffc69b6dEdidiqurazy|r|h|cffd8d8d8]|r: [WТS] Mythic +10–20 & Dawn of the Infinite Megadungeon Сarry tonight! Get 415-447 ilvl gear, Immortal run, Armor Stack & Achieves hassle-free. EXPRESS Start in 30 minutes. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["serverTime"] = 1695933061,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						18, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2745.939,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [117]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:37]|h|r |Hchannel:channel:5|h[5] |h<Busy>|cffd8d8d8[|r|Hplayer:Cogalvanya-Mal'Ganis:1813:CHANNEL:5|h|cffc69b6dCogalvanya|r|h|cffd8d8d8]|r: >>>SELL CHEAPEST|cffffffff<|r|cff00ff00<< We have a [Price Match]and !!!-20%!!! from any competitor ABERRUS|cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r]9/9 [HEROIC VIP LOOT] |r|cffffffff>|r>>MAX DROP<<<, EXPRESS Last BOSS, raids every 1 HOUR, Whisper me for!!!",
					["serverTime"] = 1695933062,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						12, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2747.105,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [118]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:43]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Safarooniee-Mal'Ganis:1814:CHANNEL:5|h|cffc41e3aSafarooniee|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00CHEAPEST IN MARKET|r|cffffffff>|r OFFERING 9/9 Heroic Full Clear NOW! |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff<|r|cff00ff00MAX DROPS|r|cffffffff>|r |cffffffff<|r|cff00ff00BEST GEARING OPTION|r|cffffffff>|r |cffffffff<|r|cff00ff00VIP Run Available|r|cffffffff>|r |cffffffff<|r|cff00ff00Cheapest|r|cffffffff>|r || |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r [PAYMENTS IN RAID FOR SAFETY] /w me for reserve your spot!",
					["serverTime"] = 1695933068,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						24, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2753.834,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [119]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:45]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Blanchiness-Mal'Ganis:1815:CHANNEL:5|h|cffc41e3aBlanchiness|r|h|cffd8d8d8]|r: [ZakRaider™] WTS FULL HEROIC |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  or ONLY Last Boss |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r || AotC || Trade gold in Raid || Free group loot",
					["serverTime"] = 1695933070,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						8, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2755.672,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [120]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:47]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Yzexyponaly-Mal'Ganis:1816:CHANNEL:5|h|cffc69b6dYzexyponaly|r|h|cffd8d8d8]|r: [WТS] Powerleveling Services! 10-70 Selfplayed Leveling, Mage Tower, Dragon Glyphs, Flightstones & Shadowflame Crests hassle-free. EXPRESS boost: start in 1 hour. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["serverTime"] = 1695933072,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						26, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2757.218,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [121]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:48]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Gylfaginning-Mal'Ganis:1817:CHANNEL:5|h|cffff7c0aGylfaginning|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS [Aberrus, the Shadowed Crucible]   Heroic |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20 (Armor Stack, Specific Key for free, Discount Multiple Keys) ANY Key MEGA DUNGEON Armor Stack available All loot tradeable GOLD ONLY",
					["serverTime"] = 1695933073,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						30, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2757.979,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [122]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:49]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Prinsa-Mal'Ganis:1818:CHANNEL:5|h|cffc41e3aPrinsa|r|h|cffd8d8d8]|r: OFFERING |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280K|r|cffffffff>|r // |cffffffff<|r|cff00ff00NORMAL 100K|r|cffffffff>|r |cffffffff<|r|cff00ff00HC&NORM 340K|r|cffffffff>|r, ECHO |cffffffff<|r|cff00ff0060K|r|cffffffff>|r HC  Sarkareth |cffffffff<|r|cff00ff00110K|r|cffffffff>|r BOTH |cffffffff<|r|cff00ff00150K|r|cffffffff>|r// Payment Inside in the raid group for safety!! /w to book!",
					["serverTime"] = 1695933074,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						34, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2759.142,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [123]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:49]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Yarita-Mal'Ganis:1819:CHANNEL:5|h|cffc41e3aYarita|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:15|h[Aberrus, the Shadowed Crucible]|h|rHeroic |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key Mega Dungeon armor Stack available All loot tradeable",
					["serverTime"] = 1695933074,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						22, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2759.838,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [124]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:50]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Aksurip-Mal'Ganis:1820:CHANNEL:5|h|cffc41e3aAksurip|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  Heroic Full Run |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key MEGA DUNGEON armor Stack available All loot tradeable",
					["serverTime"] = 1695933075,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						16, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2760.265,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [125]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:50]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Yukinahara-Mal'Ganis:1821:CHANNEL:5|h|cfffff468Yukinahara|r|h|cffd8d8d8]|r: [ZakRaider™] |cffffffff<|r|cff00ff00WTS|r|cffffffff>|r FULL HEROIC RUN |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r // Last Boss only|cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r // AOTC // Group loot // Trade Gold inside Raid",
					["serverTime"] = 1695933075,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						28, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2760.538,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [126]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:50]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Crystalragé-Mal'Ganis:1822:CHANNEL:5|h|cffc41e3aCrystalragé|r|h|cffd8d8d8]|r: [Guildies] OFFERING HEROIC FULL CLEAR NOW! |cffffff00|Hachievement:18160:Player-3684-0E3848E2:0:0:0:-1:0:0:0:0|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff(|rCompleted 9/28/23|cffffffff)|r [9/9 Heroic Full Run] [LOWEST PRICE] [MAX DROPS] [BEST FOR GEARING] [VIP RUN AVAILABLE] & HC |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r [Price Match] [Payment Inside Raid] /w me for booking!",
					["serverTime"] = 1695933075,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						10, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2760.538,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [127]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:31:51]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Vraubankk-Mal'Ganis:1823:CHANNEL:5|h|cfffff468Vraubankk|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Bakers|r|cffffffff>|r are offering  |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280K|r|cffffffff>|r // Last Boss HC |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00110k|r|cffffffff>|r // Unsaved and Funnel // Payment Inside in the raid group for safety!! We price match everyone!!  /w to book!",
					["serverTime"] = 1695933076,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						1, -- [3]
						46, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 2761.815,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [128]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
	},
}
