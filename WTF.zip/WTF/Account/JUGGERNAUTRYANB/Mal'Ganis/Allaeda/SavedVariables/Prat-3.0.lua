
Prat3CharDB = {
	["history"] = {
		["cmdhistory"] = {
			["ChatFrame10EditBox"] = {
			},
			["ChatFrame7EditBox"] = {
			},
			["ChatFrame5EditBox"] = {
			},
			["ChatFrame8EditBox"] = {
			},
			["ChatFrame4EditBox"] = {
			},
			["ChatFrame6EditBox"] = {
			},
			["ChatFrame1EditBox"] = {
			},
			["ChatFrame3EditBox"] = {
			},
			["ChatFrame2EditBox"] = {
			},
			["ChatFrame9EditBox"] = {
			},
		},
	},
}
Prat3HighCPUPerCharDB = {
	["scrollback"] = {
		["ChatFrame5"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame10"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame3"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 6,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["b"] = 0,
					["r"] = 1,
					["serverTime"] = 1695839815,
					["timestamp"] = 57079.463,
					["g"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
				}, -- [1]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["g"] = 1,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 57079.463,
					["serverTime"] = 1695841248,
					["b"] = 0,
				}, -- [2]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["serverTime"] = 1695844762,
					["r"] = 1,
					["b"] = 0,
					["timestamp"] = 57079.463,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [3]
				{
					["message"] = "0 |4day:days;, 0 |4hour:hours;, 0 |4minute:minutes;, 0 |4second:seconds;",
					["timestamp"] = 57079.463,
				}, -- [4]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 57079.463,
				}, -- [5]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 57057.881,
					["g"] = 1,
					["b"] = 0,
				}, -- [6]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame7"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame6"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame8"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame4"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 77,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:02]|h|r [S] |cffd8d8d8[|r|Hplayer:Grica-Trollbane:5021:SAY|h|cffd8bc3f70|r:|cffffffffGrica|r-|cff6ff9c3Tro|r:1|h|cffd8d8d8]|r: Disintegrate",
					["serverTime"] = 1695853824,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						272, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66142.003,
					["g"] = 1,
					["b"] = 1,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:45]|h|r [S] |cffd8d8d8[|r|Hplayer:Angelofdeãth-Dalaran:5026:SAY|h|cffd8bc3f70|r:|cffc41e3aAngelofdeãth|r-|cff00fc9cDal|r:3|h|cffd8d8d8]|r: Disintegrate",
					["serverTime"] = 1695853867,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						251, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66185.507,
					["g"] = 1,
					["b"] = 1,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Allaeda-Mal'Ganis:5030:GUILD|h|cffd8bc3f70|r:|cffa330c9Allaeda|r:4|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-3684-08CEF40C:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 0.250980406999588,
					["extraData"] = {
						48, -- [1]
						false, -- [2]
						78, -- [3]
						79, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Grändeeney-Azralon:5032:ACHIEVEMENT|h|cffd8bc3f70|r:|cff33937fGrändeeney|r-|cffd174a9Azr|r:2|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-3209-0BB6DF00:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						288, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Snøwhite-Nordrassil:5033:ACHIEVEMENT|h|cffd8bc3f70|r:|cffa330c9Snøwhite|r-|cffc95863Nor|r:1|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-121-0A8894BD:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						258, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Angelofdeãth-Dalaran:5034:ACHIEVEMENT|h|cffd8bc3f70|r:|cffc41e3aAngelofdeãth|r-|cff00fc9cDal|r:3|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-3683-0D8002FD:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						289, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Kenotah-Illidan:5035:ACHIEVEMENT|h|cffd8bc3f70|r:|cffffffffKenotah|r-|cff32e983Ill|r:1|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-57-0A080377:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						290, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [7]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Erolithien-WyrmrestAccord:5036:ACHIEVEMENT|h|cffd8bc3f70|r:|cff3fc7ebErolithien|r-|cff96bee2Wyr|r:4|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18160:Player-1171-071D6B57:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff(|rCompleted 5/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						291, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Erolithien-WyrmrestAccord:5037:ACHIEVEMENT|h|cffd8bc3f70|r:|cff3fc7ebErolithien|r-|cff96bee2Wyr|r:4|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-1171-071D6B57:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						291, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Aleyla-WyrmrestAccord:5038:ACHIEVEMENT|h|cffd8bc3f70|r:|cffffffffAleyla|r-|cff96bee2Wyr|r:5|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-1171-0AB24417:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						292, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Meda-Area52:5039:ACHIEVEMENT|h|cffd8bc3f70|r:|cffaad372Meda|r-|cff64968eAre|r:3|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-3676-0CB75B48:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						293, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Dubwubz-Illidan:5040:ACHIEVEMENT|h|cffd8bc3f70|r:|cffffffffDubwubz|r-|cff32e983Ill|r:2|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-57-0D935F36:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						294, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Deradis-Mal'Ganis:5041:ACHIEVEMENT|h|cffd8bc3f70|r:|cff3fc7ebDeradis|r:3|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-3684-0E10D0B0:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						295, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Diresteaks-Thrall:5042:ACHIEVEMENT|h|cffd8bc3f70|r:|cffc69b6dDiresteaks|r-|cff1dfd54Thr|r:2|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-3678-0D78BCC4:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						296, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Flickers-Area52:5043:ACHIEVEMENT|h|cffd8bc3f70|r:|cff8788eeFlickers|r-|cff64968eAre|r:4|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-3676-0CC993AF:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						297, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Allaeda-Mal'Ganis:5044:ACHIEVEMENT|h|cffd8bc3f70|r:|cffa330c9Allaeda|r:4|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-3684-08CEF40C:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						82, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Malthäell-Azralon:5045:ACHIEVEMENT|h|cffd8bc3f70|r:|cffffffffMalthäell|r-|cffd174a9Azr|r:2|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-3209-0BB6DF63:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						298, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [17]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:25]|h|r Received 280 Gold, 90 Silver.",
					["serverTime"] = 1695853907,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.726,
					["g"] = 1,
					["b"] = 0,
				}, -- [18]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:25]|h|r |HlootHistory:2693|h[Loot]|h: |cffa335ee|Hitem:202626::::::::70:581::4:4:9230:9411:1459:8767::::::|h[Venerated Mixing Fluid]|h|r",
					["serverTime"] = 1695853907,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						190, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66225.512,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [19]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:25]|h|r |HlootHistory:2693|h[Loot]|h: |cffa335ee|Hitem:202588::::::::70:581::4:7:9411:9314:6652:9225:9219:1459:8767::::::|h[Exacting Augmenter's Sabatons]|h|r",
					["serverTime"] = 1695853907,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						190, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66225.512,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [20]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:25]|h|r |HlootHistory:2693|h[Loot]|h: |cffa335ee|Hitem:202582::::::::70:581::4:8:6652:9413:9225:9220:9411:9314:1459:8767::::::|h[Manacles of Cruel Progress]|h|r",
					["serverTime"] = 1695853907,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						190, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66225.512,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [21]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:25]|h|r |HlootHistory:2693|h[Loot]|h: |cffa335ee|Hitem:204318::::::::70:581::4:5:6652:9411:9314:1459:8767::::::|h[Thadrion's Erratic Arcanotrode]|h|r",
					["serverTime"] = 1695853907,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						190, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66225.512,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [22]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:25]|h|r |HlootHistory:2693|h[Loot]|h: |cffa335ee|Hitem:202566::::::::70:581::4:5:6652:9411:9314:1459:8767::::::|h[Rionthus's Bladed Visage]|h|r",
					["serverTime"] = 1695853907,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						190, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66225.512,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [23]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:25]|h|r You receive currency: |cff0070dd|Hcurrency:2245:0|h[Flightstones]|h|rx35",
					["serverTime"] = 1695853907,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						83, -- [3]
						84, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66225.698,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [24]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:26]|h|r You receive loot: |cffa335ee|Hitem:204717::::::::70:581:::::::::|h[Splintered Spark of Shadowflame]|h|r",
					["serverTime"] = 1695853908,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						52, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66225.947,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [25]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:26]|h|r You receive loot: |cff0070dd|Hitem:204075::::::::70:581:::::::::|h[Whelpling's Shadowflame Crest Fragment]|h|rx10",
					["serverTime"] = 1695853908,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						52, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66225.947,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [26]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:26]|h|r |cffd8d8d8[|r|Hplayer:Allaeda-Mal'Ganis:5055:GUILD|h|cffd8bc3f70|r:|cffa330c9Allaeda|r:4|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:1181:Player-3684-08CEF40C:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Got My Mind On My Money]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853908,
					["r"] = 0.250980406999588,
					["extraData"] = {
						48, -- [1]
						false, -- [2]
						78, -- [3]
						79, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66226.171,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [27]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:26]|h|r |cffd8d8d8[|r|Hplayer:Allaeda-Mal'Ganis:5056:ACHIEVEMENT|h|cffd8bc3f70|r:|cffa330c9Allaeda|r:4|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:1181:Player-3684-08CEF40C:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Got My Mind On My Money]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853908,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						82, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66226.171,
					["g"] = 1,
					["b"] = 0,
				}, -- [28]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:26]|h|r |cffd8d8d8[|r|Hplayer:Crazycrits-Azgalor:5057:ACHIEVEMENT|h|cffd8bc3f70|r:|cff3fc7ebCrazycrits|r-|cff17e7abAzg|r:5|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:1181:Player-77-0196ADCF:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Got My Mind On My Money]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853908,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						299, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66226.414,
					["g"] = 1,
					["b"] = 0,
				}, -- [29]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:27]|h|r You loot 126 Gold, 40 Silver, 38 Copper",
					["serverTime"] = 1695853909,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						false, -- [2]
						72, -- [3]
						73, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66226.988,
					["g"] = 1,
					["b"] = 0,
				}, -- [30]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:28]|h|r |HlootHistory:2693|h[Loot]|h: You have selected Need for: |cffa335ee|Hitem:202566::::::::70:581::4:5:6652:9411:9314:1459:8767::::::|h[Rionthus's Bladed Visage]|h|r |HlootHistory:2693|h|cnLOOT_LINK_COLOR:[View Loot Rolls]|r|h",
					["serverTime"] = 1695853910,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						190, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66228.035,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [31]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:28]|h|r |cffa5a5a5Diresteaks|r-Thrall receives loot: |cffa335ee|Hitem:204717::::::::70:581:::::::::|h[Splintered Spark of Shadowflame]|h|r.",
					["serverTime"] = 1695853910,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						269, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66228.035,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [32]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:29]|h|r |HlootHistory:2693|h[Loot]|h: You have selected Greed for: |cffa335ee|Hitem:202582::::::::70:581::4:8:6652:9413:9225:9220:9411:9314:1459:8767::::::|h[Manacles of Cruel Progress]|h|r |HlootHistory:2693|h|cnLOOT_LINK_COLOR:[View Loot Rolls]|r|h",
					["serverTime"] = 1695853911,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						190, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66229.202,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [33]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:32]|h|r |HlootHistory:2693|h[Loot]|h: You have selected Greed for: |cffa335ee|Hitem:202588::::::::70:581::4:7:9411:9314:6652:9225:9219:1459:8767::::::|h[Exacting Augmenter's Sabatons]|h|r |HlootHistory:2693|h|cnLOOT_LINK_COLOR:[View Loot Rolls]|r|h",
					["serverTime"] = 1695853914,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						190, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66232.603,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [34]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:33]|h|r |HlootHistory:2693|h[Loot]|h: You have selected Greed for: |cffa335ee|Hitem:202626::::::::70:581::4:4:9230:9411:1459:8767::::::|h[Venerated Mixing Fluid]|h|r |HlootHistory:2693|h|cnLOOT_LINK_COLOR:[View Loot Rolls]|r|h",
					["serverTime"] = 1695853915,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						190, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66233.142,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [35]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:36]|h|r |cffa5a5a5Tcheemoo|r-BleedingHollow has left the instance group.",
					["serverTime"] = 1695853918,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66236.018,
					["g"] = 1,
					["b"] = 0,
				}, -- [36]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:37]|h|r |cffa5a5a5Phenanthrene|r-Frostwolf receives loot: |cff0070dd|Hitem:204464::::::::70:581:::::::::|h[Shadowflame Essence]|h|r.",
					["serverTime"] = 1695853919,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						244, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66237.51,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [37]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:40]|h|r |cffa5a5a5Meda|r-Area52 receives loot: |cffa335ee|Hitem:204717::::::::70:581:::::::::|h[Splintered Spark of Shadowflame]|h|r.",
					["serverTime"] = 1695853922,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						261, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66239.833,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [38]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:45]|h|r |cffa5a5a5Darlys|r-Area52 has left the instance group.",
					["serverTime"] = 1695853927,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66245.50200000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [39]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:47]|h|r |cffa5a5a5Meda|r-Area52 has left the instance group.",
					["serverTime"] = 1695853929,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66246.887,
					["g"] = 1,
					["b"] = 0,
				}, -- [40]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:48]|h|r |cffa5a5a5Kenotah|r-Illidan receives loot: |cffa335ee|Hitem:204717::::::::70:581:::::::::|h[Splintered Spark of Shadowflame]|h|r.",
					["serverTime"] = 1695853930,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						265, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66247.826,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [41]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:49]|h|r |cffa5a5a5Vierssra|r-Akama has left the instance group.",
					["serverTime"] = 1695853931,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66249.658,
					["g"] = 1,
					["b"] = 0,
				}, -- [42]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:54]|h|r |cffa5a5a5Snøwhite|r-Nordrassil receives loot: |cffa335ee|Hitem:204717::::::::70:581:::::::::|h[Splintered Spark of Shadowflame]|h|r.",
					["serverTime"] = 1695853936,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						259, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66254.193,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [43]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:55]|h|r |cffa5a5a5Phenanthrene|r-Frostwolf has left the instance group.",
					["serverTime"] = 1695853937,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66255.166,
					["g"] = 1,
					["b"] = 0,
				}, -- [44]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:00]|h|r |cfff48cbaMaktenshi|r has gone offline.",
					["serverTime"] = 1695853942,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66260.023,
					["g"] = 1,
					["b"] = 0,
				}, -- [45]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:01]|h|r |cffa5a5a5Murcièlagö|r-Barthilas receives loot: |cff0070dd|Hitem:190330::::::::70:581:::::::::|h[Rousing Decay]|h|r.",
					["serverTime"] = 1695853943,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						300, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66260.969,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [46]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:01]|h|r |cffa5a5a5Malthäell|r-Azralon receives loot: |cffa335ee|Hitem:204717::::::::70:581:::::::::|h[Splintered Spark of Shadowflame]|h|r.",
					["serverTime"] = 1695853943,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						248, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66261.3,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [47]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:08]|h|r |cffa5a5a5Ballsy|r-BleedingHollow has left the instance group.",
					["serverTime"] = 1695853950,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66268.352,
					["g"] = 1,
					["b"] = 0,
				}, -- [48]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:09]|h|r |cff3fc7ebDeradis|r has left the instance group.",
					["serverTime"] = 1695853951,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66269.4,
					["g"] = 1,
					["b"] = 0,
				}, -- [49]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:09]|h|r |cffa5a5a5Kenotah|r-Illidan has left the instance group.",
					["serverTime"] = 1695853951,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66269.464,
					["g"] = 1,
					["b"] = 0,
				}, -- [50]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:09]|h|r |cffa5a5a5Malthäell|r-Azralon has left the instance group.",
					["serverTime"] = 1695853951,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66269.531,
					["g"] = 1,
					["b"] = 0,
				}, -- [51]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:10]|h|r |cffa5a5a5Grändeeney|r-Azralon has left the instance group.",
					["serverTime"] = 1695853952,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66269.731,
					["g"] = 1,
					["b"] = 0,
				}, -- [52]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:11]|h|r |cffa5a5a5Flickers|r-Area52 has left the instance group.",
					["serverTime"] = 1695853953,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66271.471,
					["g"] = 1,
					["b"] = 0,
				}, -- [53]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:12]|h|r |cffa5a5a5Hölycöw|r-Akama has left the instance group.",
					["serverTime"] = 1695853954,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66272.355,
					["g"] = 1,
					["b"] = 0,
				}, -- [54]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:12]|h|r |cffa5a5a5Crazycrits|r-Azgalor has left the instance group.",
					["serverTime"] = 1695853954,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66272.404,
					["g"] = 1,
					["b"] = 0,
				}, -- [55]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:12]|h|r |cffa5a5a5Dubwubz|r-Illidan has left the instance group.",
					["serverTime"] = 1695853954,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66272.458,
					["g"] = 1,
					["b"] = 0,
				}, -- [56]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:12]|h|r |cffa5a5a5Diresteaks|r-Thrall has left the instance group.",
					["serverTime"] = 1695853954,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66272.458,
					["g"] = 1,
					["b"] = 0,
				}, -- [57]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:23]|h|r |cffa5a5a5Grica|r-Trollbane has left the instance group.",
					["serverTime"] = 1695853965,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66283.436,
					["g"] = 1,
					["b"] = 0,
				}, -- [58]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:29]|h|r |cffa5a5a5Snøwhite|r-Nordrassil has left the instance group.",
					["serverTime"] = 1695853971,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66288.97,
					["g"] = 1,
					["b"] = 0,
				}, -- [59]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:32]|h|r |cffa5a5a5Jabrule|r-Illidan has left the instance group.",
					["serverTime"] = 1695853974,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66292.499,
					["g"] = 1,
					["b"] = 0,
				}, -- [60]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:33]|h|r |cffa5a5a5Ologh|r-Nordrassil has left the instance group.",
					["serverTime"] = 1695853975,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66293.16100000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [61]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:45]|h|r |cffa5a5a5Erolithien|r-WyrmrestAccord receives loot: |cffa335ee|Hitem:204717::::::::70:581:::::::::|h[Splintered Spark of Shadowflame]|h|r.",
					["serverTime"] = 1695853987,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						242, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66305.638,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [62]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:54]|h|r |cffa5a5a5Erolithien|r-WyrmrestAccord has left the instance group.",
					["serverTime"] = 1695853996,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66314.599,
					["g"] = 1,
					["b"] = 0,
				}, -- [63]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:34:18]|h|r |cffa5a5a5Murcièlagö|r-Barthilas has left the instance group.",
					["serverTime"] = 1695854020,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66338.705,
					["g"] = 1,
					["b"] = 0,
				}, -- [64]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:36:29]|h|r |HlootHistory:2693|h[Loot]|h: |cffa5a5a5Dubwubz|r (Need - 46, Main-Spec) Won: |cffa335ee|Hitem:202626::::::::70:581::4:4:9230:9411:1459:8767::::::|h[Venerated Mixing Fluid]|h|r",
					["serverTime"] = 1695854151,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						190, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66469.032,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [65]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:36:39]|h|r |HlootHistory:2693|h[Loot]|h: |cffa5a5a5Jabrule|r (Need - 43, Main-Spec) Won: |cffa335ee|Hitem:202588::::::::70:581::4:7:9411:9314:6652:9225:9219:1459:8767::::::|h[Exacting Augmenter's Sabatons]|h|r",
					["serverTime"] = 1695854161,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						190, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66479.194,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [66]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:36:49]|h|r |HlootHistory:2693|h[Loot]|h: |cffa5a5a5Angelofdeãth|r (Need - 56, Main-Spec) Won: |cffa335ee|Hitem:202582::::::::70:581::4:8:6652:9413:9225:9220:9411:9314:1459:8767::::::|h[Manacles of Cruel Progress]|h|r",
					["serverTime"] = 1695854171,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						190, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66489.329,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [67]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:36:49]|h|r |cffa5a5a5Angelofdeãth|r-Dalaran receives loot: |cffa335ee|Hitem:202582::::::::70:581::4:8:6652:9413:9225:9220:9411:9314:1459:8767::::::|h[Manacles of Cruel Progress]|h|r.",
					["serverTime"] = 1695854171,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						262, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66489.389,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [68]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:36:56]|h|r |cffa5a5a5Angelofdeãth|r-Dalaran has left the instance group.",
					["serverTime"] = 1695854178,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66496.62,
					["g"] = 1,
					["b"] = 0,
				}, -- [69]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:36:59]|h|r |HlootHistory:2693|h[Loot]|h: You (Need - 48, Main-Spec) Won: |cffa335ee|Hitem:202566::::::::70:581::4:5:6652:9411:9314:1459:8767::::::|h[Rionthus's Bladed Visage]|h|r",
					["serverTime"] = 1695854181,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						190, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66499.465,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [70]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:36:59]|h|r You receive loot: |cffa335ee|Hitem:202566::::::::70:581::4:5:6652:9411:9314:1459:8767::::::|h[Rionthus's Bladed Visage]|h|r",
					["serverTime"] = 1695854181,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						52, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66499.53,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [71]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:37:00]|h|r |cffff80ff|Htransmogappearance:185517|h[Rionthus's Bladed Visage]|h|r has been added to your appearance collection.",
					["serverTime"] = 1695854182,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66499.87700000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [72]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:37:09]|h|r |HlootHistory:2693|h[Loot]|h: |cffa5a5a5Aleyla|r (Need - 91, Main-Spec) Won: |cffa335ee|Hitem:204318::::::::70:581::4:5:6652:9411:9314:1459:8767::::::|h[Thadrion's Erratic Arcanotrode]|h|r",
					["serverTime"] = 1695854191,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						190, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66509.62,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [73]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:37:10]|h|r |cffa5a5a5Aleyla|r-WyrmrestAccord receives loot: |cffa335ee|Hitem:204318::::::::70:581::4:5:6652:9411:9314:1459:8767::::::|h[Thadrion's Erratic Arcanotrode]|h|r.",
					["serverTime"] = 1695854192,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						240, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66509.77,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [74]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:37:38]|h|r |cffa5a5a5Aleyla|r-WyrmrestAccord has left the instance group.",
					["serverTime"] = 1695854220,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66538.45300000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [75]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:38:57]|h|r You are now Away: AFK",
					["serverTime"] = 1695854299,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66617.19,
					["g"] = 1,
					["b"] = 0,
				}, -- [76]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:39:28]|h|r |cffff80ff|Htransmogappearance:185517|h[Rionthus's Bladed Visage]|h|r has been added to your appearance collection.",
					["serverTime"] = 1695854330,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66647.996,
					["g"] = 1,
					["b"] = 0,
				}, -- [77]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:25:26]|h|r [S] |cffd8d8d8[|r|Hplayer:Diresteaks-Thrall:4920:SAY|h|cffd8bc3f70|r:|cffc69b6dDiresteaks|r-|cff1dfd54Thr|r:2|h|cffd8d8d8]|r: 3",
					["serverTime"] = 1695853488,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						250, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65806.164,
					["g"] = 1,
					["b"] = 1,
				}, -- [78]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:25:26]|h|r [S] |cffd8d8d8[|r|Hplayer:Snøwhite-Nordrassil:4921:SAY|h|cffd8bc3f70|r:|cffa330c9Snøwhite|r-|cffc95863Nor|r:1|h|cffd8d8d8]|r: 3",
					["serverTime"] = 1695853488,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						285, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65806.164,
					["g"] = 1,
					["b"] = 1,
				}, -- [79]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:25:26]|h|r [S] |cffd8d8d8[|r|Hplayer:Grica-Trollbane:4922:SAY|h|cffd8bc3f70|r:|cffffffffGrica|r-|cff6ff9c3Tro|r:1|h|cffd8d8d8]|r: 3",
					["serverTime"] = 1695853488,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						272, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65806.164,
					["g"] = 1,
					["b"] = 1,
				}, -- [80]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:25:27]|h|r [S] |cffd8d8d8[|r|Hplayer:Allaeda-Mal'Ganis:4923:SAY|h|cffd8bc3f70|r:|cffa330c9Allaeda|r:4|h|cffd8d8d8]|r: 2",
					["serverTime"] = 1695853489,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						104, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65807.181,
					["g"] = 1,
					["b"] = 1,
				}, -- [81]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:25:28]|h|r [S] |cffd8d8d8[|r|Hplayer:Allaeda-Mal'Ganis:4924:SAY|h|cffd8bc3f70|r:|cffa330c9Allaeda|r:4|h|cffd8d8d8]|r: 1",
					["serverTime"] = 1695853490,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						104, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65808.05,
					["g"] = 1,
					["b"] = 1,
				}, -- [82]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:25:28]|h|r [S] |cffd8d8d8[|r|Hplayer:Snøwhite-Nordrassil:4925:SAY|h|cffd8bc3f70|r:|cffa330c9Snøwhite|r-|cffc95863Nor|r:1|h|cffd8d8d8]|r: 1",
					["serverTime"] = 1695853490,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						285, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65808.254,
					["g"] = 1,
					["b"] = 1,
				}, -- [83]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:25:41]|h|r |cffa5a5a5Grändeeney|r-Azralon receives loot: |cff9d9d9d|Hitem:193384::::::::70:581:::::::::|h[Crumbling Bone]|h|r.",
					["serverTime"] = 1695853503,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						241, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65821.342,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [84]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:25:43]|h|r |cffa5a5a5Angelofdeãth|r-Dalaran receives loot: |cff1eff00|Hitem:204935::::::::70:581::83:5:6652:9414:9294:9501:1598:1:28:2648:::::|h[Sunless Bracers]|h|r.",
					["serverTime"] = 1695853505,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						262, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65823.625,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [85]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:25:45]|h|r Starting ready check...",
					["serverTime"] = 1695853507,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65824.768,
					["g"] = 1,
					["b"] = 0,
				}, -- [86]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:25:45]|h|r |cffa5a5a5Vierssra|r-Akama receives loot: |cff9d9d9d|Hitem:192614::::::::70:581:::::::::|h[Elemental Ooze]|h|r.",
					["serverTime"] = 1695853507,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						270, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65825.404,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [87]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:25:46]|h|r |cffa5a5a5Vierssra|r-Akama receives loot: |cff0070dd|Hitem:190330::::::::70:581:::::::::|h[Rousing Decay]|h|r.",
					["serverTime"] = 1695853508,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						270, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65825.823,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [88]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:25:46]|h|r |cffa5a5a5Vierssra|r-Akama receives loot: |cff9d9d9d|Hitem:193384::::::::70:581:::::::::|h[Crumbling Bone]|h|r.",
					["serverTime"] = 1695853508,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						270, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65826.543,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [89]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:25:48]|h|r |cffa5a5a5Quinlar|r-WyrmrestAccord is not ready",
					["serverTime"] = 1695853510,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65828.491,
					["g"] = 1,
					["b"] = 0,
				}, -- [90]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:25:49]|h|r |cffa5a5a5Flickers|r-Area52 receives loot: |cff1eff00|Hitem:204945::::::::70:581::83:4:6652:9294:9501:1598:1:28:2648:::::|h[Starless Breastplate]|h|r.",
					["serverTime"] = 1695853511,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						257, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65828.768,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [91]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:25:50]|h|r |cffa5a5a5Erolithien|r-WyrmrestAccord receives loot: |cff9d9d9d|Hitem:192614::::::::70:581:::::::::|h[Elemental Ooze]|h|rx2.",
					["serverTime"] = 1695853512,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						242, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65830.666,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [92]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:25:54]|h|r |cffa5a5a5Meda|r-Area52 receives loot: |cff1eff00|Hitem:204965::::::::70:581::83:4:6652:9294:9501:1598:1:28:2648:::::|h[Neltharic Shield]|h|r.",
					["serverTime"] = 1695853516,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						261, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65834.05500000001,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [93]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:25:57]|h|r |Hchannel:INSTANCE_CHAT|h[I] |h|cffd8d8d8[|r|Hplayer:Kenotah-Illidan:4939:INSTANCE_CHAT|h|cffd8bc3f70|r:|cffffffffKenotah|r-|cff32e983Ill|r:1|h|cffd8d8d8]|r: thanks",
					["serverTime"] = 1695853519,
					["r"] = 1,
					["extraData"] = {
						63, -- [1]
						false, -- [2]
						86, -- [3]
						281, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65836.901,
					["g"] = 0.4980392456054688,
					["b"] = 0,
				}, -- [94]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:26:01]|h|r |Hchannel:INSTANCE_CHAT|h[I] |h|cffd8d8d8[|r|Hplayer:Crazycrits-Azgalor:4941:INSTANCE_CHAT|h|cffd8bc3f70|r:|cff3fc7ebCrazycrits|r-|cff17e7abAzg|r:5|h|cffd8d8d8]|r: NP",
					["serverTime"] = 1695853523,
					["r"] = 1,
					["extraData"] = {
						63, -- [1]
						false, -- [2]
						86, -- [3]
						277, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65841.064,
					["g"] = 0.4980392456054688,
					["b"] = 0,
				}, -- [95]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:26:01]|h|r Your request to kick |cffa5a5a5Tcheemoo|r-BleedingHollow has been successfully received. 4 |4more request is:more requests are; needed to initiate a vote.",
					["serverTime"] = 1695853523,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65841.064,
					["g"] = 1,
					["b"] = 0,
				}, -- [96]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:26:16]|h|r |cffa5a5a5Snøwhite|r-Nordrassil receives loot: |cff1eff00|Hitem:204955::::::::70:581::83:4:6652:9294:9501:1598:1:28:2648:::::|h[Neltharic Beatstick]|h|r.",
					["serverTime"] = 1695853538,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						259, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65856.19,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [97]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:26:17]|h|r |Hchannel:INSTANCE_CHAT|h[I] |h|cffd8d8d8[|r|Hplayer:Erolithien-WyrmrestAccord:4947:INSTANCE_CHAT|h|cffd8bc3f70|r:|cff3fc7ebErolithien|r-|cff96bee2Wyr|r:4|h|cffd8d8d8]|r: not your job to play loot lord it allowed me to roll for it therefore its an upgrade",
					["serverTime"] = 1695853539,
					["r"] = 1,
					["extraData"] = {
						63, -- [1]
						false, -- [2]
						86, -- [3]
						280, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65857.067,
					["g"] = 0.4980392456054688,
					["b"] = 0,
				}, -- [98]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:26:23]|h|r The following players are Away: |cffa5a5a5Tcheemoo|r-BleedingHollow, |cffa5a5a5Quinlar|r-WyrmrestAccord",
					["serverTime"] = 1695853545,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65863.62700000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [99]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:26:29]|h|r |Hchannel:INSTANCE_CHAT|h[I] |h|cffd8d8d8[|r|Hplayer:Crazycrits-Azgalor:4950:INSTANCE_CHAT|h|cffd8bc3f70|r:|cff3fc7ebCrazycrits|r-|cff17e7abAzg|r:5|h|cffd8d8d8]|r: It let me roll too buddy",
					["serverTime"] = 1695853551,
					["r"] = 1,
					["extraData"] = {
						63, -- [1]
						false, -- [2]
						86, -- [3]
						277, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65869.155,
					["g"] = 0.4980392456054688,
					["b"] = 0,
				}, -- [100]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:26:36]|h|r |cffa5a5a5Malthäell|r-Azralon receives loot: |cff9d9d9d|Hitem:192614::::::::70:581:::::::::|h[Elemental Ooze]|h|r.",
					["serverTime"] = 1695853558,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						248, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65876.366,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [101]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:27:10]|h|r [S] |cffd8d8d8[|r|Hplayer:Grändeeney-Azralon:4957:SAY|h|cffd8bc3f70|r:|cff33937fGrändeeney|r-|cffd174a9Azr|r:2|h|cffd8d8d8]|r: Primeira Investida em |cffa5a5a5Grändeeney|r",
					["serverTime"] = 1695853592,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						286, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65910.281,
					["g"] = 1,
					["b"] = 1,
				}, -- [102]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:27:25]|h|r |cffa5a5a5Quinlar|r-WyrmrestAccord has left the instance group.",
					["serverTime"] = 1695853607,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65924.821,
					["g"] = 1,
					["b"] = 0,
				}, -- [103]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:27:56]|h|r |Hchannel:INSTANCE_CHAT|h[I] |h|cffd8d8d8[|r|Hplayer:Crazycrits-Azgalor:4966:INSTANCE_CHAT|h|cffd8bc3f70|r:|cff3fc7ebCrazycrits|r-|cff17e7abAzg|r:5|h|cffd8d8d8]|r: But fuck, I wish Loot Lord was a title",
					["serverTime"] = 1695853638,
					["r"] = 1,
					["extraData"] = {
						63, -- [1]
						false, -- [2]
						86, -- [3]
						277, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65955.741,
					["g"] = 0.4980392456054688,
					["b"] = 0,
				}, -- [104]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:27:57]|h|r You receive loot: |cff0070dd|Hitem:190330::::::::70:581:::::::::|h[Rousing Decay]|h|rx3",
					["serverTime"] = 1695853639,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						51, -- [3]
						52, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65957.409,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [105]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:28:13]|h|r |cffd8d8d8[|r|Hplayer:Maktenshi:4971|h|cffd8bc3f70|r:|cfff48cbaMaktenshi|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1695853655,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 65973.43000000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [106]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:29:06]|h|r [S] |cffd8d8d8[|r|Hplayer:Grändeeney-Azralon:4981:SAY|h|cffd8bc3f70|r:|cff33937fGrändeeney|r-|cffd174a9Azr|r:2|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t 11 |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t",
					["serverTime"] = 1695853708,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						286, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66026.522,
					["g"] = 1,
					["b"] = 1,
				}, -- [107]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:29:36]|h|r [S] |cffd8d8d8[|r|Hplayer:Aleyla-WyrmrestAccord:4987:SAY|h|cffd8bc3f70|r:|cffffffffAleyla|r-|cff96bee2Wyr|r:5|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t 11 |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t",
					["serverTime"] = 1695853738,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						284, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66056.087,
					["g"] = 1,
					["b"] = 1,
				}, -- [108]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:29:38]|h|r [S] |cffd8d8d8[|r|Hplayer:Aleyla-WyrmrestAccord:4988:SAY|h|cffd8bc3f70|r:|cffffffffAleyla|r-|cff96bee2Wyr|r:5|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t 12 |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t",
					["serverTime"] = 1695853740,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						284, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66058.123,
					["g"] = 1,
					["b"] = 1,
				}, -- [109]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:29:40]|h|r [S] |cffd8d8d8[|r|Hplayer:Aleyla-WyrmrestAccord:4990:SAY|h|cffd8bc3f70|r:|cffffffffAleyla|r-|cff96bee2Wyr|r:5|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t 13 |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t",
					["serverTime"] = 1695853742,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						284, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66060.125,
					["g"] = 1,
					["b"] = 1,
				}, -- [110]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:29:42]|h|r [S] |cffd8d8d8[|r|Hplayer:Hölycöw-Akama:4991:SAY|h|cffd8bc3f70|r:|cffffffffHölycöw|r-|cffe3caf7Aka|r:4|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t 13 |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t",
					["serverTime"] = 1695853744,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						254, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66061.788,
					["g"] = 1,
					["b"] = 1,
				}, -- [111]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:29:42]|h|r [S] |cffd8d8d8[|r|Hplayer:Aleyla-WyrmrestAccord:4992:SAY|h|cffd8bc3f70|r:|cffffffffAleyla|r-|cff96bee2Wyr|r:5|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t 14 |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t",
					["serverTime"] = 1695853744,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						284, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66062.098,
					["g"] = 1,
					["b"] = 1,
				}, -- [112]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:29:43]|h|r [S] |cffd8d8d8[|r|Hplayer:Hölycöw-Akama:4993:SAY|h|cffd8bc3f70|r:|cffffffffHölycöw|r-|cffe3caf7Aka|r:4|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t 14 |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t",
					["serverTime"] = 1695853745,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						254, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66063.704,
					["g"] = 1,
					["b"] = 1,
				}, -- [113]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:29:44]|h|r [S] |cffd8d8d8[|r|Hplayer:Aleyla-WyrmrestAccord:4994:SAY|h|cffd8bc3f70|r:|cffffffffAleyla|r-|cff96bee2Wyr|r:5|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t 15 |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t",
					["serverTime"] = 1695853746,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						284, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66063.928,
					["g"] = 1,
					["b"] = 1,
				}, -- [114]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:29:46]|h|r [S] |cffd8d8d8[|r|Hplayer:Aleyla-WyrmrestAccord:4995:SAY|h|cffd8bc3f70|r:|cffffffffAleyla|r-|cff96bee2Wyr|r:5|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t 16 |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t",
					["serverTime"] = 1695853748,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						284, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66066.145,
					["g"] = 1,
					["b"] = 1,
				}, -- [115]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:29:48]|h|r [S] |cffd8d8d8[|r|Hplayer:Aleyla-WyrmrestAccord:4998:SAY|h|cffd8bc3f70|r:|cffffffffAleyla|r-|cff96bee2Wyr|r:5|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t 17 |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t",
					["serverTime"] = 1695853750,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						284, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66067.951,
					["g"] = 1,
					["b"] = 1,
				}, -- [116]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:29:50]|h|r [S] |cffd8d8d8[|r|Hplayer:Aleyla-WyrmrestAccord:4999:SAY|h|cffd8bc3f70|r:|cffffffffAleyla|r-|cff96bee2Wyr|r:5|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t 18 |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t",
					["serverTime"] = 1695853752,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						284, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66070.014,
					["g"] = 1,
					["b"] = 1,
				}, -- [117]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:29:52]|h|r [S] |cffd8d8d8[|r|Hplayer:Aleyla-WyrmrestAccord:5000:SAY|h|cffd8bc3f70|r:|cffffffffAleyla|r-|cff96bee2Wyr|r:5|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t 19 |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t",
					["serverTime"] = 1695853754,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						284, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66072.1,
					["g"] = 1,
					["b"] = 1,
				}, -- [118]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:29:54]|h|r [S] |cffd8d8d8[|r|Hplayer:Aleyla-WyrmrestAccord:5001:SAY|h|cffd8bc3f70|r:|cffffffffAleyla|r-|cff96bee2Wyr|r:5|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t 20 |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t",
					["serverTime"] = 1695853756,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						284, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66074.02100000001,
					["g"] = 1,
					["b"] = 1,
				}, -- [119]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:29:56]|h|r [S] |cffd8d8d8[|r|Hplayer:Aleyla-WyrmrestAccord:5003:SAY|h|cffd8bc3f70|r:|cffffffffAleyla|r-|cff96bee2Wyr|r:5|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t 21 |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t",
					["serverTime"] = 1695853758,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						284, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66075.971,
					["g"] = 1,
					["b"] = 1,
				}, -- [120]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:29:58]|h|r [S] |cffd8d8d8[|r|Hplayer:Aleyla-WyrmrestAccord:5006:SAY|h|cffd8bc3f70|r:|cffffffffAleyla|r-|cff96bee2Wyr|r:5|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t 22 |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t",
					["serverTime"] = 1695853760,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						284, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66078.11200000001,
					["g"] = 1,
					["b"] = 1,
				}, -- [121]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:18]|h|r [S] |cffd8d8d8[|r|Hplayer:Aleyla-WyrmrestAccord:5010:SAY|h|cffd8bc3f70|r:|cffffffffAleyla|r-|cff96bee2Wyr|r:5|h|cffd8d8d8]|r: Disintegrate",
					["serverTime"] = 1695853780,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						284, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66098.119,
					["g"] = 1,
					["b"] = 1,
				}, -- [122]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:18]|h|r [S] |cffd8d8d8[|r|Hplayer:Jabrule-Illidan:5011:SAY|h|cffd8bc3f70|r:|cff0070ddJabrule|r-|cff32e983Ill|r:2|h|cffd8d8d8]|r: Disintegrate",
					["serverTime"] = 1695853780,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						253, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66098.119,
					["g"] = 1,
					["b"] = 1,
				}, -- [123]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:18]|h|r [S] |cffd8d8d8[|r|Hplayer:Hölycöw-Akama:5012:SAY|h|cffd8bc3f70|r:|cffffffffHölycöw|r-|cffe3caf7Aka|r:4|h|cffd8d8d8]|r: Disintegrate",
					["serverTime"] = 1695853780,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						254, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66098.119,
					["g"] = 1,
					["b"] = 1,
				}, -- [124]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:46]|h|r |cffa5a5a5Erolithien|r has died.",
					["serverTime"] = 1695853808,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66126.23,
					["g"] = 1,
					["b"] = 0,
				}, -- [125]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:46]|h|r |cffa5a5a5Flickers|r has died.",
					["serverTime"] = 1695853808,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66126.439,
					["g"] = 1,
					["b"] = 0,
				}, -- [126]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:02]|h|r [S] |cffd8d8d8[|r|Hplayer:Meda-Area52:5019:SAY|h|cffd8bc3f70|r:|cffaad372Meda|r-|cff64968eAre|r:3|h|cffd8d8d8]|r: Disintegrate",
					["serverTime"] = 1695853824,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						287, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66142.003,
					["g"] = 1,
					["b"] = 1,
				}, -- [127]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:02]|h|r [S] |cffd8d8d8[|r|Hplayer:Diresteaks-Thrall:5020:SAY|h|cffd8bc3f70|r:|cffc69b6dDiresteaks|r-|cff1dfd54Thr|r:2|h|cffd8d8d8]|r: Disintegrate",
					["serverTime"] = 1695853824,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						250, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66142.003,
					["g"] = 1,
					["b"] = 1,
				}, -- [128]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame9"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame1"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 39,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Malthäell-Azralon:5045:ACHIEVEMENT|h|cffd8bc3f70|r:|cffffffffMalthäell|r-|cffd174a9Azr|r:2|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-3209-0BB6DF63:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						298, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:25]|h|r Received 280 Gold, 90 Silver.",
					["serverTime"] = 1695853907,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.726,
					["g"] = 1,
					["b"] = 0,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:25]|h|r |cffff7d0a<|r|cffffd200DBM|r|cffff7d0a>|r Looking For Raid - The Forgotten Experiments down after 6 |4minute:minutes; and 9.05 |4second:seconds;!",
					["r"] = 0.41,
					["serverTime"] = 1695853907,
					["timestamp"] = 66225.397,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:26]|h|r |cffd8d8d8[|r|Hplayer:Allaeda-Mal'Ganis:5055:GUILD|h|cffd8bc3f70|r:|cffa330c9Allaeda|r:4|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:1181:Player-3684-08CEF40C:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Got My Mind On My Money]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853908,
					["r"] = 0.250980406999588,
					["extraData"] = {
						48, -- [1]
						false, -- [2]
						78, -- [3]
						79, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66226.171,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:26]|h|r |cffd8d8d8[|r|Hplayer:Allaeda-Mal'Ganis:5056:ACHIEVEMENT|h|cffd8bc3f70|r:|cffa330c9Allaeda|r:4|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:1181:Player-3684-08CEF40C:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Got My Mind On My Money]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853908,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						82, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66226.171,
					["g"] = 1,
					["b"] = 0,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:26]|h|r |cffd8d8d8[|r|Hplayer:Crazycrits-Azgalor:5057:ACHIEVEMENT|h|cffd8bc3f70|r:|cff3fc7ebCrazycrits|r-|cff17e7abAzg|r:5|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:1181:Player-77-0196ADCF:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Got My Mind On My Money]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853908,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						299, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66226.414,
					["g"] = 1,
					["b"] = 0,
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:36]|h|r |cffa5a5a5Tcheemoo|r-BleedingHollow has left the instance group.",
					["serverTime"] = 1695853918,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66236.018,
					["g"] = 1,
					["b"] = 0,
				}, -- [7]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:45]|h|r |cffa5a5a5Darlys|r-Area52 has left the instance group.",
					["serverTime"] = 1695853927,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66245.50200000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:47]|h|r |cffa5a5a5Meda|r-Area52 has left the instance group.",
					["serverTime"] = 1695853929,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66246.887,
					["g"] = 1,
					["b"] = 0,
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:47]|h|r Neltharion says: Your performance is beyond my expectations.",
					["serverTime"] = 1695853929,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66247.489,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:49]|h|r |cffa5a5a5Vierssra|r-Akama has left the instance group.",
					["serverTime"] = 1695853931,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66249.658,
					["g"] = 1,
					["b"] = 0,
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:51]|h|r Wrathion says: Wait. You knew these creatures were waiting to be unleashed?",
					["serverTime"] = 1695853933,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66251.366,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:55]|h|r |cffa5a5a5Phenanthrene|r-Frostwolf has left the instance group.",
					["serverTime"] = 1695853937,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66255.166,
					["g"] = 1,
					["b"] = 0,
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:55]|h|r Neltharion says: Of course! And you rose to the challenge, as I knew you would.",
					["serverTime"] = 1695853937,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66255.285,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:59]|h|r Wrathion says: This all seems... questionable. How malleable is this vision of yours?",
					["serverTime"] = 1695853941,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66259.685,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:00]|h|r |cfff48cbaMaktenshi|r has gone offline.",
					["serverTime"] = 1695853942,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66260.023,
					["g"] = 1,
					["b"] = 0,
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:06]|h|r Neltharion says: I was afraid of this. The process used to create you weakened your spirit. An issue I doubt I'll have with my true born heir.",
					["serverTime"] = 1695853948,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66266.335,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [17]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:08]|h|r |cffa5a5a5Ballsy|r-BleedingHollow has left the instance group.",
					["serverTime"] = 1695853950,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66268.352,
					["g"] = 1,
					["b"] = 0,
				}, -- [18]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:09]|h|r |cff3fc7ebDeradis|r has left the instance group.",
					["serverTime"] = 1695853951,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66269.4,
					["g"] = 1,
					["b"] = 0,
				}, -- [19]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:09]|h|r |cffa5a5a5Kenotah|r-Illidan has left the instance group.",
					["serverTime"] = 1695853951,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66269.464,
					["g"] = 1,
					["b"] = 0,
				}, -- [20]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:09]|h|r |cffa5a5a5Malthäell|r-Azralon has left the instance group.",
					["serverTime"] = 1695853951,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66269.531,
					["g"] = 1,
					["b"] = 0,
				}, -- [21]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:10]|h|r |cffa5a5a5Grändeeney|r-Azralon has left the instance group.",
					["serverTime"] = 1695853952,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66269.731,
					["g"] = 1,
					["b"] = 0,
				}, -- [22]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:11]|h|r |cffa5a5a5Flickers|r-Area52 has left the instance group.",
					["serverTime"] = 1695853953,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66271.471,
					["g"] = 1,
					["b"] = 0,
				}, -- [23]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:12]|h|r |cffa5a5a5Hölycöw|r-Akama has left the instance group.",
					["serverTime"] = 1695853954,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66272.355,
					["g"] = 1,
					["b"] = 0,
				}, -- [24]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:12]|h|r |cffa5a5a5Crazycrits|r-Azgalor has left the instance group.",
					["serverTime"] = 1695853954,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66272.404,
					["g"] = 1,
					["b"] = 0,
				}, -- [25]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:12]|h|r |cffa5a5a5Dubwubz|r-Illidan has left the instance group.",
					["serverTime"] = 1695853954,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66272.458,
					["g"] = 1,
					["b"] = 0,
				}, -- [26]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:12]|h|r |cffa5a5a5Diresteaks|r-Thrall has left the instance group.",
					["serverTime"] = 1695853954,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66272.458,
					["g"] = 1,
					["b"] = 0,
				}, -- [27]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:23]|h|r |cffa5a5a5Grica|r-Trollbane has left the instance group.",
					["serverTime"] = 1695853965,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66283.436,
					["g"] = 1,
					["b"] = 0,
				}, -- [28]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:29]|h|r |cffa5a5a5Snøwhite|r-Nordrassil has left the instance group.",
					["serverTime"] = 1695853971,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66288.97,
					["g"] = 1,
					["b"] = 0,
				}, -- [29]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:32]|h|r |cffa5a5a5Jabrule|r-Illidan has left the instance group.",
					["serverTime"] = 1695853974,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66292.499,
					["g"] = 1,
					["b"] = 0,
				}, -- [30]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:33]|h|r |cffa5a5a5Ologh|r-Nordrassil has left the instance group.",
					["serverTime"] = 1695853975,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66293.16100000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [31]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:33:54]|h|r |cffa5a5a5Erolithien|r-WyrmrestAccord has left the instance group.",
					["serverTime"] = 1695853996,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66314.599,
					["g"] = 1,
					["b"] = 0,
				}, -- [32]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:34:18]|h|r |cffa5a5a5Murcièlagö|r-Barthilas has left the instance group.",
					["serverTime"] = 1695854020,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66338.705,
					["g"] = 1,
					["b"] = 0,
				}, -- [33]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:36:56]|h|r |cffa5a5a5Angelofdeãth|r-Dalaran has left the instance group.",
					["serverTime"] = 1695854178,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66496.62,
					["g"] = 1,
					["b"] = 0,
				}, -- [34]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:37:00]|h|r |cffff80ff|Htransmogappearance:185517|h[Rionthus's Bladed Visage]|h|r has been added to your appearance collection.",
					["serverTime"] = 1695854182,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66499.87700000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [35]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:37:33]|h|r |TInterface\\FriendsFrame\\UI-Toast-ToastIcons.tga:16:16:0:0:128:64:2:29:34:61|t|HBNplayer:|Kq47|k:33:5109:BN_INLINE_TOAST_ALERT:0|h[|Kq47|k]|h has gone offline.",
					["serverTime"] = 1695854215,
					["r"] = 0.5098039507865906,
					["extraData"] = {
						54, -- [1]
						false, -- [2]
						220, -- [3]
						221, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66533.715,
					["g"] = 0.7725490927696228,
					["b"] = 1,
				}, -- [36]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:37:38]|h|r |cffa5a5a5Aleyla|r-WyrmrestAccord has left the instance group.",
					["serverTime"] = 1695854220,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66538.45300000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [37]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:38:57]|h|r You are now Away: AFK",
					["serverTime"] = 1695854299,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66617.19,
					["g"] = 1,
					["b"] = 0,
				}, -- [38]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:39:28]|h|r |cffff80ff|Htransmogappearance:185517|h[Rionthus's Bladed Visage]|h|r has been added to your appearance collection.",
					["serverTime"] = 1695854330,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66647.996,
					["g"] = 1,
					["b"] = 0,
				}, -- [39]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:29:50]|h|r [S] |cffd8d8d8[|r|Hplayer:Aleyla-WyrmrestAccord:4999:SAY|h|cffd8bc3f70|r:|cffffffffAleyla|r-|cff96bee2Wyr|r:5|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t 18 |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t",
					["serverTime"] = 1695853752,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						284, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66070.014,
					["g"] = 1,
					["b"] = 1,
				}, -- [40]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:29:52]|h|r [S] |cffd8d8d8[|r|Hplayer:Aleyla-WyrmrestAccord:5000:SAY|h|cffd8bc3f70|r:|cffffffffAleyla|r-|cff96bee2Wyr|r:5|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t 19 |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t",
					["serverTime"] = 1695853754,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						284, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66072.1,
					["g"] = 1,
					["b"] = 1,
				}, -- [41]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:29:54]|h|r [S] |cffd8d8d8[|r|Hplayer:Aleyla-WyrmrestAccord:5001:SAY|h|cffd8bc3f70|r:|cffffffffAleyla|r-|cff96bee2Wyr|r:5|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t 20 |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t",
					["serverTime"] = 1695853756,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						284, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66074.02100000001,
					["g"] = 1,
					["b"] = 1,
				}, -- [42]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:29:56]|h|r [S] |cffd8d8d8[|r|Hplayer:Aleyla-WyrmrestAccord:5003:SAY|h|cffd8bc3f70|r:|cffffffffAleyla|r-|cff96bee2Wyr|r:5|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t 21 |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t",
					["serverTime"] = 1695853758,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						284, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66075.971,
					["g"] = 1,
					["b"] = 1,
				}, -- [43]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:29:56]|h|r Thadrion yells: Crushed you.",
					["serverTime"] = 1695853758,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						67, -- [3]
						68, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66076.242,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [44]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:29:58]|h|r [S] |cffd8d8d8[|r|Hplayer:Aleyla-WyrmrestAccord:5006:SAY|h|cffd8bc3f70|r:|cffffffffAleyla|r-|cff96bee2Wyr|r:5|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t 22 |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2:0|t",
					["serverTime"] = 1695853760,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						284, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66078.11200000001,
					["g"] = 1,
					["b"] = 1,
				}, -- [45]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:29:59]|h|r Zskarn says: Sadly a creature with unstable arcane surges was useless, so we refined the infusion process.",
					["serverTime"] = 1695853761,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						63, -- [3]
						64, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66079.50600000001,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [46]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:09]|h|r Rionthus yells: Die, lesser things!",
					["serverTime"] = 1695853771,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						67, -- [3]
						68, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66089.23300000001,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [47]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:10]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (1)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853772,
					["timestamp"] = 66090.473,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [48]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:13]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (2)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853775,
					["timestamp"] = 66093.471,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [49]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:15]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (3)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853777,
					["timestamp"] = 66094.971,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [50]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:16]|h|r Rionthus yells: Blasted to nothing.",
					["serverTime"] = 1695853778,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						67, -- [3]
						68, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66096.135,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [51]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:16]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4638528:12:12|t |cffff1a1aInfused Explosion (1)|r |T4638528:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853778,
					["timestamp"] = 66096.45300000001,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [52]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:18]|h|r [S] |cffd8d8d8[|r|Hplayer:Aleyla-WyrmrestAccord:5010:SAY|h|cffd8bc3f70|r:|cffffffffAleyla|r-|cff96bee2Wyr|r:5|h|cffd8d8d8]|r: Disintegrate",
					["serverTime"] = 1695853780,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						284, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66098.119,
					["g"] = 1,
					["b"] = 1,
				}, -- [53]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:18]|h|r [S] |cffd8d8d8[|r|Hplayer:Jabrule-Illidan:5011:SAY|h|cffd8bc3f70|r:|cff0070ddJabrule|r-|cff32e983Ill|r:2|h|cffd8d8d8]|r: Disintegrate",
					["serverTime"] = 1695853780,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						253, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66098.119,
					["g"] = 1,
					["b"] = 1,
				}, -- [54]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:18]|h|r [S] |cffd8d8d8[|r|Hplayer:Hölycöw-Akama:5012:SAY|h|cffd8bc3f70|r:|cffffffffHölycöw|r-|cffe3caf7Aka|r:4|h|cffd8d8d8]|r: Disintegrate",
					["serverTime"] = 1695853780,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						254, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66098.119,
					["g"] = 1,
					["b"] = 1,
				}, -- [55]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:21]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (1)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853783,
					["timestamp"] = 66100.975,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [56]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:22]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (2)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853784,
					["timestamp"] = 66102.478,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [57]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:24]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (3)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853786,
					["timestamp"] = 66103.963,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [58]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:25]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (4)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853787,
					["timestamp"] = 66105.485,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [59]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:27]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4630480:12:12|t |cffff8000Casting Temporal Anomaly: 2.0 sec|r |T4630480:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853789,
					["timestamp"] = 66106.848,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [60]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:27]|h|r Rionthus yells: Perfection incarnate.",
					["serverTime"] = 1695853789,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						67, -- [3]
						68, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66107.109,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [61]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:29]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4638528:12:12|t |cffff1a1aInfused Explosion (2)|r |T4638528:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853791,
					["timestamp"] = 66108.842,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [62]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:30]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (1)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853792,
					["timestamp"] = 66110.385,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [63]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:32]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (2)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853794,
					["timestamp"] = 66111.879,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [64]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:33]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (3)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853795,
					["timestamp"] = 66113.379,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [65]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:35]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (4)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853797,
					["timestamp"] = 66114.914,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [66]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:36]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (5)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853798,
					["timestamp"] = 66116.404,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [67]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:38]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (6)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853800,
					["timestamp"] = 66117.909,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [68]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:40]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r |cffffb200[Special Warning]  |T4622450:12:12|t Breath (1) - dodge attack |T4622450:12:12|t |r",
					["r"] = 0.41,
					["serverTime"] = 1695853802,
					["timestamp"] = 66120.195,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [69]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:40]|h|r |TInterface\\Icons\\Ability_Evoker_DeepBreath.blp:20|tRionthus prepares to take in a |cFFFF0000|Hspell:406227|h[Deep Breath]|h|r!",
					["serverTime"] = 1695853802,
					["r"] = 1,
					["extraData"] = {
						42, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66120.338,
					["g"] = 0.8666667342185974,
					["b"] = 0,
				}, -- [70]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:41]|h|r Rionthus yells: Say goodbye.",
					["serverTime"] = 1695853803,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						67, -- [3]
						68, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66121.47,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [71]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:42]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4638528:12:12|t |cffff1a1aInfused Explosion (3)|r |T4638528:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853804,
					["timestamp"] = 66122.57800000001,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [72]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:46]|h|r |cffa5a5a5Erolithien|r has died.",
					["serverTime"] = 1695853808,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66126.23,
					["g"] = 1,
					["b"] = 0,
				}, -- [73]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:46]|h|r |cffa5a5a5Flickers|r has died.",
					["serverTime"] = 1695853808,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66126.439,
					["g"] = 1,
					["b"] = 0,
				}, -- [74]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:53]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (1)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853815,
					["timestamp"] = 66133.417,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [75]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:55]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (2)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853817,
					["timestamp"] = 66134.924,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [76]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:56]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (3)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853818,
					["timestamp"] = 66136.412,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [77]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:58]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (4)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853820,
					["timestamp"] = 66137.91,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [78]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:30:59]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (5)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853821,
					["timestamp"] = 66139.427,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [79]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:00]|h|r Rionthus yells: You will be erased.",
					["serverTime"] = 1695853822,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						67, -- [3]
						68, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66139.967,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [80]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:02]|h|r [S] |cffd8d8d8[|r|Hplayer:Meda-Area52:5019:SAY|h|cffd8bc3f70|r:|cffaad372Meda|r-|cff64968eAre|r:3|h|cffd8d8d8]|r: Disintegrate",
					["serverTime"] = 1695853824,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						287, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66142.003,
					["g"] = 1,
					["b"] = 1,
				}, -- [81]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:02]|h|r [S] |cffd8d8d8[|r|Hplayer:Diresteaks-Thrall:5020:SAY|h|cffd8bc3f70|r:|cffc69b6dDiresteaks|r-|cff1dfd54Thr|r:2|h|cffd8d8d8]|r: Disintegrate",
					["serverTime"] = 1695853824,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						250, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66142.003,
					["g"] = 1,
					["b"] = 1,
				}, -- [82]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:02]|h|r [S] |cffd8d8d8[|r|Hplayer:Grica-Trollbane:5021:SAY|h|cffd8bc3f70|r:|cffffffffGrica|r-|cff6ff9c3Tro|r:1|h|cffd8d8d8]|r: Disintegrate",
					["serverTime"] = 1695853824,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						272, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66142.003,
					["g"] = 1,
					["b"] = 1,
				}, -- [83]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:04]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r |cffffb200[Special Warning]  |T4622447:12:12|t 6 stacks of Infused Strikes on you |T4622447:12:12|t |r",
					["r"] = 0.41,
					["serverTime"] = 1695853826,
					["timestamp"] = 66144.682,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [84]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:06]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r |cffffb200[Special Warning]  |T4622447:12:12|t 7 stacks of Infused Strikes on you |T4622447:12:12|t |r",
					["r"] = 0.41,
					["serverTime"] = 1695853828,
					["timestamp"] = 66146.209,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [85]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:11]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Snøwhite*|r|cfff2f200 (3)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853833,
					["timestamp"] = 66151.206,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [86]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:12]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4630480:12:12|t |cffff8000Casting Temporal Anomaly: 2.0 sec|r |T4630480:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853834,
					["timestamp"] = 66151.812,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [87]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:12]|h|r Rionthus yells: Perfection incarnate.",
					["serverTime"] = 1695853834,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						67, -- [3]
						68, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66152.037,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [88]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:12]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4630480:12:12|t |cfff2f200Temporal Anomaly on |r|cfff2f200Rionthus|r|cfff2f200|r |T4630480:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853834,
					["timestamp"] = 66152.454,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [89]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:18]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r |cffffb200[Special Warning]  |T4622447:12:12|t Infused Strikes - move to |r|cffa330c9Snøwhite*|r|cffffb200 |T4622447:12:12|t |r",
					["r"] = 0.41,
					["serverTime"] = 1695853840,
					["timestamp"] = 66158.331,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [90]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:23]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r |cffffb200[Special Warning]  |T4622450:12:12|t Breath (2) - dodge attack |T4622450:12:12|t |r",
					["r"] = 0.41,
					["serverTime"] = 1695853845,
					["timestamp"] = 66162.73700000001,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [91]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:23]|h|r |TInterface\\Icons\\Ability_Evoker_DeepBreath.blp:20|tRionthus prepares to take in a |cFFFF0000|Hspell:406227|h[Deep Breath]|h|r!",
					["serverTime"] = 1695853845,
					["r"] = 1,
					["extraData"] = {
						42, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66162.88,
					["g"] = 0.8666667342185974,
					["b"] = 0,
				}, -- [92]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:24]|h|r Rionthus yells: Incinerate from above!",
					["serverTime"] = 1695853846,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						67, -- [3]
						68, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66164.189,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [93]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:25]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4638528:12:12|t |cffff1a1aInfused Explosion (1)|r |T4638528:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853847,
					["timestamp"] = 66165.679,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [94]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:39]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Snøwhite*|r|cfff2f200 (3)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853861,
					["timestamp"] = 66179.11,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [95]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:43]|h|r Rionthus yells: You will be erased.",
					["serverTime"] = 1695853865,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						67, -- [3]
						68, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66183.63100000001,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [96]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:45]|h|r [S] |cffd8d8d8[|r|Hplayer:Angelofdeãth-Dalaran:5026:SAY|h|cffd8bc3f70|r:|cffc41e3aAngelofdeãth|r-|cff00fc9cDal|r:3|h|cffd8d8d8]|r: Disintegrate",
					["serverTime"] = 1695853867,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						76, -- [3]
						251, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66185.507,
					["g"] = 1,
					["b"] = 1,
				}, -- [97]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:48]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r |cffffb200[Special Warning]  |T4622447:12:12|t Infused Strikes on |r|cffa330c9Snøwhite*|r|cffffb200 - taunt now |T4622447:12:12|t |r",
					["r"] = 0.41,
					["serverTime"] = 1695853870,
					["timestamp"] = 66188.406,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [98]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:53]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r |cffffb200[Special Warning]  |T4622447:12:12|t Infused Strikes on |r|cffa330c9Snøwhite*|r|cffffb200 - taunt now |T4622447:12:12|t |r",
					["r"] = 0.41,
					["serverTime"] = 1695853875,
					["timestamp"] = 66192.903,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [99]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:55]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4630480:12:12|t |cffff8000Casting Temporal Anomaly: 2.0 sec|r |T4630480:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853877,
					["timestamp"] = 66195.50200000001,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [100]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:55]|h|r Rionthus yells: Perfection incarnate.",
					["serverTime"] = 1695853877,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						67, -- [3]
						68, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66195.719,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [101]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:31:59]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (1)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853881,
					["timestamp"] = 66199,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [102]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:00]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (2)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853882,
					["timestamp"] = 66200.512,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [103]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:02]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (3)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853884,
					["timestamp"] = 66202.025,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [104]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:02]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4638528:12:12|t |cffff1a1aInfused Explosion (1)|r |T4638528:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853884,
					["timestamp"] = 66202.051,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [105]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:03]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (1)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853885,
					["timestamp"] = 66203.516,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [106]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:05]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (2)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853887,
					["timestamp"] = 66205.027,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [107]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:06]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r |cffffb200[Special Warning]  |T4622450:12:12|t Breath (3) - dodge attack |T4622450:12:12|t |r",
					["r"] = 0.41,
					["serverTime"] = 1695853888,
					["timestamp"] = 66206.448,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [108]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:06]|h|r |TInterface\\Icons\\Ability_Evoker_DeepBreath.blp:20|tRionthus prepares to take in a |cFFFF0000|Hspell:406227|h[Deep Breath]|h|r!",
					["serverTime"] = 1695853888,
					["r"] = 1,
					["extraData"] = {
						42, -- [1]
						false, -- [2]
						69, -- [3]
						70, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66206.62,
					["g"] = 0.8666667342185974,
					["b"] = 0,
				}, -- [109]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:08]|h|r Rionthus yells: Incinerate from above!",
					["serverTime"] = 1695853890,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						67, -- [3]
						68, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66207.868,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [110]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:20]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (3)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853902,
					["timestamp"] = 66219.794,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [111]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:21]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (4)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853903,
					["timestamp"] = 66221.293,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [112]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:23]|h|r |cffff7d0a<|r|cffffd200The Forgotten Experiments|r|cffff7d0a>|r  |T4622447:12:12|t |cfff2f200Infused Strikes on |r|cffa330c9Allaeda|r|cfff2f200 (5)|r |T4622447:12:12|t ",
					["r"] = 0.41,
					["serverTime"] = 1695853905,
					["timestamp"] = 66222.793,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [113]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Allaeda-Mal'Ganis:5030:GUILD|h|cffd8bc3f70|r:|cffa330c9Allaeda|r:4|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-3684-08CEF40C:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 0.250980406999588,
					["extraData"] = {
						48, -- [1]
						false, -- [2]
						78, -- [3]
						79, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [114]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r Rionthus yells: I... cannot... fail...",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						false, -- [2]
						67, -- [3]
						68, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [115]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Grändeeney-Azralon:5032:ACHIEVEMENT|h|cffd8bc3f70|r:|cff33937fGrändeeney|r-|cffd174a9Azr|r:2|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-3209-0BB6DF00:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						288, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [116]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Snøwhite-Nordrassil:5033:ACHIEVEMENT|h|cffd8bc3f70|r:|cffa330c9Snøwhite|r-|cffc95863Nor|r:1|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-121-0A8894BD:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						258, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [117]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Angelofdeãth-Dalaran:5034:ACHIEVEMENT|h|cffd8bc3f70|r:|cffc41e3aAngelofdeãth|r-|cff00fc9cDal|r:3|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-3683-0D8002FD:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						289, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [118]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Kenotah-Illidan:5035:ACHIEVEMENT|h|cffd8bc3f70|r:|cffffffffKenotah|r-|cff32e983Ill|r:1|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-57-0A080377:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						290, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [119]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Erolithien-WyrmrestAccord:5036:ACHIEVEMENT|h|cffd8bc3f70|r:|cff3fc7ebErolithien|r-|cff96bee2Wyr|r:4|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18160:Player-1171-071D6B57:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff(|rCompleted 5/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						291, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [120]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Erolithien-WyrmrestAccord:5037:ACHIEVEMENT|h|cffd8bc3f70|r:|cff3fc7ebErolithien|r-|cff96bee2Wyr|r:4|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-1171-071D6B57:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						291, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [121]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Aleyla-WyrmrestAccord:5038:ACHIEVEMENT|h|cffd8bc3f70|r:|cffffffffAleyla|r-|cff96bee2Wyr|r:5|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-1171-0AB24417:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						292, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [122]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Meda-Area52:5039:ACHIEVEMENT|h|cffd8bc3f70|r:|cffaad372Meda|r-|cff64968eAre|r:3|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-3676-0CB75B48:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						293, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [123]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Dubwubz-Illidan:5040:ACHIEVEMENT|h|cffd8bc3f70|r:|cffffffffDubwubz|r-|cff32e983Ill|r:2|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-57-0D935F36:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						294, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [124]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Deradis-Mal'Ganis:5041:ACHIEVEMENT|h|cffd8bc3f70|r:|cff3fc7ebDeradis|r:3|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-3684-0E10D0B0:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						295, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [125]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Diresteaks-Thrall:5042:ACHIEVEMENT|h|cffd8bc3f70|r:|cffc69b6dDiresteaks|r-|cff1dfd54Thr|r:2|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-3678-0D78BCC4:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						296, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [126]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Flickers-Area52:5043:ACHIEVEMENT|h|cffd8bc3f70|r:|cff8788eeFlickers|r-|cff64968eAre|r:4|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-3676-0CC993AF:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						297, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [127]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:32:24]|h|r |cffd8d8d8[|r|Hplayer:Allaeda-Mal'Ganis:5044:ACHIEVEMENT|h|cffd8bc3f70|r:|cffa330c9Allaeda|r:4|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:18163:Player-3684-08CEF40C:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Discarded Works]|h|r |cffffffff(|rCompleted 9/27/23|cffffffff)|r!",
					["serverTime"] = 1695853906,
					["r"] = 1,
					["extraData"] = {
						47, -- [1]
						false, -- [2]
						80, -- [3]
						82, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 66224.55500000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [128]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
	},
}
