
Scrap_CharSets = {
	["auto"] = {
	},
	["list"] = {
	},
}
