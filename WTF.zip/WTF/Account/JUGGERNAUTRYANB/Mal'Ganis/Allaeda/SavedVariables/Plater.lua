
PlaterDBChr = {
	["spellRangeCheckRangeFriendly"] = {
		[577] = 30,
		[581] = 30,
	},
	["buffsBanned"] = {
	},
	["first_run3"] = {
		["Player-3684-08CEF40C"] = true,
	},
	["spellRangeCheckRangeEnemy"] = {
		[577] = 30,
		[581] = 30,
	},
	["resources_on_target"] = false,
	["debuffsBanned"] = {
	},
	["minimap"] = {
	},
}
