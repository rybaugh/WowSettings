
Prat3CharDB = {
	["history"] = {
		["cmdhistory"] = {
			["ChatFrame10EditBox"] = {
			},
			["ChatFrame7EditBox"] = {
			},
			["ChatFrame5EditBox"] = {
			},
			["ChatFrame8EditBox"] = {
			},
			["ChatFrame4EditBox"] = {
			},
			["ChatFrame6EditBox"] = {
			},
			["ChatFrame3EditBox"] = {
			},
			["ChatFrame1EditBox"] = {
			},
			["ChatFrame2EditBox"] = {
			},
			["ChatFrame9EditBox"] = {
			},
		},
	},
}
Prat3HighCPUPerCharDB = {
	["scrollback"] = {
		["ChatFrame5"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 4,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[09:42:52]|h|r Quest accepted: The Clarion Call",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 46299.841,
					["serverTime"] = 1695735731,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [1]
				{
					["message"] = "0 |4day:days;, 1 |4hour:hours;, 20 |4minute:minutes;, 27 |4second:seconds;",
					["timestamp"] = 46299.841,
				}, -- [2]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 46299.841,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:19]|h|r |cffff80ff|Htransmogappearance:180852|h[Watcher's Clasp of Purpose]|h|r has been added to your appearance collection.",
					["serverTime"] = 1695740618,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						11, -- [3]
						12, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46360.228,
					["g"] = 1,
					["b"] = 0,
				}, -- [4]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame10"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame3"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 4,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["serverTime"] = 1695740558,
					["r"] = 1,
					["b"] = 0,
					["timestamp"] = 46299.841,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [1]
				{
					["message"] = "0 |4day:days;, 0 |4hour:hours;, 0 |4minute:minutes;, 0 |4second:seconds;",
					["timestamp"] = 46299.841,
				}, -- [2]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 46299.841,
				}, -- [3]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 46288.80800000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [4]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame7"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame6"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame8"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame4"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame9"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame1"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 18,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[09:42:52]|h|r Quest accepted: The Clarion Call",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 46299.841,
					["serverTime"] = 1695735731,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:42:53]|h|r You receive item: |cffffffff|Hitem:206942::::::::70:105:::::::::|h[Sealed Kaldorei Scroll]|h|r",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 46299.841,
					["serverTime"] = 1695735732,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						3, -- [3]
						4, -- [4]
						["n"] = 4,
					},
				}, -- [2]
				{
					["message"] = "0 |4day:days;, 1 |4hour:hours;, 20 |4minute:minutes;, 26 |4second:seconds;",
					["timestamp"] = 46299.841,
				}, -- [3]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 46299.841,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:03:19]|h|r |cff33ff99Decursive|r: Decursive 2.7.10 by John Wellesz",
					["timestamp"] = 46299.841,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:03:19]|h|r |cff33ff99Decursive|r: |cff4c7fff |cff4c7fff Decursive is now initialized, remember to check the options (/decursive) |r",
					["timestamp"] = 46299.841,
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:03:23]|h|r WA Custom Extension: |cFF00FF00Check |cFF00FFFFCustom Options|r for personalization|r",
					["timestamp"] = 46299.841,
					["serverTime"] = 1695740562,
				}, -- [7]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:03:39]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Ðuskywind-Kel'Thuzad:133:CHANNEL:1|h|cff00ff98Ðuskywind|r-|cff33d7feKel|r|h|cffd8d8d8]|r: is it bugd again?",
					["serverTime"] = 1695740578,
					["r"] = 1,
					["extraData"] = {
						69, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46320.378,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:03:48]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Valdrakken]|h",
					["serverTime"] = 1695740587,
					["r"] = 1,
					["extraData"] = {
						69, -- [1]
						false, -- [2]
						1, -- [3]
						4, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46329.386,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:03:48]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Valdrakken]|h",
					["serverTime"] = 1695740587,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46329.386,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:03:53]|h|r Brigita says: Welcome to the Roasted Ram! Seating is open.",
					["serverTime"] = 1695740592,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						9, -- [3]
						10, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46334.276,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:19]|h|r |cffff80ff|Htransmogappearance:180852|h[Watcher's Clasp of Purpose]|h|r has been added to your appearance collection.",
					["serverTime"] = 1695740618,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						11, -- [3]
						12, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46360.228,
					["g"] = 1,
					["b"] = 0,
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:19]|h|r You receive item: |cffa335ee|Hitem:180653::::::::70:105::::3:17:438:18:2:19:9:::::|h[Mythic Keystone]|h|r",
					["serverTime"] = 1695740618,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						13, -- [3]
						14, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46360.228,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:19]|h|r You receive item: |cffa335ee|Hitem:193744::::::::70:105::35:8:9321:6652:9414:9223:9219:9144:1637:8767::::::|h[Watcher's Clasp of Purpose]|h|r",
					["serverTime"] = 1695740618,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						13, -- [3]
						14, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46360.228,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:20]|h|r |Hchannel:channel:1|h[1] |h Left Channel: |Hchannel:CHANNEL:1|h[1. General - Valdrakken]|h",
					["serverTime"] = 1695740619,
					["r"] = 1,
					["extraData"] = {
						69, -- [1]
						false, -- [2]
						1, -- [3]
						4, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46361.792,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:20]|h|r |Hchannel:channel:2|h[2] |h Left Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h",
					["serverTime"] = 1695740619,
					["r"] = 0.9098039865493774,
					["extraData"] = {
						70, -- [1]
						false, -- [2]
						15, -- [3]
						16, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46361.792,
					["g"] = 0.6196078658103943,
					["b"] = 0.4745098352432251,
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:20]|h|r |Hchannel:channel:3|h[3] |h Left Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Valdrakken]|h",
					["serverTime"] = 1695740619,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46361.792,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [17]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:20]|h|r |Hchannel:channel:6|h[6] |h Left Channel: |Hchannel:CHANNEL:6|h[6. Trade (Services) - City]|h",
					["serverTime"] = 1695740619,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						18, -- [3]
						19, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46361.792,
					["g"] = 0.7490196228027344,
					["b"] = 0.7490196228027344,
				}, -- [18]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
	},
}
