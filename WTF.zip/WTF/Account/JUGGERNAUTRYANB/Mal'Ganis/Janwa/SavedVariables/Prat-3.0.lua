
Prat3CharDB = {
	["history"] = {
		["cmdhistory"] = {
			["ChatFrame10EditBox"] = {
			},
			["ChatFrame7EditBox"] = {
			},
			["ChatFrame5EditBox"] = {
			},
			["ChatFrame8EditBox"] = {
			},
			["ChatFrame4EditBox"] = {
			},
			["ChatFrame6EditBox"] = {
			},
			["ChatFrame9EditBox"] = {
			},
			["ChatFrame1EditBox"] = {
			},
			["ChatFrame2EditBox"] = {
			},
			["ChatFrame3EditBox"] = {
			},
		},
	},
}
Prat3HighCPUPerCharDB = {
	["scrollback"] = {
		["ChatFrame4"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 4,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[10:56:07]|h|r [S] |cffd8d8d8[|r|Hplayer:Corven-Mal'Ganis:10:SAY|h|cffff7c0aCorven|r|h|cffd8d8d8]|r: we huting for 450 loot my brudas?!?",
					["serverTime"] = 1695740127,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						3, -- [3]
						4, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 45868.605,
					["g"] = 1,
					["b"] = 1,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:56:08]|h|r [S] |cffd8d8d8[|r|Hplayer:Infernalism-Mal'Ganis:11:SAY|h|cff8788eeInfernalism|r|h|cffd8d8d8]|r: supposedly 2 now for US",
					["serverTime"] = 1695740128,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 45869.696,
					["g"] = 1,
					["b"] = 1,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:56:11]|h|r [S] |cffd8d8d8[|r|Hplayer:Lightnipz-Mal'Ganis:12:SAY|h|cfff48cbaLightnipz|r|h|cffd8d8d8]|r: this has been the longest 10 minute wait of my life",
					["serverTime"] = 1695740131,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						3, -- [3]
						6, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 45872.012,
					["g"] = 1,
					["b"] = 1,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:56:18]|h|r [S] |cffd8d8d8[|r|Hplayer:Greatganja-Mal'Ganis:14:SAY|h|cffa330c9Greatganja|r|h|cffd8d8d8]|r: we hunting for rabbits",
					["serverTime"] = 1695740138,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						3, -- [3]
						10, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 45879.228,
					["g"] = 1,
					["b"] = 1,
				}, -- [4]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame3"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 1,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 45820.222,
					["g"] = 1,
					["b"] = 0,
				}, -- [1]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame1"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 17,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[10:55:36]|h|r |cff33ff99Decursive|r: Decursive 2.7.10 by John Wellesz",
					["timestamp"] = 45836.937,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:55:36]|h|r |cff33ff99Decursive|r: |cff4c7fff |cff4c7fff Decursive is now initialized, remember to check the options (/decursive) |r",
					["timestamp"] = 45836.937,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:55:40]|h|r Loot Specialization set to: Survival",
					["serverTime"] = 1695740100,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 45836.937,
					["g"] = 1,
					["b"] = 0,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:55:40]|h|r WA Custom Extension: |cFF00FF00Check |cFF00FFFFCustom Options|r for personalization|r",
					["timestamp"] = 45836.937,
					["serverTime"] = 1695740100,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:55:42]|h|r Brigita says: Welcome to the Roasted Ram! Seating is open.",
					["serverTime"] = 1695740102,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 45843.742,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:56:02]|h|r Teller says: The siege on Dragonbane Keep is about to begin!",
					["serverTime"] = 1695740122,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 45863.163,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:56:03]|h|r Captain Drine says: I doubt the Primalists come to bank vaults to discuss their plans, but we may still overhear something useful. Act like you are inspecting one of the holding chests.",
					["serverTime"] = 1695740123,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 45864.52,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [7]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:56:03]|h|r Trading Post Barker says: Hey friend! Come check out our new items in the Trading Post. We just got a new shipment!",
					["serverTime"] = 1695740123,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 45864.86,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:56:07]|h|r [S] |cffd8d8d8[|r|Hplayer:Corven-Mal'Ganis:10:SAY|h|cffff7c0aCorven|r|h|cffd8d8d8]|r: we huting for 450 loot my brudas?!?",
					["serverTime"] = 1695740127,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						3, -- [3]
						4, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 45868.605,
					["g"] = 1,
					["b"] = 1,
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:56:08]|h|r [S] |cffd8d8d8[|r|Hplayer:Infernalism-Mal'Ganis:11:SAY|h|cff8788eeInfernalism|r|h|cffd8d8d8]|r: supposedly 2 now for US",
					["serverTime"] = 1695740128,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 45869.696,
					["g"] = 1,
					["b"] = 1,
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:56:11]|h|r [S] |cffd8d8d8[|r|Hplayer:Lightnipz-Mal'Ganis:12:SAY|h|cfff48cbaLightnipz|r|h|cffd8d8d8]|r: this has been the longest 10 minute wait of my life",
					["serverTime"] = 1695740131,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						3, -- [3]
						6, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 45872.012,
					["g"] = 1,
					["b"] = 1,
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:56:15]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Bellaroni-Mal'Ganis:13:CHANNEL:5|h|cff3fc7ebBellaroni|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00Moisty|r|cffffffff>|r WTS 9/9 Mythic |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r Unsaved Run from TOP US Guild -Best Prices- |cffffffff<|r|cff00ff00Gold Only|r|cffffffff>|r Run Start Tonight /w for Prices",
					["serverTime"] = 1695740135,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						7, -- [3]
						8, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 45876.755,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:56:18]|h|r [S] |cffd8d8d8[|r|Hplayer:Greatganja-Mal'Ganis:14:SAY|h|cffa330c9Greatganja|r|h|cffd8d8d8]|r: we hunting for rabbits",
					["serverTime"] = 1695740138,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						3, -- [3]
						10, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 45879.228,
					["g"] = 1,
					["b"] = 1,
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:56:25]|h|r |Hchannel:channel:1|h[1] |h Left Channel: |Hchannel:CHANNEL:1|h[1. General - Valdrakken]|h",
					["serverTime"] = 1695740145,
					["r"] = 1,
					["extraData"] = {
						69, -- [1]
						false, -- [2]
						11, -- [3]
						12, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 45886.746,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:56:25]|h|r |Hchannel:channel:2|h[2] |h Left Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h",
					["serverTime"] = 1695740145,
					["r"] = 0.9098039865493774,
					["extraData"] = {
						70, -- [1]
						false, -- [2]
						14, -- [3]
						15, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 45886.746,
					["g"] = 0.6196078658103943,
					["b"] = 0.4745098352432251,
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:56:25]|h|r |Hchannel:channel:3|h[3] |h Left Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Valdrakken]|h",
					["serverTime"] = 1695740145,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						false, -- [2]
						17, -- [3]
						18, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 45886.746,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:56:25]|h|r |Hchannel:channel:5|h[5] |h Left Channel: |Hchannel:CHANNEL:5|h[5. Trade (Services) - City]|h",
					["serverTime"] = 1695740145,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						7, -- [3]
						20, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 45886.746,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [17]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
	},
}
