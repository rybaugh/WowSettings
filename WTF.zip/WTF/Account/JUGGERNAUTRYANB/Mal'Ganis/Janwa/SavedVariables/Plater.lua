
PlaterDBChr = {
	["spellRangeCheckRangeFriendly"] = {
		[255] = 40,
		[254] = 40,
		[253] = 40,
	},
	["buffsBanned"] = {
	},
	["first_run3"] = {
		["Player-3684-09B45415"] = true,
	},
	["resources_on_target"] = false,
	["minimap"] = {
	},
	["debuffsBanned"] = {
	},
	["spellRangeCheckRangeEnemy"] = {
		[255] = 40,
		[254] = 40,
		[253] = 40,
	},
}
