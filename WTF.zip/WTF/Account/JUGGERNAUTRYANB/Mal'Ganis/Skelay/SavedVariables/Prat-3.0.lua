
Prat3CharDB = {
	["history"] = {
		["cmdhistory"] = {
			["ChatFrame10EditBox"] = {
			},
			["ChatFrame7EditBox"] = {
			},
			["ChatFrame5EditBox"] = {
			},
			["ChatFrame8EditBox"] = {
			},
			["ChatFrame4EditBox"] = {
			},
			["ChatFrame6EditBox"] = {
			},
			["ChatFrame1EditBox"] = {
			},
			["ChatFrame3EditBox"] = {
			},
			["ChatFrame2EditBox"] = {
			},
			["ChatFrame9EditBox"] = {
			},
		},
	},
}
Prat3HighCPUPerCharDB = {
	["scrollback"] = {
		["ChatFrame5"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame10"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame3"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 9,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["r"] = 1,
					["b"] = 0,
					["serverTime"] = 1695758764,
					["timestamp"] = 56958.363,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [1]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695827272,
					["r"] = 1,
				}, -- [2]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["b"] = 0,
					["r"] = 1,
					["serverTime"] = 1695827519,
					["timestamp"] = 56958.363,
					["g"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:12:14]|h|r You have been disconnected from Blizzard services.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["serverTime"] = 1695827496,
				}, -- [4]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["g"] = 1,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831086,
					["b"] = 0,
				}, -- [5]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["serverTime"] = 1695844641,
					["r"] = 1,
					["b"] = 0,
					["timestamp"] = 56958.363,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [6]
				{
					["message"] = "0 |4day:days;, 0 |4hour:hours;, 0 |4minute:minutes;, 0 |4second:seconds;",
					["timestamp"] = 56958.363,
				}, -- [7]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 56958.363,
				}, -- [8]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 56935.372,
					["g"] = 1,
					["b"] = 0,
				}, -- [9]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame7"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame6"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame8"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame4"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 4,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:07]|h|r Total time played: 49 |4day:days;, 0 |4hour:hours;, 59 |4minute:minutes;, 16 |4second:seconds;",
					["serverTime"] = 1695844649,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 56966.77,
					["g"] = 1,
					["b"] = 0,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:07]|h|r Time played this level: 0 |4day:days;, 22 |4hour:hours;, 50 |4minute:minutes;, 9 |4second:seconds;",
					["serverTime"] = 1695844649,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 56966.77,
					["g"] = 1,
					["b"] = 0,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:22]|h|r You repaired your armor for 160|TInterface\\MoneyFrame\\UI-GoldIcon:0:0:2:0|t 48|TInterface\\MoneyFrame\\UI-SilverIcon:0:0:2:0|t 26|TInterface\\MoneyFrame\\UI-CopperIcon:0:0:2:0|t",
					["serverTime"] = 1695844664,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						false, -- [2]
						16, -- [3]
						16, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56982.576,
					["g"] = 1,
					["b"] = 0,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:20]|h|r |cffd8d8d8[|r|Hplayer:Nabrocan-Mal'Ganis:2146:GUILD|h|cffd8bc3f70|r:|cffff7c0aNabrocan|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:5287:Player-3684-0D09E02A:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Rotten to the Core]|h|r |cffffffff(|rCompleted 2/23/11|cffffffff)|r!",
					["serverTime"] = 1695844722,
					["r"] = 0.250980406999588,
					["extraData"] = {
						48, -- [1]
						false, -- [2]
						52, -- [3]
						53, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57040.025,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:26:48]|h|r You are now Away: AFK",
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["b"] = 0,
					["serverTime"] = 1695828370,
					["timestamp"] = 56958.363,
					["g"] = 1,
					["r"] = 1,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:47:31]|h|r You have been inactive for some time and will be logged out of the game. If you wish to remain logged in, hit the cancel button.",
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["b"] = 0,
					["serverTime"] = 1695829613,
					["timestamp"] = 56958.363,
					["g"] = 1,
					["r"] = 1,
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[08:47:51]|h|r You have been inactive for some time and will be logged out of the game. If you wish to remain logged in, hit the cancel button.",
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["b"] = 0,
					["serverTime"] = 1695829633,
					["timestamp"] = 56958.363,
					["g"] = 1,
					["r"] = 1,
				}, -- [7]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:12:11]|h|r Total time played: 49 |4day:days;, 0 |4hour:hours;, 23 |4minute:minutes;, 34 |4second:seconds;",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831093,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:12:11]|h|r Time played this level: 0 |4day:days;, 22 |4hour:hours;, 14 |4minute:minutes;, 27 |4second:seconds;",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831093,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:12:43]|h|r This is now a cross-faction instance group. You can do these activities together: dungeons and raids (non-queued), Torghast, Rated PvP",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831125,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:12:43]|h|r Dungeon Difficulty set to Mythic.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831125,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:13:01]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Kravenus-Mal'Ganis:364:PARTY|h|cffff7c0aKravenus|r|h|cffd8d8d8]|r: She wants Dallas, because she's coming from Seattle and likes big cities.",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831143,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						4, -- [4]
						["n"] = 4,
					},
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:13:09]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:365:PARTY|h|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: In Java, the weather here is cold",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831151,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:13:19]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Kravenus-Mal'Ganis:366:PARTY|h|cffff7c0aKravenus|r|h|cffd8d8d8]|r: Bio rq.",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831161,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						4, -- [4]
						["n"] = 4,
					},
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:13:21]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Mersan-Arthas:367:PARTY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: dallas is new money/tech.  houston is old money/oil",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831163,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						6, -- [4]
						["n"] = 4,
					},
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:14:38]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Mersan-Arthas:368:PARTY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: i was in indonesia a couple of years ago working.  great place.  but yeah, it rains alot!",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831240,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						6, -- [4]
						["n"] = 4,
					},
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:14:58]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:369:PARTY|h|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: where?",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831260,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [17]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:15:24]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Mersan-Arthas:370:PARTY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: forgot the island's name.  the major city near my work was timika.",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831286,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						6, -- [4]
						["n"] = 4,
					},
				}, -- [18]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:15:32]|h|r |WImshorty-Illidan (Alliance)|w joins the party.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831294,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [19]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:15:44]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Mersan-Arthas:372:PARTY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: the island was the northern half of papua new guinea",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831306,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						6, -- [4]
						["n"] = 4,
					},
				}, -- [20]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:16:00]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:373:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: that's eastern Indonesia",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831322,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [21]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:16:04]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:376:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: yeah",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831326,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [22]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:16:19]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Mersan-Arthas:377:PARTY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: you guys only have about 70000000 islands",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831341,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						6, -- [4]
						["n"] = 4,
					},
				}, -- [23]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:16:28]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:378:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: yeah",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831350,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [24]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:16:39]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:379:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: lot a island",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831361,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [25]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:16:52]|h|r |cffa5a5a5Velystine|r-Illidan has initiated a ready check.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831374,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [26]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:17:07]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Mersan-Arthas:381:PARTY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: i had no idea how big indonesia is.  it is quite huge geographically",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831389,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						6, -- [4]
						["n"] = 4,
					},
				}, -- [27]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:17:13]|h|r You receive item: |cffffffff|Hitem:5512::::::::70:251::23:::::::|h[Healthstone]|h|r",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831395,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						7, -- [3]
						8, -- [4]
						["n"] = 4,
					},
				}, -- [28]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:17:31]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Mersan-Arthas:383:PARTY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: lots of languages.  nice people",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831413,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						6, -- [4]
						["n"] = 4,
					},
				}, -- [29]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:18:05]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:384:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: in indonesia lots of island,languages and cultures",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831447,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [30]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:18:08]|h|r |cffa5a5a5Velystine|r-Illidan has initiated a ready check.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831450,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [31]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:18:12]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Mersan-Arthas:386:PARTY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: never got to visit bali.  everyone told me to go to bali for vacation, then all the covid crap started",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831454,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						6, -- [4]
						["n"] = 4,
					},
				}, -- [32]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:18:26]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Mersan-Arthas:387:PARTY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: that shut down travel pretty hard",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831468,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						6, -- [4]
						["n"] = 4,
					},
				}, -- [33]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:18:27]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:388:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: bali is great island bro",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831469,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [34]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:18:34]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:389:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: druid?",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831476,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [35]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:19:25]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:390:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: Many Europeans visit Bali",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831527,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [36]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:19:27]|h|r |cffa5a5a5Velystine|r-Illidan has initiated a ready check.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831529,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [37]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:19:41]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:392:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: druid is not ready bro\\",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831543,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [38]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:19:53]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Mersan-Arthas:393:PARTY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: there is another vacation spot north of bali that i was told to visit.  not as busy as bali",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831555,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						6, -- [4]
						["n"] = 4,
					},
				}, -- [39]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:20:15]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Imshorty-Illidan:394:PARTY|h|cffd8bc3f70|r:|cff0070ddImshorty|r-|cff32e983Ill|r|h|cffd8d8d8]|r: druid disappeared :||",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831577,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						9, -- [4]
						["n"] = 4,
					},
				}, -- [40]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:20:20]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:395:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: xD",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831582,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [41]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:20:23]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:396:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: wait",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831585,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [42]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:20:29]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Imshorty-Illidan:397:PARTY|h|cffd8bc3f70|r:|cff0070ddImshorty|r-|cff32e983Ill|r|h|cffd8d8d8]|r: he went to bali",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831591,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						9, -- [4]
						["n"] = 4,
					},
				}, -- [43]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:20:31]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Imshorty-Illidan:398:PARTY|h|cffd8bc3f70|r:|cff0070ddImshorty|r-|cff32e983Ill|r|h|cffd8d8d8]|r: without us",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831593,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						9, -- [4]
						["n"] = 4,
					},
				}, -- [44]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:20:33]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Imshorty-Illidan:399:PARTY|h|cffd8bc3f70|r:|cff0070ddImshorty|r-|cff32e983Ill|r|h|cffd8d8d8]|r: mf",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831595,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						9, -- [4]
						["n"] = 4,
					},
				}, -- [45]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:20:33]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Mersan-Arthas:400:PARTY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: give him a minute.  brb bio.",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831595,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						6, -- [4]
						["n"] = 4,
					},
				}, -- [46]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:20:38]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Mersan-Arthas:401:PARTY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: i would have gone with him",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831600,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						6, -- [4]
						["n"] = 4,
					},
				}, -- [47]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:20:53]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:402:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: come visit java",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831615,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [48]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:20:57]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:403:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: java is the best",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831619,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [49]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:21:04]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:404:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: bali is to hot for me",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831626,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [50]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:21:39]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:405:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: Because Bali is an archipelago, there are lots of beaches",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831661,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [51]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:22:04]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Mersan-Arthas:406:PARTY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: if you are near the ocean it is hot as hell.  go into the mountains it is cold and you need a jacket.",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831686,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						6, -- [4]
						["n"] = 4,
					},
				}, -- [52]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:22:09]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:407:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: Unlike Java, Java still has lots of natural places",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831691,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [53]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:22:28]|h|r |cffa5a5a5Velystine|r-Illidan has initiated a ready check.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831710,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [54]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:22:55]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Mersan-Arthas:409:PARTY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: i liked the food except for the hotass peppers.  you guys eat some crazy peppers",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831737,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						6, -- [4]
						["n"] = 4,
					},
				}, -- [55]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:23:02]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:410:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: druids flee from battle xD",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831744,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [56]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:23:12]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:411:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: xD",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831754,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [57]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:23:47]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:412:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: indonesian is call sambal",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831789,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [58]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:23:59]|h|r |cffa5a5a5Velystine|r-Illidan has initiated a ready check.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831801,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [59]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:24:03]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Mersan-Arthas:414:PARTY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: is that the name of a pepper or food dish?",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831805,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						6, -- [4]
						["n"] = 4,
					},
				}, -- [60]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:24:20]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:415:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: pepper",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831822,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [61]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:25:48]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:416:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: lag",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831910,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [62]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:25:56]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:417:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: delay",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831918,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [63]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:25:57]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:418:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: fck",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695831919,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [64]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:27:58]|h|r [S] |cffd8d8d8[|r|Hplayer:Mersan-Arthas:420:SAY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: Blazing Charge on |cffa5a5a5Mersan|r",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832040,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
				}, -- [65]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:28:18]|h|r [S] |cffd8d8d8[|r|Hplayer:Kravenus-Mal'Ganis:421:SAY|h|cffd8bc3f70|r:|cffff7c0aKravenus|r|h|cffd8d8d8]|r: Lava Spray on |cffff7c0aKravenus|r",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832060,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						12, -- [3]
						14, -- [4]
						["n"] = 4,
					},
				}, -- [66]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:28:22]|h|r [S] |cffd8d8d8[|r|Hplayer:Imshorty-Illidan:422:SAY|h|cffd8bc3f70|r:|cff0070ddImshorty|r-|cff32e983Ill|r|h|cffd8d8d8]|r: Imshorty中了熾烈衝鋒",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832064,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						12, -- [3]
						15, -- [4]
						["n"] = 4,
					},
				}, -- [67]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:29:10]|h|r |cffd8d8d8[|r|Hplayer:Corßan:423|h|cffd8bc3f70|r:|cff33937fCorßan|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832112,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [68]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:32:33]|h|r |cffa5a5a5Velystine|r has died.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832315,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [69]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:32:39]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:435:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: sorry my bad",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832321,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [70]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:33:18]|h|r [S] |cffd8d8d8[|r|Hplayer:Imshorty-Illidan:440:SAY|h|cffd8bc3f70|r:|cff0070ddImshorty|r-|cff32e983Ill|r|h|cffd8d8d8]|r: Imshorty中了接地長矛",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832360,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						12, -- [3]
						15, -- [4]
						["n"] = 4,
					},
				}, -- [71]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:35:43]|h|r |cff33937fCorßan|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832505,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [72]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:35:59]|h|r |cffd8d8d8[|r|Hplayer:Okz:445|h|cffd8bc3f70|r:|cffc41e3aOkz|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832521,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [73]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:37:23]|h|r |cffc41e3aOkz|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832605,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [74]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:37:40]|h|r |cffd8d8d8[|r|Hplayer:Corßan:447|h|cffd8bc3f70|r:|cff33937fCorßan|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832622,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [75]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:39:33]|h|r |cffa5a5a5Imshorty|r has died.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832735,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [76]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:39:36]|h|r [S] |cffd8d8d8[|r|Hplayer:Kravenus-Mal'Ganis:453:SAY|h|cffd8bc3f70|r:|cffff7c0aKravenus|r|h|cffd8d8d8]|r: Heated Swings on |cffff7c0aKravenus|r",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832738,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						12, -- [3]
						14, -- [4]
						["n"] = 4,
					},
				}, -- [77]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:39:37]|h|r |cff33937fCorßan|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832739,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [78]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:39:38]|h|r [S] |cffd8d8d8[|r|Hplayer:Kravenus-Mal'Ganis:455:SAY|h|cffd8bc3f70|r:|cffff7c0aKravenus|r|h|cffd8d8d8]|r: 3",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832740,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						12, -- [3]
						14, -- [4]
						["n"] = 4,
					},
				}, -- [79]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:39:40]|h|r [S] |cffd8d8d8[|r|Hplayer:Kravenus-Mal'Ganis:456:SAY|h|cffd8bc3f70|r:|cffff7c0aKravenus|r|h|cffd8d8d8]|r: 1",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832742,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						12, -- [3]
						14, -- [4]
						["n"] = 4,
					},
				}, -- [80]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:39:50]|h|r |cffd8d8d8[|r|Hplayer:Boxfan:458|h|cffd8bc3f70|r:|cffc69b6dBoxfan|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832752,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [81]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:39:57]|h|r [S] |cffd8d8d8[|r|Hplayer:Mersan-Arthas:460:SAY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: Blazing Aegis on |cffa5a5a5Mersan|r",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832759,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
				}, -- [82]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:39:58]|h|r [S] |cffd8d8d8[|r|Hplayer:Mersan-Arthas:461:SAY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: 3",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832760,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
				}, -- [83]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:39:59]|h|r [S] |cffd8d8d8[|r|Hplayer:Mersan-Arthas:462:SAY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: 2",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832761,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
				}, -- [84]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:40:00]|h|r [S] |cffd8d8d8[|r|Hplayer:Mersan-Arthas:463:SAY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: 1",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832762,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
				}, -- [85]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:40:06]|h|r [S] |cffd8d8d8[|r|Hplayer:Kravenus-Mal'Ganis:465:SAY|h|cffd8bc3f70|r:|cffff7c0aKravenus|r|h|cffd8d8d8]|r: Heated Swings on |cffff7c0aKravenus|r",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832768,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						12, -- [3]
						14, -- [4]
						["n"] = 4,
					},
				}, -- [86]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:40:08]|h|r [S] |cffd8d8d8[|r|Hplayer:Kravenus-Mal'Ganis:466:SAY|h|cffd8bc3f70|r:|cffff7c0aKravenus|r|h|cffd8d8d8]|r: 3",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832770,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						12, -- [3]
						14, -- [4]
						["n"] = 4,
					},
				}, -- [87]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:40:10]|h|r [S] |cffd8d8d8[|r|Hplayer:Kravenus-Mal'Ganis:467:SAY|h|cffd8bc3f70|r:|cffff7c0aKravenus|r|h|cffd8d8d8]|r: 1",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832772,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						12, -- [3]
						14, -- [4]
						["n"] = 4,
					},
				}, -- [88]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:40:28]|h|r [S] |cffd8d8d8[|r|Hplayer:Mersan-Arthas:470:SAY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: Blazing Aegis on |cffa5a5a5Mersan|r",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832790,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
				}, -- [89]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:40:28]|h|r [S] |cffd8d8d8[|r|Hplayer:Imshorty-Illidan:471:SAY|h|cffd8bc3f70|r:|cff0070ddImshorty|r-|cff32e983Ill|r|h|cffd8d8d8]|r: Imshorty中了熾炎護盾",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832790,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						12, -- [3]
						15, -- [4]
						["n"] = 4,
					},
				}, -- [90]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:40:28]|h|r [S] |cffd8d8d8[|r|Hplayer:Mersan-Arthas:472:SAY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: 3",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832790,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
				}, -- [91]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:40:33]|h|r |cffa5a5a5Velystine|r has died.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832795,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [92]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:40:37]|h|r [S] |cffd8d8d8[|r|Hplayer:Kravenus-Mal'Ganis:476:SAY|h|cffd8bc3f70|r:|cffff7c0aKravenus|r|h|cffd8d8d8]|r: Heated Swings on |cffff7c0aKravenus|r",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832799,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						12, -- [3]
						14, -- [4]
						["n"] = 4,
					},
				}, -- [93]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:40:39]|h|r [S] |cffd8d8d8[|r|Hplayer:Kravenus-Mal'Ganis:477:SAY|h|cffd8bc3f70|r:|cffff7c0aKravenus|r|h|cffd8d8d8]|r: 3",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832801,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						12, -- [3]
						14, -- [4]
						["n"] = 4,
					},
				}, -- [94]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:40:41]|h|r [S] |cffd8d8d8[|r|Hplayer:Kravenus-Mal'Ganis:478:SAY|h|cffd8bc3f70|r:|cffff7c0aKravenus|r|h|cffd8d8d8]|r: 1",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695832803,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						12, -- [3]
						14, -- [4]
						["n"] = 4,
					},
				}, -- [95]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:45:15]|h|r |cffc69b6dBoxfan|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833077,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [96]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:45:33]|h|r |cffd8d8d8[|r|Hplayer:Corßan:493|h|cffd8bc3f70|r:|cff33937fCorßan|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833095,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [97]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:06]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Kravenus-Mal'Ganis:499:PARTY|h|cffd8bc3f70|r:|cffff7c0aKravenus|r|h|cffd8d8d8]|r: Thank you for travelling with ElitismHelper.",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833128,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						4, -- [4]
						["n"] = 4,
					},
				}, -- [98]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:06]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Kravenus-Mal'Ganis:500:PARTY|h|cffd8bc3f70|r:|cffff7c0aKravenus|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00EH|r|cffffffff>|r Amount of avoidable damage:",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833128,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						4, -- [4]
						["n"] = 4,
					},
				}, -- [99]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:06]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Kravenus-Mal'Ganis:501:PARTY|h|cffd8bc3f70|r:|cffff7c0aKravenus|r|h|cffd8d8d8]|r: 1. |cffa5a5a5Mersan|r-Arthas 166.4k",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833128,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						4, -- [4]
						["n"] = 4,
					},
				}, -- [100]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:06]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Kravenus-Mal'Ganis:502:PARTY|h|cffd8bc3f70|r:|cffff7c0aKravenus|r|h|cffd8d8d8]|r: 2. |cffa5a5a5Imshorty|r-Illidan 971.0k",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833128,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						4, -- [4]
						["n"] = 4,
					},
				}, -- [101]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:06]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Kravenus-Mal'Ganis:503:PARTY|h|cffd8bc3f70|r:|cffff7c0aKravenus|r|h|cffd8d8d8]|r: 3. |cffff7c0aKravenus|r 1231.0k",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833128,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						4, -- [4]
						["n"] = 4,
					},
				}, -- [102]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:06]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Kravenus-Mal'Ganis:504:PARTY|h|cffd8bc3f70|r:|cffff7c0aKravenus|r|h|cffd8d8d8]|r: 4. |cff00ff00Skelay|r 1990.9k",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833128,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						4, -- [4]
						["n"] = 4,
					},
				}, -- [103]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:06]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Kravenus-Mal'Ganis:505:PARTY|h|cffd8bc3f70|r:|cffff7c0aKravenus|r|h|cffd8d8d8]|r: 5. |cffa5a5a5Velystine|r-Illidan 4816.5k",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833128,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						4, -- [4]
						["n"] = 4,
					},
				}, -- [104]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:06]|h|r You receive currency: |cff0070dd|Hcurrency:2245:0|h[Flightstones]|h|rx52",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833128,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						20, -- [3]
						21, -- [4]
						["n"] = 4,
					},
				}, -- [105]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:06]|h|r You receive currency: |cff0070dd|Hcurrency:2408:0|h[Bonus Flightstones]|h|rx25",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833128,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						20, -- [3]
						21, -- [4]
						["n"] = 4,
					},
				}, -- [106]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:06]|h|r You receive item: |cff0070dd|Hitem:204076::::::::70:251:::::::::|h[Drake's Shadowflame Crest Fragment]|h|rx12",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833128,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						7, -- [3]
						8, -- [4]
						["n"] = 4,
					},
				}, -- [107]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:08]|h|r You receive loot: |cffa335ee|Hitem:204717::::::::70:251:::::::::|h[Splintered Spark of Shadowflame]|h|r",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833130,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						7, -- [3]
						8, -- [4]
						["n"] = 4,
					},
				}, -- [108]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:09]|h|r You loot 53 Gold, 15 Silver, 68 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833131,
					["extraData"] = {
						29, -- [1]
						false, -- [2]
						22, -- [3]
						23, -- [4]
						["n"] = 4,
					},
				}, -- [109]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:11]|h|r |cffa5a5a5Velystine|r-Illidan receives loot: |cffa335ee|Hitem:193786::::::::70:251::33:5:9321:6652:9144:1637:8767:1:28:1279:::::|h[Mutated Magmammoth Scale]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833133,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						7, -- [3]
						24, -- [4]
						["n"] = 4,
					},
				}, -- [110]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:11]|h|r |cffa5a5a5Velystine|r-Illidan receives loot: |cffa335ee|Hitem:204717::::::::70:251:::::::::|h[Splintered Spark of Shadowflame]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833133,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						7, -- [3]
						24, -- [4]
						["n"] = 4,
					},
				}, -- [111]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:11]|h|r |Hplayer:Velystine-Illidan:513:EMOTE:|h|cffa330c9Velystine-Illidan|r|h has looted |cffa335ee|Hitem:193786::::::::70:577::33:5:9321:6652:9144:1637:8767:1:28:1279:::::|h[Mutated Magmammoth Scale]|h|r!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833133,
					["extraData"] = {
						11, -- [1]
						false, -- [2]
						25, -- [3]
						26, -- [4]
						["n"] = 4,
					},
				}, -- [112]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:11]|h|r |Hplayer:Velystine-Illidan:514:EMOTE:|h|cffa330c9Velystine-Illidan|r|h has looted |cffa335ee|Hitem:204717::::::::70:577:::::::::|h[Splintered Spark of Shadowflame]|h|r!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833133,
					["extraData"] = {
						11, -- [1]
						false, -- [2]
						25, -- [3]
						26, -- [4]
						["n"] = 4,
					},
				}, -- [113]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:12]|h|r |cffff7c0aKravenus|r receives loot: |cffa335ee|Hitem:193776::::::::70:251::16:7:9321:6652:9223:9221:9144:1637:8767:1:28:1279:::::|h[Dragonkiln Chestguard]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833134,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						7, -- [3]
						27, -- [4]
						["n"] = 4,
					},
				}, -- [114]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:16]|h|r |cffa5a5a5Imshorty|r-Illidan receives loot: |cffa335ee|Hitem:204717::::::::70:251:::::::::|h[Splintered Spark of Shadowflame]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833138,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						7, -- [3]
						28, -- [4]
						["n"] = 4,
					},
				}, -- [115]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:24]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:517:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: can i take gear druid?",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833146,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [116]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:43]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Mersan-Arthas:518:PARTY|h|cffd8bc3f70|r:|cff8788eeMersan|r-|cff9aab5eArt|r|h|cffd8d8d8]|r: thanks for invite.  gl with the rain",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833165,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						6, -- [4]
						["n"] = 4,
					},
				}, -- [117]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:43]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:519:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: thanks a lot",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833165,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [118]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:43]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Imshorty-Illidan:520:PARTY|h|cffd8bc3f70|r:|cff0070ddImshorty|r-|cff32e983Ill|r|h|cffd8d8d8]|r: gg",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833165,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						9, -- [4]
						["n"] = 4,
					},
				}, -- [119]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:43]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Kravenus-Mal'Ganis:521:PARTY|h|cffd8bc3f70|r:|cffff7c0aKravenus|r|h|cffd8d8d8]|r: GG",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833165,
					["extraData"] = {
						3, -- [1]
						false, -- [2]
						3, -- [3]
						4, -- [4]
						["n"] = 4,
					},
				}, -- [120]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:45]|h|r |cffa5a5a5Imshorty|r-Illidan leaves the party.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833167,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [121]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:51]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Velystine-Illidan:527:PARTY|h|cffd8bc3f70|r:|cffa330c9Velystine|r-|cff32e983Ill|r|h|cffd8d8d8]|r: gg thanks a lot druid,warlock",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833173,
					["extraData"] = {
						50, -- [1]
						false, -- [2]
						3, -- [3]
						5, -- [4]
						["n"] = 4,
					},
				}, -- [122]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:51]|h|r |cffa5a5a5Mersan|r-Arthas leaves the party.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833173,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [123]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:56]|h|r |cffff7c0aKravenus|r is now the group leader.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833178,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [124]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:56]|h|r |cffa5a5a5Velystine|r-Illidan leaves the party.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833178,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [125]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:15]|h|r You leave the group.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833197,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [126]
				{
					["message"] = "0 |4day:days;, 3 |4hour:hours;, 10 |4minute:minutes;, 44 |4second:seconds;",
					["timestamp"] = 56958.363,
				}, -- [127]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 56958.363,
				}, -- [128]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame9"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame1"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 83,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:04]|h|r |cffffd700Titan Panel|r|cff19ff19 7.01.03.100107|r|cffffd700|cffffd700 by the |cffff8c00Titan Panel Development Team|r|cff19ff19|r",
					["timestamp"] = 56958.363,
					["serverTime"] = 1695844646,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:04]|h|r |cffffd700Titan: |r|cFFFFFF00Warning: |r|cff19ff19 Feature : Opening Bag Disabled Until taint is fixed or work around found.|r",
					["timestamp"] = 56958.363,
					["serverTime"] = 1695844646,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:07]|h|r Total time played: 49 |4day:days;, 0 |4hour:hours;, 59 |4minute:minutes;, 16 |4second:seconds;",
					["serverTime"] = 1695844649,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 56966.77,
					["g"] = 1,
					["b"] = 0,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:07]|h|r Time played this level: 0 |4day:days;, 22 |4hour:hours;, 50 |4minute:minutes;, 9 |4second:seconds;",
					["serverTime"] = 1695844649,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 56966.77,
					["g"] = 1,
					["b"] = 0,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:07]|h|r |cffffff00Time played this class (Dragonflight): 0 days 2 hours 15 minutes (/details playedclass)",
					["timestamp"] = 56966.932,
					["serverTime"] = 1695844649,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:07]|h|r |cffffff00Time played this class (Dragonflight): 0 days 2 hours 15 minutes (/details playedclass)",
					["timestamp"] = 56966.932,
					["serverTime"] = 1695844649,
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:07]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Aksurip-Mal'Ganis:2003:CHANNEL:6|h|cffc41e3aAksurip|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  Heroic Full Run |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key MEGA DUNGEON armor Stack available All loot tradeable",
					["serverTime"] = 1695844649,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56967.384,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [7]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:09]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Yzexyponaly-Mal'Ganis:2006:CHANNEL:6|h|cffc69b6dYzexyponaly|r|h|cffd8d8d8]|r: [WТS] Powerleveling Services! 10-70 Selfplayed Leveling, Mage Tower, Dragon Glyphs, Flightstones & Shadowflame Crests hassle-free. EXPRESS boost: start in 1 hour. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["serverTime"] = 1695844651,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						4, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56969.696,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:13]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Annycatpaw-Mal'Ganis:2012:CHANNEL:6|h|cff00ff98Annycatpaw|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00WTS|r|cffffffff>|r LAST SPOT ~~HEROIC FULL RUN~~  |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r // Trade gold inside Raid",
					["serverTime"] = 1695844655,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						6, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56973.499,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:14]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Horakhty-Mal'Ganis:2014:CHANNEL:6|h|cffa330c9Horakhty|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS|cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280k|r|cffffffff>|r-|cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r,/w for more info and DISCOUNTS! pay inside raid.",
					["serverTime"] = 1695844656,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						8, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56974.475,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:16]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Edidiqurazy-Mal'Ganis:2017:CHANNEL:6|h|cffc69b6dEdidiqurazy|r|h|cffd8d8d8]|r: [WТS] Mythic +10–20 & Dawn of the Infinite Megadungeon Сarry tonight! Get 415-447 ilvl gear, Immortal run, Armor Stack & Achieves hassle-free. EXPRESS Start in 30 minutes. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["serverTime"] = 1695844658,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						10, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56976.187,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:20]|h|r |Hchannel:channel:6|h[6] |h<Busy>|cffd8d8d8[|r|Hplayer:Murotorg-Mal'Ganis:2023:CHANNEL:6|h|cffc69b6dMurotorg|r|h|cffd8d8d8]|r: WTS >>>-20%|cffffffff<|r|cff00ff00<<OFF code: US20 Aberrus|cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|rNormal & Heroic 9/9 VIP runs with !!!MAX DROP!!!, Mythic +10-17-20 Keys for |r|cffffffff>|rMEGACHEAPPRICE< Full AFK1-70 !EXPRESSLVLing!Visit |cffffffff|Hurl:_____SkyCarry.gg|h[_____SkyCarry.gg]|h|r_____",
					["serverTime"] = 1695844662,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						12, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56980.569,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:21]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Prinsa-Mal'Ganis:2024:CHANNEL:6|h|cffc41e3aPrinsa|r|h|cffd8d8d8]|r: OFFERING |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280K|r|cffffffff>|r // |cffffffff<|r|cff00ff00NORMAL 100K|r|cffffffff>|r |cffffffff<|r|cff00ff00HC&NORM 340K|r|cffffffff>|r, ECHO |cffffffff<|r|cff00ff0060K|r|cffffffff>|r HC  Sarkareth |cffffffff<|r|cff00ff00110K|r|cffffffff>|r BOTH |cffffffff<|r|cff00ff00150K|r|cffffffff>|r// Payment Inside in the raid group for safety!! /w to book!",
					["serverTime"] = 1695844663,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						14, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56980.988,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:22]|h|r Repaired for 160 Gold, 48 Silver, 26 Copper.",
					["r"] = 1,
					["serverTime"] = 1695844664,
					["timestamp"] = 56982.576,
					["g"] = 0.85,
					["b"] = 0,
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:23]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Omawya-Mal'Ganis:2027:CHANNEL:6|h|cff00ff98Omawya|r|h|cffd8d8d8]|r: WTS MEGA DUNGEON |cffffffff<|r|cff00ff00<<  Mythic+ +10 to +24 Whatever Key lvl You Want \"Timed-Untimed\" Dawn of infinte \"Saved-Unsaved funnel\" Dm for Prices Discounts starts at Multiple x4 Best offers Come and get Your IO and Gear Fast For info and prices Dm |r|cffffffff>|r>>",
					["serverTime"] = 1695844665,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56982.733,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:23]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Omawya-Mal'Ganis:2028:CHANNEL:6|h|cff00ff98Omawya|r|h|cffd8d8d8]|r: WTS MEGA DUNGEON |cffffffff<|r|cff00ff00<<  Mythic+ +10 to +24 Whatever Key lvl You Want \"Timed-Untimed\" Dawn of infinte \"Saved-Unsaved funnel\" Dm for Prices Discounts starts at Multiple x4 Best offers Come and get Your IO and Gear Fast For info and prices Dm |r|cffffffff>|r>>",
					["serverTime"] = 1695844665,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56982.733,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:24]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Lumiimisy-Mal'Ganis:2031:CHANNEL:6|h|cffff7c0aLumiimisy|r|h|cffd8d8d8]|r: WTS M+ 11-20 / Time Guaranteed / Discount for multiple runs / KSM  / Armor Stack / You can stay afk if you want // MEGA DUNGEON HARD MOD // >> GOLD ONLY <<!!",
					["serverTime"] = 1695844666,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						19, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56983.974,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [17]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:24]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Gylfaginning-Mal'Ganis:2032:CHANNEL:6|h|cffff7c0aGylfaginning|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS [Aberrus, the Shadowed Crucible]   Heroic |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20 (Armor Stack, Specific Key for free, Discount Multiple Keys) ANY Key MEGA DUNGEON Armor Stack available All loot tradeable GOLD ONLY",
					["serverTime"] = 1695844666,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						21, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56983.974,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [18]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:24]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Aksurip-Mal'Ganis:2033:CHANNEL:6|h|cffc41e3aAksurip|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  Heroic Full Run |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key MEGA DUNGEON armor Stack available All loot tradeable",
					["serverTime"] = 1695844666,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56984.389,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [19]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:25]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Elizakay-Mal'Ganis:2036:CHANNEL:6|h|cffaad372Elizakay|r|h|cffd8d8d8]|r: WTS M+ 11-20 / Discount for multiple runs / KSM  / Armor Stack / You can stay afk if you want / MEGA DUNGEON HARD MOD // >> GOLD ONLY <<!!",
					["serverTime"] = 1695844667,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						23, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56985.615,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [20]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:27]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Yzexyponaly-Mal'Ganis:2038:CHANNEL:6|h|cffc69b6dYzexyponaly|r|h|cffd8d8d8]|r: [WТS] Aberrus Heroic & Mythic Carry! Get 428–450 ilvl upgradable gear & AotC achieve. EXPRESS boost: runs start every hour. Saved, Unsaved & VIP Lootruns available. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["serverTime"] = 1695844669,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						4, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56986.828,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [21]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:27]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Pelmewekk-Mal'Ganis:2040:CHANNEL:6|h|cffc41e3aPelmewekk|r|h|cffd8d8d8]|r: WTS Last slot for FULL  Heroic |cff66bbff|Hjournal:0:1208:15|h[Aberrus, the Shadowed Crucible]|h|r || AoTC guarantee || Gold trade in Raid || All free loot roll || /w for info",
					["serverTime"] = 1695844669,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						25, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56987.079,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [22]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:28]|h|r |Hchannel:channel:6|h[6] |h<Busy>|cffd8d8d8[|r|Hplayer:Cogalvanya-Mal'Ganis:2042:CHANNEL:6|h|cffc69b6dCogalvanya|r|h|cffd8d8d8]|r: >>>SELL CHEAPEST|cffffffff<|r|cff00ff00<< We have a [Price Match]and !!!-20%!!! from any competitor ABERRUS|cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r]9/9 [HEROIC VIP LOOT] |r|cffffffff>|r>>MAX DROP<<<, EXPRESS Last BOSS, raids every 1 HOUR, Whisper me for!!!",
					["serverTime"] = 1695844670,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						27, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56988.048,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [23]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:28]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Kashisoo-Mal'Ganis:2043:CHANNEL:6|h|cffc41e3aKashisoo|r|h|cffd8d8d8]|r: WTS POWER LEVEL FAST AND CHEAP|||| FULL AFK CAN SUMMON 10-70,10-60,60-70 PST FOR INFO|| GOLD ONLY",
					["serverTime"] = 1695844670,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						29, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56988.265,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [24]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:29]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Kashisoo-Mal'Ganis:2045:CHANNEL:6|h|cffc41e3aKashisoo|r|h|cffd8d8d8]|r: WTS POWER LEVEL FAST AND CHEAP|||| FULL AFK CAN SUMMON 10-70,10-60,60-70 PST FOR INFO|| GOLD ONLY",
					["serverTime"] = 1695844671,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						29, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56988.852,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [25]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:29]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Blanchiness-Mal'Ganis:2046:CHANNEL:6|h|cffc41e3aBlanchiness|r|h|cffd8d8d8]|r: [ZakRaider™] WTS FULL HEROIC |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  or ONLY Last Boss |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r || AotC || Trade gold in Raid || Free group loot",
					["serverTime"] = 1695844671,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						31, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56989.115,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [26]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:30]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Naysun-Mal'Ganis:2049:CHANNEL:6|h|cffc41e3aNaysun|r|h|cffd8d8d8]|r: >>WTS<< [+10]-[+24] - SpecificKeys - Portals (20 timed) - KSM/KSH - NewMega Dungeon - Get your weekly vault max level (447) - Special offers for multiples runs (x4/x8) - Free 2 Armor Stack for 4 or more Runs - DM For check prices <3",
					["serverTime"] = 1695844672,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						33, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56990.356,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [27]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:32]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Hoovies-Mal'Ganis:2052:CHANNEL:6|h|cffff7c0aHoovies|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r >WTS |cffffff00|Hachievement:18160:Player-3684-0E3848E2:0:0:0:-1:0:0:0:0|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff(|rCompleted 9/21/23|cffffffff)|r 9/9 HEROIC |cffffffff<|r|cff00ff00280k|r|cffffffff>|r & Heroic |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r - Trade INSIDE raid for safety, also offering **UNSAVED** runs /w now for more info!",
					["serverTime"] = 1695844674,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						35, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56992.472,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [28]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:33]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Edidiqurazy-Mal'Ganis:2054:CHANNEL:6|h|cffc69b6dEdidiqurazy|r|h|cffd8d8d8]|r: [WТS] Arena 3v3 & Solo Shuffle Carry! Get up to 2400 Arena Rating, 450 ilvl gear, Elite PvP Tmog, Gladiator & Legend titles hassle-free. EXPRESS boost: start tonight. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["serverTime"] = 1695844675,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						10, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56993.337,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [29]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:34]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Horakhty-Mal'Ganis:2056:CHANNEL:6|h|cffa330c9Horakhty|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS|cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280k|r|cffffffff>|r-|cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r,/w for more info and DISCOUNTS! pay inside raid.",
					["serverTime"] = 1695844676,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						8, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56994.16600000001,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [30]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:37]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Nemna-Mal'Ganis:2060:CHANNEL:6|h|cffc69b6dNemna|r|h|cffd8d8d8]|r: --WTS--  Mythic +16 +20 +22 +24 +25 Anylvl  //  Armor stack  //  Specific key  //  Items Tradeables And Specific  // THE BEST PRICES AND OFFERS // New Dungeon And Mythic Raid.- Full Run 9/9M /PvP bost Whisp Me For More info.",
					["serverTime"] = 1695844679,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56996.836,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [31]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:37]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Highalone-Mal'Ganis:2061:CHANNEL:6|h|cffffffffHighalone|r|h|cffd8d8d8]|r: WTS LAST SPOT of Heroic |cff66bbff|Hjournal:0:1208:15|h[Aberrus, the Shadowed Crucible]|h|r || FULL CLEAR 9/9 bosses || AoTC || Open Group Roll || Trade inside of the Raid ||   /w ME to GET IN!      [280k gold]",
					["serverTime"] = 1695844679,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 56997.061,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [32]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:40]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Prinsa-Mal'Ganis:2066:CHANNEL:6|h|cffc41e3aPrinsa|r|h|cffd8d8d8]|r: OFFERING |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280K|r|cffffffff>|r // |cffffffff<|r|cff00ff00NORMAL 100K|r|cffffffff>|r |cffffffff<|r|cff00ff00HC&NORM 340K|r|cffffffff>|r, ECHO |cffffffff<|r|cff00ff0060K|r|cffffffff>|r HC  Sarkareth |cffffffff<|r|cff00ff00110K|r|cffffffff>|r BOTH |cffffffff<|r|cff00ff00150K|r|cffffffff>|r// Payment Inside in the raid group for safety!! /w to book!",
					["serverTime"] = 1695844682,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						14, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57000.164,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [33]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:40]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Vraubankk-Mal'Ganis:2067:CHANNEL:6|h|cfffff468Vraubankk|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Bakers|r|cffffffff>|r are offering  |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280K|r|cffffffff>|r // Last Boss HC |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00110k|r|cffffffff>|r // Unsaved and Funnel // Payment Inside in the raid group for safety!! We price match everyone!!  /w to book!",
					["serverTime"] = 1695844682,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						41, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57000.431,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [34]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:40]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Annycatpaw-Mal'Ganis:2069:CHANNEL:6|h|cff00ff98Annycatpaw|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00WTS|r|cffffffff>|r LAST SPOT ~~HEROIC FULL RUN~~  |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r // Trade gold inside Raid",
					["serverTime"] = 1695844682,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						6, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57000.662,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [35]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:40]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Bellaroni-Mal'Ganis:2070:CHANNEL:6|h|cff3fc7ebBellaroni|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00Moisty|r|cffffffff>|r WTS 9/9 Mythic |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r Unsaved Run from TOP US Guild -Best Prices- |cffffffff<|r|cff00ff00Gold Only|r|cffffffff>|r Run Start Tonight /w for Prices",
					["serverTime"] = 1695844682,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						43, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57000.662,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [36]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:41]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Bellaroni-Mal'Ganis:2071:CHANNEL:6|h|cff3fc7ebBellaroni|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00Moisty|r|cffffffff>|r WTS 9/9 Mythic |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r Unsaved Run from TOP US Guild -Best Prices- |cffffffff<|r|cff00ff00Gold Only|r|cffffffff>|r Run Start Tonight /w for Prices",
					["serverTime"] = 1695844683,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						43, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57000.963,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [37]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:41]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Gylfaginning-Mal'Ganis:2072:CHANNEL:6|h|cffff7c0aGylfaginning|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS [Aberrus, the Shadowed Crucible]   Heroic |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20 (Armor Stack, Specific Key for free, Discount Multiple Keys) ANY Key MEGA DUNGEON Armor Stack available All loot tradeable GOLD ONLY",
					["serverTime"] = 1695844683,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						21, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57001.322,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [38]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:44]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Aksurip-Mal'Ganis:2076:CHANNEL:6|h|cffc41e3aAksurip|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  Heroic Full Run |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key MEGA DUNGEON armor Stack available All loot tradeable",
					["serverTime"] = 1695844686,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57003.85,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [39]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:44]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Yzexyponaly-Mal'Ganis:2078:CHANNEL:6|h|cffc69b6dYzexyponaly|r|h|cffd8d8d8]|r: [WТS] Mythic +10–20 & Dawn of the Infinite Megadungeon Сarry tonight! Get 415-447 ilvl gear, Immortal run, Armor Stack & Achieves hassle-free. EXPRESS Start in 30 minutes. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["serverTime"] = 1695844686,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						4, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57004.463,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [40]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:48]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Rockingex-Mal'Ganis:2084:CHANNEL:6|h|cffaad372Rockingex|r|h|cffd8d8d8]|r: ////______WTS______\\\\\\\\  Mythic Dungeon 10-23 ____ Timed / KSM / KSH ___Armor stack_____|cff66bbff|Hjournal:0:1209:8|h[Dawn of the Infinite]|h|r   ____Leveling 1-70 ///  GOLD ONLY _______<3",
					["serverTime"] = 1695844690,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						45, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57008.434,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [41]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:50]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Lumiimisy-Mal'Ganis:2087:CHANNEL:6|h|cffff7c0aLumiimisy|r|h|cffd8d8d8]|r: WTS M+ 11-20 / Time Guaranteed / Discount for multiple runs / KSM  / Armor Stack / You can stay afk if you want // MEGA DUNGEON HARD MOD // >> GOLD ONLY <<!!",
					["serverTime"] = 1695844692,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						19, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57010.044,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [42]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:51]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Edidiqurazy-Mal'Ganis:2089:CHANNEL:6|h|cffc69b6dEdidiqurazy|r|h|cffd8d8d8]|r: [WТS] Powerleveling Services! 10-70 Selfplayed Leveling, Mage Tower, Dragon Glyphs, Flightstones & Shadowflame Crests hassle-free. EXPRESS boost: start in 1 hour. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["serverTime"] = 1695844693,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						10, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57010.981,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [43]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:51]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Elizakay-Mal'Ganis:2091:CHANNEL:6|h|cffaad372Elizakay|r|h|cffd8d8d8]|r: WTS M+ 11-20 / Discount for multiple runs / KSM  / Armor Stack / You can stay afk if you want / MEGA DUNGEON HARD MOD // >> GOLD ONLY <<!!",
					["serverTime"] = 1695844693,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						23, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57011.593,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [44]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:53]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Pelmewekk-Mal'Ganis:2094:CHANNEL:6|h|cffc41e3aPelmewekk|r|h|cffd8d8d8]|r: WTS Last slot for FULL  Heroic |cff66bbff|Hjournal:0:1208:15|h[Aberrus, the Shadowed Crucible]|h|r || AoTC guarantee || Gold trade in Raid || All free loot roll || /w for info",
					["serverTime"] = 1695844695,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						25, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57013.142,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [45]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:53]|h|r |Hchannel:channel:6|h[6] |h<Busy>|cffd8d8d8[|r|Hplayer:Murotorg-Mal'Ganis:2095:CHANNEL:6|h|cffc69b6dMurotorg|r|h|cffd8d8d8]|r: WTS >>>-20%|cffffffff<|r|cff00ff00<<OFF code: US20 Aberrus|cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|rNormal & Heroic 9/9 VIP runs with !!!MAX DROP!!!, Mythic +10-17-20 Keys for |r|cffffffff>|rMEGACHEAPPRICE< Full AFK1-70 !EXPRESSLVLing!Visit |cffffffff|Hurl:_____SkyCarry.gg|h[_____SkyCarry.gg]|h|r_____",
					["serverTime"] = 1695844695,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						12, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57013.45200000001,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [46]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:54]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Horakhty-Mal'Ganis:2097:CHANNEL:6|h|cffa330c9Horakhty|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS|cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280k|r|cffffffff>|r-|cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r,/w for more info and DISCOUNTS! pay inside raid.",
					["serverTime"] = 1695844696,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						8, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57013.835,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [47]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:55]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Omawya-Mal'Ganis:2100:CHANNEL:6|h|cff00ff98Omawya|r|h|cffd8d8d8]|r: WTS MEGA DUNGEON |cffffffff<|r|cff00ff00<<  Mythic+ +10 to +24 Whatever Key lvl You Want \"Timed-Untimed\" Dawn of infinte \"Saved-Unsaved funnel\" Dm for Prices Discounts starts at Multiple x4 Best offers Come and get Your IO and Gear Fast For info and prices Dm |r|cffffffff>|r>>",
					["serverTime"] = 1695844697,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57015.593,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [48]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:56]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Omawya-Mal'Ganis:2101:CHANNEL:6|h|cff00ff98Omawya|r|h|cffd8d8d8]|r: WTS MEGA DUNGEON |cffffffff<|r|cff00ff00<<  Mythic+ +10 to +24 Whatever Key lvl You Want \"Timed-Untimed\" Dawn of infinte \"Saved-Unsaved funnel\" Dm for Prices Discounts starts at Multiple x4 Best offers Come and get Your IO and Gear Fast For info and prices Dm |r|cffffffff>|r>>",
					["serverTime"] = 1695844698,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57015.838,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [49]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:57]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Gylfaginning-Mal'Ganis:2103:CHANNEL:6|h|cffff7c0aGylfaginning|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS [Aberrus, the Shadowed Crucible]   Heroic |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20 (Armor Stack, Specific Key for free, Discount Multiple Keys) ANY Key MEGA DUNGEON Armor Stack available All loot tradeable GOLD ONLY",
					["serverTime"] = 1695844699,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						21, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57016.75500000001,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [50]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:57]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Vraubankk-Mal'Ganis:2105:CHANNEL:6|h|cfffff468Vraubankk|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Bakers|r|cffffffff>|r are offering  |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280K|r|cffffffff>|r // Last Boss HC |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00110k|r|cffffffff>|r // Unsaved and Funnel // Payment Inside in the raid group for safety!! We price match everyone!!  /w to book!",
					["serverTime"] = 1695844699,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						41, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57017.68,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [51]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:58]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Prinsa-Mal'Ganis:2107:CHANNEL:6|h|cffc41e3aPrinsa|r|h|cffd8d8d8]|r: OFFERING |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280K|r|cffffffff>|r // |cffffffff<|r|cff00ff00NORMAL 100K|r|cffffffff>|r |cffffffff<|r|cff00ff00HC&NORM 340K|r|cffffffff>|r, ECHO |cffffffff<|r|cff00ff0060K|r|cffffffff>|r HC  Sarkareth |cffffffff<|r|cff00ff00110K|r|cffffffff>|r BOTH |cffffffff<|r|cff00ff00150K|r|cffffffff>|r// Payment Inside in the raid group for safety!! /w to book!",
					["serverTime"] = 1695844700,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						14, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57018.617,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [52]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:59]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Aksurip-Mal'Ganis:2109:CHANNEL:6|h|cffc41e3aAksurip|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  Heroic Full Run |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key MEGA DUNGEON armor Stack available All loot tradeable",
					["serverTime"] = 1695844701,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57019.50500000001,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [53]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:00]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Hoovies-Mal'Ganis:2111:CHANNEL:6|h|cffff7c0aHoovies|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r >WTS |cffffff00|Hachievement:18160:Player-3684-0E3848E2:0:0:0:-1:0:0:0:0|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff(|rCompleted 9/21/23|cffffffff)|r 9/9 HEROIC |cffffffff<|r|cff00ff00280k|r|cffffffff>|r & Heroic |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r - Trade INSIDE raid for safety, also offering **UNSAVED** runs /w now for more info!",
					["serverTime"] = 1695844702,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						35, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57020.506,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [54]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:01]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Yzexyponaly-Mal'Ganis:2114:CHANNEL:6|h|cffc69b6dYzexyponaly|r|h|cffd8d8d8]|r: [WТS] Arena 3v3 & Solo Shuffle Carry! Get up to 2400 Arena Rating, 450 ilvl gear, Elite PvP Tmog, Gladiator & Legend titles hassle-free. EXPRESS boost: start tonight. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["serverTime"] = 1695844703,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						4, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57021.707,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [55]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:05]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Blanchiness-Mal'Ganis:2119:CHANNEL:6|h|cffc41e3aBlanchiness|r|h|cffd8d8d8]|r: [ZakRaider™] WTS FULL HEROIC |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  or ONLY Last Boss |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r || AotC || Trade gold in Raid || Free group loot",
					["serverTime"] = 1695844707,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						31, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57025.354,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [56]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:05]|h|r |Hchannel:channel:6|h[6] |h<Busy>|cffd8d8d8[|r|Hplayer:Cogalvanya-Mal'Ganis:2120:CHANNEL:6|h|cffc69b6dCogalvanya|r|h|cffd8d8d8]|r: >>>SELL CHEAPEST|cffffffff<|r|cff00ff00<< We have a [Price Match]and !!!-20%!!! from any competitor ABERRUS|cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r]9/9 [HEROIC VIP LOOT] |r|cffffffff>|r>>MAX DROP<<<, EXPRESS Last BOSS, raids every 1 HOUR, Whisper me for!!!",
					["serverTime"] = 1695844707,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						27, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57025.354,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [57]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:07]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Annycatpaw-Mal'Ganis:2124:CHANNEL:6|h|cff00ff98Annycatpaw|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00WTS|r|cffffffff>|r LAST SPOT ~~HEROIC FULL RUN~~  |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r // Trade gold inside Raid",
					["serverTime"] = 1695844709,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						6, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57027.705,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [58]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:08]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Gùshy-Mal'Ganis:2125:CHANNEL:2|h|cff8788eeGùshy|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00Comply|r|cffffffff>|r (9/9H) Tues Thurs 9-1130 est. Comply is in need of healers! Raids and M+ focused and pretty social. Friendly, drama free guild always looking for more. PST for info.",
					["serverTime"] = 1695844710,
					["r"] = 0.9098039865493774,
					["extraData"] = {
						70, -- [1]
						false, -- [2]
						47, -- [3]
						48, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57027.96900000001,
					["g"] = 0.6196078658103943,
					["b"] = 0.4745098352432251,
				}, -- [59]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:08]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Edidiqurazy-Mal'Ganis:2126:CHANNEL:6|h|cffc69b6dEdidiqurazy|r|h|cffd8d8d8]|r: [WТS] Aberrus Heroic & Mythic Carry! Get 428–450 ilvl upgradable gear & AotC achieve. EXPRESS boost: runs start every hour. Saved, Unsaved & VIP Lootruns available. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["serverTime"] = 1695844710,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						10, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57028.216,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [60]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:12]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Highalone-Mal'Ganis:2132:CHANNEL:6|h|cffffffffHighalone|r|h|cffd8d8d8]|r: WTS LAST SPOT of Heroic |cff66bbff|Hjournal:0:1208:15|h[Aberrus, the Shadowed Crucible]|h|r || FULL CLEAR 9/9 bosses || AoTC || Open Group Roll || Trade inside of the Raid ||   /w ME to GET IN!      [280k gold]",
					["serverTime"] = 1695844714,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57032.102,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [61]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:13]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Bapaladin-Mal'Ganis:2134:CHANNEL:2|h|cfff48cbaBapaladin|r|h|cffd8d8d8]|r: |cffffff00|Hachievement:16791:Player-3684-0E1E6AA2:1:8:12:23:4294967295:4294967295:4294967295:4294967295|h[Merchant Artisan]|h|r - |cffffd000|Htrade:Player-3684-0E1E6AA2:2108:165|h[Leatherworking]|h|r - |cffffd000|Htrade:Player-3684-0E1E6AA2:2018:164|h[Blacksmithing]|h|r - |cffffd000|Htrade:Player-3684-0E24B4D1:3908:197|h[Tailoring]|h|r - |cffffd000|Htrade:Player-3684-0E25175E:25229:755|h[Jewelcrafting]|h|r - |cffffd000|Htrade:Player-3684-0E28407F:45357:773|h[Inscription]|h|r - |cffffd000|Htrade:Player-3684-0E28407F:4036:202|h[Engineering]|h|r - |cffffd000|Htrade:Player-3684-0E24B4D1:7411:333|h[Enchanting]|h|r - All Gems - Weapon -Rings Hourglass- Torc [without Lariat] - Gear - Toxic slimy Acidic Venom  - All crest",
					["serverTime"] = 1695844715,
					["r"] = 0.9098039865493774,
					["extraData"] = {
						70, -- [1]
						false, -- [2]
						47, -- [3]
						50, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57032.981,
					["g"] = 0.6196078658103943,
					["b"] = 0.4745098352432251,
				}, -- [62]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:13]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Horakhty-Mal'Ganis:2136:CHANNEL:6|h|cffa330c9Horakhty|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS|cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280k|r|cffffffff>|r-|cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r,/w for more info and DISCOUNTS! pay inside raid.",
					["serverTime"] = 1695844715,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						8, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57033.567,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [63]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:14]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Nemna-Mal'Ganis:2137:CHANNEL:6|h|cffc69b6dNemna|r|h|cffd8d8d8]|r: --WTS--  Mythic +16 +20 +22 +24 +25 Anylvl  //  Armor stack  //  Specific key  //  Items Tradeables And Specific  // THE BEST PRICES AND OFFERS // New Dungeon And Mythic Raid.- Full Run 9/9M /PvP bost Whisp Me For More info.",
					["serverTime"] = 1695844716,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57033.862,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [64]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:15]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Vraubankk-Mal'Ganis:2139:CHANNEL:6|h|cfffff468Vraubankk|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Bakers|r|cffffffff>|r are offering  |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280K|r|cffffffff>|r // Last Boss HC |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00110k|r|cffffffff>|r // Unsaved and Funnel // Payment Inside in the raid group for safety!! We price match everyone!!  /w to book!",
					["serverTime"] = 1695844717,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						41, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57034.812,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [65]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:15]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Gylfaginning-Mal'Ganis:2141:CHANNEL:6|h|cffff7c0aGylfaginning|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS [Aberrus, the Shadowed Crucible]   Heroic |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20 (Armor Stack, Specific Key for free, Discount Multiple Keys) ANY Key MEGA DUNGEON Armor Stack available All loot tradeable GOLD ONLY",
					["serverTime"] = 1695844717,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						21, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57035.147,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [66]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:15]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Aksurip-Mal'Ganis:2142:CHANNEL:6|h|cffc41e3aAksurip|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  Heroic Full Run |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key MEGA DUNGEON armor Stack available All loot tradeable",
					["serverTime"] = 1695844717,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57035.147,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [67]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:20]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Kashisoo-Mal'Ganis:2144:CHANNEL:6|h|cffc41e3aKashisoo|r|h|cffd8d8d8]|r: WTS POWER LEVEL FAST AND CHEAP|||| FULL AFK CAN SUMMON 10-70,10-60,60-70 PST FOR INFO|| GOLD ONLY",
					["serverTime"] = 1695844722,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						29, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57039.754,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [68]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:20]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Prinsa-Mal'Ganis:2145:CHANNEL:6|h|cffc41e3aPrinsa|r|h|cffd8d8d8]|r: OFFERING |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280K|r|cffffffff>|r // |cffffffff<|r|cff00ff00NORMAL 100K|r|cffffffff>|r |cffffffff<|r|cff00ff00HC&NORM 340K|r|cffffffff>|r, ECHO |cffffffff<|r|cff00ff0060K|r|cffffffff>|r HC  Sarkareth |cffffffff<|r|cff00ff00110K|r|cffffffff>|r BOTH |cffffffff<|r|cff00ff00150K|r|cffffffff>|r// Payment Inside in the raid group for safety!! /w to book!",
					["serverTime"] = 1695844722,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						14, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57040.025,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [69]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:20]|h|r |cffd8d8d8[|r|Hplayer:Nabrocan-Mal'Ganis:2146:GUILD|h|cffd8bc3f70|r:|cffff7c0aNabrocan|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:5287:Player-3684-0D09E02A:1:9:27:23:4294967295:4294967295:4294967295:4294967295|h[Rotten to the Core]|h|r |cffffffff(|rCompleted 2/23/11|cffffffff)|r!",
					["serverTime"] = 1695844722,
					["r"] = 0.250980406999588,
					["extraData"] = {
						48, -- [1]
						false, -- [2]
						52, -- [3]
						53, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57040.025,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [70]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:20]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Kashisoo-Mal'Ganis:2147:CHANNEL:6|h|cffc41e3aKashisoo|r|h|cffd8d8d8]|r: WTS POWER LEVEL FAST AND CHEAP|||| FULL AFK CAN SUMMON 10-70,10-60,60-70 PST FOR INFO|| GOLD ONLY",
					["serverTime"] = 1695844722,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						29, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57040.353,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [71]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:20]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Yzexyponaly-Mal'Ganis:2148:CHANNEL:6|h|cffc69b6dYzexyponaly|r|h|cffd8d8d8]|r: [WТS] Powerleveling Services! 10-70 Selfplayed Leveling, Mage Tower, Dragon Glyphs, Flightstones & Shadowflame Crests hassle-free. EXPRESS boost: start in 1 hour. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["serverTime"] = 1695844722,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						4, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57040.571,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [72]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:26]|h|r |Hchannel:channel:6|h[6] |h<Busy>|cffd8d8d8[|r|Hplayer:Murotorg-Mal'Ganis:2149:CHANNEL:6|h|cffc69b6dMurotorg|r|h|cffd8d8d8]|r: WTS >>>-20%|cffffffff<|r|cff00ff00<<OFF code: US20 Aberrus|cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|rNormal & Heroic 9/9 VIP runs with !!!MAX DROP!!!, Mythic +10-17-20 Keys for |r|cffffffff>|rMEGACHEAPPRICE< Full AFK1-70 !EXPRESSLVLing!Visit |cffffffff|Hurl:_____SkyCarry.gg|h[_____SkyCarry.gg]|h|r_____",
					["serverTime"] = 1695844728,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						12, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57046.404,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [73]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:27]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Omawya-Mal'Ganis:2150:CHANNEL:6|h|cff00ff98Omawya|r|h|cffd8d8d8]|r: WTS MEGA DUNGEON |cffffffff<|r|cff00ff00<<  Mythic+ +10 to +24 Whatever Key lvl You Want \"Timed-Untimed\" Dawn of infinte \"Saved-Unsaved funnel\" Dm for Prices Discounts starts at Multiple x4 Best offers Come and get Your IO and Gear Fast For info and prices Dm |r|cffffffff>|r>>",
					["serverTime"] = 1695844729,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57046.86,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [74]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:27]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Edidiqurazy-Mal'Ganis:2151:CHANNEL:6|h|cffc69b6dEdidiqurazy|r|h|cffd8d8d8]|r: [WТS] Mythic +10–20 & Dawn of the Infinite Megadungeon Сarry tonight! Get 415-447 ilvl gear, Immortal run, Armor Stack & Achieves hassle-free. EXPRESS Start in 30 minutes. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["serverTime"] = 1695844729,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						10, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57046.86,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [75]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:27]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Omawya-Mal'Ganis:2152:CHANNEL:6|h|cff00ff98Omawya|r|h|cffd8d8d8]|r: WTS MEGA DUNGEON |cffffffff<|r|cff00ff00<<  Mythic+ +10 to +24 Whatever Key lvl You Want \"Timed-Untimed\" Dawn of infinte \"Saved-Unsaved funnel\" Dm for Prices Discounts starts at Multiple x4 Best offers Come and get Your IO and Gear Fast For info and prices Dm |r|cffffffff>|r>>",
					["serverTime"] = 1695844729,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57046.86,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [76]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:28]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Hoovies-Mal'Ganis:2153:CHANNEL:6|h|cffff7c0aHoovies|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r >WTS |cffffff00|Hachievement:18160:Player-3684-0E3848E2:0:0:0:-1:0:0:0:0|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff(|rCompleted 9/21/23|cffffffff)|r 9/9 HEROIC |cffffffff<|r|cff00ff00280k|r|cffffffff>|r & Heroic |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r - Trade INSIDE raid for safety, also offering **UNSAVED** runs /w now for more info!",
					["serverTime"] = 1695844730,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						35, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57048.549,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [77]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:29]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Rockingex-Mal'Ganis:2154:CHANNEL:6|h|cffaad372Rockingex|r|h|cffd8d8d8]|r: ////______WTS______\\\\\\\\  Mythic Dungeon 10-23 ____ Timed / KSM / KSH ___Armor stack_____|cff66bbff|Hjournal:0:1209:8|h[Dawn of the Infinite]|h|r   ____Leveling 1-70 ///  GOLD ONLY _______<3",
					["serverTime"] = 1695844731,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						45, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57049.071,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [78]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:30]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Lumiimisy-Mal'Ganis:2155:CHANNEL:6|h|cffff7c0aLumiimisy|r|h|cffd8d8d8]|r: WTS M+ 11-20 / Time Guaranteed / Discount for multiple runs / KSM  / Armor Stack / You can stay afk if you want // MEGA DUNGEON HARD MOD // >> GOLD ONLY <<!!",
					["serverTime"] = 1695844732,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						19, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57050.124,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [79]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:32]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Elizakay-Mal'Ganis:2156:CHANNEL:6|h|cffaad372Elizakay|r|h|cffd8d8d8]|r: WTS M+ 11-20 / Discount for multiple runs / KSM  / Armor Stack / You can stay afk if you want / MEGA DUNGEON HARD MOD // >> GOLD ONLY <<!!",
					["serverTime"] = 1695844734,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						23, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57051.879,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [80]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:32]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Vraubankk-Mal'Ganis:2157:CHANNEL:6|h|cfffff468Vraubankk|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Bakers|r|cffffffff>|r are offering  |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280K|r|cffffffff>|r // Last Boss HC |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00110k|r|cffffffff>|r // Unsaved and Funnel // Payment Inside in the raid group for safety!! We price match everyone!!  /w to book!",
					["serverTime"] = 1695844734,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						41, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57051.879,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [81]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:32]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Linkiie-Mal'Ganis:2158:CHANNEL:2|h|cff0070ddLinkiie|r|h|cffd8d8d8]|r: LF |cffa335ee|Hitem:193465::::::::70:264::13:1:3524:4:40:364:38:4:45:204697:48:204440:::::|h[Scale Rein Grips |A:Professions-ChatIcon-Quality-Tier1:17:15::1|a]|h|r 447 CRAFT",
					["serverTime"] = 1695844734,
					["r"] = 0.9098039865493774,
					["extraData"] = {
						70, -- [1]
						false, -- [2]
						47, -- [3]
						54, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57052.175,
					["g"] = 0.6196078658103943,
					["b"] = 0.4745098352432251,
				}, -- [82]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:32]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Horakhty-Mal'Ganis:2159:CHANNEL:6|h|cffa330c9Horakhty|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS|cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r HEROIC 9/9 |cffffffff<|r|cff00ff00280k|r|cffffffff>|r-|cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r,/w for more info and DISCOUNTS! pay inside raid.",
					["serverTime"] = 1695844734,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						1, -- [3]
						8, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 57052.654,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [83]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:51]|h|r |cffa5a5a5Mersan|r-Arthas leaves the party.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833173,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [84]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:52]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Elizakay-Mal'Ganis:529:CHANNEL:6|h|cffaad372Elizakay|r|h|cffd8d8d8]|r: WTS M+ 11-20 / Discount for multiple runs / KSM  / Armor Stack / You can stay afk if you want / MEGA DUNGEON HARD MOD // >> GOLD ONLY <<!!",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833174,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						34, -- [4]
						["n"] = 4,
					},
				}, -- [85]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:53]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Gylfaginning-Mal'Ganis:530:CHANNEL:6|h|cffff7c0aGylfaginning|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS [Aberrus, the Shadowed Crucible]   Heroic |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20 (Armor Stack, Specific Key for free, Discount Multiple Keys) ANY Key MEGA DUNGEON Armor Stack available All loot tradeable GOLD ONLY",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833175,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						36, -- [4]
						["n"] = 4,
					},
				}, -- [86]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:56]|h|r |cffff7c0aKravenus|r is now the group leader.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833178,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [87]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:56]|h|r |cffa5a5a5Velystine|r-Illidan leaves the party.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833178,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [88]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:57]|h|r |Hchannel:channel:6|h[6] |h<Away>|cffd8d8d8[|r|Hplayer:Tarap-Mal'Ganis:533:CHANNEL:6|h|cffaad372Tarap|r|h|cffd8d8d8]|r: .:WTS:. [AOTC] |cff66bbff|Hjournal:1:2520:15|h[Scalecommander Sarkareth]|h|rHEROIC >LAST BOSS ONLY|cffffffff<|r|cff00ff00   |r|cffffffff>|r>>GOING RIGHT NOW<<<  (TRADE GOLD IN RAID GROUP)",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833179,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						38, -- [4]
						["n"] = 4,
					},
				}, -- [89]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:57]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Hoovies-Mal'Ganis:534:CHANNEL:6|h|cffff7c0aHoovies|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r >WTS |cffffff00|Hachievement:18160:Player-3684-0E3848E2:0:0:0:-1:0:0:0:0|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff(|rCompleted 9/21/23|cffffffff)|r 9/9 HEROIC |cffffffff<|r|cff00ff00280k|r|cffffffff>|r & Heroic |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r - Trade INSIDE raid for safety, also offering **UNSAVED** runs /w now for more info!",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833179,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						40, -- [4]
						["n"] = 4,
					},
				}, -- [90]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:58]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Edidiqurazy-Mal'Ganis:535:CHANNEL:6|h|cffc69b6dEdidiqurazy|r|h|cffd8d8d8]|r: [WТS] Aberrus Heroic & Mythic Carry! Get 428–450 ilvl upgradable gear & AotC achieve. EXPRESS boost: runs start every hour. Saved, Unsaved & VIP Lootruns available. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833180,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						42, -- [4]
						["n"] = 4,
					},
				}, -- [91]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:46:59]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Aksurip-Mal'Ganis:536:CHANNEL:6|h|cffc41e3aAksurip|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  Heroic Full Run |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key MEGA DUNGEON armor Stack available All loot tradeable",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833181,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						30, -- [4]
						["n"] = 4,
					},
				}, -- [92]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:00]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Bellaroni-Mal'Ganis:537:CHANNEL:6|h|cff3fc7ebBellaroni|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00Moisty|r|cffffffff>|r WTS 9/9 Mythic |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r Unsaved Run from TOP US Guild -Best Prices- |cffffffff<|r|cff00ff00Gold Only|r|cffffffff>|r Run Start Tonight /w for Prices",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833182,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						44, -- [4]
						["n"] = 4,
					},
				}, -- [93]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:00]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Bellaroni-Mal'Ganis:538:CHANNEL:6|h|cff3fc7ebBellaroni|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00Moisty|r|cffffffff>|r WTS 9/9 Mythic |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r Unsaved Run from TOP US Guild -Best Prices- |cffffffff<|r|cff00ff00Gold Only|r|cffffffff>|r Run Start Tonight /w for Prices",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833182,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						44, -- [4]
						["n"] = 4,
					},
				}, -- [94]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:00]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Yzexyponaly-Mal'Ganis:539:CHANNEL:6|h|cffc69b6dYzexyponaly|r|h|cffd8d8d8]|r: [WТS] Mythic +10–20 & Dawn of the Infinite Megadungeon Сarry tonight! Get 415-447 ilvl gear, Immortal run, Armor Stack & Achieves hassle-free. EXPRESS Start in 30 minutes. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833182,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						46, -- [4]
						["n"] = 4,
					},
				}, -- [95]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:01]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Fraxin-Mal'Ganis:540:CHANNEL:6|h|cfff48cbaFraxin|r|h|cffd8d8d8]|r: —— WTS- (POWER.LEVELING) 1-70 - 60-70-(100%AFK)-(HORDE OR ALLIANCE)-(ANY SERVER)-SUPER CHEAP - Trusted - Full AFK - All Server - PST For GOOD PRICE GET UR ALT  [Level 70]  . NEGOTIABLE ———",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833183,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						48, -- [4]
						["n"] = 4,
					},
				}, -- [96]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:02]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Notoriousz-Mal'Ganis:541:CHANNEL:2|h|cffc69b6dNotoriousz|r|h|cffd8d8d8]|r: LFW |cffffd000|Htrade:Player-3684-0E263115:2018:164|h[Blacksmithing]|h|r  MAX ARMOR & WEPS Q5 43%  - MAX ALCH STONES / TOOLS  TOO ;D",
					["b"] = 0.4745098352432251,
					["r"] = 0.9098039865493774,
					["g"] = 0.6196078658103943,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833184,
					["extraData"] = {
						70, -- [1]
						false, -- [2]
						50, -- [3]
						51, -- [4]
						["n"] = 4,
					},
				}, -- [97]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:03]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Blanchiness-Mal'Ganis:542:CHANNEL:6|h|cffc41e3aBlanchiness|r|h|cffd8d8d8]|r: [ZakRaider™] WTS FULL HEROIC |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  or ONLY Last Boss |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r || AotC || Trade gold in Raid || Free group loot",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833185,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						53, -- [4]
						["n"] = 4,
					},
				}, -- [98]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:03]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Bufoo-Mal'Ganis:543:CHANNEL:6|h|cff3fc7ebBufoo|r|h|cffd8d8d8]|r: WTS LAST BOSS HEROIC |cff66bbff|Hjournal:1:2520:16|h[Scalecommander Sarkareth]|h|r  > AOTC <  RIGHT NOW Ready to go [ Trade gold in raid ] Summ ready !",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833185,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						55, -- [4]
						["n"] = 4,
					},
				}, -- [99]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:04]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Annycatpaw-Mal'Ganis:544:CHANNEL:6|h|cff00ff98Annycatpaw|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00WTS|r|cffffffff>|r ~~~FULL HEROIC RUN~~~ |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r // Last Boss only |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r // AOTC // Group loot // Trade Gold inside Raid",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833186,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						57, -- [4]
						["n"] = 4,
					},
				}, -- [100]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:05]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Lumiimisy-Mal'Ganis:545:CHANNEL:6|h|cffff7c0aLumiimisy|r|h|cffd8d8d8]|r: WTS M+ 11-20 / Time Guaranteed / Discount for multiple runs / KSM  / Armor Stack / You can stay afk if you want // MEGA DUNGEON HARD MOD // >> GOLD ONLY <<!!",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833187,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						32, -- [4]
						["n"] = 4,
					},
				}, -- [101]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:11]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Elizakay-Mal'Ganis:546:CHANNEL:6|h|cffaad372Elizakay|r|h|cffd8d8d8]|r: WTS M+ 11-20 / Discount for multiple runs / KSM  / Armor Stack / You can stay afk if you want / MEGA DUNGEON HARD MOD // >> GOLD ONLY <<!!",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833193,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						34, -- [4]
						["n"] = 4,
					},
				}, -- [102]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:11]|h|r Brigita says: Welcome to the Roasted Ram! Seating is open.",
					["b"] = 0.6235294342041016,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833193,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						59, -- [3]
						60, -- [4]
						["n"] = 4,
					},
				}, -- [103]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:12]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Gylfaginning-Mal'Ganis:548:CHANNEL:6|h|cffff7c0aGylfaginning|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS [Aberrus, the Shadowed Crucible]   Heroic |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20 (Armor Stack, Specific Key for free, Discount Multiple Keys) ANY Key MEGA DUNGEON Armor Stack available All loot tradeable GOLD ONLY",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833194,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						36, -- [4]
						["n"] = 4,
					},
				}, -- [104]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:14]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Aksurip-Mal'Ganis:549:CHANNEL:6|h|cffc41e3aAksurip|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  Heroic Full Run |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key MEGA DUNGEON armor Stack available All loot tradeable",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833196,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						30, -- [4]
						["n"] = 4,
					},
				}, -- [105]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:15]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Edidiqurazy-Mal'Ganis:550:CHANNEL:6|h|cffc69b6dEdidiqurazy|r|h|cffd8d8d8]|r: [WТS] Mythic +10–20 & Dawn of the Infinite Megadungeon Сarry tonight! Get 415-447 ilvl gear, Immortal run, Armor Stack & Achieves hassle-free. EXPRESS Start in 30 minutes. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833197,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						42, -- [4]
						["n"] = 4,
					},
				}, -- [106]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:15]|h|r |Hchannel:channel:6|h[6] |h<Away>|cffd8d8d8[|r|Hplayer:Tarap-Mal'Ganis:551:CHANNEL:6|h|cffaad372Tarap|r|h|cffd8d8d8]|r: .:WTS:. [AOTC] |cff66bbff|Hjournal:1:2520:15|h[Scalecommander Sarkareth]|h|rHEROIC >LAST BOSS ONLY|cffffffff<|r|cff00ff00   |r|cffffffff>|r>>GOING RIGHT NOW<<<  (TRADE GOLD IN RAID GROUP)",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833197,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						38, -- [4]
						["n"] = 4,
					},
				}, -- [107]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:15]|h|r You leave the group.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833197,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
				}, -- [108]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:18]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Yzexyponaly-Mal'Ganis:553:CHANNEL:6|h|cffc69b6dYzexyponaly|r|h|cffd8d8d8]|r: [WТS] Arena 3v3 & Solo Shuffle Carry! Get up to 2400 Arena Rating, 450 ilvl gear, Elite PvP Tmog, Gladiator & Legend titles hassle-free. EXPRESS boost: start tonight. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833200,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						46, -- [4]
						["n"] = 4,
					},
				}, -- [109]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:19]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Bufoo-Mal'Ganis:554:CHANNEL:6|h|cff3fc7ebBufoo|r|h|cffd8d8d8]|r: WTS LAST BOSS HEROIC |cff66bbff|Hjournal:1:2520:16|h[Scalecommander Sarkareth]|h|r  > AOTC <  RIGHT NOW Ready to go [ Trade gold in raid ] Summ ready !",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833201,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						55, -- [4]
						["n"] = 4,
					},
				}, -- [110]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:24]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Lumiimisy-Mal'Ganis:555:CHANNEL:6|h|cffff7c0aLumiimisy|r|h|cffd8d8d8]|r: WTS M+ 11-20 / Time Guaranteed / Discount for multiple runs / KSM  / Armor Stack / You can stay afk if you want // MEGA DUNGEON HARD MOD // >> GOLD ONLY <<!!",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833206,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						32, -- [4]
						["n"] = 4,
					},
				}, -- [111]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:26]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Hoovies-Mal'Ganis:556:CHANNEL:6|h|cffff7c0aHoovies|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r >WTS |cffffff00|Hachievement:18160:Player-3684-0E3848E2:0:0:0:-1:0:0:0:0|h[Aberrus, the Shadowed Crucible]|h|r |cffffffff(|rCompleted 9/21/23|cffffffff)|r 9/9 HEROIC |cffffffff<|r|cff00ff00280k|r|cffffffff>|r & Heroic |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r - Trade INSIDE raid for safety, also offering **UNSAVED** runs /w now for more info!",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833208,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						40, -- [4]
						["n"] = 4,
					},
				}, -- [112]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:30]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Elizakay-Mal'Ganis:557:CHANNEL:6|h|cffaad372Elizakay|r|h|cffd8d8d8]|r: WTS M+ 11-20 / Discount for multiple runs / KSM  / Armor Stack / You can stay afk if you want / MEGA DUNGEON HARD MOD // >> GOLD ONLY <<!!",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833212,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						34, -- [4]
						["n"] = 4,
					},
				}, -- [113]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:31]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Aksurip-Mal'Ganis:558:CHANNEL:6|h|cffc41e3aAksurip|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  Heroic Full Run |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key MEGA DUNGEON armor Stack available All loot tradeable",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833213,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						30, -- [4]
						["n"] = 4,
					},
				}, -- [114]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:31]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Gylfaginning-Mal'Ganis:559:CHANNEL:6|h|cffff7c0aGylfaginning|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS [Aberrus, the Shadowed Crucible]   Heroic |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20 (Armor Stack, Specific Key for free, Discount Multiple Keys) ANY Key MEGA DUNGEON Armor Stack available All loot tradeable GOLD ONLY",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833213,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						36, -- [4]
						["n"] = 4,
					},
				}, -- [115]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:33]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Blanchiness-Mal'Ganis:560:CHANNEL:6|h|cffc41e3aBlanchiness|r|h|cffd8d8d8]|r: [ZakRaider™] WTS FULL HEROIC |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  or ONLY Last Boss |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r || AotC || Trade gold in Raid || Free group loot",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833215,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						53, -- [4]
						["n"] = 4,
					},
				}, -- [116]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:33]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Wanalock-Mal'Ganis:561:CHANNEL:6|h|cff8788eeWanalock|r|h|cffd8d8d8]|r: WTS NEW MEGA DUNGEON / M+11 +22 |cffffff00|Hachievement:17845:Player-3684-0E126A48:1:5:26:23:4294967295:4294967295:4294967295:4294967295|h[Dragonflight Keystone Hero: Season Two]|h|r |cffffffff(|rCompleted 5/21/23|cffffffff)|r  / WORLD TOUR /POWER LEVELING 1-70 / BUNDLE FOR 4 AND 8 KEYS",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833215,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						61, -- [4]
						["n"] = 4,
					},
				}, -- [117]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:33]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Annycatpaw-Mal'Ganis:562:CHANNEL:6|h|cff00ff98Annycatpaw|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00WTS|r|cffffffff>|r ~~~FULL HEROIC RUN~~~ |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r // Last Boss only |cff66bbff|Hjournal:1:2520:14|h[Scalecommander Sarkareth]|h|r // AOTC // Group loot // Trade Gold inside Raid",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833215,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						57, -- [4]
						["n"] = 4,
					},
				}, -- [118]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:35]|h|r |Hchannel:channel:6|h[6] |h<Away>|cffd8d8d8[|r|Hplayer:Tarap-Mal'Ganis:563:CHANNEL:6|h|cffaad372Tarap|r|h|cffd8d8d8]|r: .:WTS:. [AOTC] |cff66bbff|Hjournal:1:2520:15|h[Scalecommander Sarkareth]|h|rHEROIC >LAST BOSS ONLY|cffffffff<|r|cff00ff00   |r|cffffffff>|r>>GOING RIGHT NOW<<<  (TRADE GOLD IN RAID GROUP)",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833217,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						38, -- [4]
						["n"] = 4,
					},
				}, -- [119]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:36]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Yzexyponaly-Mal'Ganis:564:CHANNEL:6|h|cffc69b6dYzexyponaly|r|h|cffd8d8d8]|r: [WТS] Powerleveling Services! 10-70 Selfplayed Leveling, Mage Tower, Dragon Glyphs, Flightstones & Shadowflame Crests hassle-free. EXPRESS boost: start in 1 hour. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833218,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						46, -- [4]
						["n"] = 4,
					},
				}, -- [120]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:37]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Fraxin-Mal'Ganis:565:CHANNEL:6|h|cfff48cbaFraxin|r|h|cffd8d8d8]|r: —— WTS- (POWER.LEVELING) 1-70 - 60-70-(100%AFK)-(HORDE OR ALLIANCE)-(ANY SERVER)-SUPER CHEAP - Trusted - Full AFK - All Server - PST For GOOD PRICE GET UR ALT  [Level 70]  . NEGOTIABLE ———",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833219,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						48, -- [4]
						["n"] = 4,
					},
				}, -- [121]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:38]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Edidiqurazy-Mal'Ganis:566:CHANNEL:6|h|cffc69b6dEdidiqurazy|r|h|cffd8d8d8]|r: [WТS] Arena 3v3 & Solo Shuffle Carry! Get up to 2400 Arena Rating, 450 ilvl gear, Elite PvP Tmog, Gladiator & Legend titles hassle-free. EXPRESS boost: start tonight. Over 24562 Trustpilot 5-star reviews. Visit |cffffffff|Hurl:WowVendor.net|h[WowVendor.net]|h|r to learn more.",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833220,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						42, -- [4]
						["n"] = 4,
					},
				}, -- [122]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:47:43]|h|r |Hchannel:channel:6|h[6] |h|cffd8d8d8[|r|Hplayer:Lumiimisy-Mal'Ganis:567:CHANNEL:6|h|cffff7c0aLumiimisy|r|h|cffd8d8d8]|r: WTS M+ 11-20 / Time Guaranteed / Discount for multiple runs / KSM  / Armor Stack / You can stay afk if you want // MEGA DUNGEON HARD MOD // >> GOLD ONLY <<!!",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 56958.363,
					["serverTime"] = 1695833225,
					["extraData"] = {
						74, -- [1]
						false, -- [2]
						29, -- [3]
						32, -- [4]
						["n"] = 4,
					},
				}, -- [123]
				{
					["message"] = "0 |4day:days;, 3 |4hour:hours;, 10 |4minute:minutes;, 16 |4second:seconds;",
					["timestamp"] = 56958.363,
				}, -- [124]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 56958.363,
				}, -- [125]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:59]|h|r |cff33ff99Decursive|r: Decursive 2.7.10 by John Wellesz",
					["timestamp"] = 56958.363,
				}, -- [126]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:59]|h|r |cff33ff99Decursive|r: |cff4c7fff |cff4c7fff Decursive is now initialized, remember to check the options (/decursive) |r",
					["timestamp"] = 56958.363,
				}, -- [127]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:04]|h|r Loot Specialization set to: Frost",
					["serverTime"] = 1695844646,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 56958.363,
					["g"] = 1,
					["b"] = 0,
				}, -- [128]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
	},
}
