
PlaterDBChr = {
	["spellRangeCheckRangeFriendly"] = {
		[252] = 30,
		[251] = 30,
		[250] = 30,
	},
	["buffsBanned"] = {
	},
	["first_run3"] = {
		["Player-3684-0706172C"] = true,
	},
	["minimap"] = {
		["minimapPos"] = 95.6713743849249,
	},
	["resources_on_target"] = false,
	["debuffsBanned"] = {
	},
	["spellRangeCheckRangeEnemy"] = {
		[252] = 30,
		[251] = 30,
		[250] = 30,
	},
}
