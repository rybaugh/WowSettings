
PlaterDBChr = {
	["spellRangeCheckRangeFriendly"] = {
		[64] = 40,
		[63] = 40,
		[62] = 40,
	},
	["buffsBanned"] = {
	},
	["first_run3"] = {
		["Player-3684-09A11AAB"] = true,
	},
	["resources_on_target"] = false,
	["minimap"] = {
	},
	["debuffsBanned"] = {
	},
	["spellRangeCheckRangeEnemy"] = {
		[64] = 40,
		[63] = 40,
		[62] = 40,
	},
}
