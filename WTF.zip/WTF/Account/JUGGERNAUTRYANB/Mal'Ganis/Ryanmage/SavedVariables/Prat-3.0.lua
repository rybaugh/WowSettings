
Prat3CharDB = {
	["history"] = {
		["cmdhistory"] = {
			["ChatFrame10EditBox"] = {
			},
			["ChatFrame7EditBox"] = {
			},
			["ChatFrame5EditBox"] = {
			},
			["ChatFrame8EditBox"] = {
			},
			["ChatFrame4EditBox"] = {
			},
			["ChatFrame6EditBox"] = {
			},
			["ChatFrame9EditBox"] = {
			},
			["ChatFrame1EditBox"] = {
			},
			["ChatFrame2EditBox"] = {
			},
			["ChatFrame3EditBox"] = {
			},
		},
	},
}
Prat3HighCPUPerCharDB = {
	["scrollback"] = {
		["ChatFrame5"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 3,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:47]|h|r |cffd8d8d8[|r|Hplayer:Brich:144|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1695740646,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46388.18,
					["g"] = 1,
					["b"] = 0,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:59]|h|r You receive item: |cffa335ee|Hitem:180653::::::::70:63::::5:17:404:18:17:19:9:20:124:21:6:::::|h[Mythic Keystone]|h|r",
					["serverTime"] = 1695740718,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						19, -- [3]
						20, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46460.793,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:59]|h|r You receive item: |cffa335ee|Hitem:205225::::::::70:63:::::::::|h[Aspects' Token of Merit]|h|rx2",
					["serverTime"] = 1695740718,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						19, -- [3]
						20, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46460.793,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [3]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame4"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 3,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:55]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Bapaladin-Mal'Ganis:162:CHANNEL:2|h|cfff48cbaBapaladin|r|h|cffd8d8d8]|r: |cffffff00|Hachievement:16791:Player-3684-0E1E6AA2:1:8:12:23:4294967295:4294967295:4294967295:4294967295|h[Merchant Artisan]|h|r - |cffffd000|Htrade:Player-3684-0E1E6AA2:2108:165|h[Leatherworking]|h|r - |cffffd000|Htrade:Player-3684-0E1E6AA2:2018:164|h[Blacksmithing]|h|r - |cffffd000|Htrade:Player-3684-0E24B4D1:3908:197|h[Tailoring]|h|r - |cffffd000|Htrade:Player-3684-0E25175E:25229:755|h[Jewelcrafting]|h|r - |cffffd000|Htrade:Player-3684-0E28407F:45357:773|h[Inscription]|h|r - |cffffd000|Htrade:Player-3684-0E28407F:4036:202|h[Engineering]|h|r - |cffffd000|Htrade:Player-3684-0E24B4D1:7411:333|h[Enchanting]|h|r - All Gems - Weapon -Rings Hourglass- Torc [without Lariat] - Gear - Toxic slimy Acidic Venom  - All crest",
					["serverTime"] = 1695740714,
					["r"] = 0.9098039865493774,
					["extraData"] = {
						70, -- [1]
						false, -- [2]
						16, -- [3]
						17, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46456.849,
					["g"] = 0.6196078658103943,
					["b"] = 0.4745098352432251,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:59]|h|r You receive item: |cffa335ee|Hitem:180653::::::::70:63::::5:17:404:18:17:19:9:20:124:21:6:::::|h[Mythic Keystone]|h|r",
					["serverTime"] = 1695740718,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						19, -- [3]
						20, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46460.793,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:59]|h|r You receive item: |cffa335ee|Hitem:205225::::::::70:63:::::::::|h[Aspects' Token of Merit]|h|rx2",
					["serverTime"] = 1695740718,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						19, -- [3]
						20, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46460.793,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [3]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame3"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 1,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 46365.617,
					["g"] = 1,
					["b"] = 0,
				}, -- [1]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame1"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 19,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:40]|h|r |cff33ff99Decursive|r: Decursive 2.7.10 by John Wellesz",
					["timestamp"] = 46380.864,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:40]|h|r |cff33ff99Decursive|r: |cff4c7fff |cff4c7fff Decursive is now initialized, remember to check the options (/decursive) |r",
					["timestamp"] = 46380.864,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:44]|h|r Loot Specialization set to: Fire",
					["serverTime"] = 1695740643,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 46380.864,
					["g"] = 1,
					["b"] = 0,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:44]|h|r WA Custom Extension: |cFF00FF00Check |cFF00FFFFCustom Options|r for personalization|r",
					["timestamp"] = 46380.864,
					["serverTime"] = 1695740643,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:47]|h|r |cffd8d8d8[|r|Hplayer:Brich:144|h|cffd8bc3f70|r:|cffc69b6dBrich|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1695740646,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46388.18,
					["g"] = 1,
					["b"] = 0,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:09]|h|r Loot Specialization set to: Fire",
					["serverTime"] = 1695740668,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 46409.775,
					["g"] = 1,
					["b"] = 0,
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:09]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Valdrakken]|h",
					["serverTime"] = 1695740668,
					["r"] = 0.7647059559822083,
					["extraData"] = {
						69, -- [1]
						false, -- [2]
						3, -- [3]
						4, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46409.775,
					["g"] = 0.9019608497619629,
					["b"] = 0.9098039865493774,
				}, -- [7]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:09]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Valdrakken]|h",
					["serverTime"] = 1695740668,
					["r"] = 0.9098039865493774,
					["extraData"] = {
						71, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46409.775,
					["g"] = 0.8941177129745483,
					["b"] = 0.4745098352432251,
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:10]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Tseridkowah-Mal'Ganis:147:CHANNEL:5|h|cffc41e3aTseridkowah|r|h|cffd8d8d8]|r: WTS |cff66bbff|Hjournal:0:1208:15|h[Aberrus, the Shadowed Crucible]|h|r Heroic mode  for only gold wisp me for more info 190k gold",
					["serverTime"] = 1695740669,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						9, -- [3]
						10, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46411.024,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:10]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Tseridkowah-Mal'Ganis:148:CHANNEL:5|h|cffc41e3aTseridkowah|r|h|cffd8d8d8]|r: WTS |cff66bbff|Hjournal:0:1208:15|h[Aberrus, the Shadowed Crucible]|h|r Heroic mode  for only gold wisp me for more info 190k gold",
					["serverTime"] = 1695740669,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						9, -- [3]
						10, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46411.024,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:12]|h|r Brigita says: Welcome to the Roasted Ram! Seating is open.",
					["serverTime"] = 1695740671,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46413.516,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:19]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Xndreita-Mal'Ganis:152:CHANNEL:5|h|cffc41e3aXndreita|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  Heroic Full Run |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key MEGA DUNGEON armor Stack available All loot tradeable",
					["serverTime"] = 1695740678,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						9, -- [3]
						14, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46420.747,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:35]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Xndreita-Mal'Ganis:153:CHANNEL:5|h|cffc41e3aXndreita|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  Heroic Full Run |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key MEGA DUNGEON armor Stack available All loot tradeable",
					["serverTime"] = 1695740694,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						9, -- [3]
						14, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46436.887,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:48]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Tseridkowah-Mal'Ganis:159:CHANNEL:5|h|cffc41e3aTseridkowah|r|h|cffd8d8d8]|r: WTS |cff66bbff|Hjournal:0:1208:15|h[Aberrus, the Shadowed Crucible]|h|r Heroic mode  for only gold wisp me for more info 190k gold",
					["serverTime"] = 1695740707,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						9, -- [3]
						10, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46449.37,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:48]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Tseridkowah-Mal'Ganis:160:CHANNEL:5|h|cffc41e3aTseridkowah|r|h|cffd8d8d8]|r: WTS |cff66bbff|Hjournal:0:1208:15|h[Aberrus, the Shadowed Crucible]|h|r Heroic mode  for only gold wisp me for more info 190k gold",
					["serverTime"] = 1695740707,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						9, -- [3]
						10, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46449.37,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:53]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:Xndreita-Mal'Ganis:161:CHANNEL:5|h|cffc41e3aXndreita|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00The Mercenaries Team|r|cffffffff>|r WTS |cff66bbff|Hjournal:0:1208:14|h[Aberrus, the Shadowed Crucible]|h|r  Heroic Full Run |cffffffff<|r|cff00ff00280k|r|cffffffff>|r AOTC |cffffffff<|r|cff00ff00100k|r|cffffffff>|r //  Mythics+ Keys +10 To +20  ANY Key MEGA DUNGEON armor Stack available All loot tradeable",
					["serverTime"] = 1695740712,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						false, -- [2]
						9, -- [3]
						14, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46454.312,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:59]|h|r You receive item: |cffa335ee|Hitem:180653::::::::70:63::::5:17:404:18:17:19:9:20:124:21:6:::::|h[Mythic Keystone]|h|r",
					["serverTime"] = 1695740718,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						19, -- [3]
						20, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46460.793,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [17]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:59]|h|r You receive item: |cffa335ee|Hitem:205225::::::::70:63:::::::::|h[Aspects' Token of Merit]|h|rx2",
					["serverTime"] = 1695740718,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						19, -- [3]
						20, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46460.793,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [18]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:06:03]|h|r |Hchannel:channel:1|h[1] |h Left Channel: |Hchannel:CHANNEL:1|h[1. General - Valdrakken]|h",
					["serverTime"] = 1695740722,
					["r"] = 0.7647059559822083,
					["extraData"] = {
						69, -- [1]
						false, -- [2]
						3, -- [3]
						4, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 46464.807,
					["g"] = 0.9019608497619629,
					["b"] = 0.9098039865493774,
				}, -- [19]
			},
			["maxElements"] = 128,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
	},
}
